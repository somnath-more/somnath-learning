import theme from './themes'
import './style.css'
import { ThemeProvider } from '@emotion/react'
import BusinessSearchPage from './pages/BusinessSetUpPage/Search'
import OwnerDetailsPage from './pages/BusinessSetUpPage/OwnerDetails'
import BusinessActivity from './pages/BusinessSetUpPage/BusinessActivity'
import { Route, Routes } from 'react-router-dom'
import TransferOptionPage from './pages/TransferOptionPage'
import LogInPage from './pages/LoginPage'
import Amount from './pages/PaymentPage/Amount'
import Recipient from './pages/PaymentPage/Recipient'
import Verification from './pages/PaymentPage/Verification'
import Review from './pages/PaymentPage/ReviewPage'
import PayPage from './pages/PaymentPage/PayPage'
import SignUpPage from './pages/SignUp'
import TransferStatusPage from './pages/TransferStatusPage'
import { useAuth0 } from '@auth0/auth0-react'
import Page404 from './pages/Page404'
import AccountTypePage from './pages/RegistrationPage/AccountType'
import CountryPage from './pages/RegistrationPage/CountryPage/Index'
import AuthenticationPage from './pages/RegistrationPage/Authentication'
import PasswordPage from './pages/RegistrationPage/Password/Index'
import { UserProvider } from './utils/hooks/contexts'
import EmptyDashboardPage from './pages/EmptyDashboardPage'

export const App = () => {
  const { isAuthenticated, isLoading } = useAuth0()

  if (isLoading) {
    return <h1>Loading...</h1>
  }
  return (
    <ThemeProvider theme={theme}>
      <UserProvider>
        <Routes>
          <Route
            path="/"
            element={isAuthenticated ? <TransferStatusPage /> : <SignUpPage />}
          />
          <Route path="/log-in" element={<LogInPage />} />
          <Route path="/account-type" element={<AccountTypePage />} />
          <Route path="/country" element={<CountryPage />} />
          <Route path="/authentication" element={<AuthenticationPage />} />
          <Route path="/password" element={<PasswordPage />} />
          <Route path="/business-details" element={<BusinessSearchPage />} />
          <Route path="/business-address" element={<BusinessSearchPage />} />
          <Route path="/business-activity" element={<BusinessActivity />} />
          <Route path="/account-owner" element={<OwnerDetailsPage />} />
          <Route path="/*" element={<Page404 />} />

          {isAuthenticated && (
            <>
              <Route path="/dashboard" element={<TransferStatusPage />} />
              <Route
                path="/transfer-options"
                element={<TransferOptionPage />}
              />
              <Route path="/amount" element={<Amount />} />
              <Route path="/recipient" element={<Recipient />} />
              <Route path="/verification" element={<Verification />} />
              <Route path="/review" element={<Review />} />
              <Route path="/pay" element={<PayPage />} />
            </>
          )}
        </Routes>
      </UserProvider>
    </ThemeProvider>
  )
}
