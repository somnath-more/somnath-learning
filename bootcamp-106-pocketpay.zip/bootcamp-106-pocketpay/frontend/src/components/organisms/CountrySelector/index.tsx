import { Grid, styled } from '@mui/material'
import { Constants, options } from 'utils/constants'
import MuiTypography from 'components/atoms/Typography'
import MuiDropdown, { OptionItem } from 'components/atoms/Dropdown'
import { useState } from 'react'
import theme from 'themes'
import { StyledContinueButton } from 'utils/styles'

export interface CountrySelectorProps {
  comboWidth?: string
  comboHeight?: string
  onClick?: () => void
}

const CountryContainer = styled(Grid)({
  display: 'flex',
  flexDirection: 'column',
  width: '516px',
  paddingBottom: '372px',
})
const StyledContainer = styled(Grid)({
  display: 'flex',
  flexDirection: 'row',
})

export const CountrySelector: React.FC<CountrySelectorProps> = ({
  comboWidth,
  comboHeight,
  onClick,
}) => {
  const getOptionImage = (option: OptionItem) => {
    return (
      <img
        src={option.imageUrl}
        alt={option.label}
        data-testid={`option-image-${option.label}`}
      />
    )
  }

  const [selectedCountry, setSelectedCountry] = useState<OptionItem | null>(
    null
  )

  const handleCountryChange = (option: OptionItem | null) => {
    setSelectedCountry(option)
  }

  const isButtonDisabled = !selectedCountry

  return (
    <StyledContainer container>
      <Grid item>
        <CountryContainer container>
          <Grid item>
            <MuiTypography
              variant="h1"
              sx={{ color: theme.palette.Text.highEmphasis }}
              data-testid="country-registration-heading"
            >
              {Constants.COUNTRY_REGISTRATION}
            </MuiTypography>
          </Grid>
          <Grid item marginTop="32px">
            <MuiDropdown
              width={comboWidth}
              height={comboHeight}
              label={Constants.SELECT_YOUR_COUNTRY}
              options={options}
              getOptionImage={getOptionImage}
              onChange={handleCountryChange}
              data-testid="country-combo-box"
            />
          </Grid>
        </CountryContainer>
      </Grid>
      <Grid item data-testid="continue-button-box">
        <StyledContinueButton
          onClick={onClick}
          variant="contained"
          sx={{ top: '455px' }}
          disabled={isButtonDisabled}
        >
          {Constants.CONTINUE}
        </StyledContinueButton>
      </Grid>
    </StyledContainer>
  )
}
