import React from 'react'
import { Meta, StoryFn } from '@storybook/react'
import { CountrySelector, CountrySelectorProps } from '.'

export default {
  title: 'Organisms/CountrySelector',
  component: CountrySelector,
  argTypes: {
    onClick: { action: 'clicked' },
  },
} as Meta

const Template: StoryFn<CountrySelectorProps> = (args) => (
  <CountrySelector {...args} />
)

export const Default = Template.bind({})
Default.args = {
  comboWidth: '516px',
}
