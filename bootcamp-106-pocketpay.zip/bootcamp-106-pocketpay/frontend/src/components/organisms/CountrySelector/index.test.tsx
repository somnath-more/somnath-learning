import React from 'react'
import '@testing-library/jest-dom'
import { fireEvent, render, screen } from '@testing-library/react'
import { CountrySelector } from '.'
import { Constants } from 'utils/constants'

describe('Country Selector', () => {
  test('it should render CountryRegistration component correctly', () => {
    render(<CountrySelector />)
    const headingElement = screen.getByTestId('country-registration-heading')
    expect(headingElement).toBeInTheDocument()
    expect(headingElement).toHaveTextContent(Constants.COUNTRY_REGISTRATION)
  })

  test('it should call onClick when the Continue button is clicked', () => {
    const onClickMock = jest.fn()
    render(<CountrySelector onClick={onClickMock} />)
    const countrySelect = screen.getByLabelText('Select your country')
    fireEvent.change(countrySelect, { target: { value: 'In' } })
    fireEvent.click(screen.getByText('India'))
    const continueButton = screen.getByText(Constants.CONTINUE)
    expect(continueButton).toBeInTheDocument()
    fireEvent.click(continueButton)
    expect(onClickMock).toHaveBeenCalledTimes(1)
  })

  test('it should test with box id', () => {
    render(<CountrySelector />)

    const Boxchecking = screen.getByTestId('continue-button-box')
    expect(Boxchecking).toBeInTheDocument()
  })

  test('it should test getOption with imageUrl', () => {
    render(<CountrySelector />)
    const textFieldElement = screen.getByLabelText('Select your country')
    fireEvent.change(textFieldElement, { target: { value: 'A' } })
    const andoraOptionImage = screen.getByTestId('option-image-Andorra')
    const austriaOptionImage = screen.getByTestId('option-image-Austria')
    expect(andoraOptionImage).toBeInTheDocument()
    expect(austriaOptionImage).toBeInTheDocument()
  })

  test('it should test getOption', () => {
    render(<CountrySelector />)
    const textFieldElement = screen.getByLabelText('Select your country')
    expect(textFieldElement).toBeInTheDocument()
    fireEvent.change(textFieldElement, { target: { value: 'I' } })
  })
})
