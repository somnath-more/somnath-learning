import { Box, styled } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import arrow from '../../../../public/assets/image/Arrowright.svg'
import CustomTextField from 'components/atoms/Input'
import theme from 'themes'
import Button from 'components/atoms/Button'
import ModalBox from './ModalBox'
import { useState } from 'react'
import {
  BankOptions,
  CANCEL_THE_TRANSFER,
  CHOOSE_BANK,
  CONTENT_OF_MODAL,
  TITLE_OF_MODAL,
} from 'utils/constants'

interface BankBoxProps {
  src: string
  alt: string
  title: string
  id: number
  handleClick?: () => void
}

const CancelButton = styled(Button)({
  padding: '16px 30px',
  width: '218px',
  height: '56px',
  borderRadius: '56px',
  textTransform: 'none',
  fontSize: '17px',
  backgroundColor: theme.palette.Structural.white,
  color: theme.palette.primary.primary500,
  '&:hover': {
    backgroundColor: theme.palette.Structural.buttonHover,
  },
  boxShadow: `0px 0px 1px 0px #1414141F, 0px 0px 8px 0px #1414140A, 0px 8px 8px 0px #1414140A`,
  marginTop: '32px',
})

const StyledBankBoxWrapper = styled(Box)({
  borderRadius: '8px',
  padding: '10px',
  backgroundColor: 'white',
  cursor: 'pointer',
  '&:hover': {
    backgroundColor: '#F0F0F0',
  },
})

export const BankBox = (props: BankBoxProps) => {
  return (
    <StyledBankBoxWrapper
      data-testid="bank-box"
      display={'flex'}
      justifyContent={'space-between'}
      flexDirection={'row'}
      width={'516px'}
      height={'50px'}
      marginBottom={'4px'}
      onClick={props.handleClick}
      style={{ cursor: props.id === 5 ? 'pointer' : 'default' }}
    >
      <Box display={'flex'} margin={'10px'} columnGap={3} alignItems="center">
        <img src={props.src} height={'28px'} width={'28px'} alt={props.alt} />
        <MuiTypography variant="caption1">{props.title}</MuiTypography>
      </Box>
      <img
        src={arrow}
        width={'24px'}
        height={'24px'}
        style={{ margin: '10px' }}
      />
    </StyledBankBoxWrapper>
  )
}

interface BankSelectorProps {
  onClick?: () => void
  onYesClicked?: () => void
}

const BankSelector = (props: BankSelectorProps) => {
  const [isModalOpen, setModalOpen] = useState(false)
  const [searchText, setSearchText] = useState('')

  const handleModalOpen = () => {
    setModalOpen(true)
  }

  const handleModalClose = () => {
    setModalOpen(false)
  }

  const handleSearchInputChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setSearchText(event.target.value)
  }

  const filteredBankOptions = BankOptions.filter((option) =>
    option.title.toLowerCase().includes(searchText.toLowerCase())
  )

  return (
    <>
      <Box width={'517px'}>
        <MuiTypography
          variant="h1"
          sx={{ marginBottom: '32px' }}
          color={theme.palette.Text.highEmphasis}
        >
          {CHOOSE_BANK}
        </MuiTypography>
        <CustomTextField
          label="Start typing to search"
          sx={{ width: '516px', color: theme.palette.Text.lowEmphasis }}
          style={{ marginBottom: '20px' }}
          onChange={handleSearchInputChange}
        />
        {filteredBankOptions.map((option) =>
          option.id === 5 ? (
            <BankBox
              key={option.id}
              src={option.src}
              alt={option.alt}
              title={option.title}
              id={option.id}
              handleClick={props.onClick}
            />
          ) : (
            <BankBox
              key={option.id}
              src={option.src}
              alt={option.alt}
              title={option.title}
              id={option.id}
            />
          )
        )}
        <center>
          <CancelButton data-testid="cancelButton" onClick={handleModalOpen}>
            {CANCEL_THE_TRANSFER}
          </CancelButton>
        </center>
      </Box>
      <ModalBox
        data-testid="modal-button"
        open={isModalOpen}
        title={TITLE_OF_MODAL}
        text={CONTENT_OF_MODAL}
        onClose={handleModalClose}
        onConfirm={props.onYesClicked}
      />
    </>
  )
}

export default BankSelector
