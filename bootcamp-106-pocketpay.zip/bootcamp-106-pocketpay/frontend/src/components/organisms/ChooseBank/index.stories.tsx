import { StoryFn, Meta } from '@storybook/react'
import BankSelector from '.'

export default {
  title: 'Organisms/BankSelector',
  component: BankSelector,
} as Meta

const Template: StoryFn<typeof BankSelector> = (args) => <BankSelector />

export const Default = Template.bind({})
Default.args = {}
