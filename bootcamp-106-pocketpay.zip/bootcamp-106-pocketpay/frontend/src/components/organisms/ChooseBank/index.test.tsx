import { render, screen, fireEvent } from '@testing-library/react'
import BankSelector, { BankBox } from '.'
import { TITLE_OF_MODAL } from 'utils/constants'
describe('BankSelector', () => {
  test('it should render BankSelector component', () => {
    render(<BankSelector />)
  })

  test('it should search for banks', () => {
    render(<BankSelector />)
    const searchInput = screen.getByLabelText('Start typing to search')
    fireEvent.change(searchInput, { target: { value: 'S' } })
    const bankOption = screen.getByText('State Bank of India')
    expect(bankOption).toBeInTheDocument()
  })

  test('it should click on a bank box', () => {
    render(<BankSelector />)
    const bankBox = screen.getByText('Lloyds')
    fireEvent.click(bankBox)
    expect(bankBox).toBeInTheDocument()
  })

  test('it should open and close the modal', () => {
    render(<BankSelector />)
    const Button = screen.getByTestId('cancelButton')
    fireEvent.click(Button)

    const modalTitle = screen.getByText(TITLE_OF_MODAL)
    expect(modalTitle).toBeInTheDocument()
    const noButton = screen.getByText('No')
    fireEvent.click(noButton)
    expect(modalTitle).not.toBeInTheDocument()
  })

  test('it should handle button onClick in the modal', () => {
    render(<BankSelector />)
    const cancelButton = screen.getByTestId('cancelButton')
    fireEvent.click(cancelButton)
    const modalTitle = screen.getByText(TITLE_OF_MODAL)
    expect(modalTitle).toBeInTheDocument()
    const yesButton = screen.getByText('Yes')
    fireEvent.click(yesButton)
    const modalElement = screen.getByText(TITLE_OF_MODAL)
    expect(modalElement).toBeInTheDocument()
    const noButton = screen.getByText('No')
    fireEvent.click(noButton)
    expect(modalElement).not.toBeInTheDocument()
  })

  test('it should redirect to another page when id is 5', () => {
    const props = {
      src: 'path/to/image.png',
      alt: 'Image Alt Text',
      title: 'Bank Title',
      id: 5,
      handleClick: () => {
        if (props.id === 5) {
          // Redirect to Dashboard
        }
      },
    }
    const handleClick = jest.fn()
    render(<BankBox {...props} handleClick={handleClick} />)
    fireEvent.click(screen.getByTestId('bank-box'))
    expect(handleClick).toHaveBeenCalledTimes(1)
    expect(screen.getByTestId('bank-box')).toBeInTheDocument()
  })

  test('it should not redirect when id is not 5', () => {
    const props = {
      src: 'path/to/image.png',
      alt: 'Image Alt Text',
      title: 'Bank Title',
      id: 10,
    }
    const handleClick = jest.fn()
    render(<BankBox {...props} handleClick={handleClick} />)
    fireEvent.click(screen.getByTestId('bank-box'))
    expect(handleClick).toHaveBeenCalledTimes(1)
    expect(screen.getByTestId('bank-box')).toBeInTheDocument()
  })
})
