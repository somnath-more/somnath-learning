import { Box, Modal, Stack, styled } from '@mui/material'
import theme from 'themes'
import MuiTypography from 'components/atoms/Typography'
import Button from 'components/atoms/Button'

interface ModalBoxProps {
  open: boolean
  title: string
  text: string
  onClose: () => void
  onConfirm?: () => void
}
const modalStyle = {
  position: 'absolute',
  width: 564,
  height: 306,
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  borderRadius: '16px',
  background: `${theme.palette.Structural.white}`,
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'space-around',
  outline: 'none',
}
const StyledButton = styled(Button)({
  width: '135px',
  height: '56px',
  borderRadius: '56px',
  boxShadow: '0px 8px 8px 0px #1414140A',
  textTransform: 'none',
})

const ModalBox = (props: ModalBoxProps) => {
  const { open, title, text, onClose, onConfirm } = props

  return (
    <Modal open={open} onClose={onClose}>
      <Box role="dialog" sx={modalStyle}>
        <Stack alignItems={'center'} rowGap={'26px'}>
          <MuiTypography variant="h1" color={theme.palette.Text.highEmphasis}>
            {title}
          </MuiTypography>
          <MuiTypography variant="body1" color={theme.palette.Text.lowEmphasis}>
            {text}
          </MuiTypography>
        </Stack>
        <Box display="flex" sx={{ gap: '20px' }}>
          <StyledButton variant="contained" onClick={onConfirm}>
            Yes
          </StyledButton>
          <StyledButton data-testid="NO" onClick={onClose}>
            No
          </StyledButton>
        </Box>
      </Box>
    </Modal>
  )
}

export default ModalBox
