import { fireEvent, render, screen } from '@testing-library/react'
import { Director_Constants, ERROR_MESSAGES } from 'utils/constants'
import ConfirmShareHolders from '.'

const mockProps = {
  ownerHeading: Director_Constants.OWNER_HEADING,
  subOwnerHeading: Director_Constants.OWNER_SUBHEADING,
  shareHoldersTitle: Director_Constants.SHARE_HOLDER,
  shareHoldersLink: Director_Constants.SHAREHOLDER_LINK,
  onClick: jest.fn(),
}

describe('ConfirmShareHolders', () => {
  beforeEach(() => {
    render(<ConfirmShareHolders {...mockProps} />)
  })

  test('it should render the shareholders', () => {
    const continueButton = screen.getByText('Continue')
    expect(screen.getByText(mockProps.ownerHeading)).toBeInTheDocument()
    expect(screen.getByText(mockProps.subOwnerHeading)).toBeInTheDocument()
    expect(screen.getByText(mockProps.shareHoldersTitle)).toBeInTheDocument()
    expect(screen.getByText(mockProps.shareHoldersLink)).toBeInTheDocument()
    expect(continueButton).toBeInTheDocument()

    const firstNameInputValue = screen.getByLabelText('First name')
    const lastNameInputValue = screen.getByLabelText('Last name')
    const dateInputValue = screen.getByLabelText('Date of birth')
    const dropdownInputValue = screen.getByLabelText('Country of residence')

    fireEvent.change(firstNameInputValue, { target: { value: 'John' } })
    expect(firstNameInputValue).toHaveValue('John')

    fireEvent.change(lastNameInputValue, { target: { value: 'Reddy' } })
    expect(lastNameInputValue).toHaveValue('Reddy')

    fireEvent.change(dateInputValue, { target: { value: '31-07-2023' } })
    expect(dateInputValue).toHaveValue('31-07-2023')

    fireEvent.change(dropdownInputValue, { target: { value: 'Ando' } })
    fireEvent.click(screen.getByText("Andorra"))

    fireEvent.click(continueButton)
    expect(mockProps.onClick).toHaveBeenCalledTimes(1)
  })

  test('it should update shareholders fields when input values change', () => {
    const firstNameInputValue = screen.getByLabelText('First name')
    const lastNameInputValue = screen.getByLabelText('Last name')
    const dateInputValue = screen.getByLabelText('Date of birth')
    const dropdownInputValue = screen.getByLabelText('Country of residence')

    fireEvent.change(firstNameInputValue, { target: { value: 'John' } })
    expect(firstNameInputValue).toHaveValue('John')

    fireEvent.change(lastNameInputValue, { target: { value: 'Reddy' } })
    expect(lastNameInputValue).toHaveValue('Reddy')

    fireEvent.change(dateInputValue, { target: { value: '31-07-2023' } })
    expect(dateInputValue).toHaveValue('31-07-2023')

    fireEvent.change(dropdownInputValue, { target: { value: 'A' } })
    expect(screen.getByTestId('option-image-Austria')).toBeInTheDocument()
  })

  test('it should display error messages', () => {
    const firstNameInputValue = screen.getByLabelText('First name')
    const lastNameInputValue = screen.getByLabelText('Last name')

    fireEvent.change(firstNameInputValue, { target: { value: 'John123' } })

    const invalidFirstNameError = screen.getByText(ERROR_MESSAGES.firstName)
    expect(invalidFirstNameError).toBeInTheDocument()

    fireEvent.change(lastNameInputValue, { target: { value: '#123WER' } })
    const invalidLastNameError = screen.getByText(ERROR_MESSAGES.lastName)
    expect(invalidLastNameError).toBeInTheDocument()
  })
})
