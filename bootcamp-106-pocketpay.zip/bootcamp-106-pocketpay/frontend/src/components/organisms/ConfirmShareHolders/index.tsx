import React, { useState } from 'react'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { Constants, options } from 'utils/constants'
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import MuiDropdown, { OptionItem } from 'components/atoms/Dropdown'
import { Box, Stack } from '@mui/material'
import AddIcon from '@mui/icons-material/Add'
import {
  StyledButton,
  StyledContentStack,
  StyledTextField,
} from '../ConfirmBusinessDirectors/styles'
import { ErrorState } from 'utils/types'
import { validateFieldForUserInformation } from 'utils/credentials'
import moment, { Moment } from 'moment'
import { styled } from 'styled-components'
import Button from 'components/atoms/Button'
import CalendarTodayOutlinedIcon from '@mui/icons-material/CalendarTodayOutlined'

export const getOptionImage = (option: OptionItem) => {
  return (
    <img
      src={option.imageUrl}
      alt={option.label}
      data-testid={`option-image-${option.label}`}
    />
  )
}

interface ShareHoldersProps {
  ownerHeading: string
  subOwnerHeading: string
  shareHoldersTitle: string
  shareHoldersLink: string
  onClick?: () => void
}

interface BusinessShareHolders {
  firstName: string
  lastName: string
  dateOfBirth: Moment | null
  countryOfResidence: string
}

const StyledContinueButton = styled(Button)({
  padding: '16px 30px',
  height: '56px',
  width: '135px',
  fontSize: '17px',
  left: '518px',
  bottom: '50px',
  boxShadow: '0px 8px 24px 0px #5533FF3D',
  color: theme.palette.Structural.white,
})

const ConfirmShareHolders = ({ ...props }: ShareHoldersProps) => {
  const [shareHolders, setShareHolders] = useState<BusinessShareHolders>({
    firstName: '',
    lastName: '',
    dateOfBirth: null,
    countryOfResidence: '',
  })

  const [errorMessages, setErrorMessages] = useState<ErrorState>({
    firstName: '',
    lastName: '',
  })

  const [selectedCountry, setSelectedCountry] = useState<OptionItem | null>(
    null
  )

  const shouldDisableDate = (date: Moment) => {
    const age18YearsAgo = moment().subtract(18, 'years')
    const age60YearsAgo = moment().subtract(60, 'years')

    return date.isAfter(age18YearsAgo) || date.isBefore(age60YearsAgo)
  }

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement>,
    field: keyof BusinessShareHolders
  ) => {
    const { value } = event.target
    setShareHolders((prevFormData) => ({
      ...prevFormData,
      [field]: value,
    }))

    const error = validateFieldForUserInformation(field, value)

    setErrorMessages((prevErrors) => ({
      ...prevErrors,
      [field]: error,
    }))
  }

  const handleCountryChange = (option: OptionItem | null) => {
    setSelectedCountry(option)
  }

  const isButtonDisabled =
    !!errorMessages.firstName ||
    !!errorMessages.lastName ||
    !shareHolders.firstName ||
    !shareHolders.lastName ||
    !shareHolders.dateOfBirth ||
    !selectedCountry

  return (
    <Box>
      <StyledContentStack>
        <Stack spacing={5}>
          <MuiTypography
            variant="h1"
            sx={{ color: theme.palette.Text.highEmphasis }}
          >
            {props.ownerHeading}
          </MuiTypography>
          <MuiTypography
            variant="body3"
            sx={{ color: theme.palette.Text.mediumEmphasis }}
          >
            {props.subOwnerHeading}
          </MuiTypography>
        </Stack>
        <Stack direction="row" sx={{ justifyContent: 'space-between' }}>
          <MuiTypography
            variant="body3"
            sx={{ color: theme.palette.Text.highEmphasis }}
          >
            {props.shareHoldersTitle}
          </MuiTypography>
        </Stack>
        <Stack spacing={10} data-testid="director-input">
          <StyledTextField
            label="First name"
            value={shareHolders.firstName}
            onChange={(e) => handleChange(e, 'firstName')}
          />
          {errorMessages.firstName && (
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.warning}
              marginTop="8px"
            >
              {errorMessages.firstName}
            </MuiTypography>
          )}
          <StyledTextField
            label="Last name"
            value={shareHolders.lastName}
            onChange={(e) => handleChange(e, 'lastName')}
          />
          {errorMessages.lastName && (
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.warning}
              marginTop="8px"
            >
              {errorMessages.lastName}
            </MuiTypography>
          )}

          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DatePicker
              label="Date of birth"
              format="DD-MM-YYYY"
              disableFuture
              views={['year', 'month', 'day']}
              sx={{
                '& .MuiSvgIcon-root': {
                  color: theme.palette.Accent.icon02,
                },
              }}
              shouldDisableYear={shouldDisableDate}
              value={shareHolders.dateOfBirth ?? null}
              onChange={(date) =>
                setShareHolders((prevFormData) => ({
                  ...prevFormData,
                  dateOfBirth: date,
                }))
              }
              slotProps={{
                inputAdornment: {
                  position: 'end',
                },
              }}
              slots={{
                openPickerIcon: CalendarTodayOutlinedIcon,
              }}
            />
          </LocalizationProvider>
          <MuiDropdown
            width="516px"
            label="Country of residence"
            options={options}
            getOptionImage={getOptionImage}
            onChange={handleCountryChange}
          />
        </Stack>
        <StyledButton startIcon={<AddIcon />}>
          {props.shareHoldersLink}
        </StyledButton>
      </StyledContentStack>
      <Stack sx={{ justifyContent: 'flex-end' }}>
        <StyledContinueButton
          sx={{
            backgroundColor: theme.palette.primary.primary500,
            borderRadius: '56px',
            textTransform: 'none',
            color: '#fff',
            '&:hover': {
              backgroundColor: theme.palette.primary.primary300,
            },
            '&:disabled': {
              backgroundColor: theme.palette.primary.primary100,
              color: theme.palette.Structural.white,
            },
          }}
          onClick={props.onClick}
          disabled={isButtonDisabled}
        >
          {Constants.CONTINUE}
        </StyledContinueButton>
      </Stack>
    </Box>
  )
}

export default ConfirmShareHolders
