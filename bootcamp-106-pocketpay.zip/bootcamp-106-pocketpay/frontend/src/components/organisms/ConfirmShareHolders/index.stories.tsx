import { StoryFn, Meta } from '@storybook/react'
import { Director_Constants } from 'utils/constants'
import ConfirmShareHolders from '.'

const meta: Meta = {
  title: 'Organisms/ConfirmShareHolders',
  component: ConfirmShareHolders,
  argTypes: {
    onClick: {
      action: 'clicked',
    },
  },
}
export default meta

const Template: StoryFn<typeof ConfirmShareHolders> = (args) => (
  <ConfirmShareHolders {...args} />
)

export const ShareHolder = Template.bind({})

ShareHolder.args = {
  ownerHeading: Director_Constants.OWNER_HEADING,
  subOwnerHeading: Director_Constants.OWNER_SUBHEADING,
  shareHoldersTitle: Director_Constants.SHARE_HOLDER,
  shareHoldersLink: Director_Constants.SHAREHOLDER_LINK,
}
