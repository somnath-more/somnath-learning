import { Box, Stack, styled } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import Button from 'components/atoms/Button'
import MuiIcon from 'components/atoms/Icons'
import {
  TRANSFER_HEADING,
  RATE,
  FEE,
  SEND_LABEL,
  LABEL_RECEIVE,
  CurrencyType,
  currencies,
  CurrencyConversion,
  Currency_Conversion_Values,
  Constants,
  TOTAL_AMOUNT,
  MODAL_CONTENT,
  RATE_GBP,
  FROM_GBP,
} from 'utils/constants'
import React from 'react'
import INFOICON from 'public/assets/image/info.svg'
import DOWNICON from 'public/assets/image/down.svg'
import CustomModal from 'components/molecules/TransferModal'
import TextfieldDropdown from 'components/molecules/TextfieldDropdown'

interface TransferDetailCardProps {
  onContinue: () => void
  onAmountSendChange?: (newAmount: string) => void
  onAmountReceiveChange?: (newAmount: string) => void
  setFromToCurrencyCode?: (
    fromCurrencyCode: string,
    toCurrencyCody: string
  ) => void
}

const TransferDetailCard: React.FC<TransferDetailCardProps> = ({
  onContinue,
  onAmountSendChange,
  onAmountReceiveChange,
  setFromToCurrencyCode,
}) => {
  const [amount, setAmount] = React.useState<string>('')
  const [selectedCurrencyOne, setselectedCurrencyOne] =
    React.useState<CurrencyType>(currencies[1])
  const [selectedCurrencyTwo, setselectedCurrencyTwo] =
    React.useState<CurrencyType>(currencies[1])
  const [convertedAmount, setConvertedAmount] = React.useState<
    number | undefined
  >(undefined)
  const [totalTransferAmount, setTotalTransferAmount] = React.useState<
    number | undefined
  >(undefined)
  const [showModal, setShowModal] = React.useState<boolean>(false)

  const transferDetails = React.useMemo(() => {
    return Currency_Conversion_Values.map((conversion) => {
      const currency = currencies.find((cur) => cur.code === conversion.id)
      return currency ? { ...conversion, code: currency.code } : null
    }).filter(Boolean) as CurrencyConversion[]
  }, [])

  const handleAmountChange = (newAmount: string) => {
    setAmount(newAmount)
    if (onAmountSendChange) onAmountSendChange(newAmount)
    performCurrencyConversion(
      newAmount,
      selectedCurrencyOne,
      selectedCurrencyTwo
    )
  }

  const performCurrencyConversion = React.useCallback(
    (
      amountValue: string,
      fromCurrency: CurrencyType,
      toCurrency: CurrencyType
    ) => {
      if (fromCurrency.code === toCurrency.code) {
        setConvertedAmount(parseFloat(amountValue))
        setTotalTransferAmount(parseFloat(amountValue))
        return
      }

      const fromCurrencyDetails = transferDetails.find(
        (item) => item.id === fromCurrency.code
      )

      const toCurrencyDetails = transferDetails.find(
        (item) => item.id === toCurrency.code
      )

      if (setFromToCurrencyCode)
        setFromToCurrencyCode(fromCurrency.code, toCurrency.code)

      if (fromCurrencyDetails && toCurrencyDetails) {
        const fromRate = fromCurrencyDetails.rates[toCurrency.code]
        const amountMinusFee =
          parseFloat(amountValue) - fromCurrencyDetails.transferFee
        setTotalTransferAmount(
          isNaN(amountMinusFee) ? undefined : amountMinusFee
        )
        const convertedValue = amountMinusFee * fromRate
        setConvertedAmount(isNaN(convertedValue) ? undefined : convertedValue)
      }
    },
    [transferDetails]
  )
  const formattedAmount = convertedAmount?.toFixed(2) ?? ''
  if (onAmountReceiveChange) onAmountReceiveChange(formattedAmount)

  React.useEffect(() => {
    performCurrencyConversion(amount, selectedCurrencyOne, selectedCurrencyTwo)
  }, [
    amount,
    selectedCurrencyOne,
    selectedCurrencyTwo,
    performCurrencyConversion,
  ])

  return (
    <Stack display="flex" flexDirection={'column'} gap={'28px'} width={'650px'}>
      <MuiTypography
        variant="h1"
        color={theme.palette.Text.highEmphasis}
        style={{ marginBottom: '25px' }}
      >
        {TRANSFER_HEADING}
      </MuiTypography>

      <Stack display="flex" flexDirection={'column'} gap={'28px'}>
        <TextfieldDropdown
          width="526px"
          label={SEND_LABEL}
          amount={amount}
          selectedCurrency={selectedCurrencyOne}
          onAmountChange={handleAmountChange}
          onCurrencyChange={(newCurrency) =>
            setselectedCurrencyOne(newCurrency)
          }
        />
        <TextfieldDropdown
          width="526px"
          label={LABEL_RECEIVE}
          amount={amount === '' ? amount : formattedAmount}
          selectedCurrency={selectedCurrencyTwo}
          onAmountChange={(newAmount) => {
            setAmount(newAmount)
            performCurrencyConversion(
              newAmount,
              selectedCurrencyOne,
              selectedCurrencyTwo
            )
          }}
          onCurrencyChange={(newCurrency) =>
            setselectedCurrencyTwo(newCurrency)
          }
        />
      </Stack>
      <Stack gap={'20px'}>
        <StyledTypography variant="body3" data-testid="conversion-line">
          {FEE}
          <span style={HorizontalLine}></span>
          <span style={{ display: 'flex', flexDirection: 'row' }}>
            {FROM_GBP}
            <MuiIcon src={INFOICON} alt="info" width="24px" height="24px" />
          </span>
        </StyledTypography>
        <StyledTypography variant="body3">
          {RATE}
          <span style={HorizontalLine}></span>

          <span
            data-testid="modal-click"
            style={{
              display: 'flex',
              flexDirection: 'row',
              cursor: 'pointer',
              color: theme.palette.primary.primary500,
            }}
            onClick={() => {
              setShowModal(true)
            }}
          >
            {RATE_GBP}
            <MuiIcon src={DOWNICON} alt="down" />
          </span>
        </StyledTypography>
        <StyledTypography variant="body3">
          {TOTAL_AMOUNT}

          <span style={HorizontalLine}></span>
          {totalTransferAmount}
          <MuiIcon src={INFOICON} alt="info" width="24px" height="24px" />
        </StyledTypography>
      </Stack>
      <OuterBox>
        <ContinueButton
          variant="contained"
          onClick={onContinue}
          disabled={!amount}
        >
          {Constants.CONTINUE}
        </ContinueButton>
      </OuterBox>
      {showModal && (
        <CustomModal isModalOpen={showModal}>
          <Stack
            sx={{ marginTop: '25px', marginLeft: '30px' }}
            width={'384px'}
            height={'64px'}
          >
            <MuiTypography
              variant="body1"
              color={theme.palette.Text.mediumEmphasis}
            >
              {MODAL_CONTENT}
            </MuiTypography>
          </Stack>

          <Box>
            <ModalStyle>
              <OkButton
                data-testid="modal-add-btn"
                variant="contained"
                onClick={() => setShowModal(!showModal)}
              >
                <MuiTypography variant="body2">Ok</MuiTypography>
              </OkButton>
            </ModalStyle>
          </Box>
        </CustomModal>
      )}
    </Stack>
  )
}

export default TransferDetailCard

const OuterBox = styled(Box)({
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'flex-end',
  alignItems: 'flex-end',
})
const ContinueButton = styled(Button)({
  textTransform: 'none',
  borderRadius: '56px',
  width: '135px',
  height: '56px',
  marginTop: '144px',
  '&:disabled': {
    backgroundColor: theme.palette.primary.primary100,
    color: theme.palette.Structural.white,
  },
})
const HorizontalLine = {
  height: '14px',
  display: 'flex',
  alignItems: 'center',
  flexGrow: 1,
  borderBottom: `1px solid ${theme.palette.Accent.stroke2}`,
  lineHeight: 0,
  margin: '0px 4px ',
}
const StyledTypography = styled(MuiTypography)({
  display: 'flex',
  flexDirection: 'row',
  color: theme.palette.Text.lowEmphasis,
  width: '526px',
})

const OkButton = styled(Button)({
  width: '135px',
  height: '56px',
  borderRadius: '56px',
  color: theme.palette.Text.contrastText,
  backgroundColor: theme.palette.primary.primary500,
  '&:hover': {
    backgroundColor: theme.palette.primary.primary300,
  },
})

const ModalOpenButton = styled(Button)({
  justifyContent: 'flex-end',
  padding: '0px',
  borderRadius: '0px',
  color: theme.palette.primary.primary500,
  backgroundColor: theme.palette.Structural.white,
  '&::hover': {
    color: theme.palette.primary.primary500,
    backgroundColor: theme.palette.primary.main,
  },
})
const ModalStyle = styled(Stack)({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  marginTop: '7rem',
})
