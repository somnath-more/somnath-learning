import React from 'react'
import { Meta, StoryFn } from '@storybook/react'
import TransferDetailCard from '.'
import { action } from '@storybook/addon-actions'

export default {
  title: 'Organisms/TransferDetailCard',
  component: TransferDetailCard,
  argTypes: {},
} as Meta

const Template: StoryFn<typeof TransferDetailCard> = (args) => (
  <TransferDetailCard {...args} />
)

export const Default = Template.bind({})
Default.args = {
  onContinue: action('continue button is clicked'),
}
