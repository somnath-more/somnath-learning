import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import TranferDetailCard from '.'
import {
  TRANSFER_HEADING,
  LABEL_RECEIVE,
  SEND_LABEL,
  Constants,
} from 'utils/constants'
import '@testing-library/jest-dom/extend-expect'

describe('TransferDetailCard', () => {
  let onContinueMock: jest.Mock<() => void>

  beforeEach(() => {
    onContinueMock = jest.fn()
    jest.mock('public/assets/image/info.svg', () => 'info.svg')
    jest.mock('public/assets/image/down.svg', () => 'down.svg')
  })
  afterEach(() => {
    onContinueMock.mockClear()
  })

  const setupComponent = () => {
    render(<TranferDetailCard onContinue={onContinueMock} />)
  }

  test('it should render without errors', () => {
    setupComponent()
    expect(screen.getByText(TRANSFER_HEADING)).toBeInTheDocument()
  })

  test('it should update amount state correctly', () => {
    setupComponent()
    const amountInput = screen.getByLabelText(SEND_LABEL) as HTMLInputElement
    fireEvent.change(amountInput, { target: { value: '100' } })
    expect(amountInput.value).toBe('100')
  })

  test('it should update selectedCurrency2 state correctly', () => {
    setupComponent()
    const currencyDropdown = screen.getByLabelText(
      LABEL_RECEIVE
    ) as HTMLInputElement
    fireEvent.change(currencyDropdown, { target: { value: 'GBP' } })
    expect(currencyDropdown.value).toBe('')
  })

  test('it should update convertedAmount state correctly when amount is changed', () => {
    setupComponent()
    const amountInput = screen.getByLabelText(SEND_LABEL) as HTMLInputElement
    fireEvent.change(amountInput, { target: { value: '100' } })
    expect(screen.getByLabelText(LABEL_RECEIVE)).toHaveValue('100.00')
  })

  test('it should call onContinue correctly', () => {
    setupComponent()

    const amountInput = screen.getByLabelText(SEND_LABEL) as HTMLInputElement
    fireEvent.change(amountInput, { target: { value: '100' } })
    
    fireEvent.click(screen.getByText(Constants.CONTINUE))
    expect(onContinueMock).toHaveBeenCalledTimes(1)
  })

  test('it should update selectedCurrency1 state correctly when currency is changed', () => {
    setupComponent()

    const selectedCurrency = screen.getAllByTestId('selected-currency')

    fireEvent.click(selectedCurrency[0])
    const activeEle1 = screen.getByText('INR')
    fireEvent.click(activeEle1)
    fireEvent.click(selectedCurrency[1])
    const activeEle2 = screen.getByText('AUD')
    fireEvent.click(activeEle2)
    expect(selectedCurrency[1]).not.toBeInTheDocument()
  })

  test('it should handle onClick  ', () => {
    setupComponent()
    const modalCards = screen.getAllByTestId('modal-click')
    fireEvent.click(modalCards[0])
    expect(modalCards[0]).toBeInTheDocument()
    const okButton = screen.getByText('Ok')

    fireEvent.click(okButton)
    waitFor(() => {
      expect(okButton).toHaveBeenCalledTimes(1)
    })
  })
})
