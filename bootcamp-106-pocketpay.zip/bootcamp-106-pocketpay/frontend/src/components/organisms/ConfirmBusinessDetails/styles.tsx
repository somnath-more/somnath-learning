import { Grid, styled } from '@mui/material'
import CustomTextField from 'components/atoms/Input'
import MuiTypography from 'components/atoms/Typography'

export const StyledContainer = styled(Grid)({
  flexDirection: 'column',
  width: '650px',
})

export const StyledEdit = styled(MuiTypography)({
  cursor: 'pointer',
})

export const StyledTextField = styled(CustomTextField)({
  width: '516px',
})
