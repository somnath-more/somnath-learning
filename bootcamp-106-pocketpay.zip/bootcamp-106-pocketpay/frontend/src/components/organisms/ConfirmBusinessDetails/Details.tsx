import { Grid } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { BusinessDetailsProps } from '.'
import { Constants } from 'utils/constants'
import { StyledContinueButton } from 'utils/styles'

const Details = (props: BusinessDetailsProps) => {
  const handleContinue = () => {
    props.onContinueClick?.()
    if (props.onSaveDetails) {
      props.onSaveDetails(props)
    }
  }

  return (
    <Grid container flexDirection="column" width="650px">
      <Grid item>
        <MuiTypography
          variant="body2"
          color={theme.palette.Text.mediumEmphasis}
        >
          {props.businessName}
        </MuiTypography>
      </Grid>
      <Grid item marginTop="12px">
        <MuiTypography variant="body2" color={theme.palette.Text.highEmphasis}>
          {props.businessNameContent}
        </MuiTypography>
      </Grid>
      <Grid item marginTop="40px">
        <MuiTypography
          variant="body2"
          color={theme.palette.Text.mediumEmphasis}
        >
          {props.registrationNumber}
        </MuiTypography>
      </Grid>
      <Grid item marginTop="12px">
        <MuiTypography variant="body2" color={theme.palette.Text.highEmphasis}>
          {props.registrationNumberContent}
        </MuiTypography>
      </Grid>
      <Grid item marginTop="40px">
        <MuiTypography
          variant="body2"
          color={theme.palette.Text.mediumEmphasis}
        >
          {props.registeredAddress}
        </MuiTypography>
      </Grid>
      <Grid item marginTop="12px">
        <MuiTypography
          variant="body2"
          color={theme.palette.Text.highEmphasis}
          width="516px"
        >
          {props.registeredAddressContent}
        </MuiTypography>
      </Grid>
      <Grid item marginTop="69px" marginLeft="515px">
        <StyledContinueButton variant="contained" onClick={handleContinue}>
          {Constants.CONTINUE}
        </StyledContinueButton>
      </Grid>
    </Grid>
  )
}

export default Details
