import { render, fireEvent, screen } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import ConfirmBusinessDetail from '.'
import EditDetails from './EditDetails'
import Details from './Details'
import {
  BUSINESS_SEARCH,
  CONFIRM_BUSINESS_DETAILS,
  Constants,
} from 'utils/constants'

const mockContent = {
  title: CONFIRM_BUSINESS_DETAILS.TITLE,
  subtitle: CONFIRM_BUSINESS_DETAILS.SUBTITLE,
  businessAddress: CONFIRM_BUSINESS_DETAILS.REGISTERED_ADDRESS,
  businessName: CONFIRM_BUSINESS_DETAILS.BUSINESS_NAME,
  registrationNumber: CONFIRM_BUSINESS_DETAILS.REGISTRATION_NUMBER,
  registeredAddress: CONFIRM_BUSINESS_DETAILS.REGISTERED_ADDRESS,
  businessNameContent: BUSINESS_SEARCH[1].label,
  registrationNumberContent:
    CONFIRM_BUSINESS_DETAILS.REGISTRATION_NUMBER_CONTENT,
  registeredAddressContent: Constants.RADIO_TYPOGRAPHY_CONTENT,
  onSaveClick: jest.fn(),
  onUpdateContent: jest.fn(),
  onCancelClick: jest.fn(),
  onInputChange: jest.fn(),
  onEditClick: jest.fn(),
  onContinueClick: jest.fn(),
}

describe('ConfirmBusinessDetail', () => {
  test('it should render business details in read-only mode', () => {
    render(<ConfirmBusinessDetail {...mockContent} />)

    expect(
      screen.getByText(mockContent.businessNameContent)
    ).toBeInTheDocument()
    expect(
      screen.getByText(mockContent.registrationNumberContent)
    ).toBeInTheDocument()
    expect(
      screen.getByText(mockContent.registeredAddressContent)
    ).toBeInTheDocument()
    expect(screen.getByText(Constants.EDIT)).toBeInTheDocument()
    expect(screen.getByText(Constants.CONTINUE)).toBeInTheDocument()
  })

  describe('ConfirmBusinessDetail', () => {
    test('it should switch to edit mode when "Edit" button is clicked', () => {
      render(<ConfirmBusinessDetail {...mockContent} />)

      expect(
        screen.queryByLabelText(CONFIRM_BUSINESS_DETAILS.BUSINESS_NAME)
      ).not.toBeInTheDocument()
      expect(
        screen.queryByLabelText(CONFIRM_BUSINESS_DETAILS.REGISTRATION_NUMBER)
      ).not.toBeInTheDocument()
      expect(
        screen.queryByLabelText(CONFIRM_BUSINESS_DETAILS.REGISTERED_ADDRESS)
      ).not.toBeInTheDocument()

      fireEvent.click(screen.getByText(Constants.EDIT))

      expect(
        screen.getByLabelText(CONFIRM_BUSINESS_DETAILS.BUSINESS_NAME)
      ).toBeInTheDocument()
      expect(
        screen.getByLabelText(CONFIRM_BUSINESS_DETAILS.REGISTRATION_NUMBER)
      ).toBeInTheDocument()
      expect(
        screen.getByLabelText(CONFIRM_BUSINESS_DETAILS.REGISTERED_ADDRESS)
      ).toBeInTheDocument()
    })
  })

  test('it should switch to read-only mode when "Cancel" button is clicked in edit mode', () => {
    render(<ConfirmBusinessDetail {...mockContent} />)

    fireEvent.click(screen.getByText(Constants.EDIT))
    expect(
      screen.getByLabelText(CONFIRM_BUSINESS_DETAILS.BUSINESS_NAME)
    ).toBeInTheDocument()

    fireEvent.click(screen.getByText(Constants.CANCEL))
    expect(
      screen.queryByLabelText(CONFIRM_BUSINESS_DETAILS.BUSINESS_NAME)
    ).not.toBeInTheDocument()
  })
})

describe('EditDetails', () => {
  test('it should update the input fields and call "onInputChange" when edited', () => {
    const mockOnInputChange = jest.fn()

    render(<EditDetails {...mockContent} onInputChange={mockOnInputChange} />)

    const businessNameChangeEvent = {
      target: { value: 'New Business Name' },
    }
    const registrationNumberChangeEvent = {
      target: { value: '0987654321' },
    }
    const registeredAddressChangeEvent = {
      target: { value: 'New Sample Address' },
    }

    fireEvent.change(
      screen.getByLabelText(CONFIRM_BUSINESS_DETAILS.BUSINESS_NAME),
      businessNameChangeEvent
    )

    fireEvent.change(
      screen.getByLabelText(CONFIRM_BUSINESS_DETAILS.REGISTRATION_NUMBER),
      registrationNumberChangeEvent
    )

    fireEvent.change(
      screen.getByLabelText(CONFIRM_BUSINESS_DETAILS.REGISTERED_ADDRESS),
      registeredAddressChangeEvent
    )

    expect(mockOnInputChange).toHaveBeenCalledTimes(3)
    expect(mockOnInputChange.mock.calls[0][1]).toBe('businessNameContent')
    expect(mockOnInputChange.mock.calls[1][1]).toBe('registrationNumberContent')
    expect(mockOnInputChange.mock.calls[2][1]).toBe('registeredAddressContent')
  })

  test('it should call "onSaveClick" and "onUpdateContent" when "Save" button is clicked and switch back to read-only mode', () => {
    const mockOnSaveClick = jest.fn()
    const mockOnUpdateContent = jest.fn()
    const updatedBusinessNameContent = 'New Business Name'

    render(
      <ConfirmBusinessDetail
        {...mockContent}
        onSaveClick={mockOnSaveClick}
        onUpdateContent={mockOnUpdateContent}
      />
    )

    fireEvent.click(screen.getByText(Constants.EDIT))
    fireEvent.change(
      screen.getByLabelText(CONFIRM_BUSINESS_DETAILS.BUSINESS_NAME),
      {
        target: { value: updatedBusinessNameContent },
      }
    )

    fireEvent.click(screen.getByText(Constants.SAVE))
    expect(mockOnSaveClick).toHaveBeenCalledTimes(1)
    expect(mockOnUpdateContent).toHaveBeenCalledTimes(2)

    expect(
      screen.queryByLabelText(CONFIRM_BUSINESS_DETAILS.BUSINESS_NAME)
    ).not.toBeInTheDocument()
  })
})

describe('Details', () => {
  test('it should render business details in read-only mode', () => {
    render(<Details {...mockContent} />)

    expect(
      screen.getByText(mockContent.businessNameContent)
    ).toBeInTheDocument()
    expect(
      screen.getByText(mockContent.registrationNumberContent)
    ).toBeInTheDocument()
    expect(
      screen.getByText(mockContent.registeredAddressContent)
    ).toBeInTheDocument()
    expect(screen.getByText(Constants.CONTINUE)).toBeInTheDocument()
  })
})
