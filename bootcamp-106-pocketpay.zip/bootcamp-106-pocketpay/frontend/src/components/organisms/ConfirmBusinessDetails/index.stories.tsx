import { StoryFn, Meta } from '@storybook/react'
import ConfirmBusinessDetail from '.'
import {
  BUSINESS_SEARCH,
  CONFIRM_BUSINESS_DETAILS,
  Constants,
} from 'utils/constants'

const meta: Meta = {
  title: 'Organisms/Confirm Business Detials',
  component: ConfirmBusinessDetail,
}
export default meta

const Template: StoryFn<typeof ConfirmBusinessDetail> = (args) => (
  <ConfirmBusinessDetail {...args} />
)

export const Primary = Template.bind({})

Primary.args = {
  title: CONFIRM_BUSINESS_DETAILS.TITLE,
  subtitle: CONFIRM_BUSINESS_DETAILS.SUBTITLE,
  businessAddress: CONFIRM_BUSINESS_DETAILS.REGISTERED_ADDRESS,
  businessName: CONFIRM_BUSINESS_DETAILS.BUSINESS_NAME,
  registrationNumber: CONFIRM_BUSINESS_DETAILS.REGISTRATION_NUMBER,
  registeredAddress: CONFIRM_BUSINESS_DETAILS.REGISTERED_ADDRESS,
  businessNameContent: BUSINESS_SEARCH[1].label,
  registrationNumberContent:
    CONFIRM_BUSINESS_DETAILS.REGISTRATION_NUMBER_CONTENT,
  registeredAddressContent: Constants.RADIO_TYPOGRAPHY_CONTENT,
}
