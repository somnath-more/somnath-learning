import { Grid } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import { BusinessDetailsProps } from '.'
import { Constants } from 'utils/constants'
import { StyledTextField } from './styles'
import { StyledCancelButton, StyledSaveButton } from 'utils/styles'

const EditDetails = (props: BusinessDetailsProps) => {
  const handleSaveClick = () => {
    props.onSaveClick?.()
    props.onUpdateContent?.(props)
    if (props.onSaveDetails) {
      props.onSaveDetails(props)
    }
  }

  const handleCancelClick = () => {
    props.onCancelClick?.()
  }

  const handleInputChange = (
    event: React.ChangeEvent<HTMLInputElement>,
    field: keyof BusinessDetailsProps
  ) => {
    props.onInputChange?.(event, field)
    if (props.onSaveDetails) {
      props.onSaveDetails(props)
    }
  }

  return (
    <Grid container flexDirection="column" width="650px">
      <Grid item marginTop="20px">
        <StyledTextField
          label={props.businessName}
          value={props.businessNameContent}
          onChange={(e) => handleInputChange(e, 'businessNameContent')}
        />
      </Grid>
      <Grid item marginTop="20px">
        <StyledTextField
          label={props.registrationNumber}
          value={props.registrationNumberContent}
          onChange={(e) => handleInputChange(e, 'registrationNumberContent')}
        />
      </Grid>
      <Grid item marginTop="20px">
        <StyledTextField
          label={props.registeredAddress}
          value={props.registeredAddressContent}
          onChange={(e) => handleInputChange(e, 'registeredAddressContent')}
          multiline={true}
        />
      </Grid>
      <Grid item marginTop="105px">
        <Grid container justifyContent="flex-end" gap="20px">
          <Grid item>
            <StyledCancelButton variant="contained" onClick={handleCancelClick}>
              <MuiTypography variant="body2">{Constants.CANCEL}</MuiTypography>
            </StyledCancelButton>
          </Grid>
          <Grid item>
            <StyledSaveButton variant="contained" onClick={handleSaveClick}>
              <MuiTypography variant="body2">{Constants.SAVE}</MuiTypography>
            </StyledSaveButton>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  )
}

export default EditDetails
