import { useState } from 'react'
import { Grid } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import Details from './Details'
import EditDetails from './EditDetails'
import { Constants } from 'utils/constants'
import { StyledContainer } from './styles'

export interface BusinessDetailsProps {
  title: string
  subtitle: string
  businessAddress: string
  businessName: string
  registrationNumber: string
  registeredAddress: string
  businessNameContent: string
  registrationNumberContent: string
  registeredAddressContent: string
  onCancelClick?: () => void
  onSaveClick?: () => void
  onInputChange?: (
    event: React.ChangeEvent<HTMLInputElement>,
    field: keyof BusinessDetailsProps
  ) => void
  onEditClick?: () => void
  onUpdateContent?: (content: BusinessDetailsProps) => void
  onContinueClick?: () => void
  onSaveDetails?: (data: BusinessDetailsProps) => void
}

const ConfirmBusinessDetail = (props: BusinessDetailsProps) => {
  const [editMode, setEditMode] = useState(false)
  const [editedContent, setEditedContent] =
    useState<BusinessDetailsProps>(props)

  const handleEditClick = () => {
    setEditMode(true)
  }

  const handleCancelEdit = () => {
    setEditMode(false)
    setEditedContent(props)
  }

  const handleSaveClick = () => {
    setEditMode(false)
    props.onUpdateContent?.(editedContent)
    props.onSaveClick?.()
  }

  const handleInputChange = (
    event: React.ChangeEvent<HTMLInputElement>,
    field: keyof BusinessDetailsProps
  ) => {
    const { value } = event.target
    setEditedContent((prevEditedContent) => ({
      ...prevEditedContent,
      [field]: value,
    }))
  }

  return (
    <StyledContainer container>
      <Grid item>
        <MuiTypography variant="h1" color={theme.palette.Text.highEmphasis}>
          {props.title}
        </MuiTypography>
      </Grid>
      <Grid item marginTop="12px" width={380}>
        <MuiTypography
          variant="body3"
          color={theme.palette.Text.mediumEmphasis}
        >
          {props.subtitle}
        </MuiTypography>
      </Grid>
      <Grid item marginTop="32px">
        <Grid container flexDirection="row">
          <Grid item marginRight="388px">
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.mediumEmphasis}
            >
              {props.businessAddress}
            </MuiTypography>
          </Grid>
          <Grid item>
            {!editMode && (
              <MuiTypography
                variant="caption1"
                color={theme.palette.primary.primary500}
                onClick={handleEditClick}
                style={{ cursor: 'pointer', textDecoration: 'underline' }}
              >
                {Constants.EDIT}
              </MuiTypography>
            )}
          </Grid>
        </Grid>
      </Grid>
      <Grid item marginTop="20px">
        {editMode ? (
          <EditDetails
            title={props.title}
            subtitle={props.title}
            businessAddress={props.businessAddress}
            businessName={props.businessName}
            registrationNumber={props.registrationNumber}
            registeredAddress={props.registeredAddress}
            businessNameContent={editedContent.businessNameContent}
            registrationNumberContent={editedContent.registrationNumberContent}
            registeredAddressContent={editedContent.registeredAddressContent}
            onCancelClick={handleCancelEdit}
            onSaveClick={handleSaveClick}
            onInputChange={handleInputChange}
            onEditClick={props.onEditClick}
            onUpdateContent={props.onUpdateContent}
            onSaveDetails={props.onSaveDetails}
          />
        ) : (
          <Details
            title={props.title}
            subtitle={props.title}
            businessAddress={props.businessAddress}
            businessName={props.businessName}
            registrationNumber={props.registrationNumber}
            registeredAddress={props.registeredAddress}
            businessNameContent={editedContent.businessNameContent}
            registrationNumberContent={editedContent.registrationNumberContent}
            registeredAddressContent={editedContent.registeredAddressContent}
            onEditClick={handleEditClick}
            onUpdateContent={setEditedContent}
            onCancelClick={props.onCancelClick}
            onSaveClick={props.onSaveClick}
            onInputChange={props.onInputChange}
            onContinueClick={props.onContinueClick}
            onSaveDetails={props.onSaveDetails}
          />
        )}
      </Grid>
    </StyledContainer>
  )
}

export default ConfirmBusinessDetail
