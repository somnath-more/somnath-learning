import { Stack } from '@mui/material'
import theme from 'themes'
import MuiTypography from 'components/atoms/Typography'
import CustomTextField from 'components/atoms/Input'
import { Constants } from 'utils/constants'
import { StyledCancelButton, StyledSaveButton } from 'utils/styles'
import { ReviewInfo } from 'utils/types'
import { useState } from 'react'

interface EditTransferDetailsProps {
  onTransferConfirmationPage: boolean
  setOnTransferConfirmationPage: React.Dispatch<React.SetStateAction<boolean>>
  gbpValue: string
  setGBPValue: React.Dispatch<React.SetStateAction<string>>
  reviewInfo: ReviewInfo[]
}

const EditTransferDetails = ({ ...props }: EditTransferDetailsProps) => {
  const [gbpValue, setGBPValue] = useState('100.00 GBP')

  const handleCancel = () => {
    props.setOnTransferConfirmationPage(!props.onTransferConfirmationPage)
  }

  const handleSave = () => {
    props.setGBPValue(gbpValue)
    props.setOnTransferConfirmationPage(!props.onTransferConfirmationPage)
  }

  const handleCurrencyChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setGBPValue(event.target.value)
  }

  return (
    <>
      <Stack sx={{ width: '800px' }}>
        <Stack
          sx={{
            width: '650px',
            padding: '10px',
          }}
          spacing={8}
        >
          <Stack spacing={7}>
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.lowEmphasis}
              sx={{
                marginBottom: '20px',
              }}
            >
              {Constants.TRANSFER_DETAILS_TITLE}
            </MuiTypography>
            <CustomTextField
              variant="outlined"
              label="Amount"
              value={gbpValue}
              onChange={handleCurrencyChange}
            />
            {props.reviewInfo.map((item) => {
              return (
                <CustomTextField
                  key={item.id}
                  label={item.option}
                  disabled
                  value={item.value}
                />
              )
            })}
          </Stack>
        </Stack>
        <Stack
          direction="row"
          sx={{
            justifyContent: 'flex-end',
            alignItems: 'center',
            marginTop: '35px',
          }}
          spacing={5}
        >
          <StyledCancelButton variant="contained" onClick={handleCancel}>
            {Constants.CANCEL}
          </StyledCancelButton>
          <StyledSaveButton variant="contained" onClick={handleSave}>
            {Constants.SAVE}
          </StyledSaveButton>
        </Stack>
      </Stack>
    </>
  )
}

export default EditTransferDetails
