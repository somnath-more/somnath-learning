import { Stack } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { ReviewInfo } from 'utils/types'

interface TransferDetailsProps {
  gbpValue?: string
  reviewInfo: ReviewInfo[]
}

const TransferDetails = ({ gbpValue, reviewInfo }: TransferDetailsProps) => {
  return (
    <>
      {reviewInfo.map((item) => {
        return (
          <Stack
            key={item.id}
            direction="row"
            sx={{ alignItems: 'center', justifyContent: 'space-between' }}
          >
            <MuiTypography
              variant="body2"
              sx={{ color: theme.palette.Text.mediumEmphasis }}
            >
              {item.option}
            </MuiTypography>
            <MuiTypography
              variant="body2"
              sx={{ color: theme.palette.Text.highEmphasis }}
            >
              {item.option === 'Fee:' ? gbpValue : item.value}
            </MuiTypography>
          </Stack>
        )
      })}
    </>
  )
}
export default TransferDetails
