import { Stack } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { ReviewInfo } from 'utils/types'

interface ScheduleDetailsProps {
  reviewInfo: ReviewInfo[]
}

const ScheduleDetails = ({ reviewInfo }: ScheduleDetailsProps) => {
  return (
    <>
      {reviewInfo.map((item) => {
        return (
          <Stack
            key={item.id}
            direction="row"
            sx={{ alignItems: 'center', justifyContent: 'space-between' }}
          >
            <MuiTypography
              variant="body2"
              sx={{ color: theme.palette.Text.mediumEmphasis }}
            >
              {item.option}
            </MuiTypography>
            <MuiTypography
              variant="body2"
              sx={{ color: theme.palette.Text.highEmphasis }}
            >
              {item.value}
            </MuiTypography>
          </Stack>
        )
      })}
    </>
  )
}
export default ScheduleDetails
