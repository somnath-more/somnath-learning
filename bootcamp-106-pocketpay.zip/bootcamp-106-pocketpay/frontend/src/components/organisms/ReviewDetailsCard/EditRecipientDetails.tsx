import { Stack } from '@mui/material'
import theme from 'themes'
import MuiTypography from 'components/atoms/Typography'
import CustomTextField from 'components/atoms/Input'
import { Constants } from 'utils/constants'
import { ErrorState, RecipientInformation } from 'utils/types'
import { StyledCancelButton, StyledSaveButton } from 'utils/styles'
import { useState } from 'react'
import { validateFieldForRecipientDetails } from 'utils/credentials'

interface EditRecipientDetailsProps {
  onRecipientConfirmationPage: boolean
  setOnRecipientConfirmationPage: React.Dispatch<React.SetStateAction<boolean>>
  recipientData: RecipientInformation
  setRecipientData: React.Dispatch<React.SetStateAction<RecipientInformation>>
}

const EditRecipientDetails = (props: EditRecipientDetailsProps) => {
  const [formData, setFormData] = useState<RecipientInformation>(
    props.recipientData
  )

  const handleCancel = () => {
    props.setOnRecipientConfirmationPage(!props.onRecipientConfirmationPage)
  }

  const handleSubmit = () => {
    props.setRecipientData(formData)
    props.setOnRecipientConfirmationPage(!props.onRecipientConfirmationPage)
  }

  const [errors, setErrors] = useState<ErrorState>({
    email: '',
    account_number: '',
    account_type: '',
    name: '',
  })

  const handleRecipientDataChange = (
    event: React.ChangeEvent<HTMLInputElement>,
    field: keyof RecipientInformation
  ) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      [field]: event.target.value,
    }))

    const error = validateFieldForRecipientDetails(field, event.target.value)

    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: error,
    }))
  }

  return (
    <>
      <Stack sx={{ width: '800px' }}>
        <Stack
          sx={{
            width: '650px',
            padding: '10px',
          }}
          spacing={8}
        >
          <Stack spacing={7}>
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.lowEmphasis}
              sx={{
                marginBottom: '20px',
              }}
            >
              {Constants.BUSINESS_DETAILS}
            </MuiTypography>
            <CustomTextField
              label="Name"
              value={formData.name}
              onChange={(e) => handleRecipientDataChange(e, 'name')}
            />
            {errors.name && (
              <MuiTypography
                variant="caption1"
                color={theme.palette.Text.warning}
                marginTop="8px"
              >
                {errors.name}
              </MuiTypography>
            )}
            <CustomTextField
              label="Email"
              value={formData.email}
              onChange={(e) => handleRecipientDataChange(e, 'email')}
            />
            {errors.email && (
              <MuiTypography
                variant="caption1"
                color={theme.palette.Text.warning}
                marginTop="8px"
              >
                {errors.email}
              </MuiTypography>
            )}
            <CustomTextField
              label="Account number"
              value={formData.account_number}
              onChange={(e) => handleRecipientDataChange(e, 'account_number')}
            />
            {errors.account_number && (
              <MuiTypography
                variant="caption1"
                color={theme.palette.Text.warning}
                marginTop="8px"
              >
                {errors.account_number}
              </MuiTypography>
            )}
            <CustomTextField
              label="Account type"
              value={formData.account_type}
              onChange={(e) => handleRecipientDataChange(e, 'account_type')}
            />
            {errors.account_type && (
              <MuiTypography
                variant="caption1"
                color={theme.palette.Text.warning}
                marginTop="8px"
              >
                {errors.account_type}
              </MuiTypography>
            )}
          </Stack>
        </Stack>
        <Stack
          direction="row"
          sx={{
            justifyContent: 'flex-end',
            alignItems: 'center',
            marginTop: '35px',
          }}
          spacing={5}
        >
          <StyledCancelButton variant="contained" onClick={handleCancel}>
            {Constants.CANCEL}
          </StyledCancelButton>
          <StyledSaveButton variant="contained" onClick={handleSubmit}>
            {Constants.SUBMIT}
          </StyledSaveButton>
        </Stack>
      </Stack>
    </>
  )
}

export default EditRecipientDetails
