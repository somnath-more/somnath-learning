import { Stack } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { RecipientInformation, ReviewInfo } from 'utils/types'

export const getValueByOption = (
  option: string,
  recipientData: RecipientInformation
) => {
  switch (option) {
    case 'Name':
      return recipientData.name
    case 'Email':
      return recipientData.email
    case 'Account number':
      return recipientData.account_number
    case 'Account type':
      return recipientData.account_type
    default:
      return ''
  }
}

interface RecipientDetailsProps {
  recipientData: RecipientInformation
  recipientInfo: ReviewInfo[]
}

const RecipientDetails: React.FC<RecipientDetailsProps> = ({
  recipientData,
  recipientInfo,
}) => {
  return (
    <>
      {recipientInfo.map((item) => {
        const value = getValueByOption(item.option, recipientData)
        return (
          <>
            <Stack
              key={item.id}
              direction="row"
              sx={{ alignItems: 'center', justifyContent: 'space-between' }}
            >
              <MuiTypography
                variant="body2"
                sx={{ color: theme.palette.Text.mediumEmphasis }}
              >
                {item.option}
              </MuiTypography>
              <MuiTypography
                variant="body2"
                sx={{ color: theme.palette.Text.highEmphasis }}
              >
                {value}
              </MuiTypography>
            </Stack>
          </>
        )
      })}
    </>
  )
}
export default RecipientDetails
