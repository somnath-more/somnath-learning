import { StoryFn, Meta } from '@storybook/react'
import ReviewDetailsCard from '.'
import {
  RECIPIENT_DETAILS,
  SCHEDULE_DETAILS,
  TRANSFER_DETAILS,
} from 'utils/constants'

export default {
  title: 'Organisms/Review Details Card',
  component: ReviewDetailsCard,
  argTypes: {
    onClick: {
      action: 'clicked',
    },
  },
} as Meta<typeof ReviewDetailsCard>

const Template: StoryFn<typeof ReviewDetailsCard> = (args) => (
  <ReviewDetailsCard {...args} />
)

export const Default = Template.bind({})
Default.args = {
  eurAmount: '114.68 EUR',
  scheduleInfo: SCHEDULE_DETAILS,
  transferInfo: TRANSFER_DETAILS,
  recipientInfo: RECIPIENT_DETAILS,
}
