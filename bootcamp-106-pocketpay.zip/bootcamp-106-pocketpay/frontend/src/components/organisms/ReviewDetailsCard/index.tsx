import MuiTypography from 'components/atoms/Typography'
import { Box, Stack } from '@mui/material'
import ArrowLeft from 'public/assets/image/arrowLeft.svg'
import MuiIcon from 'components/atoms/Icons'
import RecipientDetails from './RecipientDetails'
import TransferDetails from './TransferDetails'
import ScheduleDetails from './ScheduledDetails'
import { Constants } from 'utils/constants'
import { StyledBox, StyledDetailsBox } from './styles'
import { useState } from 'react'
import theme from 'themes'
import { RecipientInformation, ReviewInfo } from 'utils/types'
import { StyledContinueButton } from 'utils/styles'
import EditTransferDetails from './EditTransferDetails'
import EditRecipientDetails from './EditRecipientDetails'

export interface ReviewDetailsCardProps {
  eurAmount: string
  onContinueClick?: () => void
  scheduleInfo: ReviewInfo[]
  transferInfo: ReviewInfo[]
  recipientInfo: ReviewInfo[]
}

const ReviewDetailsCard = (props: ReviewDetailsCardProps) => {
  const [onTransferConfirmationPage, setOnTransferConfirmationPage] =
    useState(false)
  const [onRecipientConfirmationPage, setOnRecipientConfirmationPage] =
    useState(false)
  const [gbpValue, setGBPValue] = useState('100.00 GBP')

  const [recipientData, setRecipientData] = useState<RecipientInformation>({
    name: 'Mario Gabriel',
    first_name: 'Mario',
    last_name: 'Gabriel',
    email: 'mario.gabriel@gmail.com',
    account_number: '21363738391910',
    account_type: 'checking',
    IFSC_code: '',
  })

  const handleEditTransfer = () => {
    setOnTransferConfirmationPage(!onTransferConfirmationPage)
  }

  const handleEditReview = () => {
    setOnRecipientConfirmationPage(!onRecipientConfirmationPage)
  }

  return (
    <Box>
      <StyledBox>
        <Stack>
          <MuiTypography
            variant="h1"
            sx={{
              color: theme.palette.Text.highEmphasis,
              marginBottom: '25px',
            }}
          >
            {Constants.REVIEW_DETAILS_TITLE}
          </MuiTypography>
          {!onTransferConfirmationPage && !onRecipientConfirmationPage && (
            <>
              <Stack spacing={8}>
                <StyledDetailsBox spacing={2}>
                  <Stack
                    direction="row"
                    sx={{
                      alignItems: 'center',
                      justifyContent: 'space-between',
                    }}
                  >
                    <MuiTypography
                      variant="caption1"
                      sx={{ color: theme.palette.Text.lowEmphasis }}
                    >
                      {Constants.TRANSFER_DETAILS_TITLE}
                    </MuiTypography>
                    <MuiTypography
                      data-testid="Clickable_EditText"
                      variant="linkText"
                      color={`${theme.palette.primary.primary500}`}
                      sx={{
                        textDecoration: 'underline',
                        cursor: 'pointer',
                      }}
                      onClick={handleEditTransfer}
                    >
                      {Constants.EDIT}
                    </MuiTypography>
                  </Stack>

                  <Stack direction="row" alignItems="center" spacing={2}>
                    <MuiTypography
                      variant="body2"
                      sx={{ color: theme.palette.Text.highEmphasis }}
                    >
                      {gbpValue}
                    </MuiTypography>
                    <MuiIcon
                      src={ArrowLeft}
                      alt="Arrow Left Icon"
                      width="24px"
                      height="24px"
                    />
                    <MuiTypography
                      variant="body2"
                      sx={{ color: theme.palette.Text.highEmphasis }}
                    >
                      {props.eurAmount}
                    </MuiTypography>
                  </Stack>

                  <TransferDetails
                    gbpValue={gbpValue}
                    reviewInfo={props.transferInfo}
                  />
                </StyledDetailsBox>

                <StyledDetailsBox spacing={2}>
                  <Stack
                    direction="row"
                    sx={{
                      alignItems: 'center',
                      justifyContent: 'space-between',
                    }}
                  >
                    <MuiTypography
                      variant="caption1"
                      sx={{ color: theme.palette.Text.lowEmphasis }}
                    >
                      {Constants.RECIPIENT_DETAILS}
                    </MuiTypography>
                    <MuiTypography
                      variant="linkText"
                      color={`${theme.palette.primary.primary500}`}
                      sx={{
                        textDecoration: 'underline',
                        cursor: 'pointer',
                      }}
                      onClick={handleEditReview}
                    >
                      {Constants.CHANGE_LINK}
                    </MuiTypography>
                  </Stack>
                  <RecipientDetails
                    recipientData={recipientData}
                    recipientInfo={props.recipientInfo}
                  />
                </StyledDetailsBox>

                <StyledDetailsBox spacing={2}>
                  <Stack
                    direction="row"
                    sx={{
                      alignItems: 'center',
                      justifyContent: 'space-between',
                    }}
                  >
                    <MuiTypography
                      variant="caption1"
                      sx={{ color: theme.palette.Text.lowEmphasis }}
                    >
                      {Constants.SCHEDULE_DETAILS_TILLE}
                    </MuiTypography>
                    <MuiTypography
                      variant="linkText"
                      color={`${theme.palette.primary.primary500}`}
                      sx={{
                        textDecoration: 'underline',
                        cursor: 'pointer',
                      }}
                    >
                      {Constants.EDIT}
                    </MuiTypography>
                  </Stack>
                  <ScheduleDetails reviewInfo={props.scheduleInfo} />
                </StyledDetailsBox>

                <Stack
                  spacing={4}
                  sx={{ justifyContent: 'center', alignItems: 'center' }}
                >
                  <MuiTypography
                    variant="body2"
                    sx={{
                      color: theme.palette.Text.mediumEmphasis,
                      textAlign: 'center',
                      width: '55%',
                    }}
                  >
                    {Constants.TERMS_AND_CONDITIONS}
                  </MuiTypography>
                  <StyledContinueButton
                    variant="contained"
                    onClick={props.onContinueClick}
                  >
                    {Constants.CONFIRM_AND_CONTINUE}
                  </StyledContinueButton>
                </Stack>
              </Stack>
            </>
          )}
        </Stack>
      </StyledBox>
      {onTransferConfirmationPage && (
        <EditTransferDetails
          onTransferConfirmationPage={onTransferConfirmationPage}
          setOnTransferConfirmationPage={setOnTransferConfirmationPage}
          gbpValue={gbpValue}
          setGBPValue={setGBPValue}
          reviewInfo={props.transferInfo}
        />
      )}
      {onRecipientConfirmationPage && (
        <EditRecipientDetails
          onRecipientConfirmationPage={onRecipientConfirmationPage}
          setOnRecipientConfirmationPage={setOnRecipientConfirmationPage}
          recipientData={recipientData}
          setRecipientData={setRecipientData}
        />
      )}
    </Box>
  )
}
export default ReviewDetailsCard
