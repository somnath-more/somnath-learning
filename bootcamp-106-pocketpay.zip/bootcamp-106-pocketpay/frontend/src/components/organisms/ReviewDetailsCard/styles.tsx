import { Box, Stack, styled } from '@mui/material'

export const StyledBox = styled(Box)`
  @media (max-width: 800px) {
    display: flex;
    flex-direction: column;
  }
`

export const StyledDetailsBox = styled(Stack)`
  display: flex;
  @media (max-width: 800px) {
    flex-direction: column;
  }
`
