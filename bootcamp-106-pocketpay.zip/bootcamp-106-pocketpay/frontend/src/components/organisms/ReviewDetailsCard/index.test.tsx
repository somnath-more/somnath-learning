import { fireEvent, render, screen } from '@testing-library/react'
import ReviewDetailsCard from '.'
import {
  ERROR_MESSAGES,
  RECIPIENT_DETAILS,
  SCHEDULE_DETAILS,
  TRANSFER_DETAILS,
} from 'utils/constants'
import { getValueByOption } from './RecipientDetails'

const mockProps = {
  eurAmount: '114.67 EUR',
  scheduleInfo: SCHEDULE_DETAILS,
  transferInfo: TRANSFER_DETAILS,
  recipientInfo: RECIPIENT_DETAILS,
  onContinueClick: jest.fn(),
}

const recipientData = {
  name: 'John Doe',
  first_name: 'John',
  last_name: 'Doe',
  IFSC_code: '',
  email: 'john.doe@example.com',
  account_number: '1234567890',
  account_type: 'Savings',
}

describe('ReviewDetailsCard', () => {
  beforeEach(() => {
    render(<ReviewDetailsCard {...mockProps} />)
  })

  test('it should render the component with correct titles', () => {
    expect(
      screen.getByText('Review details of your transfer')
    ).toBeInTheDocument()
    expect(screen.getByText('Transfer details')).toBeInTheDocument()
    expect(screen.getByText('Recipient details')).toBeInTheDocument()
    expect(screen.getByText('Schedule details')).toBeInTheDocument()
    expect(screen.getByText(mockProps.eurAmount)).toBeInTheDocument()
  })

  test('it should display the edit transfer details form when "Edit" link is clicked and allow to change GBP value', () => {
    fireEvent.click(screen.getByTestId('Clickable_EditText'))
    expect(screen.getByLabelText('Amount')).toBeInTheDocument()

    const saveButton = screen.getByText('Save')
    const textField = screen.getByLabelText('Amount')

    expect(textField).toBeInTheDocument()
    fireEvent.change(textField, { target: { value: '200.00 GBP' } })

    expect(saveButton).toBeInTheDocument()
    fireEvent.click(saveButton)

    const updatedGBPValue = screen.queryAllByText('200.00 GBP')
    expect(updatedGBPValue.length).toBeGreaterThan(1)
  })

  test('it should display the edit transfer details form when "Edit" link is clicked and should not change GBP value when cancel is clicked', () => {
    fireEvent.click(screen.getByTestId('Clickable_EditText'))
    expect(screen.getByLabelText('Amount')).toBeInTheDocument()

    const cancelButton = screen.getByText('Cancel')
    const textField = screen.getByLabelText('Amount')

    expect(textField).toBeInTheDocument()
    fireEvent.change(textField, { target: { value: '200.00 GBP' } })

    expect(cancelButton).toBeInTheDocument()
    fireEvent.click(cancelButton)
  })

  test('it should display the edit recipient details form when "Change" link is clicked and allow to change the text fields', () => {
    fireEvent.click(screen.getByText('Change'))
    expect(screen.getByText('Business details')).toBeInTheDocument()
    const submitButton = screen.getByText('Submit')
    const unknownOption = 'Unknown Option'

    const result = getValueByOption(unknownOption, recipientData)
    expect(result).toBe('')

    const nameTextField = screen.getByLabelText('Name')
    const emailTextField = screen.getByLabelText('Email')
    const accountNumberTextField = screen.getByLabelText('Account number')
    const accountTypeTextField = screen.getByLabelText('Account type')

    expect(nameTextField).toBeInTheDocument()
    expect(emailTextField).toBeInTheDocument()
    expect(accountNumberTextField).toBeInTheDocument()
    expect(accountTypeTextField).toBeInTheDocument()

    const nameValue = 'example'
    const emailInput = 'test@gmail.com'
    const accountNumberInput = '12345678901234'
    const accountTypeInput = 'Checking'

    fireEvent.change(nameTextField, { target: { value: nameValue } })
    fireEvent.change(emailTextField, { target: { value: emailInput } })
    fireEvent.change(accountNumberTextField, {
      target: { value: accountNumberInput },
    })
    fireEvent.change(accountTypeTextField, {
      target: { value: accountTypeInput },
    })

    expect(submitButton).toBeInTheDocument()
    fireEvent.click(submitButton)

    const updatedNameField = screen.getByText(nameValue)
    expect(updatedNameField).toBeInTheDocument()

    const updatedEmailField = screen.getByText(emailInput)
    expect(updatedEmailField).toBeInTheDocument()

    const updatedAccountNumber = screen.getByText(accountNumberInput)
    expect(updatedAccountNumber).toBeInTheDocument()

    const updatedAccountType = screen.getByText(accountTypeInput)
    expect(updatedAccountType).toBeInTheDocument()
  })

  test('it should display the edit recipient details form when "Change" link is clicked and should not allow to change the text fields when cancel is clicked', () => {
    fireEvent.click(screen.getByText('Change'))

    const cancelButton = screen.getByText('Cancel')
    const unknownOption = 'Unknown Option'

    const result = getValueByOption(unknownOption, recipientData)
    expect(result).toBe('')

    const nameTextField = screen.getByLabelText('Name')
    const emailTextField = screen.getByLabelText('Email')
    const accountNumberTextField = screen.getByLabelText('Account number')
    const accountTypeTextField = screen.getByLabelText('Account type')

    expect(nameTextField).toBeInTheDocument()
    expect(emailTextField).toBeInTheDocument()
    expect(accountNumberTextField).toBeInTheDocument()
    expect(accountTypeTextField).toBeInTheDocument()

    const nameValue = 'example'
    const emailInput = 'test@gmail.com'
    const accountNumberInput = '12345678901234'
    const accountTypeInput = 'Checking'

    fireEvent.change(nameTextField, { target: { value: nameValue } })
    fireEvent.change(emailTextField, { target: { value: emailInput } })
    fireEvent.change(accountNumberTextField, {
      target: { value: accountNumberInput },
    })
    fireEvent.change(accountTypeTextField, {
      target: { value: accountTypeInput },
    })

    expect(cancelButton).toBeInTheDocument()
    fireEvent.click(cancelButton)
  })

  test('it should display error messages ', () => {
    fireEvent.click(screen.getByText('Change'))

    const nameTextField = screen.getByLabelText('Name')
    const emailTextField = screen.getByLabelText('Email')
    const accountNumberTextField = screen.getByLabelText('Account number')
    const accountTypeTextField = screen.getByLabelText('Account type')

    expect(nameTextField).toBeInTheDocument()
    expect(emailTextField).toBeInTheDocument()
    expect(accountNumberTextField).toBeInTheDocument()
    expect(accountTypeTextField).toBeInTheDocument()

    const nameValue = '1234'
    const emailInput = 'invalid-email'
    const accountNumberInput = 'account-number'
    const accountTypeInput = '1235'

    fireEvent.change(nameTextField, { target: { value: nameValue } })
    const invalidNameError = screen.getByText(ERROR_MESSAGES.firstName)
    expect(invalidNameError).toBeInTheDocument()

    fireEvent.change(emailTextField, { target: { value: emailInput } })
    const invalidEmailError = screen.getByText(ERROR_MESSAGES.email)
    expect(invalidEmailError).toBeInTheDocument()

    fireEvent.change(accountNumberTextField, {
      target: { value: accountNumberInput },
    })
    const invalidAccountNumberError = screen.getByText(
      ERROR_MESSAGES.accountNumber
    )
    expect(invalidAccountNumberError).toBeInTheDocument()

    fireEvent.change(accountTypeTextField, {
      target: { value: accountTypeInput },
    })
    const invalidAccountTypeError = screen.getByText(ERROR_MESSAGES.accountType)
    expect(invalidAccountTypeError).toBeInTheDocument()
  })
})
