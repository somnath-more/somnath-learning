import { StoryFn, Meta } from '@storybook/react'
import TransferTypeCard from '.'
import { cardData } from 'utils/constants'

export default {
  title: 'Organisms/TransferTypeCard',
  component: TransferTypeCard,
} as Meta

const Template: StoryFn<typeof TransferTypeCard> = (args) => (
  <TransferTypeCard {...args} />
)

export const Primary = Template.bind({})
Primary.args = {
  fastAndEasyCards: cardData.slice(0, 2),
  lowCostCards: [cardData[2]],
  advanceTransferCards: [cardData[3]],
}
