import React from 'react'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import TransferTypeCard from '.'
import { cardData } from 'utils/constants'

const fastAndEasyCards = cardData.slice(0, 2)
const lowCostCards = [cardData[2]]
const advanceTransferCards = [cardData[3]]
describe('TransferTypeCard', () => {
  test('it should select the bank card when clicked', () => {
    render(
      <TransferTypeCard
        fastAndEasyCards={fastAndEasyCards}
        lowCostCards={lowCostCards}
        advanceTransferCards={advanceTransferCards}
      />
    )
    const firstBankcard = screen.getAllByTestId('radio-button')
    fireEvent.click(firstBankcard[0])
    waitFor(() => {
      expect(firstBankcard[0]).toHaveBeenCalledTimes(1)
    })
  })

  test('it should render TransferTypeCard component', () => {
    render(
      <TransferTypeCard
        fastAndEasyCards={advanceTransferCards}
        lowCostCards={advanceTransferCards}
        advanceTransferCards={advanceTransferCards}
      />
    )
  })
})
