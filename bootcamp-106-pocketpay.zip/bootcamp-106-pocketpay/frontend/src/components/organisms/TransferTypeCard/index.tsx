import React, { useState } from 'react'
import { Stack, styled } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import Bankcard from 'components/molecules/Bankcard'
import theme from 'themes'
import {
  ADVANCE_TRANSFER,
  CHOOSE_TRANSFER_TYPE,
  FAST_EASY_TRANSFER,
  LOW_COST,
} from 'utils/constants'
import { CardDataProps } from 'utils/types'

interface TransferTypeCardProps {
  fastAndEasyCards: CardDataProps[]
  lowCostCards: CardDataProps[]
  advanceTransferCards: CardDataProps[]
  onCardSelected?: (cardId: number) => void
}

const StyledBox = styled(Stack)({
  width: '516px',
  alignItems: 'center',
  justifyContent: 'space-between',
  padding: '14px 20px',
  cursor: 'pointer',
  '&:hover': {
    backgroundColor: `${theme.palette.Structural.cardHover}`,
  },
})

const TransferTypeCard = (props: TransferTypeCardProps) => {
  const [selectedOption, setSelectedOption] = useState<number>()

  const handleCardClick = (cardId: number) => {
    setSelectedOption(cardId)
    if (props.onCardSelected) {
      props.onCardSelected(cardId)
    }
  }

  const renderBankcards = (cards: CardDataProps[]) => {
    return cards.map((card) => {
      const isClickable =
        card.heading !== 'Credit card' && card.heading !== 'SWIFT Transfer'

      return (
        <>
          <StyledBox>
            <Bankcard
              data-testid={'radio-button'}
              key={card.heading}
              {...card}
              checked={selectedOption === card.id}
              onClick={isClickable ? () => handleCardClick(card.id) : () => {}}
            />
          </StyledBox>
        </>
      )
    })
  }

  const typographyStyles = {
    margin: '32px 0 12px',
  }

  return (
    <Stack width={'500px'}>
      <MuiTypography variant="h1" color={theme.palette.Text.highEmphasis}>
        {CHOOSE_TRANSFER_TYPE}
      </MuiTypography>

      <MuiTypography
        variant="caption1"
        color={theme.palette.Text.mediumEmphasis}
        style={typographyStyles}
      >
        {FAST_EASY_TRANSFER}
      </MuiTypography>

      <Stack gap={'28px'} marginLeft={'16px'}>
        {renderBankcards(props.fastAndEasyCards)}
      </Stack>

      <MuiTypography
        variant="caption1"
        marginTop={'20px'}
        color={theme.palette.Text.mediumEmphasis}
        style={typographyStyles}
      >
        {LOW_COST}
      </MuiTypography>
      <Stack marginLeft={'16px'} marginTop={'28px'}>
        {renderBankcards(props.lowCostCards)}
      </Stack>
      <MuiTypography
        variant="caption1"
        marginTop={'36px'}
        color={theme.palette.Text.mediumEmphasis}
        style={typographyStyles}
      >
        {ADVANCE_TRANSFER}
      </MuiTypography>
      <Stack marginLeft={'16px'} marginTop={'28px'}>
        {renderBankcards(props.advanceTransferCards)}
      </Stack>
    </Stack>
  )
}

export default TransferTypeCard
