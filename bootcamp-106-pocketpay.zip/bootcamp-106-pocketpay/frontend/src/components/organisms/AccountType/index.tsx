import { AccountTypeDataProps } from 'utils/types'
import { Box, Grid, styled } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import AccountCard from 'components/molecules/AccountCard'
import _ from 'lodash'

export interface AccountTypeProps {
  header: string
  subHeading: string
  onClick: () => void
  accountTypeData: AccountTypeDataProps[]
}

const StyledContainer = styled(Grid)({
  display: 'inline-flex',
  paddingRight: '0px',
  flexDirection: 'column',
  justifyContent: 'flex-end',
  alignItems: 'flex-start',
  gap: '40px',
})

const AccountType = (props: AccountTypeProps) => {
  return (
    <StyledContainer container>
      <Grid item sx={{ width: '516px' }}>
        <MuiTypography
          variant="h1"
          color={theme.palette.Text.highEmphasis}
          sx={{ marginBottom: '10px' }}
        >
          {props.header}
        </MuiTypography>
        <MuiTypography
          variant="body3"
          color={theme.palette.Text.mediumEmphasis}
        >
          {props.subHeading}
        </MuiTypography>
      </Grid>

      <Grid container spacing="20px" direction={'column'}>
        {props.accountTypeData.map((data, index) => (
          <Grid item key={data.id}>
            {data.text == 'Business account' ? (
              <Box onClick={props.onClick}>
                <AccountCard
                  icon={data.icon}
                  iconAlt={data.iconAlt}
                  text={data.text}
                  subText={_.get(data, 'subText', '')}
                />
              </Box>
            ) : (
              <AccountCard
                icon={data.icon}
                iconAlt={data.iconAlt}
                text={data.text}
                subText={_.get(data, 'subText', '')}
              />
            )}
          </Grid>
        ))}
      </Grid>
    </StyledContainer>
  )
}

export default AccountType
