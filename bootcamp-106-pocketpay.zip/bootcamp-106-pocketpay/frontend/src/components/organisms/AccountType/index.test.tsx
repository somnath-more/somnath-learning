import React from 'react'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import AccountType from '.'

describe('AccountType component', () => {
  const mockOnClick = jest.fn()
  const mockAccountTypeData = [
    {
      id: 1,
      icon: 'icon1',
      iconAlt: 'Icon 1',
      text: 'Account Type 1',
      subText: 'Subtext 1',
    },
    {
      id: 2,
      icon: 'icon2',
      iconAlt: 'Icon 2',
      text: 'Account Type 2',
      subText: 'Subtext 2',
    },
  ]

  const defaultProps = {
    header: 'Header Text',
    subHeading: 'Subheading Text',
    onClick: mockOnClick,
    accountTypeData: mockAccountTypeData,
  }

  it('renders header and subheading correctly', () => {
    render(<AccountType {...defaultProps} />)

    expect(screen.getByText('Header Text')).toBeInTheDocument()
    expect(screen.getByText('Subheading Text')).toBeInTheDocument()
  })

  it('renders account type cards with correct data', () => {
    render(<AccountType {...defaultProps} />)

    mockAccountTypeData.forEach((data) => {
      expect(screen.getByText(data.text)).toBeInTheDocument()
      expect(screen.getByText(data.subText)).toBeInTheDocument()
      expect(screen.getByAltText(data.iconAlt)).toBeInTheDocument()
    })
  })

  it('calls onClick when an account type card is clicked', () => {
    render(<AccountType {...defaultProps} />)

    const accountTypeCard = screen.getByText('Account Type 1')
    userEvent.click(accountTypeCard)

    expect(mockOnClick).toHaveBeenCalledTimes(0)
  })
})
