import { StoryFn, Meta } from '@storybook/react'
import { action } from '@storybook/addon-actions'
import AccountType from '.'
import { ACCOUNT_TYPE, accountTypeData } from 'utils/constants'

const meta: Meta = {
  title: 'Organisms/Account Type',
  component: AccountType,
}
export default meta

const Template: StoryFn<typeof AccountType> = (args) => (
  <AccountType {...args} />
)

export const AccountTypeData = Template.bind({})

AccountTypeData.args = {
  header: ACCOUNT_TYPE.QUESTION,
  subHeading: ACCOUNT_TYPE.SUGGESTION,
  accountTypeData: accountTypeData,
  onClick: action('Option is Clicked'),
}
