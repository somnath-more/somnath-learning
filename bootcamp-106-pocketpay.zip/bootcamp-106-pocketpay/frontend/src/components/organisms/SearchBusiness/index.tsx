import { ChangeEvent, useState } from 'react'
import Autocomplete from '@mui/material/Autocomplete'
import SearchIcon from '@mui/icons-material/Search'
import {
  BUSINESS_SEARCH,
  CANT_FIND_BUSINESS,
  ENTER_YOUR_DETAILS,
  SEARCH_BUSINESS_CAPTION,
  SEARCH_BUSINESS_TITLE,
} from 'utils/constants'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { Divider, Grid, Stack } from '@mui/material'
import CustomTextField from 'components/atoms/Input'

interface SearchBusinessProp {
  handleSearchNext: (str: string) => void
}

const SearchBusiness = (props: SearchBusinessProp) => {
  const [open, setOpen] = useState(false)
  const [selectedOption, setSelectedOption] = useState('')

  const handleToggle = () => {
    setOpen((prevOpen) => !prevOpen)
  }

  const handleChange = (event: ChangeEvent<{}>, newValue: any) => {
    setSelectedOption(newValue)
    props.handleSearchNext(newValue.label)
  }

  return (
    <>
      <Grid container flexDirection="column" width="650px" spacing={3}>
        <Grid item>
          <MuiTypography variant="h1" color={theme.palette.Text.highEmphasis}>
            {SEARCH_BUSINESS_TITLE}
          </MuiTypography>
        </Grid>
        <Grid item>
          <MuiTypography
            variant="body3"
            color={theme.palette.Text.mediumEmphasis}
          >
            {SEARCH_BUSINESS_CAPTION}
          </MuiTypography>
        </Grid>

        <Grid item marginTop="35px">
          <Autocomplete
            open={open}
            data-testid={'autocomplete-dropdown'}
            onOpen={handleToggle}
            onClose={handleToggle}
            onChange={handleChange}
            options={BUSINESS_SEARCH}
            getOptionLabel={(option) => option.label}
            filterOptions={(options, { inputValue }) => {
              const filteredOptions = options.filter((option) =>
                option.label.toLowerCase().includes(inputValue.toLowerCase())
              )
              return filteredOptions.length > 0 ? filteredOptions : options
            }}
            renderOption={(props, option) => {
              const label = option.label
              const parts = label.split('?')
              const isGrey = parts[0] === CANT_FIND_BUSINESS
              const isPurple = parts[1] === ENTER_YOUR_DETAILS

              return (
                <>
                  {option === BUSINESS_SEARCH[BUSINESS_SEARCH.length - 1] ? (
                    <Divider />
                  ) : null}
                  <li
                    {...props}
                    style={{
                      cursor: option.disabled ? 'not-allowed' : 'pointer',
                    }}
                    data-testid="business-options"
                  >
                    <Stack display="flex" flexDirection="row">
                      <MuiTypography
                        color={
                          isGrey ? theme.palette.Text.mediumEmphasis : 'black'
                        }
                      >
                        {isGrey ? `${parts[0]}?` : `${parts[0]}`}
                      </MuiTypography>
                      {isPurple && (
                        <MuiTypography color={theme.palette.primary.primary500}>
                          &nbsp;{parts[1]}
                        </MuiTypography>
                      )}
                    </Stack>
                  </li>
                </>
              )
            }}
            renderInput={(params) => (
              <div style={{ width: '516px' }}>
                <CustomTextField
                  {...params}
                  label="Search your business"
                  variant="outlined"
                  style={{
                    borderColor: theme.palette.Structural.white,
                  }}
                  InputProps={{
                    ...params.InputProps,
                    endAdornment: (
                      <SearchIcon
                        data-testid="search-icon"
                        onClick={handleToggle}
                        style={{
                          cursor: 'pointer',
                          color: theme.palette.Text.lowEmphasis,
                        }}
                      />
                    ),
                  }}
                />
              </div>
            )}
          />
        </Grid>
      </Grid>
    </>
  )
}

export default SearchBusiness
