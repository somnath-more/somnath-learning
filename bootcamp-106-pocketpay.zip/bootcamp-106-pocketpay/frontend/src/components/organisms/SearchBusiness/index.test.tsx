import { render, fireEvent } from '@testing-library/react'
import SearchBusiness from '.'
import { SEARCH_BUSINESS_CAPTION, SEARCH_BUSINESS_TITLE } from 'utils/constants'

const props = {
  handleSearchNext: jest.fn(),
}

describe('SearchBUSINESS component', () => {
  test('it should call handleChange with the selected option label', () => {
    const { getByLabelText, getAllByTestId, getByTestId } = render(
      <SearchBusiness {...props} />
    )

    const searchInput = getByLabelText('Search your business')
    fireEvent.change(searchInput, {
      target: { value: 'Zemoso technologies pvt ltd' },
    })

    const dropdown = getByTestId('autocomplete-dropdown')
    fireEvent.mouseDown(dropdown)

    const option = getAllByTestId('business-options')
    fireEvent.click(option[0])

    expect(props.handleSearchNext).toHaveBeenCalledWith(
      'Zemoso technologies pvt ltd'
    )
  })

  test('it should render the title and caption correctly', () => {
    const { getByText } = render(<SearchBusiness {...props} />)
    const titleElement = getByText(SEARCH_BUSINESS_TITLE)
    expect(titleElement).toBeInTheDocument()
    const captionElement = getByText(SEARCH_BUSINESS_CAPTION)
    expect(captionElement).toBeInTheDocument()
  })

  test('it should render the search input correctly', () => {
    const { getByLabelText } = render(<SearchBusiness {...props} />)
    const searchInput = getByLabelText('Search your business')
    expect(searchInput).toBeInTheDocument()
  })

  test('it should open the dropdown on search icon click', () => {
    const { getByLabelText, getByTestId } = render(
      <SearchBusiness {...props} />
    )

    const searchInput = getByLabelText('Search your business')
    expect(searchInput).toBeInTheDocument()

    const searchIcon = getByTestId('search-icon')
    fireEvent.click(searchIcon)

    const dropdown = getByTestId('autocomplete-dropdown')
    expect(dropdown).toBeInTheDocument()
  })

  test('it should filter options based on user input', () => {
    const { getByLabelText } = render(<SearchBusiness {...props} />)
    const searchInput = getByLabelText('Search your business')
    fireEvent.click(searchInput)
    fireEvent.change(searchInput, { target: { value: 'some text' } })
  })
})
