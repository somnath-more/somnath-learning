import { StoryFn, Meta } from '@storybook/react'
import SearchBusiness from '.'

export default {
  title: 'Organisms/SearchBusiness',
  component: SearchBusiness,
} as Meta

const Template: StoryFn = (args) => <SearchBusiness {...args} />

export const Default = Template.bind({})
Default.args = {}
