import { render, screen } from '@testing-library/react'
import TranferOptions, { TranferOptionsProps } from '.'
import Dollar from 'public/assets/image/Dollar.svg'
import SendMoneyIcon from 'public/assets/image/Unionsendicon.svg'
import { Constants } from 'utils/constants'

const mockProps: TranferOptionsProps = {
  header: 'Test Header',
  onClick: jest.fn(),
  transferOptionData: [
    {
      id: 1,
      icon: Dollar,
      iconAlt: 'Dollar not found',
      text: Constants.BUSINESS_OR_CHARITY,
      subText: '',
    },
    {
      id: 2,
      icon: SendMoneyIcon,
      iconAlt: 'Send Money not found',
      text: Constants.SEND_MONEY,
      subText: Constants.SEND_MONEY_SUBTEXT,
    },
  ],
}

describe('TranferOptions', () => {
  test('it should render the header correctly', () => {
    render(<TranferOptions {...mockProps} />)

    const questionElement = screen.getByText(mockProps.header)
    expect(questionElement).toBeInTheDocument()
  })

  test('it should render the account card with subtext correctly', () => {
    render(<TranferOptions {...mockProps} />)

    const subTextElement = screen.getByText(
      mockProps.transferOptionData[1].subText
    )
    expect(subTextElement).toBeInTheDocument()
  })
})
