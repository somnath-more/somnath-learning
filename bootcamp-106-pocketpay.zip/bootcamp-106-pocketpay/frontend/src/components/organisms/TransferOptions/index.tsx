import { AccountDataProps } from 'utils/types'
import { Box, Grid, styled } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import AccountCard from 'components/molecules/AccountCard'
import _ from 'lodash'

export interface TranferOptionsProps {
  header: string
  handleSendMoney: () => void
  handleSetUp?: () => void
  transferOptionData: AccountDataProps[]
}

const StyledContainer = styled(Grid)({
  display: 'inline-flex',
  paddingRight: '0px',
  flexDirection: 'column',
  justifyContent: 'flex-end',
  alignItems: 'flex-start',
  gap: '40px',
})

const TranferOptions = (props: TranferOptionsProps) => {
  return (
    <StyledContainer container>
      <Grid item>
        <MuiTypography variant="h1" color={theme.palette.Text.highEmphasis}>
          {props.header}
        </MuiTypography>
      </Grid>
      <Grid container spacing="20px" direction={'column'}>
        {props.transferOptionData.map((data, index) => (
          <Grid item key={data.id}>
            {data.text === 'Business or Charity' ||
            data.text === 'Send Money' ? (
              <Box onClick={props.handleSendMoney}>
                <AccountCard
                  icon={data.icon}
                  iconAlt={data.iconAlt}
                  text={data.text}
                  subText={_.get(data, 'subText', '')}
                />
              </Box>
            ) : (
              <Box onClick={props.handleSetUp}>
                <AccountCard
                  icon={data.icon}
                  iconAlt={data.iconAlt}
                  text={data.text}
                  subText={_.get(data, 'subText', '')}
                />
              </Box>
            )}
          </Grid>
        ))}
      </Grid>
    </StyledContainer>
  )
}

export default TranferOptions
