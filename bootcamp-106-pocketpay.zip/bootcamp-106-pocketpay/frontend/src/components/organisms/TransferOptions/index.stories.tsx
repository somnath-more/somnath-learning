import { StoryFn, Meta } from '@storybook/react'
import { action } from '@storybook/addon-actions'
import TranferOptions from '.'
import {
  TRANSFER_OPTIONS,
  accountData,
  recipientSelectData,
} from 'utils/constants'

const meta: Meta = {
  title: 'Organisms/Transfer Options',
  component: TranferOptions,
}
export default meta

const Template: StoryFn<typeof TranferOptions> = (args) => (
  <TranferOptions {...args} />
)

export const AccountData = Template.bind({})
export const RecipientSelectData = Template.bind({})

AccountData.args = {
  header: TRANSFER_OPTIONS.INTENT_QUESTION,
  transferOptionData: accountData,
  onClick: action('Option is Clicked'),
}

RecipientSelectData.args = {
  header: TRANSFER_OPTIONS.RECIPIENT_QUESTION,
  transferOptionData: recipientSelectData,
  onClick: action('Option is Clicked'),
}
