import { Link, Stack } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import { Constants, MOBILE_NUMBER_DROPDOWN } from 'utils/constants'
import ResendBox from './ResendBox'
import theme from 'themes'
import { useState } from 'react'
import Authentication from '.'
import { StyledStack } from './styles'

interface ApproveOtherWayProps {
  phoneNo: string
}
const ApproveOtherWay = (props: ApproveOtherWayProps) => {
  const [hasMobile, setHasMobile] = useState(false)
  const handleShowMobile = () => {
    setHasMobile(!hasMobile)
  }

  return (
    <>
      {hasMobile ? (
        <Authentication
          title={Constants.VERIFY_PHONE_NUMBER_WITH_CODE}
          subtitle={Constants.ACCOUNT_SECURE}
          phoneNo={props.phoneNo}
          countryCodes={MOBILE_NUMBER_DROPDOWN}
        />
      ) : (
        <StyledStack>
          <Stack>
            <MuiTypography
              variant="h1"
              sx={{
                color: theme.palette.Text.highEmphasis,
                marginBottom: '15px',
              }}
            >
              {Constants.APPROVE_ANOTHER_WAY}
            </MuiTypography>
            <MuiTypography
              variant="body3"
              sx={{
                color: theme.palette.Text.mediumEmphasis,
                marginBottom: '30px',
              }}
            >
              {Constants.WE_SENT_TO} {props.phoneNo}
            </MuiTypography>
            <ResendBox resendHeading={Constants.RESEND_CODE} />
            <ResendBox resendHeading={Constants.VOICE_CALL} />
            <Link
              variant="inherit"
              underline="always"
              sx={{
                color: theme.palette.primary.primary500,
                cursor: 'pointer',
                marginTop: '20px',
              }}
              onClick={handleShowMobile}
            >
              {Constants.USE_DIFFERENT_PHN_NO}
            </Link>
          </Stack>
        </StyledStack>
      )}
    </>
  )
}
export default ApproveOtherWay
