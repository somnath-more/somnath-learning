import { Stack, styled } from '@mui/material'

export const StyledStack = styled(Stack)({
  width: '650px',
  gap: '315px',
  padding: '10px',
  marginLeft: '160px'
})
