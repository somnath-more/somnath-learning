import { fireEvent, render, screen } from '@testing-library/react'
import VerifyMobile from '.'
import { Constants, MOBILE_NUMBER_DROPDOWN } from 'utils/constants'

const mockProps = {
  title: 'Verify your phone number with a code',
  subtitle: 'It helps us keep your account secure.',
  countryCodes: MOBILE_NUMBER_DROPDOWN,
  phoneNo: 8923454657788,
}

describe('Authentication', () => {
  test('it should render the component with title and subtitle', () => {
    const { getByText } = render(<VerifyMobile {...mockProps} />)

    const titleElement = getByText(mockProps.title)
    const subtitleElement = getByText(mockProps.subtitle)

    expect(titleElement).toBeInTheDocument()
    expect(subtitleElement).toBeInTheDocument()
  })

  test('it should render authentication and approve another way on clicking the continue button and the link text', () => {
    render(<VerifyMobile {...mockProps} />)

    const continueButton = screen.getByText(Constants.CONTINUE)

    const mobileNumber = screen.getByLabelText("Mobile number")
    fireEvent.change(mobileNumber, { target: { value: '+441234567890' } })
    expect(continueButton).toBeInTheDocument()
    fireEvent.click(continueButton)
    const code = screen.getByText('Enter the 6-digit code')
    expect(code).toBeInTheDocument()

    const submitButton = screen.getByText('Submit')
    expect(submitButton).toBeInTheDocument()
    expect(submitButton).toBeDisabled

    const inputValue = '123456'
    const textField = screen.getByPlaceholderText('Enter code here')
    fireEvent.change(textField, { target: { value: inputValue } })

    const expectedValue = inputValue
    expect(textField).toHaveValue(expectedValue)
    expect(submitButton).toBeEnabled

    const inputCodeValue = 'abcd1234'
    const inputField = screen.getByPlaceholderText('Enter code here')
    fireEvent.change(inputField, { target: { value: inputCodeValue } })

    const expectedCodeValue = inputCodeValue
    expect(inputField).toHaveValue(expectedCodeValue)
    expect(submitButton).toBeDisabled

    const button = screen.getByText('I didn’t recieve a code')
    expect(button).toBeInTheDocument()
    fireEvent.click(button)
    const element = screen.getByText('Approve another way')
    expect(element).toBeInTheDocument()

    const linkText = screen.getByText('Use a different phone number')
    expect(linkText).toBeInTheDocument()
    fireEvent.click(linkText)
    const title = screen.getByText(mockProps.title)
    expect(title).toBeInTheDocument()
    const subtitle = screen.getByText(mockProps.subtitle)
    expect(subtitle).toBeInTheDocument()
  })
})
