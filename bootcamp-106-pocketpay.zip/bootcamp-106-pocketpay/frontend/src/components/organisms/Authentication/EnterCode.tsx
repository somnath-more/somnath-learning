import { Link, Stack } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import CustomTextField from 'components/atoms/Input'
import theme from 'themes'
import { Constants } from 'utils/constants'
import ApproveOtherWay from './ApproveOtherWay'
import { useState } from 'react'
import { StyledStack } from './styles'
import { StyledSaveButton } from 'utils/styles'

interface EnterCodeProps {
  phoneNo: string 
  handleSubmit?: () => void
}

const EnterCode = (props: EnterCodeProps) => {
  const [codeValue, setCodeValue] = useState('')
  const [showOtherWay, setShowOtherWay] = useState(false)

  const handleCodeChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const input = event.target.value
    const sixDigitNumber = /^\d{6}$/

    if (sixDigitNumber.test(input)) {
      setCodeValue(input)
    } else {
      setCodeValue('')
    }
  }
  const handleShowOtherWay = () => {
    setShowOtherWay(!showOtherWay)
  }

  return (
    <>
      {showOtherWay ? (
        <ApproveOtherWay phoneNo={props.phoneNo} />
      ) : (
        <StyledStack>
          <Stack>
            <MuiTypography
              variant="h1"
              sx={{
                color: theme.palette.Text.highEmphasis,
                marginBottom: '15px',
              }}
            >
              {Constants.ENTER_SIX_DIGIT_CODE}
            </MuiTypography>
            <MuiTypography
              variant="body3"
              sx={{
                color: theme.palette.Text.mediumEmphasis,
                marginBottom: '30px',
              }}
            >
              {Constants.WE_SENT_TO} {props.phoneNo}
            </MuiTypography>

            <CustomTextField
              label="6-digit code"
              placeholder="Enter code here"
              sx={{ width: '516px' }}
              type="text"
              onChange={handleCodeChange}
            />

            <Link
              variant="inherit"
              underline="always"
              sx={{
                color: theme.palette.primary.primary500,
                cursor: 'pointer',
                marginTop: '20px',
              }}
              onClick={handleShowOtherWay}
            >
              {Constants.CODE_NOT_RECEIVED}
            </Link>
          </Stack>

          <Stack alignItems="flex-end">
            <StyledSaveButton
              variant="contained"
              disabled={codeValue.length != 6}
              onClick={props.handleSubmit}
            >
              {Constants.SUBMIT}
            </StyledSaveButton>
          </Stack>
        </StyledStack>
      )}
    </>
  )
}
export default EnterCode
