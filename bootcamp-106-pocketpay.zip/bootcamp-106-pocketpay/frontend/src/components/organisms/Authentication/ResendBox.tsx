import { Stack, styled } from '@mui/material'
import MuiIcon from 'components/atoms/Icons'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import ArrowRight from 'public/assets/image/Arrowright.svg'

interface ResendBoxProps {
  resendHeading: string
}
const StyledResendBox = styled(Stack)({
  width: '516px',
  alignItems: 'center',
  justifyContent: 'space-between',
  padding: '14px 20px',
  cursor: 'pointer',
  '&:hover': {
    backgroundColor: `${theme.palette.Structural.cardHover}`,
    color: '#fff',
  },
})
const ResendBox = ({ resendHeading }: ResendBoxProps) => {
  return (
    <>
      <StyledResendBox direction="row">
        <MuiTypography
          variant="caption1"
          sx={{ color: theme.palette.Text.highEmphasis }}
        >
          {resendHeading}
        </MuiTypography>
        <MuiIcon src={ArrowRight} alt="Arrow Icon" />
      </StyledResendBox>
    </>
  )
}

export default ResendBox
