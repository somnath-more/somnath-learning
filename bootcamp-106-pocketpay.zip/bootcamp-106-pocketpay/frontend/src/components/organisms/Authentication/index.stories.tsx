import { StoryFn, Meta } from '@storybook/react'
import VerifyMobile from '.'
import { Constants, MOBILE_NUMBER_DROPDOWN } from 'utils/constants'

export default {
  title: 'Organisms/Authentication',
  component: VerifyMobile,
} as Meta<typeof VerifyMobile>

const Template: StoryFn<typeof VerifyMobile> = (args) => (
  <VerifyMobile {...args} />
)

export const Default = Template.bind({})
Default.args = {
  title: Constants.VERIFY_PHONE_NUMBER_WITH_CODE,
  subtitle: Constants.ACCOUNT_SECURE,
  countryCodes: MOBILE_NUMBER_DROPDOWN,
  phoneNo: 8923454657788,
}
