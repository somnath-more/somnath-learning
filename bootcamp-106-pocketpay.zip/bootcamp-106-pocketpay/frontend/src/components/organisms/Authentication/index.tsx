import { Stack } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import { useState } from 'react'
import theme from 'themes'
import { Constants } from 'utils/constants'
import AvatarDropdown from 'components/molecules/AvatarDropdown'
import { CountryProps } from 'utils/types'
import EnterCode from './EnterCode'
import { StyledStack } from './styles'
import { StyledContinueButton } from 'utils/styles'

interface AuthenticationProps {
  title: string
  subtitle: string
  countryCodes: CountryProps[]
  phoneNo: string
  onClick?: () => void
  saveMobileNumber?: (data: string) => void
}
const Authentication = (props: AuthenticationProps) => {
  const [hasContinue, setHasContinue] = useState(false)
  const [isButtonDisable, setIsButtonDisable] = useState(true)
  const handleContinueButton = () => {
    setHasContinue(!hasContinue)
  }

  const handleMobileNumberChange = (isValid: boolean) => {
    setIsButtonDisable(!isValid)
  }

  return (
    <>
      {hasContinue ? (
        <EnterCode phoneNo={props.phoneNo} handleSubmit={props.onClick} />
      ) : (
        <StyledStack>
          <Stack>
            <MuiTypography
              variant="h1"
              sx={{
                color: theme.palette.Text.highEmphasis,
                marginBottom: '15px',
              }}
            >
              {props.title}
            </MuiTypography>
            <MuiTypography
              variant="body3"
              sx={{
                color: theme.palette.Text.mediumEmphasis,
                marginBottom: '40px',
              }}
            >
              {props.subtitle}
            </MuiTypography>
            <AvatarDropdown
              onMobileNumberChange={handleMobileNumberChange}
              countriesName={props.countryCodes}
              saveMobileNumber={props.saveMobileNumber}
            />
          </Stack>
          <Stack alignItems="flex-end">
            <StyledContinueButton
              variant="contained"
              onClick={handleContinueButton}
              disabled={isButtonDisable}
            >
              {Constants.CONTINUE}
            </StyledContinueButton>
          </Stack>
        </StyledStack>
      )}
    </>
  )
}
export default Authentication
