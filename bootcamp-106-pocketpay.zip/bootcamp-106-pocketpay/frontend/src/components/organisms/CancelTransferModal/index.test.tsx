import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import CancelTransferModal, { ModalProps } from '.'
import {
  CANCEL_TRANFER_MODAL,
  accountOptions,
  selectExistingAccount,
} from 'utils/constants'

const mockProps: ModalProps = {
  open: true,
  refundMoney: CANCEL_TRANFER_MODAL.REFUND_MONEY,
  header: CANCEL_TRANFER_MODAL.HEADER,
  existingAccounts: selectExistingAccount,
  onClick: jest.fn(),
}

describe('CancelTransferModal', () => {
  test('it should render the modal header and refund money correctly', () => {
    render(<CancelTransferModal {...mockProps} />)

    const modalHeader = screen.getByText(mockProps.header)
    const refundMoneyText = screen.getByText(mockProps.refundMoney)

    expect(modalHeader).toBeInTheDocument()
    expect(refundMoneyText).toBeInTheDocument()
  })

  test('it should disable the second dropdown when "Select account" is selected', () => {
    render(<CancelTransferModal {...mockProps} />)

    const selectAccountDropdown = screen.getByLabelText(
      CANCEL_TRANFER_MODAL.SELECT_ACCOUNT_LABEL
    )
    const selectOptionDropdown = screen.getByLabelText(
      CANCEL_TRANFER_MODAL.SELECT_OPTION_LABEL
    )

    expect(selectOptionDropdown).toBeDisabled()

    fireEvent.change(selectAccountDropdown, {
      target: { value: accountOptions[0].label },
    })

    waitFor(() => {
      expect(selectOptionDropdown).not.toBeDisabled()
    })

    fireEvent.change(selectAccountDropdown, {
      target: { value: accountOptions[1].label },
    })

    expect(selectOptionDropdown).toBeDisabled()
  })

  test('it should toggle modal visibility when "Select account" changes', () => {
    render(<CancelTransferModal {...mockProps} />)

    const selectAccountDropdown = screen.getByLabelText(
      CANCEL_TRANFER_MODAL.SELECT_ACCOUNT_LABEL
    )

    fireEvent.change(selectAccountDropdown, {
      target: { value: accountOptions[1].label },
    })

    waitFor(() => {
      expect(
        screen.queryByLabelText(CANCEL_TRANFER_MODAL.SELECT_OPTION_LABEL)
      ).toBeInTheDocument()
    })

    fireEvent.change(selectAccountDropdown, {
      target: { value: accountOptions[0].label },
    })

    waitFor(() => {
      expect(
        screen.queryByLabelText(CANCEL_TRANFER_MODAL.SELECT_OPTION_LABEL)
      ).toBeInTheDocument()
    })
  })

  test('it should update the selected account state when "Select an option" changes', () => {
    render(<CancelTransferModal {...mockProps} />)

    const cancelButton = screen.getAllByRole('button', { name: 'Open' })
    fireEvent.click(cancelButton[0])
    waitFor(() => {
      expect(cancelButton).toHaveBeenCalledTimes(1)
    })

    const selectOption = screen.getByText(accountOptions[0].label)
    fireEvent.click(selectOption)
    waitFor(() => {
      expect(selectOption).toHaveBeenCalledTimes(1)
    })

    const selectOptionLabel = screen.getByLabelText(
      CANCEL_TRANFER_MODAL.SELECT_OPTION_LABEL
    )
    expect(selectOptionLabel).toBeInTheDocument()

    fireEvent.keyDown(selectOptionLabel, {
      key: 'ArrowDown',
    })
    fireEvent.keyDown(selectOptionLabel, {
      key: 'ArrowDown',
    })
    fireEvent.keyDown(selectOptionLabel, {
      key: 'Enter',
    })

    waitFor(() => {
      expect(mockProps.onClick).toHaveBeenCalledTimes(1)
    })
  })
})
