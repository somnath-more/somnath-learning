import React, { useState } from 'react'
import { Grid, Modal } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { modalStyle, selectContainer } from './style'
import MuiDropdown, { OptionItem } from 'components/atoms/Dropdown'
import { StyledContinueButton } from 'utils/styles'
import {
  CANCEL_TRANFER_MODAL,
  Constants,
  accountOptions,
} from 'utils/constants'
import _ from 'lodash'

export interface ModalProps {
  open: boolean
  refundMoney: string
  header: string
  existingAccounts: OptionItem[]
  onClick: () => void
  onClose: () => void
}

const CancelTransferModal: React.FC<ModalProps> = ({
  open,
  refundMoney,
  header,
  existingAccounts,
  onClick,
  onClose,
}) => {
  const [selectedAccount, setSelectedAccount] = useState<OptionItem | null>(
    null
  )
  const [isOptionDropdownDisabled, setIsOptionDropdownDisabled] = useState(true)

  const handleAccountChange = (value: OptionItem | null) => {
    setIsOptionDropdownDisabled(
      !_.isEqual(value?.label, accountOptions[0].label)
    )
  }

  const handleSelect = (value: OptionItem | null) => {
    setSelectedAccount(value)
  }

  return (
    <Modal open={open} onClose={onClose}>
      <Grid container sx={modalStyle}>
        <Grid item>
          <MuiTypography
            variant="body1"
            color={theme.palette.Text.highEmphasis}
          >
            {header}
          </MuiTypography>
        </Grid>
        <Grid item marginTop="40px" marginBottom="20px">
          <MuiTypography
            variant="caption1"
            color={theme.palette.Text.mediumEmphasis}
          >
            {refundMoney}
          </MuiTypography>
        </Grid>
        <Grid container sx={selectContainer}>
          <Grid item>
            <MuiDropdown
              label={CANCEL_TRANFER_MODAL.SELECT_ACCOUNT_LABEL}
              options={accountOptions}
              value={selectedAccount}
              onChange={handleAccountChange}
            />
          </Grid>
          <Grid item marginTop="20px">
            <MuiDropdown
              label={CANCEL_TRANFER_MODAL.SELECT_OPTION_LABEL}
              options={existingAccounts}
              onChange={handleSelect}
              disabled={isOptionDropdownDisabled}
            />
          </Grid>
        </Grid>
        {selectedAccount && (
          <Grid item marginTop="40px" container justifyContent="center">
            <StyledContinueButton onClick={onClick} variant="contained">
              {Constants.CANCEL_TRANFER}
            </StyledContinueButton>
          </Grid>
        )}
      </Grid>
    </Modal>
  )
}

export default CancelTransferModal
