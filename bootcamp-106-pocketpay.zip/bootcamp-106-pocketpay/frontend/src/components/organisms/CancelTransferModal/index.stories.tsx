import { Meta, StoryFn } from '@storybook/react'
import CancelTransferModal from '.'
import { action } from '@storybook/addon-actions'
import { CANCEL_TRANFER_MODAL, selectExistingAccount } from 'utils/constants'

export default {
  title: 'Organisms/Cancel Transfer Modal',
  component: CancelTransferModal,
} as Meta

const Template: StoryFn<typeof CancelTransferModal> = (args) => (
  <CancelTransferModal {...args} />
)

export const Default = Template.bind({})
Default.args = {
  open: true,
  header: CANCEL_TRANFER_MODAL.HEADER,
  refundMoney: CANCEL_TRANFER_MODAL.REFUND_MONEY,
  existingAccounts: selectExistingAccount,
  onClick: action('Cancel transfer is clicked'),
}
