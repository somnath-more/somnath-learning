import { Grid, styled } from '@mui/material'
import theme from 'themes'

export const modalStyle = {
  position: 'absolute',
  width: 564,
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  borderRadius: '16px',
  background: `${theme.palette.Structural.white}`,
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'left',
  padding: '24px',
  outline: 'none',
}

export const selectContainer = {
  display: 'flex',
  flexDirection: 'column',
  width: '516px',
  flexShrink: 0,
  borderRadius: '8px',
}

export const StyledSelectOptions = styled(Grid)({
  cursor: 'pointer',
  marginTop: '36px',
})
