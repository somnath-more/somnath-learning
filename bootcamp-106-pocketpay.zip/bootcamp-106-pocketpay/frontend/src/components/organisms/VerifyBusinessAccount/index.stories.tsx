import { StoryFn, Meta } from '@storybook/react'
import { action } from '@storybook/addon-actions'
import VerifyBusinessAccount from '.'
import {
  CategoryOptions,
  SizeOfBusinessOptions,
  SubCategoryOptions,
} from 'utils/constants'

const meta: Meta = {
  title: 'Organisms/VerifyBusinessAccount',
  component: VerifyBusinessAccount,
}
export default meta

const Template: StoryFn<typeof VerifyBusinessAccount> = (args) => (
  <VerifyBusinessAccount {...args} />
)

export const Primary = Template.bind({})

Primary.args = {
  categoryOptions: CategoryOptions,
  subCategoryOptions: SubCategoryOptions,
  sizeOfBusinessOptions: SizeOfBusinessOptions,
  onContinueClick: action('Continue Button is Clicked '),
}
