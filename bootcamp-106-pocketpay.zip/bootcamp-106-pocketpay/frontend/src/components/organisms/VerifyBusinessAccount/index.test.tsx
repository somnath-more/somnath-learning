import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import VerifyBusinessAccount from '.'
import {
  CategoryOptions,
  SizeOfBusinessOptions,
  SubCategoryOptions,
} from 'utils/constants'
import MuiDropdown from 'components/atoms/Dropdown'

const props = {
  categoryOptions: CategoryOptions,
  subCategoryOptions: SubCategoryOptions,
  sizeOfBusinessOptions: SizeOfBusinessOptions,
  onContinueClick: jest.fn(),
}

describe('Verify Business Account', () => {
  beforeEach(() => {
    render(<VerifyBusinessAccount {...props} />)
  })

  const mockOnChange = jest.fn()
  const setupCategoryDropdown = () => {
    render(<MuiDropdown options={CategoryOptions} onChange={mockOnChange} />)
  }
  const setupSubCategoryDropdown = () => {
    render(<MuiDropdown options={SubCategoryOptions} onChange={mockOnChange} />)
  }
  const setupSizeOfBusinessDropdown = () => {
    render(
      <MuiDropdown options={SizeOfBusinessOptions} onChange={mockOnChange} />
    )
  }

  test('it should render all the text fields correctly', () => {
    expect(screen.getByLabelText('Category')).toBeInTheDocument()
    expect(screen.getByLabelText('Subcategory')).toBeInTheDocument()
    expect(screen.getByLabelText('Size of your business')).toBeInTheDocument()
    expect(screen.getByText('Continue')).toBeInTheDocument()
  })

  test('it should call onChange with the selected option for category', () => {
    const continueButton = screen.getByText('Continue')
    expect(continueButton).toBeDisabled

    setupCategoryDropdown()
    const category = screen.getByLabelText('Category')

    fireEvent.mouseDown(category)
    const categoryOption = screen.getByText('Real estate or construction')
    fireEvent.click(categoryOption)

    waitFor(() => {
      expect(mockOnChange).toHaveBeenCalledTimes(1)
    })

    setupSubCategoryDropdown()
    const subCategory = screen.getByLabelText('Subcategory')

    fireEvent.mouseDown(subCategory)
    const subCategoryOption = screen.getByText(
      'Real estate sale, purchase and management'
    )
    fireEvent.click(subCategoryOption)

    waitFor(() => {
      expect(mockOnChange).toHaveBeenCalledTimes(1)
    })

    setupSizeOfBusinessDropdown()
    const sizeOfBusiness = screen.getByLabelText('Size of your business')

    fireEvent.mouseDown(sizeOfBusiness)
    const sizeOfBusinessOption = screen.getByText('50-100')
    fireEvent.click(sizeOfBusinessOption)

    waitFor(() => {
      expect(mockOnChange).toHaveBeenCalledTimes(1)
    })

    expect(continueButton).toBeEnabled
    fireEvent.click(continueButton)
    expect(props.onContinueClick).toHaveBeenCalledTimes(1)
  })
})
