import { Grid } from '@mui/material'
import MuiDropdown, { OptionItem } from 'components/atoms/Dropdown'
import MuiTypography from 'components/atoms/Typography'
import { useState } from 'react'
import theme from 'themes'
import { Constants } from 'utils/constants'
import { StyledContinueButton } from 'utils/styles'

interface VerifyBusinessAccountProps {
  categoryOptions: OptionItem[]
  sizeOfBusinessOptions: OptionItem[]
  subCategoryOptions: OptionItem[]
  onContinueClick: () => void
  saveBusinessActivity?: (businessActivity: SelectedOptions) => void
}

export interface SelectedOptions {
  selectedCategory: OptionItem | null
  selectedSubCategory: OptionItem | null
  selectedSizeOfBusiness: OptionItem | null
}

const VerifyBusinessAccount = ({
  categoryOptions,
  subCategoryOptions,
  sizeOfBusinessOptions,
  onContinueClick,
  saveBusinessActivity,
}: VerifyBusinessAccountProps) => {
  const [selectedOptions, setSelectedOptions] = useState<SelectedOptions>({
    selectedCategory: null,
    selectedSubCategory: null,
    selectedSizeOfBusiness: null,
  })

  const handleOptionChange = (
    optionName: string,
    selectedOption: OptionItem | null
  ) => {
    setSelectedOptions((prevState) => ({
      ...prevState,
      [optionName]: selectedOption,
    }))

    if (saveBusinessActivity) {
      saveBusinessActivity(selectedOptions)
    }
  }

  const isButtonDisabled =
    !selectedOptions.selectedCategory ||
    !selectedOptions.selectedSubCategory ||
    !selectedOptions.selectedSizeOfBusiness

  return (
    <>
      <Grid container flexDirection="column" width="650px" spacing={3}>
        <Grid item>
          <MuiTypography
            variant="h1"
            sx={{ color: theme.palette.Text.highEmphasis }}
          >
            {Constants.VERIFY}
          </MuiTypography>
        </Grid>
        <Grid item>
          <MuiTypography
            variant="body3"
            sx={{ color: theme.palette.Text.mediumEmphasis }}
          >
            {Constants.VERIFY_STATUS}
          </MuiTypography>
        </Grid>
        <Grid item marginTop="25px" width="515px">
          <Grid container flexDirection="column" spacing={5}>
            <Grid item>
              <MuiDropdown
                options={categoryOptions}
                label="Category"
                onChange={(selectedOption) => {
                  handleOptionChange('selectedCategory', selectedOption)
                }}
                value={selectedOptions.selectedCategory}
              />
            </Grid>
            <Grid item>
              <MuiDropdown
                options={subCategoryOptions}
                label="Subcategory"
                onChange={(selectedOption) =>
                  handleOptionChange('selectedSubCategory', selectedOption)
                }
                value={selectedOptions.selectedSubCategory}
              />
            </Grid>
            <Grid item>
              <MuiDropdown
                options={sizeOfBusinessOptions}
                label="Size of your business"
                onChange={(selectedOption) =>
                  handleOptionChange('selectedSizeOfBusiness', selectedOption)
                }
                value={selectedOptions.selectedSizeOfBusiness}
              />
            </Grid>
          </Grid>
        </Grid>
        <Grid item marginTop="130px">
          <Grid container justifyContent="flex-end">
            <StyledContinueButton
              disabled={isButtonDisabled}
              onClick={onContinueClick}
            >
              {Constants.CONTINUE}
            </StyledContinueButton>
          </Grid>
        </Grid>
      </Grid>
    </>
  )
}

export default VerifyBusinessAccount
