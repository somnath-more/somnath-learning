import { render, fireEvent, screen } from '@testing-library/react'
import SignUp from '.'
import { BrowserRouter } from 'react-router-dom'
import { useAuth0 } from '@auth0/auth0-react'
import { Constants, ERROR_MESSAGES } from 'utils/constants'
import * as Router from 'react-router'

jest.mock('@auth0/auth0-react', () => ({
  useAuth0: jest.fn(),
}))

describe('SignUp Component', () => {
  let navigateMock = jest.fn()
  let loginWithRedirectMock = jest.fn()

  beforeEach(() => {
    ;(useAuth0 as jest.Mock).mockReturnValue({
      loginWithRedirect: loginWithRedirectMock,
    })
    jest.mock('react-router-dom', () => ({
      ...jest.requireActual('react-router-dom'),
    }))
    jest.spyOn(Router, 'useNavigate').mockImplementation(() => navigateMock)
    render(
      <BrowserRouter>
        <SignUp signupHeading="Sign Up" logInWith="Log In With" />
      </BrowserRouter>
    )
  })

  test('it should render correctly', () => {
    expect(screen.getByText('Sign Up')).toBeInTheDocument()
    expect(screen.getByText('Log In With')).toBeInTheDocument()
  })

  test('it should enable the "Next" button when email is valid', () => {
    const emailInput = screen.getByLabelText('Email')
    const nextButton = screen.getByText('Next')

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } })

    expect(nextButton).not.toBeDisabled()
  })

  test('it should call loginWithRedirect when an icon is clicked', () => {
    const iconElements = screen.getAllByAltText((altText) =>
      altText.startsWith('Icon for ')
    )
    const icon = iconElements[0]
    fireEvent.click(icon)

    expect(loginWithRedirectMock).toHaveBeenCalledTimes(1)
  })

  test('it should show error message for invalid email format', async () => {
    const emailInput = screen.getByLabelText('Email')

    fireEvent.change(emailInput, { target: { value: 'invalidemail' } })

    const errorMessage = await screen.findByText(ERROR_MESSAGES.email)
    expect(errorMessage).toBeInTheDocument()
  })

  test('it should navigate when login link is clicked', () => {
    const loginLink = screen.getByText(Constants.LOGIN)
    fireEvent.click(loginLink)
    expect(navigateMock).toHaveBeenCalledWith('/log-in')
  })

  test('it should navigate to business setup page when "Next" button is clicked', () => {
    const emailInput = screen.getByLabelText('Email')

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } })
    const nextButton = screen.getByRole('button', { name: 'Next' })
    fireEvent.click(nextButton)
    expect(navigateMock).toHaveBeenCalledWith('/account-type')
  })

  test('it should display "Terms of use" and "Privacy Policy" links', () => {
    const hasTermsOfUseLink = () =>
      screen.queryByText((content, element) => {
        const hasMatchingText =
          element?.tagName.toLowerCase() === 'span' &&
          content.includes('Terms of use')
        return hasMatchingText
      }) !== null

    const hasPrivacyPolicyLink = () =>
      screen.queryByText((content, element) => {
        const hasMatchingText =
          element?.tagName.toLowerCase() === 'span' &&
          content.includes('Privacy Policy')
        return hasMatchingText
      }) !== null

    expect(hasTermsOfUseLink()).toBe(false)
    expect(hasPrivacyPolicyLink()).toBe(false)
  })
})
