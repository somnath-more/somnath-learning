import { StoryFn, Meta } from '@storybook/react'
import SignUp from '.'
import { Constants } from 'utils/constants'

const meta: Meta = {
  title: 'Organisms/SignUp',
  component: SignUp,
}
export default meta

const Template: StoryFn<typeof SignUp> = (args) => <SignUp {...args} />

export const Primary = Template.bind({})

Primary.args = {
  signupHeading: Constants.SIGN_UP_HEADING,
  logInWith: Constants.LOG_IN_WITH,
}
