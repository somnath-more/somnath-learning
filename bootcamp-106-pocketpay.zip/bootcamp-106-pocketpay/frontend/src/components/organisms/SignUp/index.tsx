import { Box, Divider, Grid, styled } from '@mui/material'
import Button from 'components/atoms/Button'
import CustomTextField from 'components/atoms/Input'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import IconGrid from 'components/molecules/IconGrid'
import { ChangeEvent, useContext, useState } from 'react'
import { validateEmailFormat } from 'utils/credentials'
import { Constants, ERROR_MESSAGES, icons } from 'utils/constants'
import { useNavigate } from 'react-router-dom'
import { useAuth0 } from '@auth0/auth0-react'
import { UserContext } from 'utils/hooks/contexts'

interface SignUpProps {
  signupHeading: string
  logInWith: string
}

const ContainerGrid = styled(Grid)({
  width: '516px',
  display: 'flex',
  flexDirection: 'column',
})

export const StyledButton = styled(Button)({
  textTransform: 'none',
  display: 'flex',
  width: '516px',
  padding: '16px 43px',
  justifyContent: 'center',
  alignItems: 'center',
  gap: '10px',
  borderRadius: '56px',
  '&:disabled': {
    backgroundColor: theme.palette.primary.primary100,
    color: theme.palette.Structural.white,
  },
})

interface SignUpDetails {
  email: string
}

const SignUp = ({ signupHeading, logInWith }: SignUpProps) => {
  const navigate = useNavigate()
  const { loginWithRedirect } = useAuth0()
  const { userData, setUserData } = useContext(UserContext)
  const [sigUpDetails, setSignUpDetails] = useState<SignUpDetails>({
    email: '',
  })
  const [emailError, setEmailError] = useState<SignUpDetails>({
    email: '',
  })

  const onSignUpNext = () => {
    const updatedUserDetails = {
      ...userData,
      email: sigUpDetails.email,
    }
    setUserData(updatedUserDetails)
    navigate('/account-type')
  }

  const handleEmailChange = (
    event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
    field: keyof SignUpDetails
  ) => {
    const { value } = event.target
    setSignUpDetails((prevState) => ({
      ...prevState,
      [field]: value,
    }))

    const errorState = {
      [field]:
        !validateEmailFormat(value) && value.length ? ERROR_MESSAGES.email : '',
    }
    setEmailError((prevErrors) => ({
      ...prevErrors,
      ...errorState,
    }))
  }
  const isButtonDisabled = !!emailError.email || !sigUpDetails.email

  return (
    <Box>
      <MuiTypography variant="h1" color={theme.palette.Text.highEmphasis}>
        {signupHeading}
      </MuiTypography>
      <ContainerGrid container sx={{ alignItems: 'center' }}>
        <Grid item sx={{ marginTop: '32px' }}>
          <CustomTextField
            onChange={(event) => handleEmailChange(event, 'email')}
            label="Email"
            placeholder="Enter your email address"
            sx={{ width: '516px' }}
            value={sigUpDetails.email}
          />
          {emailError && (
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.warning}
            >
              {emailError.email}
            </MuiTypography>
          )}
        </Grid>
        <Grid item sx={{ marginTop: '40px' }}>
          <StyledButton
            children="Next"
            variant="contained"
            disabled={isButtonDisabled}
            onClick={onSignUpNext}
          />
        </Grid>
        <Grid item sx={{ marginTop: '40px' }}>
          <MuiTypography
            variant="caption1"
            color={theme.palette.Text.mediumEmphasis}
            sx={{
              width: '94px',
              height: '21px',
            }}
          >
            {logInWith}
          </MuiTypography>
        </Grid>
        <Grid item sx={{ marginTop: '20px' }}>
          <IconGrid
            icons={icons}
            handleIconClick={() => {
              loginWithRedirect()
            }}
          />
        </Grid>
        <Grid item sx={{ marginTop: '39px' }}>
          <Grid
            item
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.mediumEmphasis}
            >
              {Constants.REGISTERING}
              <span style={{ color: theme.palette.primary.main }}>
                <u>{Constants.TERMS}</u>
              </span>
              and
              <span style={{ color: theme.palette.primary.main }}>
                <u>{Constants.POLICY}</u>
              </span>
            </MuiTypography>
          </Grid>
          <Grid item sx={{ marginTop: '48px' }}>
            <Divider sx={{ width: '516px' }} />
          </Grid>
        </Grid>
        <Grid item sx={{ marginTop: '32px' }}>
          <MuiTypography
            variant="caption1"
            color={theme.palette.Text.mediumEmphasis}
            sx={{ cursor: 'pointer' }}
          >
            {Constants.ALREADY_HAVING_ACCOUNT}
            <span
              style={{ color: theme.palette.primary.main }}
              onClick={() => navigate('/log-in')}
            >
              <u>{Constants.LOGIN}</u>
            </span>
          </MuiTypography>
        </Grid>
      </ContainerGrid>
    </Box>
  )
}

export default SignUp
