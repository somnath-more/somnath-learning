import { StoryFn, Meta } from '@storybook/react'
import { FILL_YOUR_DETAILS, options } from 'utils/constants'
import AccountOwnerDetail from '.'

const meta: Meta = {
  title: 'Organisms/AccountOwnerDetail',
  component: AccountOwnerDetail,
  argTypes: {
    onClick: {
      action: 'clicked',
    },
  },
}
export default meta

const Template: StoryFn<typeof AccountOwnerDetail> = (args) => (
  <AccountOwnerDetail {...args} />
)

export const AccountOwner = Template.bind({})

AccountOwner.args = {
  ownerHeading: FILL_YOUR_DETAILS.HEADING,
  subOwnerHeading: FILL_YOUR_DETAILS.SUB_HEADING,
  options: options,
}
