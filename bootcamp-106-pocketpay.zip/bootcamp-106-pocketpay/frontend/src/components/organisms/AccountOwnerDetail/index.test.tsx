import { render, screen, fireEvent } from '@testing-library/react'
import AccountOwnerDetail from '.'
import { ERROR_MESSAGES, FILL_YOUR_DETAILS, options } from 'utils/constants'

const props = {
  ownerHeading: FILL_YOUR_DETAILS.HEADING,
  subOwnerHeading: FILL_YOUR_DETAILS.SUB_HEADING,
  options: options,
  onClick: jest.fn(),
}

describe('AccountOwnerDetail Component', () => {
  beforeEach(() => {
    render(<AccountOwnerDetail {...props} />)
  })

  test('it should render component with correct titles', () => {
    expect(screen.getByText(props.ownerHeading)).toBeInTheDocument()
    expect(screen.getByText(props.subOwnerHeading)).toBeInTheDocument()
  })

  test('it should update text fields when input values change', () => {
    const firstNameInputValue = screen.getByLabelText('First name')
    const lastNameInputValue = screen.getByLabelText('Last name')
    const dateInputValue = screen.getByLabelText('Date of birth')
    const dropdownInputValue = screen.getByLabelText('Country of residence')
    const homeAddressInputValue = screen.getByLabelText('Home address')
    const cityInputValue = screen.getByLabelText('City')
    const pincodeInputValue = screen.getByLabelText('Pincode')

    fireEvent.change(firstNameInputValue, { target: { value: 'John' } })
    expect(firstNameInputValue).toHaveValue('John')

    fireEvent.change(lastNameInputValue, { target: { value: 'Reddy' } })
    expect(lastNameInputValue).toHaveValue('Reddy')

    fireEvent.change(dateInputValue, { target: { value: '31-07-2023' } })
    expect(dateInputValue).toHaveValue('31-07-2023')

    fireEvent.change(dropdownInputValue, { target: { value: 'A' } })
    expect(screen.getByTestId('option-image-Austria')).toBeInTheDocument()

    fireEvent.change(homeAddressInputValue, {
      target: { value: '43 Bishophthorpe Road' },
    })
    expect(homeAddressInputValue).toHaveValue('43 Bishophthorpe Road')

    fireEvent.change(cityInputValue, { target: { value: 'Pencoed' } })
    expect(cityInputValue).toHaveValue('Pencoed')

    fireEvent.change(pincodeInputValue, { target: { value: 'CF35 7RJ' } })
    expect(pincodeInputValue).toHaveValue('CF35 7RJ')

    const countrySelect = screen.getAllByLabelText('Country of residence')
    fireEvent.change(countrySelect[0] as HTMLInputElement, {
      target: { value: 'In' },
    })
    fireEvent.click(screen.getByText('India'))
    expect(countrySelect[0]).toHaveValue('India')
  })

  test('it should display error messages', () => {
    const firstNameInputValue = screen.getByLabelText('First name')
    const lastNameInputValue = screen.getByLabelText('Last name')
    const homeAddressInputValue = screen.getByLabelText('Home address')
    const cityInputValue = screen.getByLabelText('City')
    const pincodeInputValue = screen.getByLabelText('Pincode')

    fireEvent.change(firstNameInputValue, { target: { value: 'John123' } })

    const invalidFirstNameError = screen.getByText(ERROR_MESSAGES.firstName)
    expect(invalidFirstNameError).toBeInTheDocument()

    fireEvent.change(lastNameInputValue, { target: { value: '#123WER' } })
    const invalidLastNameError = screen.getByText(ERROR_MESSAGES.lastName)
    expect(invalidLastNameError).toBeInTheDocument()

    fireEvent.change(homeAddressInputValue, {
      target: { value: '43$&Road 123' },
    })
    const invalidAddressError = screen.getByText(ERROR_MESSAGES.homeAddress)
    expect(invalidAddressError).toBeInTheDocument()

    fireEvent.change(cityInputValue, { target: { value: '12345' } })
    const invalidCityError = screen.getByText(ERROR_MESSAGES.city)
    expect(invalidCityError).toBeInTheDocument()

    fireEvent.change(pincodeInputValue, { target: { value: 'cf23 DF' } })
    const invalidPinCodeError = screen.getByText(ERROR_MESSAGES.city)
    expect(invalidPinCodeError).toBeInTheDocument()
  })
})
