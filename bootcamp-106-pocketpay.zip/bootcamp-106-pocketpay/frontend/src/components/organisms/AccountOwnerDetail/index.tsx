import React, { useState } from 'react'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { Constants } from 'utils/constants'
import { LocalizationProvider } from '@mui/x-date-pickers'
import { DatePicker } from '@mui/x-date-pickers/DatePicker'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import MuiDropdown, { OptionItem } from 'components/atoms/Dropdown'
import { Grid } from '@mui/material'
import { StyledTextField } from '../ConfirmBusinessDirectors/styles'
import { getOptionImage } from '../ConfirmShareHolders'
import { ErrorState, UserInformation } from 'utils/types'
import { validateFieldForUserInformation } from 'utils/credentials'
import moment, { Moment } from 'moment'
import { StyledContinueButton } from 'utils/styles'
import CalendarTodayOutlinedIcon from '@mui/icons-material/CalendarTodayOutlined'

interface AccountOwnerProps {
  ownerHeading: string
  subOwnerHeading: string
  options: OptionItem[]
  onClick: () => void
  saveOwnerDetails?: (userData: UserInformation) => void
}

const AccountOwnerDetail: React.FC<AccountOwnerProps> = (props) => {
  const [accountHolder, setAccountHolders] = useState<UserInformation>({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    dateOfBirth: null,
    phone_no: '',
    countryOfResidence: 'United Kingdom',
    homeAddress: '',
    city: '',
    pinCode: '',
    accountType: ''
  })

  const [errors, setErrors] = useState<ErrorState>({
    firstName: '',
    lastName: '',
    homeAddress: '',
    city: '',
    pinCode: '',
  })

  const [selectedCountry, setSelectedCountry] = useState<OptionItem | null>(
    null
  )

  const handleInputChange = (
    event: React.ChangeEvent<HTMLInputElement>,
    field: keyof UserInformation
  ) => {
    const { value } = event.target
    setAccountHolders((prevFormData) => ({
      ...prevFormData,
      [field]: value,
    }))

    if (props.saveOwnerDetails) {
      props.saveOwnerDetails(accountHolder)
    }
    const error = validateFieldForUserInformation(field, value)

    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: error,
    }))
  }

  const handleCountryChange = (option: OptionItem | null) => {
    setSelectedCountry(option)
  }

  const shouldDisableDate = (date: Moment) => {
    const age18YearsAgo = moment().subtract(18, 'years')
    const age60YearsAgo = moment().subtract(60, 'years')

    return date.isAfter(age18YearsAgo) || date.isBefore(age60YearsAgo)
  }

  const isButtonDisabled =
    !accountHolder.firstName ||
    !accountHolder.lastName ||
    !accountHolder.homeAddress ||
    !accountHolder.city ||
    !accountHolder.pinCode ||
    !accountHolder.dateOfBirth ||
    !!errors.firstName ||
    !!errors.lastName ||
    !!errors.homeAddress ||
    !!errors.city ||
    !!errors.pinCode ||
    !selectedCountry

  return (
    <>
      <Grid container spacing={3} flexDirection="column" width="650px">
        <Grid item>
          <MuiTypography
            variant="h1"
            sx={{ color: theme.palette.Text.highEmphasis }}
          >
            {props.ownerHeading}
          </MuiTypography>
        </Grid>
        <Grid item>
          <MuiTypography
            variant="body3"
            sx={{ color: theme.palette.Text.mediumEmphasis }}
          >
            {props.subOwnerHeading}
          </MuiTypography>
        </Grid>
        <Grid item marginTop="25px">
          <Grid container flexDirection="column" width="515px" spacing={6}>
            <Grid item>
              <StyledTextField
                label="First name"
                value={accountHolder.firstName}
                onChange={(e) => handleInputChange(e, 'firstName')}
              />
              {errors.firstName && (
                <MuiTypography
                  variant="caption1"
                  color={theme.palette.Text.warning}
                  marginTop="8px"
                >
                  {errors.firstName}
                </MuiTypography>
              )}
            </Grid>
            <Grid item>
              <StyledTextField
                label="Last name"
                value={accountHolder.lastName}
                onChange={(e) => handleInputChange(e, 'lastName')}
              />
              {errors.lastName && (
                <MuiTypography
                  variant="caption1"
                  color={theme.palette.Text.warning}
                  marginTop="8px"
                >
                  {errors.lastName}
                </MuiTypography>
              )}
            </Grid>
            <Grid item>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DatePicker
                  label="Date of birth"
                  format="DD-MM-YYYY"
                  disableFuture
                  views={['year', 'month', 'day']}
                  value={accountHolder.dateOfBirth ?? null}
                  sx={{
                    width: '515px',
                    '& .MuiFormControl-root-MuiTextField-root': {
                      '& .MuiInputLabel-root': {
                        color: theme.palette.Text.lowEmphasis,
                      },
                    },
                    '& .MuiSvgIcon-root': {
                      color: theme.palette.Accent.icon02,
                    },
                  }}
                  onChange={(date) =>
                    setAccountHolders((prevFormData) => ({
                      ...prevFormData,
                      dateOfBirth: date,
                    }))
                  }
                  shouldDisableYear={shouldDisableDate}
                  slotProps={{
                    inputAdornment: {
                      position: 'end',
                    },
                  }}
                  slots={{
                    openPickerIcon: CalendarTodayOutlinedIcon,
                  }}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item>
              <MuiDropdown
                label="Country of residence"
                options={props.options}
                getOptionImage={getOptionImage}
                sx={{
                  color: '#E4E4E5',
                }}
                onChange={handleCountryChange}
                value={
                  selectedCountry ? selectedCountry.label : 'United Kingdom'
                }
              />
            </Grid>
            <Grid item>
              <StyledTextField
                label="Home address"
                value={accountHolder.homeAddress}
                onChange={(e) => handleInputChange(e, 'homeAddress')}
              />
              {errors.homeAddress && (
                <MuiTypography
                  variant="caption1"
                  color={theme.palette.Text.warning}
                  marginTop="8px"
                >
                  {errors.homeAddress}
                </MuiTypography>
              )}
            </Grid>
            <Grid item>
              <StyledTextField
                label="City"
                value={accountHolder.city}
                onChange={(e) => handleInputChange(e, 'city')}
              />
              {errors.city && (
                <MuiTypography
                  variant="caption1"
                  color={theme.palette.Text.warning}
                  marginTop="8px"
                >
                  {errors.city}
                </MuiTypography>
              )}
            </Grid>
            <Grid item>
              <StyledTextField
                label="Pincode"
                value={accountHolder.pinCode}
                onChange={(e) => handleInputChange(e, 'pinCode')}
              />
              {errors.pinCode && (
                <MuiTypography
                  variant="caption1"
                  color={theme.palette.Text.warning}
                  marginTop="8px"
                >
                  {errors.pinCode}
                </MuiTypography>
              )}
            </Grid>
          </Grid>
        </Grid>
        <Grid item>
          <Grid container justifyContent="flex-end">
            <StyledContinueButton
              onClick={props.onClick}
              disabled={isButtonDisabled}
            >
              {Constants.CONTINUE}
            </StyledContinueButton>
          </Grid>
        </Grid>
      </Grid>
    </>
  )
}

export default AccountOwnerDetail
