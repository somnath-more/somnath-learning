import { Grid, styled } from '@mui/material'
import theme from 'themes'

export const StyledContainer = styled(Grid)({
  width: '516px',
  display: 'inline-flex',
  paddingRight: '0px',
  flexDirection: 'column',
  justifyContent: 'flex-end',
  alignItems: 'flex-start',
  gap: '40px',
})

export const StyledInnerContainer = styled(Grid)({
  borderRadius: '16px',
  border: `1px solid ${theme.palette.Text.main}`,
})
