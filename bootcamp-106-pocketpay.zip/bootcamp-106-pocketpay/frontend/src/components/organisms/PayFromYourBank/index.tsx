import { Grid } from '@mui/material'
import { StyledContainer, StyledInnerContainer } from './style'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { Constants, PAY_FROM_YOUR_BANK } from 'utils/constants'
import Image from 'components/atoms/Image'
import IMAGE from 'public/assets/image/PayFromYourBank.svg'
import { StyledCancelButton, StyledContinueButton } from 'utils/styles'
import { BulletPointProps } from 'utils/types'

interface PayFromYourBankProps {
  title: string
  subtitle1: string
  subtitle2: string
  amount: string
  summaryPoints: BulletPointProps[]
  onContinue: () => void
}

const PayFromYourBank = (props: PayFromYourBankProps) => {
  return (
    <StyledContainer container>
      <Grid item>
        <MuiTypography variant="h1" color={theme.palette.Text.highEmphasis}>
          {props.title}
        </MuiTypography>
      </Grid>
      <Grid item>
        <StyledInnerContainer container>
          <Grid item margin="48px 32px 0px 32px">
            <MuiTypography
              variant="body3"
              color={theme.palette.Text.mediumEmphasis}
            >
              {`${props.subtitle1}`}
              <span style={{ color: theme.palette.Text.highEmphasis }}>
                {`${PAY_FROM_YOUR_BANK.BUSINESS}`}
              </span>
              {`${props.subtitle2}`}
              <span style={{ color: theme.palette.Text.highEmphasis }}>
                {`${props.amount}`}
              </span>
              {`${PAY_FROM_YOUR_BANK.TRANSFER}`}
            </MuiTypography>
          </Grid>
          <Grid item margin="24px 0px 0px 32px">
            <MuiTypography
              variant="body1"
              color={theme.palette.Text.highEmphasis}
            >
              {PAY_FROM_YOUR_BANK.SAVE_SECURE}
            </MuiTypography>
          </Grid>
          <Grid item margin="0px 52px 0px 15px">
            <MuiTypography
              variant="body3"
              color={theme.palette.Text.mediumEmphasis}
            >
              <ul>
                {props.summaryPoints.map((element) => (
                  <li key={element.id}>{element.point}</li>
                ))}
              </ul>
            </MuiTypography>
          </Grid>
          <Grid item margin="40px 166px 0px 166px">
            <Image
              alt={'Image not found'}
              src={IMAGE}
              width="183px"
              height="60px"
            />
          </Grid>
          <Grid item margin="40px 149px 0px 149px">
            <StyledContinueButton
              variant="contained"
              onClick={props.onContinue}
              sx={{ width: '218px' }}
            >
              {Constants.CONTINUE_PAY}
            </StyledContinueButton>
          </Grid>
          <Grid item margin="36px 149px 48px 149px">
            <StyledCancelButton variant="contained" sx={{ width: '218px' }}>
              {Constants.PAY_MANUALLY}
            </StyledCancelButton>
          </Grid>
        </StyledInnerContainer>
      </Grid>
    </StyledContainer>
  )
}

export default PayFromYourBank
