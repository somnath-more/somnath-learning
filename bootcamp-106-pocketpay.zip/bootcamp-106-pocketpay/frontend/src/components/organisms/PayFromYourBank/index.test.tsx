import { render, screen, fireEvent } from '@testing-library/react'
import PayFromYourBank from '.'
import { Constants, PAY_FROM_YOUR_BANK } from 'utils/constants'
import { bulletPoints } from 'utils/types'

const mockProps = {
  title: PAY_FROM_YOUR_BANK.TITLE,
  subtitle1: PAY_FROM_YOUR_BANK.SUBTITLE1,
  subtitle2: PAY_FROM_YOUR_BANK.SUBTITLE2,
  amount: PAY_FROM_YOUR_BANK.AMOUNT,
  summaryPoints: bulletPoints,
  onContinue: jest.fn(),
}

describe('PayFromYourBank', () => {
  test('it should render PayFromYourBank component without errors', () => {
    render(<PayFromYourBank {...mockProps} />)
  })

  test('it should render the correct title, subtitles, and amount', () => {
    render(<PayFromYourBank {...mockProps} />)

    const subtitleTextRegex1 =
      /You’ll be redirected to Lloyds, where you can securely log in to your own /i
    const subtitleTextRegex2 = /account and approve the payment for your /i

    expect(screen.getByText(mockProps.title)).toBeInTheDocument()
    expect(screen.getByText(subtitleTextRegex1)).toBeInTheDocument()
    expect(screen.getByText(subtitleTextRegex2)).toBeInTheDocument()
    expect(screen.getByText(mockProps.amount)).toBeInTheDocument()
  })

  test('it should call onContinue when "Continue Pay" button is clicked', () => {
    render(<PayFromYourBank {...mockProps} />)

    const continueButton = screen.getByRole('button', {
      name: Constants.CONTINUE_PAY,
    })
    fireEvent.click(continueButton)

    expect(mockProps.onContinue).toHaveBeenCalledTimes(1)
  })
})
