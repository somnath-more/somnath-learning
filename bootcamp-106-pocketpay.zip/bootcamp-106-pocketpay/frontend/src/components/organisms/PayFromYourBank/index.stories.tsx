import { StoryFn, Meta } from '@storybook/react'
import PayFromYourBank from '.'
import { PAY_FROM_YOUR_BANK } from 'utils/constants'
import { action } from '@storybook/addon-actions'
import { bulletPoints } from 'utils/types'

const meta: Meta = {
  title: 'Organisms/Pay From Your Bank',
  component: PayFromYourBank,
}
export default meta

const Template: StoryFn<typeof PayFromYourBank> = (args) => (
  <PayFromYourBank {...args} />
)

export const Default = Template.bind({})

Default.args = {
  title: PAY_FROM_YOUR_BANK.TITLE,
  subtitle1: PAY_FROM_YOUR_BANK.SUBTITLE1,
  subtitle2: PAY_FROM_YOUR_BANK.SUBTITLE2,
  amount: PAY_FROM_YOUR_BANK.AMOUNT,
  summaryPoints: bulletPoints,
  onContinue: action('Continue and Pay is Clicked'),
}
