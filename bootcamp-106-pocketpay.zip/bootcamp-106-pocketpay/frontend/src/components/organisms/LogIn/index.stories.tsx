import { StoryFn, Meta } from '@storybook/react'
import { Constants } from 'utils/constants'
import LogIn from '.'

const meta: Meta = {
  title: 'Organisms/LogIn',
  component: LogIn,
}
export default meta

const Template: StoryFn<typeof LogIn> = (args) => <LogIn {...args} />

export const Primary = Template.bind({})

Primary.args = {
  loginHeading: Constants.LOG_IN_HEADING,
  troubleLogin: Constants.TROUBLE_LOGIN,
  loginWith: Constants.LOG_IN_WITH,
}
