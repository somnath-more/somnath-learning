import { ChangeEvent, useState } from 'react'
import CustomTextField from 'components/atoms/Input'
import { Box, Grid, InputAdornment, styled } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import IconGrid from 'components/molecules/IconGrid'
import { VisibilityOffOutlined, VisibilityOutlined } from '@mui/icons-material'
import CheckboxTypography from 'components/molecules/CheckboxTypography'
import { StyledButton } from '../SignUp'
import { validateFieldForLogIn } from 'utils/credentials'
import { icons } from 'utils/constants'
import { useAuth0 } from '@auth0/auth0-react'

interface LogInProps {
  loginHeading: string
  loginWith: string
  troubleLogin: string
  onLogInButtonClick?: () => void
  onSignUpClick?: () => void
}

export interface LogInDetails {
  email: string
  password: string
}

const ContainerGrid = styled(Grid)({
  width: '516px',
  display: 'flex',
  flexDirection: 'column',
})

const LogIn = ({ loginHeading, loginWith, troubleLogin }: LogInProps) => {
  const { loginWithRedirect } = useAuth0()
  const [showPassword, setShowPassword] = useState(false)
  const [logInDetails, setLogInDetails] = useState<LogInDetails>({
    email: '',
    password: '',
  })
  const [errors, setErrors] = useState<{ email: string; password: string }>({
    email: '',
    password: '',
  })

  const handleInputChange = (
    event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
    field: keyof LogInDetails
  ) => {
    const { value } = event.target
    setLogInDetails((prevState) => ({
      ...prevState,
      [field]: value,
    }))

    const error = validateFieldForLogIn(field, value)

    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: error,
    }))
  }

  const isButtonDisabled =
    !!errors.email ||
    !!errors.password ||
    !logInDetails.email ||
    !logInDetails.password

  const togglePasswordVisibility = () => {
    setShowPassword((prevShowPassword) => !prevShowPassword)
  }

  return (
    <Box>
      <MuiTypography variant="h1" color={theme.palette.Text.highEmphasis}>
        {loginHeading}
      </MuiTypography>
      <ContainerGrid container>
        <Grid item sx={{ marginTop: '40px' }}>
          <CustomTextField
            label="Email"
            placeholder="Enter your email address"
            sx={{ width: '100%' }}
            value={logInDetails.email}
            onChange={(event) => handleInputChange(event, 'email')}
          />
          {errors.email && (
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.warning}
            >
              {errors.email}
            </MuiTypography>
          )}
        </Grid>
        <Grid item sx={{ marginTop: '16px' }}>
          <CustomTextField
            label="Password"
            placeholder="Enter your password"
            sx={{ width: '100%' }}
            type={showPassword ? 'text' : 'password'}
            value={logInDetails.password}
            onChange={(event) => handleInputChange(event, 'password')}
            InputProps={{
              endAdornment: (
                <InputAdornment
                  position="end"
                  style={{
                    cursor: 'pointer',
                    color: theme.palette.Text.highEmphasis,
                  }}
                >
                  {showPassword ? (
                    <VisibilityOutlined
                      data-testid="toggle-password-visibility-icon"
                      onClick={togglePasswordVisibility}
                    />
                  ) : (
                    <VisibilityOffOutlined
                      data-testid="toggle-password-visibility-icon"
                      onClick={togglePasswordVisibility}
                    />
                  )}
                </InputAdornment>
              ),
            }}
          />
          {errors.password && (
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.warning}
            >
              {errors.password}
            </MuiTypography>
          )}
        </Grid>
        <Grid item sx={{ marginTop: '40px' }}>
          <StyledButton
            children="Log in"
            variant="contained"
            disabled={isButtonDisabled}
          />
        </Grid>
        <Grid
          item
          sx={{ marginTop: '20px', display: 'flex', justifyContent: 'center' }}
        >
          <CheckboxTypography label="Remember me" variant="body3" />
          <MuiTypography
            color={theme.palette.primary.primary500}
            sx={{ fontSize: '16px', marginLeft: '200px', cursor: 'pointer' }}
          >
            <u>{troubleLogin}</u>
          </MuiTypography>
        </Grid>
        <Grid item sx={{ marginTop: '40px', textAlign: 'center' }}>
          <MuiTypography
            variant="caption1"
            color={theme.palette.Text.mediumEmphasis}
          >
            {loginWith}
          </MuiTypography>
        </Grid>
        <Grid item sx={{ marginTop: '20px', paddingLeft: '90px' }}>
          <IconGrid icons={icons} handleIconClick={() => loginWithRedirect()} />
        </Grid>
      </ContainerGrid>
    </Box>
  )
}

export default LogIn
