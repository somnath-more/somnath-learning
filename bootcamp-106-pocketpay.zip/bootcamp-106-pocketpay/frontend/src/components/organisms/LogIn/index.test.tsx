import { render, fireEvent, screen, waitFor } from '@testing-library/react'
import LogIn from '.'
import { Constants } from 'utils/constants'
import { BrowserRouter } from 'react-router-dom'
import { useAuth0 } from '@auth0/auth0-react'

jest.mock('@auth0/auth0-react', () => ({
  useAuth0: jest.fn(),
}))

const loginHeading = Constants.LOG_IN_HEADING
const loginWith = Constants.LOG_IN_WITH
const troubleLogin = Constants.TROUBLE_LOGIN

describe('LogIn', () => {
  let loginWithRedirectMock = jest.fn()

  beforeEach(() => {
    ;(useAuth0 as jest.Mock).mockReturnValue({
      loginWithRedirect: loginWithRedirectMock,
    })
    render(
      <BrowserRouter>
        <LogIn
          loginHeading={loginHeading}
          loginWith={loginWith}
          troubleLogin={troubleLogin}
        />
      </BrowserRouter>
    )
  })
  test('it should handle input changes', () => {
    const emailInput = screen.getByLabelText('Email') as HTMLInputElement
    const passwordInput = screen.getByLabelText('Password') as HTMLInputElement
    expect(emailInput.value).toBe('')
    expect(passwordInput.value).toBe('')

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } })
    fireEvent.change(passwordInput, { target: { value: 'password123' } })

    expect(emailInput.value).toBe('test@example.com')
    expect(passwordInput.value).toBe('password123')
  })

  test('it should call loginWithRedirect when an icon is clicked', () => {
    const iconElements = screen.getAllByAltText((altText) =>
      altText.startsWith('Icon for ')
    )
    const icon = iconElements[0]
    fireEvent.click(icon)

    expect(loginWithRedirectMock).toHaveBeenCalledTimes(1)
  })

  test('it should show error message for invalid email format', async () => {
    const emailInput = screen.getByLabelText('Email') as HTMLInputElement

    fireEvent.change(emailInput, { target: { value: 'invalid-email' } })

    await waitFor(() => {
      const errorMessage = screen.getByText(/Invalid email format/i)
      expect(errorMessage).toBeInTheDocument()
    })
  })

  test('it should enable the "Log in" button when email and password are valid', () => {
    const emailInput = screen.getByLabelText('Email') as HTMLInputElement
    const passwordInput = screen.getByLabelText('Password') as HTMLInputElement
    const loginButton = screen.getByRole('button', {
      name: 'Log in',
    }) as HTMLButtonElement

    const validEmail = 'user@example.com'
    const validPassword = 'P@ssw0rd!'
    fireEvent.change(emailInput, { target: { value: validEmail } })
    fireEvent.change(passwordInput, { target: { value: validPassword } })

    expect(loginButton).not.toBeDisabled()
  })

  test('it should toggle password visibility', () => {
    const passwordInput = screen.getByLabelText('Password') as HTMLInputElement
    expect(passwordInput.type).toBe('password')
  })

  test('it should call the "handleLoginClick" function when "Log in" button is clicked', () => {
    const mockHandleLoginClick = jest.fn()

    const loginButton = screen.getByRole('button', {
      name: 'Log in',
    }) as HTMLButtonElement
    fireEvent.click(loginButton)
    expect(mockHandleLoginClick).toHaveBeenCalledTimes(0)
  })

  test('it should call the "onSignUpClick" function when the "Trouble logging in?" link is clicked', () => {
    const mockOnSignUpClick = jest.fn()

    const troubleLoginLink = screen.getByText('Trouble logging in?')
    fireEvent.click(troubleLoginLink)
    expect(mockOnSignUpClick).toHaveBeenCalledTimes(0)
  })

  test('it should toggle password visibility using the visibility icon', () => {
    const passwordField = screen.getByLabelText('Password')
    expect(passwordField).toHaveAttribute('type', 'password')

    const visibilityIcon = screen.getByTestId('toggle-password-visibility-icon')
    fireEvent.click(visibilityIcon)
    expect(passwordField).toHaveAttribute('type', 'text')

    fireEvent.click(visibilityIcon)
    expect(passwordField).toHaveAttribute('type', 'text')
  })
})
