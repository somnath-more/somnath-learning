import { Grid, styled } from '@mui/material'
import CustomTextField from 'components/atoms/Input'

export const StyledContainer = styled(Grid)({
  flexDirection: 'column',
  width: '516px',
})

export const StyledTextField = styled(CustomTextField)({
  width: '516px',
})
