import { ChangeEvent, useEffect, useState } from 'react'
import { TradingAddress, tradingAddresses } from 'utils/types'
import { StyledContainer, StyledTextField } from './style'
import { Grid } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { CONFIRM_TRADING_ADDRESS, Constants } from 'utils/constants'
import { StyledCancelButton, StyledSaveButton } from 'utils/styles'
import RadioTypography from 'components/molecules/RadioTypography'
import AddressModal from '../AddressModal'
import _ from 'lodash'

export interface TradingAddressProps {
  title: string
  subtitle: string
  tradingAddresses: string
  onConfirmAddress: () => void
  saveAddress?: (data: TradingAddress[]) => void
}

const ConfirmTradingAddress = (props: TradingAddressProps) => {
  const [showModal, setShowModal] = useState<boolean>(false)
  const [tradeAddress, setTradeAddress] = useState<string>('')
  const [selectedAddressIndex, setSelectedAddressIndex] = useState<number>(0)
  const [isEditMode, setIsEditMode] = useState(false)
  const [tradingAddressList, setTradingAddressList] =
    useState<TradingAddress[]>(tradingAddresses)
  const [isFormValid, setIsFormValid] = useState(false)

  useEffect(() => {
    setIsFormValid(!_.isEmpty(tradeAddress))
  }, [tradeAddress])

  const addTradingAddress = (address: string) => {
    const trimmedAddress = address.trim()
    setTradingAddressList((prevList) => [
      ...prevList,
      { addressId: prevList.length + 1, address: trimmedAddress },
    ])
    setShowModal(false)
    if (props.saveAddress) {
      props.saveAddress(tradingAddressList)
    }
  }

  const saveEditedAddress = () => {
    const updatedAddressList = [...tradingAddressList]
    updatedAddressList[selectedAddressIndex].address = tradeAddress
    setTradingAddressList(updatedAddressList)
    setIsEditMode(false)
    if (props.saveAddress) {
      props.saveAddress(tradingAddressList)
    }
  }

  const handleAddressChange = (
    event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { value } = event.target
    setTradeAddress(value)
    if (props.saveAddress) {
      props.saveAddress(tradingAddressList)
    }
  }
  return (
    <StyledContainer container>
      <Grid item>
        <MuiTypography
          variant="h1"
          sx={{ color: theme.palette.Text.highEmphasis }}
        >
          {props.title}
        </MuiTypography>
      </Grid>
      <Grid item marginTop="12px" width="516px">
        <MuiTypography
          variant="body3"
          color={theme.palette.Text.mediumEmphasis}
        >
          {props.subtitle}
        </MuiTypography>
      </Grid>
      <Grid item marginTop="32px" flexDirection="row" gap="346px">
        <Grid container flexDirection="row">
          <Grid item marginRight="346px">
            <MuiTypography
              variant="body2"
              color={theme.palette.Text.mediumEmphasis}
            >
              {props.tradingAddresses}
            </MuiTypography>
          </Grid>
          <Grid item>
            {!isEditMode && (
              <MuiTypography
                variant="caption1"
                color={theme.palette.primary.primary500}
                onClick={() => {
                  setTradeAddress(
                    tradingAddressList[selectedAddressIndex].address
                  )
                  setIsEditMode(true)
                }}
                style={{ cursor: 'pointer', textDecoration: 'underline' }}
              >
                {Constants.EDIT}
              </MuiTypography>
            )}
          </Grid>
        </Grid>
      </Grid>
      <Grid item marginTop="12px">
        {isEditMode ? (
          <Grid container flexDirection="column">
            <Grid item padding="12px">
              <StyledTextField
                label={`Trading address ${selectedAddressIndex + 1}`}
                multiline={true}
                value={tradeAddress}
                onChange={handleAddressChange}
              />
            </Grid>
            <Grid item marginTop="62px">
              <Grid
                container
                flexDirection="column"
                justifyContent="center"
                alignItems="center"
              >
                <Grid item>
                  <StyledCancelButton
                    variant="contained"
                    style={{ width: '218px' }}
                    onClick={() => setIsEditMode(false)}
                  >
                    {Constants.CANCEL}
                  </StyledCancelButton>
                </Grid>
                <Grid item marginTop="20px">
                  <StyledSaveButton
                    variant="contained"
                    style={{ width: '218px' }}
                    disabled={!isFormValid}
                    onClick={saveEditedAddress}
                  >
                    {Constants.SAVE}
                  </StyledSaveButton>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        ) : (
          <Grid container flexDirection="column">
            <Grid item>
              {tradingAddressList.map((addressData, index) => (
                <Grid item key={addressData.addressId} marginLeft="24px">
                  <RadioTypography
                    key={addressData.addressId}
                    heading={`Address ${addressData.addressId}`}
                    content={addressData.address}
                    onClick={() => setSelectedAddressIndex(index)}
                    checked={index === selectedAddressIndex}
                    data-testid="radio-button"
                  />
                </Grid>
              ))}
            </Grid>
            <Grid item marginTop="40px">
              <Grid
                container
                flexDirection="column"
                justifyContent="center"
                alignItems="center"
              >
                <Grid item>
                  <StyledCancelButton
                    variant="contained"
                    style={{ width: '250px' }}
                    onClick={() => setShowModal(true)}
                  >
                    {CONFIRM_TRADING_ADDRESS.ADD_TRADING_ADDRESS}
                  </StyledCancelButton>
                </Grid>
                <Grid item marginTop="20px">
                  <StyledSaveButton
                    variant="contained"
                    style={{ width: '250px' }}
                    onClick={props.onConfirmAddress}
                  >
                    {Constants.CONFIRM}
                  </StyledSaveButton>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        )}
        {showModal && (
          <AddressModal
            open={showModal}
            onClose={() => {
              setShowModal(false)
            }}
            onSave={(address) => {
              setTradeAddress(address)
              addTradingAddress(address)
            }}
            tradingAddressList={tradingAddressList}
          />
        )}
      </Grid>
    </StyledContainer>
  )
}

export default ConfirmTradingAddress
