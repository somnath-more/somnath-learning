import {
  render,
  screen,
  fireEvent,
  waitFor,
  getByRole,
} from '@testing-library/react'
import { CONFIRM_TRADING_ADDRESS, Constants } from 'utils/constants'
import ConfirmTradingAddress, { TradingAddressProps } from '.'

const mockProps: TradingAddressProps = {
  title: CONFIRM_TRADING_ADDRESS.TITLE,
  subtitle: CONFIRM_TRADING_ADDRESS.SUBTITLE,
  tradingAddresses: CONFIRM_TRADING_ADDRESS.TRADING_ADRESSES,
  onConfirmAddress: jest.fn(),
}

const newAddress = 'New Address'
const testAddress = 'Trading address 1'

describe('ConfirmTradingAddress', () => {
  test('it should update the address and switch back to read-only mode when "Save" button is clicked', () => {
    render(<ConfirmTradingAddress {...mockProps} />)
    fireEvent.click(screen.getByText(Constants.EDIT))

    const addressInput = screen.getByLabelText(testAddress)
    fireEvent.change(addressInput, { target: { value: newAddress } })

    const saveButton = screen.getByText(Constants.SAVE)
    fireEvent.click(saveButton)

    expect(addressInput).not.toBeInTheDocument()
    expect(screen.getByText(newAddress)).toBeInTheDocument()
  })

  test('it should switch to read-only mode when "Cancel" button is clicked in edit mode', () => {
    render(<ConfirmTradingAddress {...mockProps} />)

    fireEvent.click(screen.getByText(Constants.EDIT))
    fireEvent.click(screen.getByText(Constants.CANCEL))
    expect(screen.getByText(Constants.EDIT)).toBeInTheDocument()
  })

  test('it should add a new trading address when "Add" button is clicked', () => {
    const { getByText } = render(<ConfirmTradingAddress {...mockProps} />)

    const addAddressButton = getByText(
      CONFIRM_TRADING_ADDRESS.ADD_TRADING_ADDRESS
    )
    fireEvent.click(addAddressButton)

    const modalTextField = screen.getByRole('textbox')
    fireEvent.change(modalTextField, { target: { value: 'Trading Address 2' } })
    expect(modalTextField).toHaveValue('Trading Address 2')

    waitFor(() => {
      const addButton = getByText('Add')
      fireEvent.click(addButton)
      expect(addButton).toHaveBeenCalledTimes(1)
    })
  })

  test('it should update the selected address onClick on address card', () => {
    render(<ConfirmTradingAddress {...mockProps} />)

    const addressCards = screen.getAllByTestId('radio-button')
    fireEvent.click(addressCards[0])
    waitFor(() => {
      expect(addressCards[0]).toHaveBeenCalledTimes(1)
    })
  })

  test('should call saveAddress when editing trading address', () => {
    const saveAddressMock = jest.fn()
    render(
      <ConfirmTradingAddress
        title="Title"
        subtitle="Subtitle"
        tradingAddresses="Trading Addresses"
        onConfirmAddress={() => {}}
        saveAddress={saveAddressMock}
      />
    )
    const editButton = screen.getByText('Edit')
    fireEvent.click(editButton)

    const addressInput = screen.getByLabelText('Trading address 1')
    fireEvent.change(addressInput, { target: { value: 'New Address 2' } })

    const saveButton = screen.getByText('Save')
    fireEvent.click(saveButton)

    expect(saveAddressMock).toHaveBeenCalledWith([
      { address: 'New Address 2', addressId: 1 },
    ])
  })

  test('should call saveAddress when adding a trading address', () => {
    const saveMock = jest.fn()
    render(
      <ConfirmTradingAddress
        title="Title"
        subtitle="Subtitle"
        tradingAddresses="Trading Addresses"
        onConfirmAddress={() => {}}
        saveAddress={saveMock}
      />
    )
    const addAddressButton = screen.getByText('Add trading address')
    fireEvent.click(addAddressButton)
    const modalAddressInput = screen.getByLabelText('Trading Address 2')
    fireEvent.change(modalAddressInput, { target: { value: 'New Address 3' } })

    const saveModalButton = screen.getByText('Add')
    fireEvent.click(saveModalButton)

    const addressCards = screen.getAllByTestId('radio-button')
    fireEvent.click(addressCards[1])
    const confirmButton = screen.getByText('Confirm')
    fireEvent.click(confirmButton)
    expect(saveMock).toHaveBeenCalledWith([
      { addressId: 1,  "address": "New Address 2", },
    ]);
  });
})
