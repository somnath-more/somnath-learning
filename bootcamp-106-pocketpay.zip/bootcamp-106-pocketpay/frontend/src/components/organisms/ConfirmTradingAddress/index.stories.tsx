import { Meta, StoryFn } from '@storybook/react'
import ConfirmTradingAddress from '.'
import { action } from '@storybook/addon-actions'
import { CONFIRM_TRADING_ADDRESS } from 'utils/constants'

export default {
  title: 'Organisms/Confirm Trading Address',
  component: ConfirmTradingAddress,
} as Meta<typeof ConfirmTradingAddress>

const Template: StoryFn<typeof ConfirmTradingAddress> = (args) => (
  <ConfirmTradingAddress {...args} />
)

export const Default = Template.bind({})
Default.args = {
  title: CONFIRM_TRADING_ADDRESS.TITLE,
  subtitle: CONFIRM_TRADING_ADDRESS.SUBTITLE,
  tradingAddresses: CONFIRM_TRADING_ADDRESS.TRADING_ADRESSES,
  onConfirmAddress: action('Continue button clicked'),
}
