import { fireEvent, render, screen } from '@testing-library/react'
import PayWithYourCard from '.'
import { BankCardData, Constants, ERROR_MESSAGES } from 'utils/constants'

describe('Pay with your card', () => {
  test('it should render the component with correct heading and content', () => {
    render(<PayWithYourCard bankCardData={BankCardData} />)
    const title = screen.getByText(Constants.PAY_WITH_YOUR_CARD)
    expect(title).toBeInTheDocument()
    expect(screen.getByText('SAVED CARD')).toBeInTheDocument()
    expect(screen.getByText('NEW CARD')).toBeInTheDocument()
  })

  test('it should change the tab on click', () => {
    render(<PayWithYourCard bankCardData={BankCardData} />)
    const savedCardTabContent = screen.getByTestId('save-tab-content')

    expect(screen.getByRole('tablist')).toBeInTheDocument()
    const saveCardTabLabel = screen.getByText('SAVED CARD')
    fireEvent.click(saveCardTabLabel)
    expect(savedCardTabContent).toBeInTheDocument()

    const newCardTabLabel = screen.getByText('NEW CARD')
    fireEvent.click(newCardTabLabel)
    expect(savedCardTabContent).not.toBeInTheDocument()
  })

  test('it should validate CVV code format for first textfield', () => {
    render(<PayWithYourCard bankCardData={BankCardData} />)
    const cvvInput = screen.getAllByLabelText('CVV / CVC')

    fireEvent.change(cvvInput[0], { target: { value: 1235 } })
    expect(screen.getByText(ERROR_MESSAGES.cvvCode)).toBeInTheDocument()

    fireEvent.change(cvvInput[0], { target: { value: 123 } })
    expect(cvvInput[0]).toHaveValue('123')
  })

  test('it should validate CVV code format for second textfield', () => {
    render(<PayWithYourCard bankCardData={BankCardData} />)

    const cvvInput = screen.getAllByLabelText('CVV / CVC')

    fireEvent.change(cvvInput[1], { target: { value: 1235 } })
    expect(screen.getByText(ERROR_MESSAGES.cvvCode)).toBeInTheDocument()

    fireEvent.change(cvvInput[1], { target: { value: 123 } })
    expect(cvvInput[1]).toHaveValue('123')
  })

  test('it should change the radio button on click', () => {
    render(<PayWithYourCard bankCardData={BankCardData} />)

    const radioButton = screen.getAllByTestId('radio-button')
    expect(radioButton[0]).toBeChecked

    const cvvInput = screen.getAllByLabelText('CVV / CVC')

    fireEvent.change(cvvInput[1], { target: { value: 123 } })
    expect(cvvInput[1]).toHaveValue('123')

    const radioButton2 = radioButton[1]
    fireEvent.click(radioButton2)
    expect(radioButton[1]).toBeChecked
    expect(cvvInput[1]).toBeNull
  })

  test('it should change the radio button on click', () => {
    render(<PayWithYourCard bankCardData={BankCardData} />)

    const radioButton = screen.getAllByTestId('radio-button')
    expect(radioButton[1]).not.toBeChecked

    const cvvInput = screen.getAllByLabelText('CVV / CVC')
    fireEvent.change(cvvInput[0], { target: { value: 123 } })
    expect(cvvInput[0]).toHaveValue('123')

    fireEvent.click(radioButton[1])
    expect(radioButton[1]).toBeChecked

    expect(cvvInput[0]).toBeNull
  })
})
