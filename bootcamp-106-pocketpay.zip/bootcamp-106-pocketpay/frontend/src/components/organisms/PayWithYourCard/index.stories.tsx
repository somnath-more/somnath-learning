import { StoryFn, Meta } from '@storybook/react'
import { action } from '@storybook/addon-actions'
import PayWithYourCard from '.'
import { BankCardData } from 'utils/constants'

const meta: Meta = {
  title: 'Organisms/PayWithYourCard',
  component: PayWithYourCard,
}
export default meta

const Template: StoryFn<typeof PayWithYourCard> = (args) => (
  <PayWithYourCard {...args} />
)

export const Primary = Template.bind({})

Primary.args = {
  bankCardData: BankCardData,
}
