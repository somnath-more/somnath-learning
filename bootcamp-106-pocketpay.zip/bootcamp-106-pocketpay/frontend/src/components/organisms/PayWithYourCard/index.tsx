import { Box, Stack, Tab, Tabs } from '@mui/material'
import CustomTextField from 'components/atoms/Input'
import MuiTypography from 'components/atoms/Typography'
import RadioTypography from 'components/molecules/RadioTypography'
import React, { useState } from 'react'
import theme from 'themes'
import CreditCardIcon from '@mui/icons-material/CreditCard'
import { BankCardData, Constants, ERROR_MESSAGES } from 'utils/constants'
import { validateCVVCodeFormat } from 'utils/credentials'

interface PayWithYourCardProps {
  bankCardData: typeof BankCardData
  setCardValue?: (validCvv: boolean) => void
}

interface TabProps {
  value: number
  index: number
  children: React.ReactNode
}
const TabPanel = (props: TabProps) => {
  return <div>{props.value === props.index && <>{props.children}</>}</div>
}

const PayWithYourCard = (props: PayWithYourCardProps) => {
  const [value, setValue] = React.useState(0)
  const [selectedRadio, setSelectedRadio] = useState<number>(0)
  const [cardFields, setCardFields] = useState<string[]>([])
  const [errors, setErrors] = useState<boolean[]>([])

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }

  const handleToggle = (index: React.SetStateAction<number>) => {
    setSelectedRadio(index)
    setCardFields([])
  }

  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement>,
    index: number
  ) => {
    const inputValue = event.target.value
    setCardFields((prev) => {
      const updatedFields = [...prev]
      updatedFields[index] = inputValue
      return updatedFields
    })

    const isValidCvv = validateCVVCodeFormat(inputValue)
    if(props.setCardValue) props.setCardValue(isValidCvv)
    setErrors((prev) => {
      const updatedErrors = [...prev]
      updatedErrors[index] = !isValidCvv
      return updatedErrors
    })
  }

  return (
    <Box sx={{ width: '500px', padding: '30px' }}>
      <MuiTypography
        variant="h1"
        sx={{ color: theme.palette.Text.highEmphasis }}
      >
        {Constants.PAY_WITH_YOUR_CARD}
      </MuiTypography>
      <Box
        sx={{
          borderBottom: 1,
          borderColor: 'divider',
          padding: '25px',
        }}
      >
        <Tabs value={value} onChange={handleTabChange}>
          <Tab label="SAVED CARD" />
          <Tab label="NEW CARD" sx={{ marginLeft: '45px' }} />
        </Tabs>
      </Box>

      <TabPanel value={value} index={0}>
        <Box sx={{ padding: '10px' }}>
          <Stack spacing={3} data-testid="save-tab-content">
            {props.bankCardData.map((data, index) => (
              <Stack key={data.id} direction="column" spacing={2}>
                <RadioTypography
                  heading={data.heading}
                  checked={selectedRadio === index}
                  onClick={() => handleToggle(index)}
                  cardNumber={data.cardNumber}
                  expiryDate={data.expiryDate}
                  hasCard
                />
                <Stack sx={{ paddingLeft: '70px' }}>
                  <CustomTextField
                    label="CVV / CVC"
                    type="text"
                    value={cardFields[index] || ''}
                    onChange={(e) => handleChange(e, index)}
                    sx={{
                      width: 'max-content',
                    }}
                    InputProps={{
                      endAdornment: <CreditCardIcon color="action" />,
                    }}
                  />
                  {errors[index] && (
                    <MuiTypography
                      variant="caption1"
                      color={theme.palette.Text.warning}
                      marginTop="8px"
                    >
                      {ERROR_MESSAGES.cvvCode}
                    </MuiTypography>
                  )}
                </Stack>
              </Stack>
            ))}
          </Stack>
        </Box>
      </TabPanel>
    </Box>
  )
}

export default PayWithYourCard
