import { render, screen, fireEvent } from '@testing-library/react'
import LloydsPaymentDetails from '.'

describe('LloydsPaymentDetails tests', () => {
  test('should render lloyds payment details component with correct heading and labels', () => {
    render(<LloydsPaymentDetails />)
    expect(
      screen.getByText(
        /Next, go to your Lloyds’s online banking and make a payment/i
      )
    ).toBeInTheDocument()
    expect(
      screen.getByText(/Our bank details for payments in GBP/i)
    ).toBeInTheDocument()
    expect(
      screen.getByText(
        /Below are the bank details for this payment. Please only send the money from an account in your name/i
      )
    ).toBeInTheDocument()
    expect(screen.getByText(/Payee Name/i)).toBeInTheDocument()
    expect(screen.getByText(/Use this reference/i)).toBeInTheDocument()
    expect(screen.getByText(/#356778810/i)).toBeInTheDocument()
    expect(screen.getByText(/Amount to send/i)).toBeInTheDocument()
    expect(screen.getByText(/UK Sort code/i)).toBeInTheDocument()
    expect(screen.getByText(/Account number/i)).toBeInTheDocument()
    expect(screen.getByText(/Our bank Address/i)).toBeInTheDocument()
    expect(screen.getByText(/You can use your Lloyds/i)).toBeInTheDocument()
    expect(
      screen.getByText(
        /or mobile app to make your bank transfer to pocket pay/i
      )
    ).toBeInTheDocument()
  })

  test('should render buttons', () => {
    const handleCancel = jest.fn()
    const handleContinue = jest.fn()
    render(
      <LloydsPaymentDetails confirm={handleContinue} cancel={handleCancel} />
    )
    const onlineBankingButton = screen.getByRole('button', {
      name: 'online banking',
    })
    expect(onlineBankingButton).toBeInTheDocument()
    const cancelTransferButton = screen.getByRole('button', {
      name: 'Cancel the transfer',
    })
    expect(cancelTransferButton).toBeInTheDocument()
    fireEvent.click(cancelTransferButton)
    expect(handleCancel).toHaveBeenCalledTimes(1)

    const continueButton = screen.getByRole('button', { name: 'Continue' })
    expect(continueButton).toBeInTheDocument()
    fireEvent.click(continueButton)
    expect(handleContinue).toHaveBeenCalledTimes(1)
  })
})
