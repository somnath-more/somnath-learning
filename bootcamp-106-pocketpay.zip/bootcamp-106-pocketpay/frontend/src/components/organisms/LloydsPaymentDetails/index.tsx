import { Grid, Paper, Stack, styled } from '@mui/material'
import theme from 'themes'
// import Lloyds from 'public/assets/image/Lloyds bank.svg'
import Lloyds from 'public/assets/image/IconhorseIcon.svg'
import {
  ACCOUNT_NUMBER,
  ACCOUNT_NUMBER_LABEL,
  BankDetailsBankAddress,
  BankDetailsHeading,
  BankDetailsPaperHeading,
  BankDetailsPaperInfo,
  CANCEL_THE_TRANSFER,
  Constants,
  lloydsPaymentDetails,
  ourBankAddress,
  youCanUseYourLloyds,
} from 'utils/constants'
import Button from 'components/atoms/Button'
import MuiTypography from 'components/atoms/Typography'
import Image from 'components/atoms/Image'

const StyledStack = styled(Stack)({
  overflowY: 'auto',
  '&::-webkit-scrollbar': {
    display: 'none',
  },
})

const StyledButton = styled(Button)`
  width: 14vw;
  height: 5.9vh;
  border-radius: ${theme.spacing(14)};
  text-transform: none;
`

interface LloydsPaymentDetailsProps {
  confirm?: () => void
  cancel?: () => void
}

const LloydsPaymentDetails = (props: LloydsPaymentDetailsProps) => {
  return (
    <StyledStack spacing={theme.spacing(2)} width="32vw">
      <MuiTypography variant={'h1'} color={theme.palette.text.primary}>
        {BankDetailsHeading}
      </MuiTypography>
      <Paper
        sx={{
          width: '27.9vw',
          padding: '2vw',
          border: `1px solid ${theme.palette.grey[300]}`,
          borderRadius: theme.spacing(4),
        }}
      >
        <Stack spacing={'2.7vh'}>
          <Stack alignItems={'center'}>
            <Image
              data-testid="bank-logo"
              alt="bankLogo"
              src={Lloyds}
              width={theme.spacing(10)}
              height={theme.spacing(10)}
            />
          </Stack>
          <Stack>
            <MuiTypography variant={'body1'}>
              {BankDetailsPaperHeading}
            </MuiTypography>
          </Stack>
          <Stack>
            <MuiTypography
              variant={'caption1'}
              color={theme.palette.text.secondary}
            >
              {BankDetailsPaperInfo}
            </MuiTypography>
          </Stack>
          <Stack>
            <Grid container spacing={'2vh'}>
              {lloydsPaymentDetails.map(
                (
                  entryList: { label: string; text: string }[],
                  index: number
                ) => {
                  return (
                    <>
                      <Grid item xs={8}>
                        <Stack>
                          <MuiTypography
                            variant={'caption1'}
                            color={theme.palette.text.secondary}
                          >
                            {entryList[0].label}
                          </MuiTypography>
                          <MuiTypography
                            variant={'body2'}
                            color={theme.palette.text.primary}
                          >
                            {entryList[0].text}
                          </MuiTypography>
                        </Stack>
                      </Grid>
                      <Grid item xs={4}>
                        <Stack>
                          <Stack>
                            <MuiTypography
                              variant={'caption1'}
                              color={theme.palette.text.secondary}
                            >
                              {entryList[1].label}
                            </MuiTypography>
                          </Stack>
                          <Stack>
                            <MuiTypography
                              variant={'body2'}
                              color={theme.palette.text.primary}
                            >
                              {entryList[1].text}
                            </MuiTypography>
                          </Stack>
                        </Stack>
                      </Grid>
                    </>
                  )
                }
              )}
              <Grid item xs={12}>
                <Stack>
                  <MuiTypography
                    variant={'caption1'}
                    color={theme.palette.text.secondary}
                  >
                    {ACCOUNT_NUMBER_LABEL}
                  </MuiTypography>
                  <MuiTypography>{ACCOUNT_NUMBER}</MuiTypography>
                </Stack>
              </Grid>
              <Grid item xs={6}>
                <Stack>
                  <MuiTypography
                    variant={'caption1'}
                    color={theme.palette.text.secondary}
                  >
                    {ourBankAddress}
                  </MuiTypography>
                  <MuiTypography
                    variant={'body2'}
                    color={theme.palette.text.primary}
                  >
                    {BankDetailsBankAddress}
                  </MuiTypography>
                </Stack>
              </Grid>
            </Grid>
          </Stack>
          <Stack>
            <MuiTypography
              variant={'caption1'}
              color={theme.palette.text.secondary}
            >
              {youCanUseYourLloyds[0]}
              <Button
                variant="text"
                children="online banking"
                sx={{ textTransform: 'none', textDecoration: 'underline' }}
              />
              {youCanUseYourLloyds[1]}
            </MuiTypography>
          </Stack>
          <Stack alignItems={'center'}>
            <StyledButton
              onClick={props.confirm}
              variant="contained"
              color="primary"
              children={
                <MuiTypography
                  variant={'body2'}
                  color={theme.palette.Structural.white}
                >
                  {Constants.CONTINUE}
                </MuiTypography>
              }
            />
          </Stack>
          <Stack alignItems={'center'}>
            <StyledButton
              variant="contained"
              children={
                <MuiTypography
                  variant={'body2'}
                  color={theme.palette.primary.main}
                >
                  {CANCEL_THE_TRANSFER}
                </MuiTypography>
              }
              onClick={props.cancel}
              sx={{
                backgroundColor: theme.palette.Structural.white,
                color: theme.palette.primary.primary500,
                '&:hover': {
                  backgroundColor: theme.palette.Structural.buttonHover,
                },
                boxShadow: `0px 0px 1px 0px #1414141F, 0px 0px 8px 0px #1414140A, 0px 8px 8px 0px #1414140A`,
              }}
            />
          </Stack>
        </Stack>
      </Paper>
    </StyledStack>
  )
}

export default LloydsPaymentDetails
