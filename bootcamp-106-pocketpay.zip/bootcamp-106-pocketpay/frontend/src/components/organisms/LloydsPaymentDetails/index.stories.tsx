import React from 'react'
import { StoryFn, Meta } from '@storybook/react'
import LloydsPaymentDetails from '.'

export default {
  title: 'Organisms/LloydsPaymentDetails',
  component: LloydsPaymentDetails,
} as Meta

const Template: StoryFn<typeof LloydsPaymentDetails> = (args) => (
  <LloydsPaymentDetails {...args} />
)

export const Default = Template.bind({})
Default.args = {
  confirm: () => {
    console.log('Confirm button clicked')
  },
}
