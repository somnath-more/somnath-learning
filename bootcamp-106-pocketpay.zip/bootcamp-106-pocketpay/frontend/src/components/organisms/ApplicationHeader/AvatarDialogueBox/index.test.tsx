import React from 'react'
import { fireEvent, render, screen } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import profile from 'public/assets/image/Avatar.svg'
import AvatarDialogueBox from '.'
import DialogOptions from '../DialogueBox'
import { useAuth0 } from '@auth0/auth0-react'

jest.mock('@auth0/auth0-react', () => ({
  useAuth0: jest.fn(),
}))

const mockUserValue = {
  name: 'John Doe',
}

const props = {
  open: true,
  anchorEl: document.createElement('img'),
  onClose: jest.fn(),
  onClick: jest.fn(),
  title: 'Test Title',
  caption: 'Test Caption',
}

describe('AvatarDialogueBox', () => {
  beforeEach(()=>{
    (useAuth0 as jest.Mock).mockReturnValue({
      user: mockUserValue,
    })
  })
  test('it should render correctly when the prop open is true', () => {
    const { getByText } = render(<DialogOptions {...props} />)
    const titleElement = getByText(props.title)
    const captionElement = getByText(props.caption)
    expect(titleElement).toBeInTheDocument()
    expect(captionElement).toBeInTheDocument()
  })

  test('it should call onClose when clicked on MenuItem', () => {
    const { getByText } = render(<DialogOptions {...props} />)
    const menuItem = getByText('Your details')
    fireEvent.click(menuItem)
    expect(props.onClose).toHaveBeenCalled()
  })

  test('it should render Avatar and name correctly', () => {
    (useAuth0 as jest.Mock).mockReturnValue({ user: null })
    render(<AvatarDialogueBox />)
    const nameElement = screen.getByText('Ross Gener')
    expect(nameElement).toBeInTheDocument()
  })

  test('it should open and close the dialog on Avatar click', () => {
    render(<AvatarDialogueBox />)
    const dialogOptions = screen.queryByTestId('dialog-options')
    expect(dialogOptions).toBeNull()
    const avatarImage = screen.getByTestId('avatar-image')
    fireEvent.click(avatarImage)
    const openedDialogOptions = screen.queryByTestId('dialog-options')
    expect(openedDialogOptions).toBeInTheDocument()
    const menuItem = screen.getByText('Your details')
    fireEvent.click(menuItem)
  })

  test('renders user name as title when user is logged in', () => {
    render(<AvatarDialogueBox />)

    const name = screen.getByTestId('user-name')
    expect(name).toBeInTheDocument()
    expect(name.textContent).toBe(mockUserValue.name)
  })
})
