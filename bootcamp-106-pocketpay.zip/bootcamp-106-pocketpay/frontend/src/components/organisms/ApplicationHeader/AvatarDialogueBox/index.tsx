import React, { useState } from 'react'
import DialogOptions from '../DialogueBox'
import profile from 'public/assets/image/Avatar.svg'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { Avatar, Box } from '@mui/material'
import MuiIcon from 'components/atoms/Icons'
import bell from 'public/assets/image/bell.svg'
import { styled } from 'styled-components'
import { Constants } from 'utils/constants'
import { useAuth0 } from '@auth0/auth0-react'

const StyledBox = styled(Box)({
  display: 'flex',
  gap: '20px',
  width: '209px',
  padding: '10px',
  alignItems: 'center',
})

const AvatarDialogueBox = () => {
  const { user } = useAuth0()
  const [anchorEl, setAnchorEl] = useState<HTMLImageElement | null>(null)

  const handleAvatarClick = (event: React.MouseEvent<HTMLImageElement>) => {
    setAnchorEl(event.currentTarget)
  }

  const handleCloseDialog = () => {
    setAnchorEl(null)
  }

  return (
    <>
      <StyledBox>
        <MuiIcon alt={'bell'} src={bell} width="24px" />
        <Avatar
          data-testid="avatar-image"
          src={user?.picture ?? profile}
          alt="Avatar"
          sx={{
            width: '28px',
            height: '28px',
            cursor: 'pointer',
          }}
          onClick={handleAvatarClick}
        />
        <MuiTypography
          data-testid="user-name"
          variant="caption1"
          color={theme.palette.Text.mediumEmphasis}
        >
          {user?.name ?? Constants.USER_NAME}
        </MuiTypography>
      </StyledBox>
      <DialogOptions
        open={!!anchorEl}
        anchorEl={anchorEl}
        onClose={handleCloseDialog}
        data-testid="close-button"
        title={user?.name ?? Constants.USER_NAME}
        caption={Constants.USER_ID}
      />
    </>
  )
}

export default AvatarDialogueBox
