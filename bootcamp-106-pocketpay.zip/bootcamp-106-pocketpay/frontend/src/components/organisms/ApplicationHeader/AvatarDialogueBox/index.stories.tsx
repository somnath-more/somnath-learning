import React from 'react'
import { StoryFn, Meta } from '@storybook/react'
import AvatarDialogueBox from '.'

export default {
  title: 'Organisms/ApplicationHeader',
  component: AvatarDialogueBox,
} as Meta

const Template: StoryFn = () => <AvatarDialogueBox />

export const Default = Template.bind({})
