import React from 'react'
import { render, fireEvent } from '@testing-library/react'
import DialogOptions from '.'
import { useAuth0 } from '@auth0/auth0-react'
const props = {
  open: true,
  anchorEl: document.createElement('img'),
  onClose: jest.fn(),
  title: 'Test Title',
  caption: 'Test Caption',
}

jest.mock('@auth0/auth0-react', () => ({
  useAuth0: jest.fn(),
}))

describe('DialogOptions', () => {
  let logoutMock = jest.fn()
  beforeEach(() => {
    (useAuth0 as jest.Mock).mockReturnValue({
      logout: logoutMock,
    })
  })
  
  test('it should render correctly when the prop open is true', () => {
    const { getByText } = render(<DialogOptions {...props} />)
    const titleElement = getByText(props.title)
    const captionElement = getByText(props.caption)
    expect(titleElement).toBeInTheDocument()
    expect(captionElement).toBeInTheDocument()
  })

  test('it should call onClose when clicked on MenuItem', () => {
    const { getByText } = render(<DialogOptions {...props} />)
    const menuItem = getByText('Your details')
    fireEvent.click(menuItem)
    expect(props.onClose).toHaveBeenCalledTimes(1)
  })

  test('it should call onClick when clicked on Logout', () => {
    const { getByText } = render(<DialogOptions {...props} />)
    const logoutItem = getByText('Logout')
    fireEvent.click(logoutItem)
    expect(logoutMock).toHaveBeenCalledTimes(1)
  })
})
