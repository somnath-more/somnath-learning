import React from 'react'
import { Box, Divider, MenuItem, Popover, styled } from '@mui/material'
import IconTypography from 'components/molecules/IconTypography'
import theme from 'themes'
import MuiTypography from 'components/atoms/Typography'
import { menuItems } from 'utils/constants'
import { useAuth0 } from '@auth0/auth0-react'

interface DialogOptionsProps {
  open: boolean
  anchorEl: HTMLImageElement | null
  onClose: () => void
  title: string
  caption: string
}

const StyledBox = styled(Box)({
  width: '209px',
  height: '309px',
  borderRadius: '8px',
})

const HeaderBox = styled(Box)({
  height: '60px',
  width: '209px',
  paddingLeft: '13px',
  paddingTop: '10px',
})

const MenuBox = styled(Box)({
  height: '56px',
  width: '209px',
})

const TitleBox = styled(Box)({
  fontWeight: 'bold',
  paddingLeft: '13px',
  paddingRight: '16px',
})

const DialogOptions = ({
  open,
  anchorEl,
  onClose,
  title,
  caption,
}: DialogOptionsProps) => {
  const { logout } = useAuth0()

  const handleClose = () => {
    onClose()
  }

  return (
    <Popover
      data-testid="dialog-options"
      open={open}
      anchorEl={anchorEl}
      onClose={handleClose}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'left',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
    >
      <StyledBox>
        <HeaderBox>
          <TitleBox>
            <MuiTypography variant="body2">{title}</MuiTypography>
          </TitleBox>
          <Box paddingLeft="13px">
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.lowEmphasis}
            >
              {caption}
            </MuiTypography>
          </Box>
        </HeaderBox>
        <Divider />
        <Box paddingTop="10px">
          {menuItems.map((menuItem) => (
            <MenuBox key={menuItem.id}>
              <MenuItem onClick={handleClose}>
                {menuItem.id === 4 ? (
                  <IconTypography
                    src={menuItem.icon}
                    alt={menuItem.alt}
                    text={menuItem.text}
                    iconColor={theme.palette.Text.highEmphasis}
                    textColor={theme.palette.Text.highEmphasis}
                    variant="body2"
                    onClick={logout}
                  />
                ) : (
                  <IconTypography
                    src={menuItem.icon}
                    alt={menuItem.alt}
                    text={menuItem.text}
                    disableClick
                    iconColor={theme.palette.Text.highEmphasis}
                    textColor={theme.palette.Text.highEmphasis}
                    variant="body2"
                  />
                )}
              </MenuItem>
            </MenuBox>
          ))}
        </Box>
      </StyledBox>
    </Popover>
  )
}

export default DialogOptions
