import React from 'react'
import { StoryFn, Meta } from '@storybook/react'
import DialogOptions from '.'

export default {
  title: 'Organisms/ApplicationHeader/DialogOptions',
  component: DialogOptions,
  argTypes: {
    open: {
      control: 'boolean',
    },
    anchorEl: {
      control: null,
    },
    onClose: {
      action: 'closed',
    },
    title: {
      control: 'text',
    },
    caption: {
      control: 'text',
    },
  },
} as Meta

const Template: StoryFn<typeof DialogOptions> = (args) => (
  <DialogOptions {...args} />
)

export const Default = Template.bind({})
Default.args = {
  open: true,
  anchorEl: null,
  title: 'Ross Gener',
  caption: 'P44561754',
}
