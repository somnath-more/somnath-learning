import { Box, IconButton, Stack } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import AddIcon from '@mui/icons-material/Add'
import { Constants, options } from 'utils/constants'
import {
  StyledButton,
  StyledContentStack,
  StyledContinueButton,
  StyledTextField,
} from './styles'
import React, { useState } from 'react'
import CloseIcon from '@mui/icons-material/Close'
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import MuiDropdown, { OptionItem } from 'components/atoms/Dropdown'
import { getOptionImage } from '../ConfirmShareHolders'
import { ErrorState } from 'utils/types'
import { validateFieldForUserInformation } from 'utils/credentials'
import moment, { Moment } from 'moment'
import CalendarTodayOutlinedIcon from '@mui/icons-material/CalendarTodayOutlined'

export interface ConfirmBusinessDirectorsProps {
  directorHeading: string
  subDirectorHeading: string
  directorTitle: string
  directorLink: string
  onClick?: () => void
}

export interface BusinessDirectors {
  firstName: string
  lastName: string
  dateOfBirth: Moment | null
  countryOfResidence: string
}

export const initialDirector: BusinessDirectors = {
  firstName: '',
  lastName: '',
  dateOfBirth: null,
  countryOfResidence: '',
}

const ConfirmBusinessDirectors: React.FC<ConfirmBusinessDirectorsProps> = ({
  ...props
}) => {
  const [directors, setDirectors] = useState<BusinessDirectors[]>([
    initialDirector,
  ])

  const [selectedCountry, setSelectedCountry] = useState<OptionItem | null>(
    null
  )

  const [errorMessages, setErrorMessages] = useState<ErrorState>({
    firstName: '',
    lastName: '',
  })

  const [index, setIndex] = useState<number>(0)

  const handleAddDirector = () => {
    setDirectors([...directors, initialDirector])
    setIndex(index + 1)
  }

  const handleRemoveDirectors = (index: number) => {
    const updatedDirectors = [...directors]
    updatedDirectors.splice(index, 1)
    setDirectors(updatedDirectors)
  }

  const shouldDisableDate = (date: Moment) => {
    const age18YearsAgo = moment().subtract(18, 'years')
    const age60YearsAgo = moment().subtract(60, 'years')

    return date.isAfter(age18YearsAgo) || date.isBefore(age60YearsAgo)
  }

  const handleChange = (
    index: number,
    event: React.ChangeEvent<HTMLInputElement>,
    field: keyof BusinessDirectors
  ) => {
    const updatedDirectors = directors.map((director, i) => {
      if (i === index) {
        return { ...director, [field]: event.target.value }
      }
      return director
    })
    setDirectors(updatedDirectors)

    const error = validateFieldForUserInformation(field, event.target.value)

    setErrorMessages((prevErrors) => ({
      ...prevErrors,
      [field]: error,
    }))
  }

  const handleCountryChange = (option: OptionItem | null) => {
    setSelectedCountry(option)
  }

  let isButtonDisable = false

  directors.forEach((director) => {
    if (
      !selectedCountry ||
      !!errorMessages.firstName ||
      !!errorMessages.lastName ||
      !director.firstName ||
      !director.lastName ||
      !director.dateOfBirth
    ) {
      isButtonDisable = true
    }
  })

  return (
    <Box>
      <StyledContentStack>
        <Stack spacing={5}>
          <MuiTypography
            variant="h1"
            sx={{ color: theme.palette.Text.highEmphasis }}
          >
            {props.directorHeading}
          </MuiTypography>
          <MuiTypography
            variant="body3"
            sx={{ color: theme.palette.Text.mediumEmphasis }}
          >
            {props.subDirectorHeading}
          </MuiTypography>
        </Stack>
        {directors.map((director, index) => (
          <>
            <Stack direction="row" sx={{ justifyContent: 'space-between' }}>
              <MuiTypography
                variant="body3"
                sx={{ color: theme.palette.Text.highEmphasis }}
              >
                {props.directorTitle} {index + 1}
              </MuiTypography>
              {index >= 1 && (
                <IconButton
                  onClick={() => handleRemoveDirectors(index)}
                  data-testid="close-icon"
                >
                  <CloseIcon />
                </IconButton>
              )}
            </Stack>

            <Stack spacing={10} data-testid="director-input">
              <StyledTextField
                label="First name"
                value={director.firstName}
                onChange={(e) => handleChange(index, e, 'firstName')}
              />
              {errorMessages.firstName && (
                <MuiTypography
                  variant="caption1"
                  color={theme.palette.Text.warning}
                  marginTop="8px"
                >
                  {errorMessages.firstName}
                </MuiTypography>
              )}
              <StyledTextField
                label="Last name"
                value={director.lastName}
                onChange={(e) => handleChange(index, e, 'lastName')}
              />
              {errorMessages.lastName && (
                <MuiTypography
                  variant="caption1"
                  color={theme.palette.Text.warning}
                  marginTop="8px"
                >
                  {errorMessages.lastName}
                </MuiTypography>
              )}

              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DatePicker
                  label="Date of birth"
                  format="DD-MM-YYYY"
                  disableFuture
                  views={['year', 'month', 'day']}
                  sx={{
                    '& .MuiSvgIcon-root': {
                      color: theme.palette.Accent.icon02,
                    },
                  }}
                  value={director.dateOfBirth ?? null}
                  onChange={(date) => {
                    let updateDirector = directors.map((director) => {
                      return { ...director, ['dateOfBirth']: date }
                    })
                    setDirectors(updateDirector)
                  }}
                  shouldDisableYear={shouldDisableDate}
                  slotProps={{
                    inputAdornment: {
                      position: 'end',
                    },
                  }}
                  slots={{
                    openPickerIcon: CalendarTodayOutlinedIcon,
                  }}
                />
              </LocalizationProvider>
              <MuiDropdown
                width="516px"
                label="Country of residence"
                options={options}
                getOptionImage={getOptionImage}
                onChange={handleCountryChange}
              />
            </Stack>
          </>
        ))}
        <StyledButton startIcon={<AddIcon />} onClick={handleAddDirector}>
          {props.directorLink}
        </StyledButton>
      </StyledContentStack>
      <Stack sx={{ justifyContent: 'flex-end' }}>
        <StyledContinueButton
          onClick={props.onClick}
          disabled={isButtonDisable}
        >
          {Constants.CONTINUE}
        </StyledContinueButton>
      </Stack>
    </Box>
  )
}

export default ConfirmBusinessDirectors
