import { StoryFn, Meta } from '@storybook/react'
import ConfirmBusinessDirectors from '.'
import { Director_Constants } from 'utils/constants'

const meta: Meta = {
  title: 'Organisms/ConfirmBusinessDirectors',
  component: ConfirmBusinessDirectors,
  argTypes: {
    onClick: {
      action: 'clicked',
    },
  },
}
export default meta

const Template: StoryFn<typeof ConfirmBusinessDirectors> = (args) => (
  <ConfirmBusinessDirectors {...args} />
)

export const Director = Template.bind({})

Director.args = {
  directorHeading: Director_Constants.DIRECTOR_HEADING,
  subDirectorHeading: Director_Constants.DIRECTOR_SUBHEADING,
  directorTitle: Director_Constants.DIRECTOR,
  directorLink: Director_Constants.DIRECTOR_LINK,
}
