import { fireEvent, render, screen } from '@testing-library/react'
import { Director_Constants } from 'utils/constants'
import ConfirmBusinessDirectors from '.'

const mockProps = {
  directorHeading: Director_Constants.DIRECTOR_HEADING,
  subDirectorHeading: Director_Constants.DIRECTOR_SUBHEADING,
  directorTitle: Director_Constants.DIRECTOR,
  directorLink: Director_Constants.DIRECTOR_LINK,
  onClick: jest.fn(),
}

describe('ConfirmBusinessDirectors', () => {
  beforeEach(() => {
    render(<ConfirmBusinessDirectors {...mockProps} />)
  })

  test('it should render the business directors with correct titles', () => {
    const continueButton = screen.getByText('Continue')
    const firstNameInputValue = screen.getByLabelText('First name')
    const lastNameInputValue = screen.getByLabelText('Last name')
    const dateInputValue = screen.getByLabelText('Date of birth')
    expect(screen.getByText(mockProps.directorHeading)).toBeInTheDocument()
    expect(screen.getByText(mockProps.subDirectorHeading)).toBeInTheDocument()
    expect(screen.getByText(mockProps.directorLink)).toBeInTheDocument()
    expect(continueButton).toBeInTheDocument()
    fireEvent.change(firstNameInputValue, { target: { value: 'John' } })
    expect(firstNameInputValue).toHaveValue('John')

    fireEvent.change(lastNameInputValue, { target: { value: 'Reddy' } })
    expect(lastNameInputValue).toHaveValue('Reddy')

    fireEvent.change(dateInputValue, { target: { value: '31-07-2023' } })
    expect(dateInputValue).toHaveValue('31-07-2023')
    const countrySelect = screen.getByLabelText('Country of residence')
    fireEvent.change(countrySelect, { target: { value: 'In' } })
    fireEvent.click(screen.getByText('India'))

    fireEvent.click(continueButton)
    expect(mockProps.onClick).toHaveBeenCalledTimes(1)
  })

  test('it should add a new director when add director link is clicked and should be able to remove a director when close icon is clicked', () => {
    expect(screen.getAllByTestId('director-input')).toHaveLength(1)

    const addDirectorButton = screen.getByText(mockProps.directorLink)
    fireEvent.click(addDirectorButton)

    expect(screen.getAllByTestId('director-input')).toHaveLength(2)
    const removeButton = screen.getByTestId('close-icon')

    fireEvent.click(removeButton)
    expect(screen.getAllByTestId('director-input')).toHaveLength(1)
  })

  test('it should add a new director when add another director is clicked', () => {
    const addButton = screen.getByText(mockProps.directorLink)
    fireEvent.click(addButton)

    const firstNameInputs = screen.getAllByLabelText('First name')
    fireEvent.change(firstNameInputs[1], { target: { value: 'John' } })
  })

  test('it should update director fields when input values change', () => {
    const firstNameInputValue = screen.getByLabelText('First name')
    const lastNameInputValue = screen.getByLabelText('Last name')
    const dateInputValue = screen.getByLabelText('Date of birth')
    const dropdownInputValue = screen.getByLabelText('Country of residence')

    fireEvent.change(firstNameInputValue, { target: { value: 'John' } })
    expect(firstNameInputValue).toHaveValue('John')

    fireEvent.change(lastNameInputValue, { target: { value: 'Reddy' } })
    expect(lastNameInputValue).toHaveValue('Reddy')

    fireEvent.change(dateInputValue, { target: { value: '31-07-2023' } })
    expect(dateInputValue).toHaveValue('31-07-2023')

    fireEvent.change(dropdownInputValue, { target: { value: 'A' } })
    expect(screen.getByTestId('option-image-Austria')).toBeInTheDocument()
  })
})
