import { Button, Stack, styled } from '@mui/material'
import CustomTextField from 'components/atoms/Input'
import theme from 'themes'

export const StyledContentStack = styled(Stack)`
  @media screen and (min-width: 600px) {
    width: 516px;
  }

  @media screen and (max-width: 600px) {
    width: 100%;
  }
  display: flex;
  margin: 30px 0 20px;
  gap: 20px;
  justify-content: space-between;
`

export const StyledTextField = styled(CustomTextField)({
  '& .MuiOutlinedInput-root': {
    '&.Mui-focused fieldset': {
      borderBottom: `2px solid ${theme.palette.primary.primary500}`,
    },
  },
})

export const StyledButton = styled(Button)`
  @media screen and (min-width: 600px) {
    width: 197px;
  }

  @media screen and (max-width: 600px) {
    width: 100%;
  }
  width: 197px;
  padding-left: 0px;
  text-transform: none;
`
export const StyledContinueButton = styled(Button)({
  padding: '16px 30px',
  height: '56px',
  width: '135px',
  borderRadius: '56px',
  textTransform: 'none',
  fontSize: '17px',
  left: '518px',
  bottom: '50px',
  boxShadow: '0px 8px 24px 0px #5533FF3D',
  backgroundColor: theme.palette.primary.primary500,
  color: theme.palette.Structural.white,
  '&:hover': {
    backgroundColor: theme.palette.primary.primary300,
  },
  '&:disabled': {
    backgroundColor: theme.palette.primary.primary100,
    color: theme.palette.Structural.white,
  },
})
