import { VisibilityOffOutlined, VisibilityOutlined } from '@mui/icons-material'
import { Grid, InputAdornment, styled } from '@mui/material'
import CustomTextField from 'components/atoms/Input'
import MuiTypography from 'components/atoms/Typography'
import { ChangeEvent, useState } from 'react'
import theme from 'themes'
import { Constants } from 'utils/constants'
import { validateFieldForLogIn } from 'utils/credentials'
import { StyledContinueButton } from 'utils/styles'

const PasswordContainer = styled(Grid)({
  display: 'flex',
  flexDirection: 'column',
  width: '516px',
  paddingBottom: '372px',
})
const StyledContainer = styled(Grid)({
  display: 'flex',
  flexDirection: 'row',
})

interface CreatePasswordProps {
  header: string
  onClick: () => void
  savePassword?: (password: string) => void
}

const CreatePassword = (props: CreatePasswordProps) => {
  const [showPassword, setShowPassword] = useState(false)
  const [inputPassword, setInputPassword] = useState<string>('')
  const [errors, setErrors] = useState<{ password: string }>({
    password: '',
  })

  const passwordVisibility = () => {
    setShowPassword((prevShowPassword) => !prevShowPassword)
  }

  const handleInput = (
    event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
    field: keyof { password: string }
  ) => {
    const { value } = event.target
    setInputPassword(value)

    if (props.savePassword) {
      props.savePassword(inputPassword)
    }

    const error = validateFieldForLogIn(field, value)

    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: error,
    }))
  }

  const isButtonDisabled = !!errors.password || !inputPassword

  return (
    <StyledContainer container>
      <Grid item>
        <PasswordContainer container>
          <Grid item>
            <MuiTypography variant="h1" color={theme.palette.Text.highEmphasis}>
              {props.header}
            </MuiTypography>
          </Grid>
          <Grid item marginTop="32px">
            <CustomTextField
              label={Constants.ENTER_PASSWORD}
              type={showPassword ? 'text' : 'password'}
              value={inputPassword}
              onChange={(event) => handleInput(event, 'password')}
              InputProps={{
                endAdornment: (
                  <InputAdornment
                    position="end"
                    style={{
                      cursor: 'pointer',
                      color: theme.palette.Text.highEmphasis,
                    }}
                  >
                    {showPassword ? (
                      <VisibilityOutlined
                        data-testid="toggle-password-visibility-icon"
                        onClick={passwordVisibility}
                      />
                    ) : (
                      <VisibilityOffOutlined
                        data-testid="toggle-password-visibility-icon"
                        onClick={passwordVisibility}
                      />
                    )}
                  </InputAdornment>
                ),
              }}
            />
            {errors.password && (
              <MuiTypography
                variant="caption1"
                color={theme.palette.Text.warning}
              >
                {errors.password}
              </MuiTypography>
            )}
          </Grid>
        </PasswordContainer>
      </Grid>
      <Grid item>
        <StyledContinueButton
          onClick={props.onClick}
          variant="contained"
          sx={{ top: '452px' }}
          disabled={isButtonDisabled}
        >
          {Constants.CONTINUE}
        </StyledContinueButton>
      </Grid>
    </StyledContainer>
  )
}

export default CreatePassword
