import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import CreatePassword from '.'
import { Constants } from 'utils/constants'

const mockProps = {
  header: Constants.CREATE_PASSWORD,
  onClick: jest.fn(),
}

describe('CreatePassword', () => {
  test('it should render the header correctly', () => {
    render(<CreatePassword {...mockProps} />)
    const header = screen.getByText(mockProps.header)
    expect(header).toBeInTheDocument()
  })

  test('it should render the password input correctly', () => {
    render(<CreatePassword {...mockProps} />)
    const passwordInput = screen.getByLabelText(Constants.ENTER_PASSWORD)
    expect(passwordInput).toHaveAttribute('type', 'password')
  })

  test('it should toggle password visibility when the visibility icon is clicked', () => {
    render(<CreatePassword {...mockProps} />)
    const visibilityIcon = screen.getByTestId('toggle-password-visibility-icon')
    const passwordInput = screen.getByLabelText(Constants.ENTER_PASSWORD)

    expect(passwordInput).toHaveAttribute('type', 'password')

    fireEvent.click(visibilityIcon)
    expect(passwordInput).toHaveAttribute('type', 'text')
    expect(visibilityIcon).toHaveAttribute(
      'data-testid',
      'toggle-password-visibility-icon'
    )
  })

  test('it should call the onClick function when the "Continue" button is clicked', () => {
    render(<CreatePassword {...mockProps} />)
    const passwordInput = screen.getByLabelText(Constants.ENTER_PASSWORD)
    const continueButton = screen.getByText(Constants.CONTINUE)

    fireEvent.change(passwordInput, { target: { value: 'strongPassword123' } })

    fireEvent.click(continueButton)
    waitFor(() => {
      expect(mockProps.onClick).toHaveBeenCalledTimes(1)
    })
  })
})
