import { action } from '@storybook/addon-actions'
import { Meta, StoryFn } from '@storybook/react'
import CreatePassword from '.'
import { Constants } from 'utils/constants'

export default {
  title: 'Organisms/Create a Password',
  component: CreatePassword,
} as Meta<typeof CreatePassword>

const Template: StoryFn<typeof CreatePassword> = (args) => (
  <CreatePassword {...args} />
)

export const Default = Template.bind({})
Default.args = {
  header: Constants.CREATE_PASSWORD,
  onClick: action('Continue is clicked'),
}
