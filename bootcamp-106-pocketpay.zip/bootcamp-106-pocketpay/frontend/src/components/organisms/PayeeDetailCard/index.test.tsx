import React from 'react'
import '@testing-library/jest-dom'
import { screen, render, fireEvent } from '@testing-library/react'
import PayeeDetailCard from '.'
import {
  CANCEL_THIS_TRANSFER,
  CONTINUE_TO_PAY,
  PAYEE_DETAIL_CARD_VALUES,
} from 'utils/constants'

const mockProps = {
  toAmount: '114.68 EUR',
  fromAmount: '100.00 GBP',
  handleCancel:jest.fn(),
  handleContinue:jest.fn()
}

describe('PayeeDetailCard', () => {
  test('it should render the text correctly', () => {
    render(<PayeeDetailCard {...mockProps} />)
    const textElement = screen.getByText(PAYEE_DETAIL_CARD_VALUES[0].heading)
    expect(textElement).toBeInTheDocument()
  })

  test('it should check Cancel button', () => {
    render(<PayeeDetailCard {...mockProps} />)
    const cancelButtonElement = screen.getByRole('button', {
      name: CANCEL_THIS_TRANSFER,
    })
    expect(cancelButtonElement).toBeInTheDocument()
    fireEvent.click(cancelButtonElement)
    expect(mockProps.handleCancel).toHaveBeenCalledTimes(1);
  })

  test('it should not render the button when props is given', () => {
    render(<PayeeDetailCard hasButtons={false} {...mockProps} />)
    const buttonElement = screen.queryByRole('button')
    expect(buttonElement).not.toBeInTheDocument()
  })

  test('it should check Continue button', () => {
    render(<PayeeDetailCard {...mockProps} />)
    const continueButtonElement = screen.getByRole('button', {
      name: CONTINUE_TO_PAY,
    })
    expect(continueButtonElement).toBeInTheDocument()
    fireEvent.click(continueButtonElement)
    expect(mockProps.handleContinue).toHaveBeenCalledTimes(1);
  })
})
