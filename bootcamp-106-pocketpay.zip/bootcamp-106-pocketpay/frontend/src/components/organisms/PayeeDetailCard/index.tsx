import { Box, Grid, Stack, styled } from '@mui/material'
import React from 'react'
import {
  CANCEL_THIS_TRANSFER,
  CONTINUE_TO_PAY,
  PAYEE_DETAIL_CARD_VALUES,
} from 'utils/constants'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import MuiIcon from 'components/atoms/Icons'
import Button from 'components/atoms/Button'
import LeftArrowIcon from 'public/assets/image/arrowLeft.svg'

const StyledBox = styled(Box)`
  padding: 30px;
  border-radius: 16px;
  box-sizing: border-box;
`
const StyledButtonStack = styled(Stack)`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px;
  flex-direction: column;
`

const commonButtonStyles = {
  borderRadius: '56px',
  textTransform: 'none',
  width: '218px',
  height: '56px',
  color: theme.palette.primary.primary500,
  backgroundColor: theme.palette.primary.contrastText,
  ':hover': {
    backgroundColor: theme.palette.Structural.buttonHover,
  },
};

const primaryButtonStyles = {
  borderRadius: '56px',
  textTransform: 'none',
  width: '218px',
  height: '56px',
  ':hover': {
    backgroundColor: theme.palette.primary.primary300,
  },
};

const secondaryButtonStyles = {
  borderRadius: '56px',
  textTransform: 'none',
  width: '218px',
  height: '56px',
  ':hover': {
    backgroundColor: theme.palette.primary.primary300,
  },
  '&:disabled': {
    backgroundColor: theme.palette.primary.primary100,
    color: theme.palette.Structural.white,
  },
};

const StyledStack = styled(Stack)`
  display: flex;
  justify-content: space-between;
  flex-direction: row;
  margin: 0 0 20px;
`
const StyledTypographyStack = styled(Stack)`
  display: flex;
  flex-direction: row;
  margin: 20px 0;
  gap: 20px;
`
const StyledGrid = styled(Grid)`
  margin: 30px 0 20px;
`
interface PayeeDetailCardProps {
  hasButtons?: boolean
  disableButtons?: boolean
  sx?: React.CSSProperties
  toAmount: string
  disableValue? : boolean
  fromAmount: string
  handleCancel?: () => void
  handleContinue?: () => void
  valueKeys?: string[]
}

const PayeeDetailCard = ({
  hasButtons = true,
  disableValue,
  disableButtons,
  sx,
  ...props
}: PayeeDetailCardProps) => {
  const renderOptionStacks = (
    options: { id: number; option: string; value: string }[],
    valueKeys?: string[]
  ) => {
    return options.map(
      (data: { id: number; option: string; value: string }) => (
        <StyledStack key={data.id}>
          <MuiTypography
            variant="body2"
            color={theme.palette.Text.mediumEmphasis}
          >
            {data.option}
          </MuiTypography>
          <MuiTypography
            variant="body2"
            color={theme.palette.Text.highEmphasis}
          >
            {valueKeys && valueKeys[data.id - 1]
              ? valueKeys[data.id - 1]
              : data.value}
          </MuiTypography>
        </StyledStack>
      )
    )
  }

  const renderButtons = () => {
    if (!hasButtons && !disableButtons) return null
    return(
    <StyledButtonStack>
        <Button
          variant="contained"
          data-testid="continue-test"
          sx={disableButtons ? secondaryButtonStyles : primaryButtonStyles}
          disabled={!disableValue && disableButtons}
          onClick={props.handleContinue}
        >
          {CONTINUE_TO_PAY}
        </Button>
        <Button
          variant="contained"
          data-testid="cancel-test"
          sx={commonButtonStyles}
          onClick={props.handleCancel}
        >
          {CANCEL_THIS_TRANSFER}
        </Button>
      </StyledButtonStack>
    )
  }

  return (
    <div>
      <StyledBox border={`1px solid ${theme.palette.Accent.stroke2}`} sx={sx}>
        <StyledStack>
          <MuiTypography
            variant="caption1"
            color={theme.palette.Text.lowEmphasis}
          >
            {PAYEE_DETAIL_CARD_VALUES[0].heading}
          </MuiTypography>
        </StyledStack>
        <StyledTypographyStack>
          <MuiTypography
            variant="body2"
            color={theme.palette.Text.highEmphasis}
          >
            {props.fromAmount}
          </MuiTypography>
          <MuiIcon
            src={LeftArrowIcon}
            alt="Left arrow MuiIcon"
            style={{ height: '24px' }}
          />
          <MuiTypography
            variant="body2"
            color={theme.palette.Text.highEmphasis}
          >
            {props.toAmount}
          </MuiTypography>
        </StyledTypographyStack>
        {renderOptionStacks(PAYEE_DETAIL_CARD_VALUES[0].options)}
        <StyledGrid>
          <MuiTypography
            variant="caption1"
            color={theme.palette.Text.lowEmphasis}
          >
            {PAYEE_DETAIL_CARD_VALUES[1].heading}
          </MuiTypography>
        </StyledGrid>
        {renderOptionStacks(
          PAYEE_DETAIL_CARD_VALUES[1].options,
          props.valueKeys
        )}

        {renderButtons()}
      </StyledBox>
    </div>
  )
}

export default PayeeDetailCard
