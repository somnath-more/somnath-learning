import React from 'react'
import { Meta, StoryFn } from '@storybook/react'
import PayeeDetailCard from '.'
import { GBP_AMOUNT, REVIEW_DETAILS_EUR_AMOUNT } from 'utils/constants'

export default {
  title: 'organisms/PayeeDetailCard',
  component: PayeeDetailCard,
} as Meta<typeof PayeeDetailCard>

const template: StoryFn<typeof PayeeDetailCard> = (args) => (
  <PayeeDetailCard {...args} />
)

export const Default = template.bind({})
Default.args = {
  hasButtons: true,
  sx: { width: '474px', height: '650' },
  fromAmount: GBP_AMOUNT,
  toAmount: REVIEW_DETAILS_EUR_AMOUNT,
}
