import { render, fireEvent, screen } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import RecipientDetails from '.'
import { Constants, ERROR_MESSAGES } from 'utils/constants'

describe('RecipientDetails', () => {
  test('it should display error messages for invalid email and account number', () => {
    render(
      <RecipientDetails
        checkboxLabel={Constants.RECIPIENT_CHECKBOX}
        IFSC_codeLabel={Constants.IFSC_LABEL}
        recipient={Constants.RECIPIENT_DETAILS}
      />
    )

    const emailInput = screen.getByLabelText('Email')
    const accountNumberInput = screen.getByLabelText('Account Number')

    fireEvent.change(emailInput, { target: { value: 'invalid-email' } })

    const invalidEmailError = screen.getByText((content, element) => {
      const errorMessage = ERROR_MESSAGES.email
      const elementHasCorrectClass =
        element !== null && element.classList.contains('MuiTypography-caption1')
      return elementHasCorrectClass && content.startsWith(errorMessage)
    })
    expect(invalidEmailError).toBeInTheDocument()

    fireEvent.change(accountNumberInput, { target: { value: 'abcde' } })

    const invalidAccountNumberError = screen.getByText((content, element) => {
      const errorMessage = ERROR_MESSAGES.accountNumber
      const elementHasCorrectClass =
        element !== null && element.classList.contains('MuiTypography-caption1')
      return elementHasCorrectClass && content.startsWith(errorMessage)
    })
    expect(invalidAccountNumberError).toBeInTheDocument()

    fireEvent.change(emailInput, {
      target: { value: 'valid-email@example.com' },
    })
    expect(screen.queryByText('Invalid email format')).toBeNull()

    fireEvent.change(accountNumberInput, {
      target: { value: '12345678901234' },
    })
    expect(screen.queryByText(ERROR_MESSAGES.accountNumber)).toBeNull()
  })

  test('it should enable the "Continue" button when all inputs are valid', () => {
    render(
      <RecipientDetails
        checkboxLabel={Constants.RECIPIENT_CHECKBOX}
        IFSC_codeLabel={Constants.IFSC_LABEL}
        recipient={Constants.RECIPIENT_DETAILS}
      />
    )

    const emailInput = screen.getByLabelText('Email')
    const accountNumberInput = screen.getByLabelText('Account Number')
    const firstName = screen.getByLabelText('First Name')
    const lastName = screen.getByLabelText('Last Name')
    const ifsc = screen.getByLabelText(Constants.IFSC_LABEL)
    const continueButton = screen.getByRole('button', {
      name: Constants.CONTINUE,
    })

    fireEvent.change(emailInput, {
      target: { value: 'validemail@example.com' },
    })
    fireEvent.change(accountNumberInput, {
      target: { value: '12345678901234' },
    })
    fireEvent.change(firstName, {
      target: { value: 'Valid' },
    })
    fireEvent.change(lastName, {
      target: { value: 'name' },
    })
    fireEvent.change(ifsc, {
      target: { value: 'IC1234' },
    })
    const countrySelect = screen.getByLabelText('Select Account type')
    fireEvent.change(countrySelect, { target: { value: 'Sa' } })
    fireEvent.click(screen.getByText('Savings'))

    expect(continueButton).not.toBeDisabled()
  })

  test('it should display error messages for invalid first name and last name', () => {
    render(
      <RecipientDetails
        checkboxLabel={Constants.RECIPIENT_CHECKBOX}
        IFSC_codeLabel={Constants.IFSC_LABEL}
        recipient={Constants.RECIPIENT_DETAILS}
      />
    )

    const firstNameInput = screen.getByLabelText('First Name')
    const lastNameInput = screen.getByLabelText('Last Name')

    fireEvent.change(firstNameInput, { target: { value: '1234' } })
    const invalidFirstNameError = screen.getByText(ERROR_MESSAGES.firstName)
    expect(invalidFirstNameError).toBeInTheDocument()

    fireEvent.change(lastNameInput, { target: { value: '5678' } })
    const invalidLastNameError = screen.getByText(ERROR_MESSAGES.lastName)
    expect(invalidLastNameError).toBeInTheDocument()
  })

  test('it should hide error messages when first name and last name are valid', () => {
    render(
      <RecipientDetails
        checkboxLabel={Constants.RECIPIENT_CHECKBOX}
        IFSC_codeLabel={Constants.IFSC_LABEL}
        recipient={Constants.RECIPIENT_DETAILS}
      />
    )
    const firstNameInput = screen.getByLabelText('First Name')
    const lastNameInput = screen.getByLabelText('Last Name')
    fireEvent.change(firstNameInput, { target: { value: 'John' } })
    expect(screen.queryByText(ERROR_MESSAGES.firstName)).not.toBeInTheDocument()

    fireEvent.change(lastNameInput, { target: { value: 'Doe' } })
    expect(screen.queryByText(ERROR_MESSAGES.lastName)).not.toBeInTheDocument()
  })

  test('it should display error message for invalid IFSC code', () => {
    render(
      <RecipientDetails
        checkboxLabel={Constants.RECIPIENT_CHECKBOX}
        IFSC_codeLabel={Constants.IFSC_LABEL}
        recipient={Constants.RECIPIENT_DETAILS}
      />
    )

    const ifscInput = screen.getByLabelText(Constants.IFSC_LABEL)

    fireEvent.change(ifscInput, { target: { value: 'invalidIFSC' } })
    const invalidIFSCError = screen.getByText(ERROR_MESSAGES.ifscCode)
    expect(invalidIFSCError).toBeInTheDocument()
  })
})
