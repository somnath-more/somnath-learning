import { StoryFn, Meta } from '@storybook/react'
import { Constants } from 'utils/constants'
import RecipientDetails from '.'

const meta: Meta = {
  title: 'Organisms/Recipient Details',
  component: RecipientDetails,
}
export default meta

const Template: StoryFn<typeof RecipientDetails> = (args) => (
  <RecipientDetails {...args} />
)

export const Primary = Template.bind({})

Primary.args = {
  checkboxLabel: Constants.RECIPIENT_CHECKBOX,
  ifscLabel: Constants.IFSC_LABEL,
  recipient: Constants.RECIPIENT_DETAILS,
}
