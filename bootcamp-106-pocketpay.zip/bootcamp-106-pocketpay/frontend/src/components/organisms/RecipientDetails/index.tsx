import { Box, Grid, styled } from '@mui/material'
import MuiDropdown, { OptionItem } from 'components/atoms/Dropdown'
import CustomTextField from 'components/atoms/Input'
import MuiTypography from 'components/atoms/Typography'
import CheckboxTypography from 'components/molecules/CheckboxTypography'
import { ChangeEvent, useState } from 'react'
import theme from 'themes'
import { Constants, accountType } from 'utils/constants'
import { validateFieldForRecipientDetails } from 'utils/credentials'
import { ErrorState, RecipientInformation } from 'utils/types'
import { StyledSaveButton } from 'utils/styles'

const StyledContainer = styled(Grid)({
  flexDirection: 'column',
})

const StyledTextField = styled(CustomTextField)({
  width: '525px',
  height: '60px',
})

interface RecipientDetailsProps {
  checkboxLabel: string
  IFSC_codeLabel: string
  recipient: string
  onSaveDetails?: () => void
  saveRecipientData?: (recipientData: RecipientInformation) => void
}

const RecipientDetails: React.FC<RecipientDetailsProps> = ({
  checkboxLabel,
  IFSC_codeLabel,
  recipient,
  onSaveDetails,
  saveRecipientData,
}) => {
  const [recipientDetails, setRecipientDetails] =
    useState<RecipientInformation>({
      name: '',
      email: '',
      account_number: '',
      first_name: '',
      last_name: '',
      account_type: '',
      IFSC_code: '',
    })

  const [errors, setErrors] = useState<ErrorState>({
    email: '',
    account_number: '',
    first_name: '',
    last_name: '',
    IFSC_code: '',
  })

  const [selectedAccount, setSelectedAccount] = useState<
    OptionItem | null | string
  >(null)

  const isButtonDisabled =
    !!errors.email ||
    !!errors.account_number ||
    !!errors.first_name ||
    !!errors.last_name ||
    !!errors.IFSC_code ||
    !!errors.account_number ||
    !recipientDetails.email ||
    !recipientDetails.account_number ||
    !recipientDetails.first_name ||
    !recipientDetails.last_name ||
    !recipientDetails.IFSC_code ||
    !selectedAccount

  const handleInputChange = (
    event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
    field: keyof RecipientInformation
  ) => {
    const { value } = event.target
    setRecipientDetails((prevState) => ({
      ...prevState,
      [field]: value,
    }))

    if (saveRecipientData) saveRecipientData(recipientDetails)
    const error = validateFieldForRecipientDetails(field, value)

    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: error,
    }))
  }

  const handlesSelectedAccount = (option: OptionItem | null) => {
    if (option) {
      setSelectedAccount(option.label)
      setRecipientDetails((prevState) => ({
        ...prevState,
        accountType: option.label,
      }))
      if (saveRecipientData) saveRecipientData(recipientDetails)
    }
  }

  return (
    <StyledContainer container>
      <Grid item>
        <MuiTypography variant="h1" color={theme.palette.Text.highEmphasis}>
          Send to someone
        </MuiTypography>
      </Grid>
      <Grid item marginTop="25px">
        <Box display="flex" flexDirection="column">
          <StyledTextField
            label="Email"
            value={recipientDetails.email}
            onChange={(event) => handleInputChange(event, 'email')}
          />
          {errors.email && (
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.warning}
              marginTop="8px"
            >
              {errors.email}
            </MuiTypography>
          )}
        </Box>
      </Grid>
      <Grid item marginTop="14px">
        <CheckboxTypography label={checkboxLabel} variant="body3" />
      </Grid>
      <Grid item marginTop="40px">
        <MuiTypography variant="body3">{recipient}</MuiTypography>
      </Grid>
      <Grid item marginTop="12px">
        <Box display="flex" flexDirection="column">
          <StyledTextField
            label="Account Number"
            onChange={(event) => handleInputChange(event, 'account_number')}
          />
          {errors.account_number && (
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.warning}
              marginTop="8px"
            >
              {errors.account_number}
            </MuiTypography>
          )}
        </Box>
      </Grid>
      <Grid item marginTop="25px">
        <Box display="flex" flexDirection="column">
          <StyledTextField
            label="First Name"
            onChange={(event) => handleInputChange(event, 'first_name')}
          />
          {errors.first_name && (
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.warning}
              marginTop="8px"
            >
              {errors.first_name}
            </MuiTypography>
          )}
        </Box>
      </Grid>
      <Grid item marginTop="25px">
        <Box display="flex" flexDirection="column">
          <StyledTextField
            label="Last Name"
            onChange={(event) => handleInputChange(event, 'last_name')}
          />
          {errors.last_name && (
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.warning}
              marginTop="8px"
            >
              {errors.last_name}
            </MuiTypography>
          )}
        </Box>
      </Grid>
      <Grid item marginTop="25px">
        <Box display="flex" flexDirection="column">
          <StyledTextField
            label={IFSC_codeLabel}
            onChange={(event) => handleInputChange(event, 'IFSC_code')}
          />
          {errors.IFSC_code && (
            <MuiTypography
              variant="caption1"
              color={theme.palette.Text.warning}
              marginTop="8px"
            >
              {errors.IFSC_code}
            </MuiTypography>
          )}
        </Box>
      </Grid>
      <Grid item marginTop="25px">
        <Box display="flex" alignItems="center">
          <MuiDropdown
            label="Select Account type"
            options={accountType}
            width="525px"
            height="60px"
            onChange={handlesSelectedAccount}
          />
          <StyledSaveButton
            variant="contained"
            onClick={onSaveDetails}
            disabled={isButtonDisabled}
          >
            <MuiTypography
              variant="body2"
              color={theme.palette.Structural.white}
            >
              {Constants.CONTINUE}
            </MuiTypography>
          </StyledSaveButton>
        </Box>
      </Grid>
    </StyledContainer>
  )
}

export default RecipientDetails
