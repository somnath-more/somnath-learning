import React, { useState } from 'react'
import Modal from '@mui/material/Modal'
import Box from '@mui/material/Box'
import { TextField } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import { ADD_BUTTON, ADD_TRADING_ADDRESS } from 'utils/constants'
import theme from 'themes'
import { TradingAddress } from 'utils/types'
import { StyledSaveButton } from 'utils/styles'

interface AddressModalProps {
  open: boolean
  onClose: () => void
  onSave: (address: string) => void
  tradingAddressList: TradingAddress[]
}

const AddressModal: React.FC<AddressModalProps> = ({
  open,
  onClose,
  onSave,
  tradingAddressList,
}) => {
  const [address, setAddress] = useState<string>('')

  const handleAddressChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setAddress(event.target.value)
  }

  const handleSaveAddress = () => {
    onSave(address)
    setAddress('')
    onClose()
  }

  const modalStyle = {
    position: 'absolute',
    width: 564,
    height: 306,
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    borderRadius: '16px',
    background: `${theme.palette.Structural.white}`,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'left',
    justifyContent: 'space-around',
    padding: 5,
    outline: 'none',
  }

  return (
    <Modal open={open} onClose={onClose}>
      <Box sx={modalStyle}>
        <MuiTypography
          variant="h1"
          sx={{ color: theme.palette.primary.primary500 }}
        >
          {ADD_TRADING_ADDRESS}
        </MuiTypography>
        <TextField
          label={`Trading Address ${tradingAddressList.length + 1}`}
          variant="outlined"
          value={address}
          onChange={handleAddressChange}
          multiline
          rows={3}
          sx={{ borderRadius: '8px' }}
        />
        <center>
          <StyledSaveButton
            variant="contained"
            disabled={!address.length}
            onClick={handleSaveAddress}
          >
            {ADD_BUTTON}
          </StyledSaveButton>
        </center>
      </Box>
    </Modal>
  )
}

export default AddressModal
