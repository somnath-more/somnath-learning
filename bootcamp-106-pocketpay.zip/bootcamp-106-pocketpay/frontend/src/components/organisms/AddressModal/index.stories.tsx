import React from 'react'
import { StoryFn, Meta } from '@storybook/react'
import AddressModal from '.'
import { action } from '@storybook/addon-actions'
import { tradingAddresses } from 'utils/types'

export default {
  title: 'Organisms/AddressModal',
  component: AddressModal,
} as Meta

const Template: StoryFn<typeof AddressModal> = (args) => (
  <AddressModal {...args} />
)

export const Default = Template.bind({})
Default.args = {
  open: true,
  onClose: action('Modal closed'),
  onSave: action('Address Saved'),
  tradingAddressList: tradingAddresses,
}
