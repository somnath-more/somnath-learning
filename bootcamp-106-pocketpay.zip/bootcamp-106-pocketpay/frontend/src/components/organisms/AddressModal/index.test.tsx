import { render, fireEvent, screen } from '@testing-library/react'
import AddressModal from '.'
import { tradingAddresses } from 'utils/types'

const open = true
const onClose = jest.fn()
const onSave = jest.fn()
const newAddress = '456 New Road, Town'

describe('AddressModal', () => {
  test('it should render the modal correctly with button', () => {
    const { getByLabelText, getByText } = render(
      <AddressModal
        open={open}
        onClose={onClose}
        onSave={onSave}
        tradingAddressList={tradingAddresses}
      />
    )

    const modalTitle = getByText(/Add Trading Address/i)
    expect(modalTitle).toBeInTheDocument()

    const addressInput = getByLabelText('Trading Address 2')
    expect(addressInput).toBeInTheDocument()
    const addButton = getByText('Add')
    expect(addButton).toBeInTheDocument()
  })

  test('it should call onSave and onClose when the "Add" button is clicked', () => {
    const { getByLabelText, getByText } = render(
      <AddressModal
        open={open}
        onClose={onClose}
        onSave={onSave}
        tradingAddressList={tradingAddresses}
      />
    )
    const addressInput = getByLabelText('Trading Address 2')
    fireEvent.change(addressInput, { target: { value: newAddress } })
    const addButton = getByText('Add')
    fireEvent.click(addButton)
    expect(onSave).toHaveBeenCalledTimes(1)
    expect(onSave).toHaveBeenCalledWith(newAddress)
    expect(onClose).toHaveBeenCalledTimes(1)
  })

  test('it should render the trading addresses correctly', () => {
    render(
      <AddressModal
        open={open}
        onClose={onClose}
        onSave={onSave}
        tradingAddressList={tradingAddresses}
      />
    )

    const modalTitle = screen.getByText(/Add Trading Address/i)
    expect(modalTitle).toBeInTheDocument()

    const addButton = screen.getByText('Add')
    expect(addButton).toBeInTheDocument()
  })
})
