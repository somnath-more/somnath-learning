import { StoryFn, Meta } from '@storybook/react'
import NavBar from '.'
import PocketPayLogo from 'public/assets/image/PocketPay.svg'
import {
  Constants,
  JarsConstants,
  SideNav,
  balancesConstants,
} from 'utils/constants'

const meta: Meta = {
  title: 'Organisms/NavigationBar',
  component: NavBar,
  argTypes: {
    onClick: {
      action: 'clicked',
    },
  },
}
export default meta

const Template: StoryFn<typeof NavBar> = (args) => <NavBar {...args} />

export const Primary = Template.bind({})

Primary.args = {
  logoUrl: PocketPayLogo,
  balances: balancesConstants,
  jars: JarsConstants,
  sideNav: SideNav,
  balanceHeader: Constants.BALANCES,
  jarHeader: Constants.JARS,
  hasBalances: true,
}
