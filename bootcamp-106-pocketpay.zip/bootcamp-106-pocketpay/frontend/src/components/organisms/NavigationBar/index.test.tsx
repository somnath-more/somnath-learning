import { fireEvent, render, screen } from '@testing-library/react'
import NavBar from '.'
import { JarsConstants, SideNav, balancesConstants } from 'utils/constants'

const mockProps = {
  logoUrl: 'public/assets/image/PocketPay.svg',
  hasBalances: false,
  balances: balancesConstants,
  jars: JarsConstants,
  sideNav: SideNav,
  balanceHeader: 'Balance',
  jarHeader: 'Jars',
  onClick: jest.fn(),
}

describe('NavBar', () => {
  test('it should render the logo with the correct alt text and URL', () => {
    render(<NavBar {...mockProps} />)
    const logoElement = screen.getByAltText('pocket pay logo')
    expect(logoElement).toBeInTheDocument()
    expect(logoElement).toHaveAttribute('src', mockProps.logoUrl)
  })

  test('it should render the list items', () => {
    render(<NavBar {...mockProps} hasBalances />)
    const home = screen.getByText('Home')
    const cards = screen.getByText('Cards')
    const balanceHeader = screen.getByTestId('BalanceHeader')
    expect(home).toBeInTheDocument()
    expect(cards).toBeInTheDocument()
    expect(balanceHeader).toBeInTheDocument()
  })

  test('it should call the onClick function when the Icon Typography is clicked', () => {
    render(<NavBar {...mockProps} />)
    const element = screen.getAllByTestId('icon-svg')
    element.forEach((item) => {
      item.onclick = mockProps.onClick
      fireEvent.click(item)
      expect(mockProps.onClick).toHaveBeenCalled()
    })
  })
})
