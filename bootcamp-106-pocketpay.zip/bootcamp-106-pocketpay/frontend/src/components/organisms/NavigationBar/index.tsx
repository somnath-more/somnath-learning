import { Box, Divider, Stack } from '@mui/material'
import styled from 'styled-components'
import IconTypography from 'components/molecules/IconTypography'
import MuiChip from 'components/atoms/Chip'
import theme from 'themes'
import MuiTypography from 'components/atoms/Typography'
import AvatarTypography from 'components/molecules/AvatarTypography'
import MuiIcon from 'components/atoms/Icons'
import { AvatarTypoProps, SideNavBarProps } from 'utils/types'
import React from 'react'

const StyledBox = styled(Box)({
  minWidth: '16.8vw',
  backgroundColor: '#fff',
  paddingTop: '10px',
  minHeight: '98vh',
})

const StyledRow = styled(Box)({
  padding: '5px',
  height: '34px',
  width: '192px',
  gap: '12px',
})

const StyledStack = styled(Stack)({
  padding: '15px',
  margin: '0px',
})

const StyledInnerBox = styled(Box)({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: '25px',
})

const StyledTypography = styled(MuiTypography)({
  color: theme.palette.Text.mediumEmphasis,
})

interface NavBarProps {
  logoUrl: any
  sideNav: SideNavBarProps[]
  balances: AvatarTypoProps[]
  jars: AvatarTypoProps[]
  hasBalances: boolean
  balanceHeader: string
  jarHeader: string
  onClick?: () => void
}

const NavBar = (props: NavBarProps) => {
  const [selected, setSelected] = React.useState(1)
  const handleClick = (SideNavBarProps: { id: number; title: string }) => {
    setSelected(SideNavBarProps.id)
  }
  return (
    <StyledBox>
      <StyledInnerBox>
        <MuiIcon
          alt="pocket pay logo"
          src={props.logoUrl}
          width="103px"
          height="22px"
        />
      </StyledInnerBox>
      <StyledStack spacing={3}>
        {props.sideNav.map((list) => (
          <StyledRow key={list.id}>
            <Stack
              direction="row"
              spacing={10}
              sx={{
                alignItems: 'center',
                justifyContent: 'flex-start',
              }}
            >
              <IconTypography
                src={list.src}
                alt="nav-images"
                text={list.title}
                variant="caption1"
                textColor={
                  selected === list.id
                    ? theme.palette.primary.primary500
                    : theme.palette.Text.mediumEmphasis
                }
                iconColor={
                  selected === list.id
                    ? theme.palette.primary.primary500
                    : theme.palette.Text.mediumEmphasis
                }
                onClick={() => handleClick(list)}
              />
              {list.isChip && (
                <MuiChip
                  label={list.isChip}
                  sx={{
                    width: '63px',
                    height: '26px',
                    borderRadius: '16px',
                    color: theme.palette.primary.primary500,
                    backgroundColor: theme.palette.Structural.buttonHover,
                  }}
                />
              )}
            </Stack>
          </StyledRow>
        ))}
      </StyledStack>
      {props.hasBalances && (
        <>
          <Divider />
          <StyledStack spacing={2}>
            <StyledTypography variant="caption1" data-testid="BalanceHeader">
              {props.balanceHeader}
            </StyledTypography>
            {props.balances.map((list) => (
              <AvatarTypography
                key={list.id}
                avatar={list.avatar}
                avatarAltText={list.avatarAltText}
                text={list.text}
                typoVariant={list.typoVariant}
                avatarHeight={list.avatarHeight}
                avatarWidth={list.avatarWidth}
                boxWidth={list.boxWidth}
                boxHeight={list.boxHeight}
                typoColorVariant={list.typoColorVariant}
              />
            ))}
          </StyledStack>
          <Divider />
          <StyledStack>
            <StyledTypography variant="caption1">
              {props.jarHeader}
            </StyledTypography>
            {props.jars.map((list) => (
              <AvatarTypography
                key={list.id}
                avatar={list.avatar}
                avatarAltText={list.avatarAltText}
                text={list.text}
                typoVariant={list.typoVariant}
                avatarHeight={list.avatarHeight}
                avatarWidth={list.avatarWidth}
                boxWidth={list.boxWidth}
                boxHeight={list.boxHeight}
                typoColorVariant={list.typoColorVariant}
              />
            ))}
          </StyledStack>
        </>
      )}
    </StyledBox>
  )
}

export default NavBar
