import { StoryFn, Meta } from '@storybook/react'
import TransferStatusCard from '.'
import { UPDATES_INFO } from 'utils/constants'
import { action } from '@storybook/addon-actions'

const meta: Meta = {
  title: 'Organisms/TransferStatusCard',
  component: TransferStatusCard,
}
export default meta

const Template: StoryFn<typeof TransferStatusCard> = (args) => (
  <TransferStatusCard {...args} />
)

export const Primary = Template.bind({})

Primary.args = {
  text: 'Mario Gabriel',
  gbpValue: '100 GBP',
  eurValue: '114.68 EUR',
  updates: UPDATES_INFO,
  activeSteps: 3,
  onCancelClick: action('Cancel Transfer is Clicked'),
  onRefundStatus: false,
}
