import { Avatar, Stack } from '@mui/material'
import MuiIcon from 'components/atoms/Icons'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import ArrowUpIcon from 'public/assets/image/arrowUp.svg'

interface HeadingSectionProps {
  text: string
  subText: string
  gbpValue: string
  eurValue: string
}

const HeaderSection = (props: HeadingSectionProps) => {
  return (
    <>
      <Stack direction="row" sx={{ padding: '10px', gap: '1140px' }}>
        <Stack direction="row" spacing={4}>
          <Avatar sx={{ backgroundColor: `${theme.palette.Structural.blue}` }}>
            <MuiIcon alt="icon" src={ArrowUpIcon} width="24px" height="24px" />
          </Avatar>
          <Stack spacing={1}>
            <MuiTypography
              variant="body2"
              sx={{ color: theme.palette.Text.highEmphasis }}
            >
              {props.text}
            </MuiTypography>
            <MuiTypography
              variant="caption1"
              sx={{ color: theme.palette.Text.mediumEmphasis }}
            >
              {props.subText}
            </MuiTypography>
          </Stack>
        </Stack>
        <Stack spacing={1} sx={{ textAlign: 'right', alignItems: 'center' }}>
          <MuiTypography
            variant="caption1"
            sx={{ color: theme.palette.Text.highEmphasis }}
          >
            {props.gbpValue}
          </MuiTypography>
          <MuiTypography
            variant="caption1"
            sx={{ color: theme.palette.Text.mediumEmphasis }}
          >
            {props.eurValue}
          </MuiTypography>
        </Stack>
      </Stack>
    </>
  )
}

export default HeaderSection
