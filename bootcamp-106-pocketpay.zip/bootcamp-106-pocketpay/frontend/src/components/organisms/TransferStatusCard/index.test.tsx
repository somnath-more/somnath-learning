import { fireEvent, render, screen } from '@testing-library/react'
import TransferStatusCard from '.'
import { Constants, UPDATES_INFO } from 'utils/constants'

const props = {
  text: 'Mario Gabriel',
  gbpValue: '100 GBP',
  eurValue: '114.68 EUR',
  updates: UPDATES_INFO,
  activeSteps: 4,
  onCancelClick: jest.fn(),
  onRefundStatus: false,
}

describe('TransferStatusCard', () => {
  test('it should render transfer status card accordion correctly', () => {
    render(<TransferStatusCard {...props} />)
    const accordion = screen.getByRole('accordion')
    expect(accordion).toBeInTheDocument()
  })

  test('it should change the tab on click', () => {
    const { container } = render(<TransferStatusCard {...props} />)
    const updateTabLabel = screen.getByText('UPDATES')
    fireEvent.click(updateTabLabel)

    const verticalStepper = screen.getByTestId('vertical-stepper')
    expect(verticalStepper).toBeInTheDocument()

    const activeStepElement = container.querySelector('.activestep')
    expect(activeStepElement).toBeInTheDocument()

    const detailsTabLabel = screen.getByText('DETAILS')
    fireEvent.click(detailsTabLabel)
  })

  test('it should display refund status', () => {
    render(<TransferStatusCard {...props} onRefundStatus />)
    const refund = screen.getByText(Constants.REFUND_MONEY)
    const refundStatus = screen.getByText(Constants.REFUND_MONEY_STATUS)

    expect(refund).toBeInTheDocument()
    expect(refundStatus).toBeInTheDocument()
  })

  test('it should render sharemodal on click', () => {
    render(<TransferStatusCard {...props} />)
    const modal = screen.getByTestId('ShareOutlinedIcon')
    expect(modal).toBeInTheDocument()
    fireEvent.click(modal)
    expect(screen.getByText(Constants.SHARE_MODAL_TITLE)).toBeInTheDocument()
  })
})
