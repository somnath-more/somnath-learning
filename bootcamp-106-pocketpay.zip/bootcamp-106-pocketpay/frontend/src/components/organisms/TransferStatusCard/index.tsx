import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Divider,
  IconButton,
  Stack,
  Tab,
  Tabs,
  styled,
} from '@mui/material'
import React, { useState } from 'react'
import VerticalStepper from 'components/molecules/VerticalStepper'
import {
  CANCEL_THE_TRANSFER,
  CANCEL_TRANFER_MODAL,
  Constants,
  StepsForVerticalStepper,
  selectExistingAccount,
} from 'utils/constants'
import ShareOutlinedIcon from '@mui/icons-material/ShareOutlined'
import HelpOutlineOutlinedIcon from '@mui/icons-material/HelpOutlineOutlined'
import ShareModalComponent from 'components/molecules/ShareModal'
import ImageIcon from 'public/assets/image/shareModalImage.svg'
import Button from 'components/atoms/Button'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import { StyledCancelButton } from 'utils/styles'
import HeaderSection from './HeaderSection'
import theme from 'themes'
import MuiTypography from 'components/atoms/Typography'
import CancelTransferModal from '../CancelTransferModal'
import { ReviewInfo } from 'utils/types'
import ScheduleDetails from '../ReviewDetailsCard/ScheduledDetails'

interface TransferStatusCardProps {
  text: string
  gbpValue: string
  eurValue: string
  updates: ReviewInfo[]
  onCancelClick: () => void
  activeSteps: number
  onRefundStatus: boolean
}

const StyledAccordion = styled(Accordion)`
  @media screen and (min-width: 769px) and (max-width: 1024px) {
    width: 100%;
  }
  @media screen and (min-width: 1025px) and (max-width: 1440px) {
    width: 1440px;
  }
  border-radius: 4px;
  box-shadow: 0px 1px 5px 0px #00000026;
  background: #ffffff;
`

interface TabProps {
  value: number
  index: number
  children: React.ReactNode
}
const TabPanel = (props: TabProps) => {
  return <div>{props.value === props.index && <>{props.children}</>}</div>
}

const TransferStatusCard = ({ ...props }: TransferStatusCardProps) => {
  const [value, setValue] = React.useState(0)
  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue)
  }

  const [shareModal, setShareModal] = useState(false)
  const [isCancelTransfer, setIsCancelTransfer] = useState<boolean>(false)

  const handleShareModalClick = () => {
    if (!isCancelTransfer) setShareModal(!shareModal)
  }
  const handleCancelTransferClick = () => {
    setIsCancelTransfer(!isCancelTransfer)
  }
  return (
    <Box>
      <StyledAccordion role="accordion">
        <AccordionSummary expandIcon={<ExpandMoreIcon />} id="panel-header">
          <HeaderSection
            text={props.text}
            subText={props.onRefundStatus ? 'Cancelled' : 'Sending'}
            gbpValue={props.gbpValue}
            eurValue={props.eurValue}
          />
        </AccordionSummary>
        <Divider />
        <Box
          sx={{
            borderBottom: 1,
            borderColor: 'divider',
            marginTop: '20px',
          }}
        >
          <Stack direction="row" sx={{ justifyContent: 'space-between' }}>
            <Tabs value={value} onChange={handleChange}>
              <Tab label="UPDATES" />
              <Tab label="DETAILS" />
            </Tabs>

            <Stack
              direction="row"
              spacing={3}
              sx={{
                alignItems: 'center',
                justifyContent: 'flex-end',
                paddingBottom: '10px',
                marginRight: '20px',
              }}
            >
              <Button
                sx={{
                  textTransform: 'none',
                  backgroundColor: theme.palette.Structural.blue,
                  color: theme.palette.Text.highEmphasis,
                  border: `1px solid ${theme.palette.Structural.main}`,
                }}
                endIcon={<ExpandMoreIcon />}
                disableRipple
              >
                General
              </Button>
              <IconButton onClick={handleShareModalClick}>
                {shareModal && (
                  <ShareModalComponent
                    src={ImageIcon}
                    open={shareModal}
                    onClose={handleShareModalClick}
                  />
                )}
                <ShareOutlinedIcon />
              </IconButton>
              <HelpOutlineOutlinedIcon />
            </Stack>
          </Stack>
        </Box>
        <AccordionDetails>
          <TabPanel value={value} index={0} data-testid="update-tab-content">
            {props.onRefundStatus ? (
              <>
                <Box sx={{ margin: '20px' }}>
                  <Stack sx={{ alignItems: 'flex-start', gap: '35px' }}>
                    <Stack spacing={3} width="400px">
                      <ScheduleDetails reviewInfo={props.updates} />
                    </Stack>

                    <Stack spacing={3}>
                      <MuiTypography
                        variant="body1"
                        sx={{ color: theme.palette.Text.highEmphasis }}
                      >
                        {Constants.REFUND_MONEY}
                      </MuiTypography>
                      <MuiTypography
                        variant="body3"
                        sx={{ color: theme.palette.Text.mediumEmphasis }}
                      >
                        {Constants.REFUND_MONEY_STATUS}
                      </MuiTypography>
                    </Stack>
                  </Stack>
                </Box>
              </>
            ) : (
              <>
                <Box sx={{ margin: '20px' }}>
                  <Stack sx={{ gap: '40px' }}>
                    <Stack spacing={3} width="400px">
                      <ScheduleDetails reviewInfo={props.updates} />
                    </Stack>
                    <VerticalStepper
                      steps={StepsForVerticalStepper}
                      activeStep={props.activeSteps}
                    />
                  </Stack>
                  <Stack sx={{ alignItems: 'flex-end' }}>
                    <StyledCancelButton
                      sx={{ width: '216px' }}
                      onClick={handleCancelTransferClick}
                    >
                      {CANCEL_THE_TRANSFER}
                    </StyledCancelButton>
                  </Stack>
                </Box>
                {isCancelTransfer && (
                  <CancelTransferModal
                    open={isCancelTransfer}
                    header={CANCEL_TRANFER_MODAL.HEADER}
                    refundMoney={CANCEL_TRANFER_MODAL.REFUND_MONEY}
                    existingAccounts={selectExistingAccount}
                    onClick={props.onCancelClick}
                    onClose={handleCancelTransferClick}
                  />
                )}
              </>
            )}
          </TabPanel>
        </AccordionDetails>
      </StyledAccordion>
    </Box>
  )
}

export default TransferStatusCard
