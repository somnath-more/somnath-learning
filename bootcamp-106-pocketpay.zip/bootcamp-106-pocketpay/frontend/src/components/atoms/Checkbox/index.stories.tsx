import React from 'react'
import { Meta, StoryFn } from '@storybook/react'
import CheckboxAtom, { Prop } from '.'

export default {
  title: 'Atoms/CheckboxAtom',
  component: CheckboxAtom,
} as Meta

const Template: StoryFn<Prop> = (args) => <CheckboxAtom {...args} />

export const CheckBox = Template.bind({})
CheckBox.args = {
  checked: false,
}
