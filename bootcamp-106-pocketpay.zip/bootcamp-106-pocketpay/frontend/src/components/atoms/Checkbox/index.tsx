import React from 'react'
import { Checkbox as MuiCheckbox, styled, CheckboxProps } from '@mui/material'
import theme from 'themes'

const StyledCheckbox = styled(MuiCheckbox)({
  width: '24px',
  height: '24px',
  color: theme.palette.primary.primary500,
  '&.Mui-checked': {
    color: theme.palette.primary.primary500,
  },
})
export interface Prop extends CheckboxProps {}
const CheckboxAtom = (props: Prop) => {
  return <StyledCheckbox {...props} />
}
export default CheckboxAtom
