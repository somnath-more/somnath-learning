import React from 'react'
import { render, screen } from '@testing-library/react'
import MuiChip from '.'
import { ChipProps } from '@mui/material'

const chipElement = 'Sample Chip'

describe('MuiChip', () => {
  const props: ChipProps = {
    label: chipElement,
    color: 'primary',
    onDelete: jest.fn(),
  }

  it('it should render the chip component with the provided props', () => {
    const { container } = render(<MuiChip {...props} />)
    const screenChipElement = screen.getByText(chipElement)
    expect(screenChipElement).toBeInTheDocument()
    expect(container.firstChild).toHaveTextContent(chipElement)
    expect(typeof props.onDelete).toBe('function')
  })
})
