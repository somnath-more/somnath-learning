import { StoryFn, Meta } from '@storybook/react'
import MuiChip from '.'
import theme from 'themes'

const meta: Meta = {
  title: 'Atoms/Chip',
  component: MuiChip,
}
export default meta

const Template: StoryFn<typeof MuiChip> = (args) => <MuiChip {...args} />

export const Primary = Template.bind({})

Primary.args = {
  label: 'New',
  sx: {
    color: theme.palette.primary.primary500,
    backgroundColor: theme.palette.Structural.buttonHover,
  },
}
