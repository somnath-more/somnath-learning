import React from 'react'
import { ChipProps, Chip } from '@mui/material'

const MuiChip = (props: ChipProps) => {
  return <Chip {...props} />
}

export default MuiChip
