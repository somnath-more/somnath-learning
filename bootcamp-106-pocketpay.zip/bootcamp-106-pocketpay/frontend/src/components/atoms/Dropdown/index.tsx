import React from 'react'
import TextField from '@mui/material/TextField'
import Autocomplete from '@mui/material/Autocomplete'
import { styled } from '@mui/material/styles'
import { Box, Grid } from '@mui/material'
import theme from 'themes'
import Typography from 'components/atoms/Typography'
import { getOptionLabel } from 'utils/dropdownUtils'

export interface OptionItem {
  id?: number
  imageUrl?: string
  label: string
  subLabel?: string
}

export interface DropdownProps {
  label?: string
  options: OptionItem[]
  width?: number | string
  height?: number | string
  backgroundColor?: string
  value?: OptionItem | null | string
  onChange?: (value: OptionItem | null) => void
  getOptionImage?: (option: OptionItem) => React.ReactNode
  sx?: React.CSSProperties
  disabled?: boolean
}

const StyledTextField = styled(TextField)({
  display: 'flex',
  alignItems: 'center',
  borderRadius: '8px',
  '& label.Mui-focused': {
    color: theme.palette.primary.primary500,
  },
  '& .MuiOutlinedInput-root': {
    '& fieldset': {
      color: theme.palette.Text.lowEmphasis,
      borderRadius: '8px',
    },
    '&:hover fieldset': {
      borderColor: theme.palette.Accent.stroke2,
      color: theme.palette.Text.lowEmphasis,
      borderRadius: '8px',
    },
    '&.Mui-focused fieldset': {
      borderColor: theme.palette.Accent.stroke2,
      color: theme.palette.Text.lowEmphasis,
      borderRadius: '8px',
      borderBottom: `2px solid ${theme.palette.primary.primary500}`,
    },
  },
})

const StyledBox = styled(Box)({
  '& .MuiAutocomplete-option.Mui-focused': {
    backgroundColor: theme.palette.Structural.white,
  },
  '& .MuiAutocomplete-option[aria-selected="true"].Mui-focused': {
    backgroundColor: theme.palette.Structural.white,
  },
  '& .MuiAutocomplete-option[aria-selected="true"]': {
    backgroundColor: theme.palette.Structural.white,
  },
})

const MuiDropdown: React.FC<DropdownProps> = ({
  label,
  options,
  width,
  height,
  backgroundColor,
  onChange,
  getOptionImage,
  disabled,
}) => {
  const renderOptionImage = (option: OptionItem) => {
    if (getOptionImage) {
      return getOptionImage(option)
    }
    return null
  }

  return (
    <Autocomplete
      disablePortal
      disabled={disabled}
      options={options}
      style={{ width: width, height: height }}
      onChange={(event, value) => onChange?.(value)}
      renderOption={(props, option) => (
        <StyledBox>
          <li
            {...props}
            style={{
              padding: 16,
              gap: 24,
              display: 'flex',
              alignItems: 'center',
              cursor: 'pointer',
            }}
          >
            {renderOptionImage(option)}
            <Grid container flexDirection="column">
              <Grid item>
                <Typography
                  variant="body2"
                  color={theme.palette.Text.highEmphasis}
                >
                  {getOptionLabel(option, label ?? '')}
                </Typography>
              </Grid>
              {option.subLabel && (
                <Grid item>
                  <Typography
                    variant="body2"
                    color={theme.palette.Text.mediumEmphasis}
                    marginTop="9px"
                  >
                    {`Ending in ${option.subLabel.slice(-4)}`}
                  </Typography>
                </Grid>
              )}
            </Grid>
          </li>
        </StyledBox>
      )}
      renderInput={(params) => (
        <StyledTextField
          {...params}
          label={label ?? 'Select currency'}
          sx={{ backgroundColor: { backgroundColor } }}
          InputProps={{
            ...params.InputProps,
          }}
        />
      )}
    />
  )
}

export default MuiDropdown
