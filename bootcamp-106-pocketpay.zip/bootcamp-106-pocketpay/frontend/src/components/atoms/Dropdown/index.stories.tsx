import React from 'react'
import { Meta, StoryFn } from '@storybook/react'
import MuiDropdown, { DropdownProps, OptionItem } from './index'
import uk from 'public/assets/image/uk.svg'
import austria from 'public/assets/image/Lloyds bank.svg'

export default {
  component: MuiDropdown,
  title: 'Atoms/Dropdown',
} as Meta

const Template: StoryFn<typeof MuiDropdown> = (args) => (
  <MuiDropdown {...args} />
)

const options: OptionItem[] = [
  { label: 'Option 1', imageUrl: `${uk}` },
  { label: 'Option 2', imageUrl: `${austria}` },
]

export const Default = Template.bind({})
Default.args = {
  label: 'Select currency',
  options: options,
  getOptionImage: (option) => (
    <img
      src={option.imageUrl}
      alt={option.label}
      style={{ width: '24px', height: '24px' }}
    />
  ),
}
