import React from 'react'
import { render, fireEvent } from '@testing-library/react'
import MuiDropdown, { OptionItem } from '.'
import '@testing-library/jest-dom'
import { Avatar } from '@mui/material'

describe('MuiDropdown', () => {
  const options: OptionItem[] = [
    { imageUrl: 'image1.jpg', label: 'Option 1' },
    { imageUrl: 'image2.jpg', label: 'Option 2' },
    { imageUrl: 'image3.jpg', label: 'Option 3' },
  ]

  test('it should render the MuiDropdown component', () => {
    const { getByLabelText } = render(<MuiDropdown options={options} />)
    const comboBoxInput = getByLabelText('Select currency')
    expect(comboBoxInput).toBeInTheDocument()
  })

  test('it should display option when clicked', () => {
    const { getByLabelText, getByText } = render(
      <MuiDropdown options={options} />
    )
    const dropdownInput = getByLabelText('Select currency')

    fireEvent.mouseDown(dropdownInput)

    const option1 = getByText('Option 1')
    const option2 = getByText('Option 2')
    const option3 = getByText('Option 3')

    expect(option1).toBeInTheDocument()
    expect(option2).toBeInTheDocument()
    expect(option3).toBeInTheDocument()
  })

  test('it should call onChange when an option is selected', () => {
    const mockOnChange = jest.fn()
    const { getByLabelText, getByText } = render(
      <MuiDropdown options={options} onChange={mockOnChange} />
    )
    const dropdownInput = getByLabelText('Select currency')

    fireEvent.mouseDown(dropdownInput)

    const option2 = getByText('Option 2')
    fireEvent.click(option2)

    expect(mockOnChange).toHaveBeenCalledWith(options[1])
    expect(mockOnChange).toHaveBeenCalledTimes(1)
  })

  test('it should return the correct label for getOptionLabel', () => {
    const { getByLabelText, getByText } = render(
      <MuiDropdown options={options} />
    )
    const dropdownInput = getByLabelText('Select currency')

    fireEvent.mouseDown(dropdownInput)

    const option1 = getByText('Option 1')
    const option2 = getByText('Option 2')

    expect(option1).toBeInTheDocument()
    expect(option2).toBeInTheDocument()

    const option1Label = option1.textContent
    const option2Label = option2.textContent

    expect(option1Label).toBe('Option 1')
    expect(option2Label).toBe('Option 2')
  })

  test('it should call onChange with the selected option', () => {
    const mockOnChange = jest.fn()
    const { getByLabelText, getByText } = render(
      <MuiDropdown options={options} onChange={mockOnChange} />
    )
    const dropdownInput = getByLabelText('Select currency')

    fireEvent.mouseDown(dropdownInput)

    const option2 = getByText('Option 2')
    fireEvent.click(option2)

    expect(mockOnChange).toHaveBeenCalledTimes(1)
    expect(mockOnChange).toHaveBeenCalledWith(options[1])
  })

  test('it should display the option image', () => {
    const mockGetOptionImage = jest.fn()
    mockGetOptionImage.mockReturnValue(<Avatar src="image1.jpg" />)
    const { getByLabelText, getByText } = render(
      <MuiDropdown options={options} getOptionImage={mockGetOptionImage} />
    )
    const dropdownInput = getByLabelText('Select currency')
    fireEvent.mouseDown(dropdownInput)
    const option1Image = getByText('Option 1')
    const option2Image = getByText('Option 2')
    const option3Image = getByText('Option 3')
    expect(option1Image).toBeInTheDocument()
    expect(option2Image).toBeInTheDocument()
    expect(option3Image).toBeInTheDocument()
  })
})
