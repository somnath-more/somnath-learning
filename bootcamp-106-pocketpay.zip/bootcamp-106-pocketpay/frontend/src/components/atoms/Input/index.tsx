import React from 'react'
import { TextField, styled } from '@mui/material'
import theme from 'themes'

interface CustomTextFieldProps {
  children?: React.ReactNode | string
  variant?: 'standard' | 'outlined' | 'filled'
  placeholder?: string
  sx?: object
  label?: string
  style?: React.CSSProperties
  InputProps?: object
  width?: number
  onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void
  required?: boolean
  disabled?: boolean
  helperText?: string
  default?: string
  size?: 'medium' | 'small'
  type?: string
  multiline?: boolean
  value?: string
}

const CustomField = styled(TextField)({
  display: 'flex',
  alignItems: 'center',
  borderRadius: '8px',
  '& label.Mui-focused': {
    color: theme.palette.primary.primary500,
  },
  '& .MuiOutlinedInput-root': {
    borderRadius: '8px',
    '& fieldset': {
      color: theme.palette.Text.lowEmphasis,
    },
    '&:hover fieldset': {
      borderColor: theme.palette.Accent.stroke2,
      color: theme.palette.Text.lowEmphasis,
    },
    '&.Mui-focused fieldset': {
      borderColor: theme.palette.Accent.stroke2,
      color: theme.palette.Text.lowEmphasis,
      borderBottom: `2px solid ${theme.palette.primary.primary500}`,
    },
  },
  '& .MuiInputLabel-root': {
    color: theme.palette.Text.lowEmphasis,
  },
})

const CustomTextField: React.FC<CustomTextFieldProps> = (
  props: CustomTextFieldProps
) => {
  return <CustomField {...props} fullWidth />
}

export default CustomTextField
