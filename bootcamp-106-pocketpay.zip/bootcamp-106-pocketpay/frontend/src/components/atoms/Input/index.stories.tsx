import React, { useState } from 'react'
import { StoryFn, Meta } from '@storybook/react'
import CustomTextField from '.'

export default {
  title: 'Atoms/TextField',
  component: CustomTextField,
} as Meta<typeof CustomTextField>

const Template: StoryFn<typeof CustomTextField> = (args) => (
  <CustomTextField {...args} />
)

export const Default = Template.bind({})
Default.args = {
  label: 'First Name',
  variant: 'outlined',
  sx: {
    width: '516px',
    height: '60px',
  },
  onChange: () => console.log('onChange event'),
}
