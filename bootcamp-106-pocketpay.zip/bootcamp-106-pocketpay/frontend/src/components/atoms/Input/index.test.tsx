import React from 'react'
import { render, screen, fireEvent } from '@testing-library/react'
import CustomTextField from '.'
import '@testing-library/jest-dom/extend-expect'

describe('CustomTextField', () => {
  test('it should render with provided label', () => {
    render(<CustomTextField label="Test Label" />)

    const labelElement = screen.getByLabelText('Test Label')
    expect(labelElement).toBeInTheDocument()
  })

  test('it should update the input value when onChange is called', () => {
    render(<CustomTextField />)

    const inputElement = screen.getByRole('textbox') as HTMLInputElement
    fireEvent.change(inputElement, { target: { value: 'New Value' } })

    expect(inputElement.value).toBe('New Value')
  })
})
