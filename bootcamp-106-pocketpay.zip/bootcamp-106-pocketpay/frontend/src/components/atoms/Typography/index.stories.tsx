import { StoryFn, Meta } from '@storybook/react'
import MuiTypography from '.'
import theme from 'themes'

const meta: Meta = {
  title: 'Atoms/Typography',
  component: MuiTypography,
  argTypes: {
    align: {
      options: ['center', 'inherit', 'justify', 'left', 'right'],
      control: { type: 'radio' },
    },
    variant: {
      options: ['h1', 'body1', 'body2', 'body3', 'caption1', 'linkText'],
      control: { type: 'radio' },
    },
  },
}
export default meta

const Template: StoryFn<typeof MuiTypography> = (args) => (
  <MuiTypography {...args} />
)

export const Primary = Template.bind({})

Primary.args = {
  children: 'Transfer details',
  variant: 'h1',
  align: 'center',
  sx: {
    color: theme.palette.Text.lowEmphasis,
  },
}
