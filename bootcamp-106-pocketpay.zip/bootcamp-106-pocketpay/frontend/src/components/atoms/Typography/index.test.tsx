import * as React from 'react'
import { render, screen } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import MuiTypography from '.'

describe('Test Suit for Typography', () => {
  test('renders Typography component correctly', () => {
    render(<MuiTypography>PocketPay</MuiTypography>)
    const text = screen.getByText(/PocketPay/i)
    expect(text).toBeInTheDocument()
  })

  test('render heading', () => {
    render(
      <MuiTypography variant="h1" children="Review Details of your transfer" />
    )
    const heading = screen.getByRole('heading')
    expect(heading).toBeInTheDocument()
  })
})
