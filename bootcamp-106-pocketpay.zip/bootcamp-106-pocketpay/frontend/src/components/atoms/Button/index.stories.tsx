import React from 'react'
import { Meta, StoryFn } from '@storybook/react'
import Button from '.'
import theme from 'themes'

export default {
  title: 'Atoms/Button',
  component: Button,
  argTypes: {
    onClick: {
      action: 'clicked',
    },
    variant: {
      options: ['contained', 'outlined', 'text'],
      control: { type: 'radio' },
    },
  },
} as Meta

const Template: StoryFn<typeof Button> = (args) => <Button {...args} />

export const LoginButton = Template.bind({})
LoginButton.args = {
  children: 'Log in',
  sx: {
    textTransform: 'none',
    borderRadius: '56px',
  },
}
export const Cancel = Template.bind({})
Cancel.args = {
  children: 'Cancel',
  sx: {
    backgroundColor: theme.palette.Structural.white,
    color: theme.palette.primary.primary500,
    textTransform: 'none',
    font: theme.typography.body2,
    width: '135px',
    height: '56px',
    borderRadius: '56px',
  },
}
