import React from 'react'
import { render, screen } from '@testing-library/react'
import MyAvatar from '.'

describe('MyAvatar', () => {
  it('renders the avatar with the provided alt text and src', () => {
    const altText = 'Avatar not found'
    const imagePath = 'path/to/avatar.png'

    render(<MyAvatar alt={altText} src={imagePath} />)

    const avatarElement = screen.getByAltText(altText)
    expect(avatarElement).toBeInTheDocument()
    expect(avatarElement).toHaveAttribute('src', imagePath)
  })
})
