import { render, fireEvent, screen } from '@testing-library/react'
import RadioButton from '.'

describe('RadioButton test suit', () => {
  test('it should render radio with default props', () => {
    render(<RadioButton size="medium" />)
    const radio = screen.getByRole('radio')
    expect(radio).toBeInTheDocument()
    expect(radio).toHaveClass('PrivateSwitchBase-input css-1m9pwf3')
    expect(radio).toHaveAttribute('name', 'radio-buttons')
  })

  test('it should render if the radio button is checked or unchecked', () => {
    const { getByRole } = render(<RadioButton />)
    const radioButton = getByRole('radio')
    expect(radioButton).not.toBeChecked()
    fireEvent.click(radioButton, { target: { checked: true } })
    expect(radioButton).toBeChecked()
  })
})
