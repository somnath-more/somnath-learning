import { Radio, RadioProps, styled } from '@mui/material'
import theme from 'themes'

const StyledRadioButton = styled(Radio)({
  color: theme.palette.Structural.main,
  '&.Mui-checked': {
    color: theme.palette.primary.primary500,
  },
})

const RadioButton = (props: RadioProps) => {
  const { size = 'medium', ...restProps } = props

  return (
    <div>
      <StyledRadioButton size={size} name="radio-buttons" {...restProps} />
    </div>
  )
}

export default RadioButton
