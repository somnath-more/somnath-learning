import { StoryFn, Meta } from '@storybook/react'
import RadioButton from '.'

const meta: Meta = {
  title: 'Atoms/RadioButton',
  component: RadioButton,
  argTypes: {
    size: {
      options: ['small', 'medium'],
      control: 'radio',
    },
    onChange: { action: 'clicked' },
  },
}
export default meta

const Template: StoryFn<typeof RadioButton> = (args) => (
  <RadioButton {...args} />
)

export const Primary = Template.bind({})

Primary.args = {}
