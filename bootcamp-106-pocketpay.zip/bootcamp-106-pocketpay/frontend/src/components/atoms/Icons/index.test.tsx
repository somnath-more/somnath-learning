import { render, screen } from '@testing-library/react'
import MuiIcon from '.'

const props = {
  url: './assets/image/Email.svg',
  altText: 'Email not found',
  style: {
    width: '50px',
    height: '50px',
  },
}

describe('Icon', () => {
  test('it should render icon with default props', () => {
    render(<MuiIcon src={props.url} alt={props.altText} style={props.style} />)

    const icon = screen.getByRole('img')
    expect(icon).toBeInTheDocument()
    expect(icon).toHaveAttribute('src', props.url)
    expect(icon).toHaveAttribute('alt', props.altText)
    expect(icon).toHaveStyle('width: 50px')
    expect(icon).toHaveStyle('height: 50px')
  })
})
