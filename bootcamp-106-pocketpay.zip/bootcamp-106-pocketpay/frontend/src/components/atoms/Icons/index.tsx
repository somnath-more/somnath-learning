interface IconProps {
  src: string
  alt: string
  style?: React.CSSProperties
  width?: string
  height?: string
  onClick?: () => void
}

const MuiIcon = ({ ...props }: IconProps) => {
  const { src, alt, style, height, width, onClick } = props
  return (
    <img
      data-testid="Atom-Icon"
      src={src}
      alt={alt}
      style={style}
      height={height}
      width={width}
      onClick={onClick}
    />
  )
}
export default MuiIcon

MuiIcon.defaultProps = {
  height: '28px',
  width: '28px',
}
