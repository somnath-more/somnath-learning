import { Meta, StoryFn } from '@storybook/react'
import FLAG from 'public/assets/image/flag icon.svg'
import BUSINESS from 'public/assets/image/Business.svg'
import AUSTRIA from 'public/assets/image/Austria.svg'
import EMAIL from 'public/assets/image/Email.svg'
import HOME from 'public/assets/image/homefill.svg'
import CREDITCARD from 'public/assets/image/credit-card.svg'
import GiftIcon from 'public/assets/image/gift.svg'
import MuiIcon from '.'

export default {
  title: 'Atoms/MuiIcons',
  component: MuiIcon,
  size: {
    options: ['small', 'medium', 'large'],
    control: { type: 'select' },
  },
} as Meta<typeof MuiIcon>

const Template: StoryFn<typeof MuiIcon> = (args) => <MuiIcon {...args} />

export const Default = Template.bind({})
Default.args = {
  src: FLAG,
  alt: 'flag icon',
}

