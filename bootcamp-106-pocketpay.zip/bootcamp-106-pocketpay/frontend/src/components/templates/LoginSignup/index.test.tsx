import { render, screen } from '@testing-library/react'
import LoginSignUp from '.'

describe('LoginSignUp', () => {
  it('renders the LoginSignup component with the provided head and children', () => {
    render(
      <LoginSignUp
        image={<h1>Login/SignUp</h1>}
        children={<div>Content</div>}
      />
    )

    expect(screen.getByText('Login/SignUp')).toBeInTheDocument
    expect(screen.getByText('Content')).toBeInTheDocument
  })
})
