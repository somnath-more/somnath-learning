import { Meta, StoryFn } from '@storybook/react'
import LoginSignUp, { LoginSignUpProps } from '.'
import SignUp from 'components/organisms/SignUp'
import Image from 'components/atoms/Image'
import LOGO from 'public/assets/image/Brand.svg'
import CLOSE from 'public/assets/image/close.svg'
import MuiIcon from 'components/atoms/Icons'
import LogIn from 'components/organisms/LogIn'

export default {
  title: 'Templates/LoginSignUp',
  component: LoginSignUp,
} as Meta

const Template: StoryFn<LoginSignUpProps> = (args) => <LoginSignUp {...args} />
export const signUp = Template.bind({})

signUp.args = {
  image: <Image src={LOGO} alt="logo" width="103px" height="22px" />,
  children: (
    <SignUp
      signupHeading="Create your PocketPay account"
      logInWith="Or, log in with"
    />
  ),
}

export const signIn = Template.bind({})
signIn.args = {
  image: <Image src={LOGO} alt="logo" width="103px" height="22px" />,
  children: (
    <LogIn
      loginHeading="Welcome back"
      troubleLogin="Trouble logging in?"
      loginWith="Or, log in with"
    />
  ),
  closeIcon: (
    <MuiIcon src={CLOSE} alt="close icon" width="24px" height="24px" />
  ),
}
