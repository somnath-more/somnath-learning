import React from 'react'
import { Box } from '@mui/material'
import { styled } from 'styled-components'

export interface LoginSignUpProps {
  image: React.ReactNode
  children: React.ReactNode
  closeIcon?: React.ReactNode
}

const Wrapper = styled(Box)({
  width: '98vw',
  height: '98vh',
  display: 'flex',
  flexDirection: 'column',
  overflow: 'hidden',
  '.head': {
    paddingLeft: '80px',
    paddingRight: '40px',
    marginTop: '24px',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
})

const StyleBody = styled(Box)({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  height: '100vh',
  flexDirection: 'column',
  overflowY: 'auto',
  paddingTop: '10vh',
  paddingBottom: '10vh',
  '&::-webkit-scrollbar': {
    width: '0',
  },
})

const LoginSignUp = ({ image, children, closeIcon }: LoginSignUpProps) => {
  return (
    <Wrapper>
      <Box className="head">
        <Box>{image}</Box>
        <Box>{closeIcon}</Box>
      </Box>
      <StyleBody>{children}</StyleBody>
    </Wrapper>
  )
}

export default LoginSignUp
