import { Meta, StoryObj } from '@storybook/react'
import { StepperTemplate } from '.'
import TransferDetailCard from 'components/organisms/TransferDetailCard'
import HorizontalStepper from 'components/molecules/Stepper'
import CLOSE from 'public/assets/image/close.svg'
import BACK from 'public/assets/image/Back button.svg'
import Image from 'components/atoms/Image'
import LOGO from 'public/assets/image/Brand.svg'
import { stepsForTransactions } from 'utils/constants'

const meta: Meta<typeof StepperTemplate> = {
  title: 'Templates/Stepper',
  component: StepperTemplate,
}

export default meta

type Story = StoryObj<typeof StepperTemplate>

export const Default: Story = {
  args: {
    headerStepper: (
      <HorizontalStepper
        horizontalStepperValues={stepsForTransactions}
        presentValue={1}
      />
    ),
    headerClose: <Image src={CLOSE} alt="logo" width="103px" height="22px" />,
    headerImage: <Image src={LOGO} alt="logo" width="103px" height="22px" />,
    backButton: <Image src={BACK} alt="logo" width="103px" height="22px" />,
    content: <TransferDetailCard onContinue={() => {}} />,
  },
}
