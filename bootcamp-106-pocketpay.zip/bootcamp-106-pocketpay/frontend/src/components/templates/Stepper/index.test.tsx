import React from 'react'
import { render } from '@testing-library/react'
import { StepperTemplate } from './'

describe('StepperTemplate Component', () => {
  const mockHeaderImg = <div data-testid="header-image">Header Image</div>
  const mockHeaderStepper = (
    <div data-testid="header-stepper">Header Stepper</div>
  )
  const mockHeaderClose = <div data-testid="header-close">Header Close</div>
  const mockBackButton = <div data-testid="back-button">Back Button</div>
  const mockContent = <div data-testid="content">Content</div>

  it('renders component with all props', () => {
    const props = {
      headerImage: mockHeaderImg,
      headerStepper: mockHeaderStepper,
      headerClose: mockHeaderClose,
      backButton: mockBackButton,
      content: mockContent,
    }

    const { getByTestId } = render(<StepperTemplate {...props} />)

    expect(getByTestId('header-image')).toBeInTheDocument()
    expect(getByTestId('header-stepper')).toBeInTheDocument()
    expect(getByTestId('header-close')).toBeInTheDocument()
    expect(getByTestId('back-button')).toBeInTheDocument()
    expect(getByTestId('content')).toBeInTheDocument()
  })

  it('renders component with only required props', () => {
    const props = {
      headerImage: mockHeaderImg,
      content: mockContent,
    }

    const { getByTestId, queryByTestId } = render(
      <StepperTemplate {...props} />
    )

    expect(getByTestId('header-image')).toBeInTheDocument()
    expect(queryByTestId('header-stepper')).toBeNull()
    expect(queryByTestId('header-close')).toBeNull()
    expect(queryByTestId('back-button')).toBeNull()
    expect(getByTestId('content')).toBeInTheDocument()
  })

  it('renders component without optional props', () => {
    const props = {
      headerImage: mockHeaderImg,
      headerClose: mockHeaderClose,
      content: mockContent,
    }

    const { getByTestId, queryByTestId } = render(
      <StepperTemplate {...props} />
    )

    expect(getByTestId('header-image')).toBeInTheDocument()
    expect(queryByTestId('header-stepper')).toBeNull()
    expect(getByTestId('header-close')).toBeInTheDocument()
    expect(queryByTestId('back-button')).toBeNull()
    expect(getByTestId('content')).toBeInTheDocument()
  })
})
