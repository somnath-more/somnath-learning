import { Box } from '@mui/material'
import { styled } from 'styled-components'

interface StepperTemplateProps {
  headerImage: React.ReactElement
  headerStepper?: React.ReactElement
  headerClose?: React.ReactElement
  backButton?: React.ReactElement
  content?: React.ReactElement
}

const PrimaryBox = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  width: '100vw',
  height: '100vh',
  paddingTop: '24px',
})
const SecondaryBox = styled(Box)({
  display: 'flex',
  width: '100vw',
  height: '100vh',
  flexDirection: 'column',
  alignItems: 'center',
})

const HeaderBox = styled(Box)({
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginLeft: '80px',
  marginRight: '80px',
})
const BackButtonStyle = styled(Box)({
  display: 'flex',
  marginRight: '800px',
  marginTop: '20px',
})
const ContentBox = styled(Box)({
  display: 'flex',
  marginTop: '24px',
})

export const StepperTemplate = (props: StepperTemplateProps) => {
  const { headerImage, headerStepper, headerClose, backButton, content } = props

  return (
    <PrimaryBox>
      <HeaderBox>
        {headerImage}
        {headerStepper}
        {headerClose}
      </HeaderBox>
      
      
      <SecondaryBox>
      <BackButtonStyle>{backButton}</BackButtonStyle>
        <ContentBox>{content}</ContentBox>
      </SecondaryBox>
      
    </PrimaryBox>
  )
}
