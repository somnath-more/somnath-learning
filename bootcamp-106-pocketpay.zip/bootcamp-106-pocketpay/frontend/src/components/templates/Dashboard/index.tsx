import { Box, Stack, styled } from '@mui/material'
import Button from 'components/atoms/Button'
import MuiTypography from 'components/atoms/Typography'
import React from 'react'
import theme from 'themes'
import { Constants } from 'utils/constants'

interface DashboardTemplateProps {
  sideNav: React.ReactNode
  header: React.ReactNode
  main: React.ReactNode
  onSendMoney: () => void
}

const StyledFilledButton = styled(Button)({
  padding: '16px 30px',
  color: 'primary',
  textTransform: 'none',
  textAlign: 'center',
  borderRadius: '56px',
  boxShadow: '0px 8px 24px 0px #5533FF3D',
  '&:hover': {
    backgroundColor: `${theme.palette.primary.primary500}`,
    color: '#fff',
  },
})

const StyledApplicationStack = styled(Stack)`
  width: 99vw"
  height: 60px;
  display: flex;
  box-shadow: 0px 1px 8px 0px #0000000d;
  background: #fff;
  align-items: flex-end;
`

const StyledBox = styled(Box)`
  width: 100%;
  display: flex;
  padding: 18px;
`

const Wrapper = styled(Box)({
  width: '99vw',
  height: '98vh',
  display: 'flex',
  flexDirection: 'row',
  background: '#F8F9FA',
})
const InnerWrapper = styled(Box)({
  flexDirection: 'row',
})

const DashboardTemplate = (props: DashboardTemplateProps) => {
  return (
    <Wrapper data-testid="dashboard-template">
      <Box minWidth="16.8vw">{props.sideNav}</Box>
      <InnerWrapper minWidth="82vw" height="7.8vh">
        <Box>
          <StyledApplicationStack>{props.header}</StyledApplicationStack>
        </Box>
        <Box>
          <StyledBox>
            <Stack spacing={6}>
              <Stack
                direction="row"
                sx={{
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                <MuiTypography
                  variant="h1"
                  color={theme.palette.Text.highEmphasis}
                >
                  {Constants.HOME}
                </MuiTypography>
                <StyledFilledButton
                  variant="contained"
                  onClick={props.onSendMoney}
                >
                  {Constants.SEND_MONEY}
                </StyledFilledButton>
              </Stack>
              {props.main}
            </Stack>
          </StyledBox>
        </Box>
      </InnerWrapper>
    </Wrapper>
  )
}

export default DashboardTemplate
