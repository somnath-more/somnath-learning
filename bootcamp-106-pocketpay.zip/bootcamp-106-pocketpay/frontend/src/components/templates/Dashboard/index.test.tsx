import { fireEvent, render, screen } from '@testing-library/react'
import DashboardTemplate from '.'

const props = {
  sideNav: <div>Side Nav</div>,
  header: <div>Header</div>,
  main: <div>Main Content</div>,
  onSendMoney: jest.fn(),
}

describe('Dashboard Template', () => {
  test('it should render the dashboard template correctly', () => {
    render(<DashboardTemplate {...props} />)
    expect(screen.getByTestId('dashboard-template')).toBeInTheDocument()
    expect(screen.getByText('Side Nav')).toBeInTheDocument()
    expect(screen.getByText('Header')).toBeInTheDocument()
    expect(screen.getByText('Main Content')).toBeInTheDocument()
    expect(screen.getByText('Home')).toBeInTheDocument()
    expect(screen.getByText('Send Money')).toBeInTheDocument()
  })

  test('calls onSendMoney when the "Send Money" button is clicked', () => {
    render(<DashboardTemplate {...props} />)
    const button = screen.getByText('Send Money')
    fireEvent.click(button)
    expect(props.onSendMoney).toHaveBeenCalledTimes(1)
  })
})
