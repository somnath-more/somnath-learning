import { StoryFn, Meta } from '@storybook/react'
import { action } from '@storybook/addon-actions'
import DashboardTemplate from '.'
import NavBar from 'components/organisms/NavigationBar'
import PocketPayLogo from 'public/assets/image/PocketPay.svg'
import {
  Constants,
  JarsConstants,
  SideNav,
  UPDATES_INFO,
  balancesConstants,
} from 'utils/constants'
import AvatarDialogueBox from 'components/organisms/ApplicationHeader/AvatarDialogueBox'
import ImageTypography from 'components/molecules/ImageTypography'
import HOMEPAGE_IMG from 'public/assets/image/Illustration.svg'
import theme from 'themes'
import TransferStatusCard from 'components/organisms/TransferStatusCard'

const meta: Meta = {
  title: 'Templates/Dashboard-Template',
  component: DashboardTemplate,
}
export default meta

const Template: StoryFn<typeof DashboardTemplate> = (args) => (
  <DashboardTemplate {...args} />
)

export const Primary = Template.bind({})
export const Secondary = Template.bind({})

Primary.args = {
  sideNav: (
    <NavBar
      logoUrl={PocketPayLogo}
      balances={balancesConstants}
      jars={JarsConstants}
      sideNav={SideNav}
      balanceHeader={Constants.BALANCES}
      jarHeader={Constants.JARS}
      hasBalances={false}
    />
  ),
  header: <AvatarDialogueBox />,
  main: (
    <ImageTypography
      src={HOMEPAGE_IMG}
      alt={'Home -image'}
      text={
        <div style={{ color: theme.palette.Text.mediumEmphasis }}>
          This is where you’ll see your activity and transactions.
          <br />
          Choose how you’d like to get started.
        </div>
      }
      width="10.8125rem"
      height="11.4375rem"
      variant="body1"
    />
  ),
  onSendMoney: action('Continue Button is Clicked '),
}

Secondary.args = {
  sideNav: (
    <NavBar
      logoUrl={PocketPayLogo}
      balances={balancesConstants}
      jars={JarsConstants}
      sideNav={SideNav}
      balanceHeader={Constants.BALANCES}
      jarHeader={Constants.JARS}
      hasBalances
    />
  ),
  header: <AvatarDialogueBox />,
  main: (
    <TransferStatusCard
      text="Mario Gabriel"
      gbpValue="100 GBP"
      eurValue="114.68 EUR"
      updates={UPDATES_INFO}
      onCancelClick={() => console.log('Cancel Button is Clicked')}
      activeSteps={3}
      onRefundStatus={false}
    />
  ),
  onSendMoney: action('Continue Button is Clicked '),
}
