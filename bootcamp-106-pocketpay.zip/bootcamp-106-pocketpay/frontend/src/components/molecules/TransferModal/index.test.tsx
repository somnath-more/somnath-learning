import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import CustomModal from '.'
import '@testing-library/jest-dom/extend-expect'

describe('Modal', () => {
  const mockOnClose = jest.fn()

  it('renders modal content when isModalOpen is true', () => {
    render(
      <CustomModal isModalOpen={true}>
        <div>Modal Content</div>
      </CustomModal>
    )

    const modalContent = screen.getByTestId('modal-content')
    expect(modalContent).toBeInTheDocument()
    expect(modalContent.textContent).toBe('Modal Content')
  })

  it('does not render modal content when isModalOpen is false', () => {
    render(
      <CustomModal isModalOpen={false}>
        <div>Modal Content</div>
      </CustomModal>
    )

    const modalContent = screen.queryByTestId('modal-content')
    expect(modalContent).toBeNull()
  })
  test('calls onClose when modal is closed', () => {
    render(
      <CustomModal isModalOpen={true}>
        <p>Modal Content</p>
      </CustomModal>
    )
    const modal = screen.getByTestId('modal')
    fireEvent.click(modal)
    waitFor(() => {
      expect(screen.getByText('Modal Content')).toBeInTheDocument()
      expect(mockOnClose).toHaveBeenCalledTimes(1)
    })
  })
})
