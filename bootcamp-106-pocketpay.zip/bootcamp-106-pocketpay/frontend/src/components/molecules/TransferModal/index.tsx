import { Grid, Modal as MuiModal, styled } from '@mui/material'
import theme from 'themes'

export interface ModalProps {
  children: React.ReactNode
  isModalOpen: boolean
}

const CustomModal = ({ children, isModalOpen }: ModalProps) => {
  return (
    <div data-testid="modal-container">
      <MuiModal open={isModalOpen} data-testid="modal">
        <StyledContainer data-testid="modal-content">
          {children}
        </StyledContainer>
      </MuiModal>
    </div>
  )
}

export default CustomModal

const StyledContainer = styled(Grid)({
  all: 'unset',
  display: 'flex',
  flexWrap: 'wrap',
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  background: theme.palette.Structural.white,
  bordercolor: theme.palette.Structural.white,
  borderRadius: '16px',
  padding: '5px',
  width: 564,
  height: 306,
  justifyContent: 'center',
  flexDirection: 'column',
  paddingBottom:theme.spacing(6)
})
