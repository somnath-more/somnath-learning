import { Meta, StoryFn } from '@storybook/react'
import CustomModal, { ModalProps } from '.'
import Grid from '@mui/material/Grid'
import Button from 'components/atoms/Button'
import theme from 'themes'
import { Box } from '@mui/material'
import MuiTypography from '../../atoms/Typography'

export default {
  title: 'Molecules/Modal',
  component: CustomModal,
} as Meta

const Template: StoryFn<ModalProps> = (args) => <CustomModal {...args} />

export const SampleModal = Template.bind({})

SampleModal.args = {
  children: (
    <Box sx={{ width: '35.21rem', height: '20.93rem' }}>
      <Grid
        style={{
          marginTop: '3.75rem',
          marginLeft: '2.5rem',
        }}
        item
      >
        <MuiTypography
          variant="body1"
          color={theme.palette.Text.mediumEmphasis}
        >
          We`ll apply this rate if we receive <br /> your money today.
        </MuiTypography>
      </Grid>
      <Grid
        style={{
          marginTop: '8.5rem',
          marginLeft: '13.1rem',
        }}
        item
      >
        <Button
          variant="contained"
          style={{
            width: '8.4rem',
            height: '3.4rem',
            paddingTop: '1rem',
            paddingBottom: '1rem',
            paddingLeft: '1.88rem',
            paddingRight: '1.88rem',
            borderRadius: '3.5rem',
            marginBottom: '20px',
          }}
        >
          <MuiTypography variant="body2" color={theme.palette.Structural.white}>
            OK
          </MuiTypography>
        </Button>
      </Grid>
    </Box>
  ),
  isModalOpen: true,
}
