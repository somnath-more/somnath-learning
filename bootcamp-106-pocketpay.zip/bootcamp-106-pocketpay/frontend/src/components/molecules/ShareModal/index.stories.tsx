import { StoryFn, Meta } from '@storybook/react'
import ShareModalComponent from '.'
import ImageIcon from 'public/assets/image/shareModalImage.svg'
import { action } from '@storybook/addon-actions'

const meta: Meta = {
  title: 'Molecules/ShareModal',
  component: ShareModalComponent,
}
export default meta

const Template: StoryFn<typeof ShareModalComponent> = (args) => (
  <ShareModalComponent {...args} />
)

export const Primary = Template.bind({})

Primary.args = {
  src: ImageIcon,
  open: true,
  onClose: action('Closed the modal'),
}
