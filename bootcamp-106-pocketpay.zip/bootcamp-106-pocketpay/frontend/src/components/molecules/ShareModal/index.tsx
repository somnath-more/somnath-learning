import styled from '@emotion/styled'
import { Dialog, Stack } from '@mui/material'
import theme from 'themes'
import MuiTypography from 'components/atoms/Typography'
import MuiIcon from 'components/atoms/Icons'
import EmailIcon from 'public/assets/image/EmailIcon.svg'
import CopyLink from 'public/assets/image/Copy link.svg'
import { Constants } from 'utils/constants'

const StyledModal = styled(Dialog)({
  '& .MuiPaper-root': {
    width: '34.25rem',
    height: '31.875rem',
    borderRadius: '1rem',
  },
})

interface ShareModalProps {
  src: any
  open: boolean
  onClose: () => void
}

const ShareModalComponent = (props: ShareModalProps) => {
  return (
    <>
      <StyledModal
        open={props.open}
        onClose={props.onClose}
        data-testid="shareModal"
      >
        <Stack
          sx={{
            alignItems: 'center',
            padding: '30px 15px',
            margin: '23px',
          }}
          spacing={10}
        >
          <MuiTypography
            variant="body1"
            sx={{ color: theme.palette.Text.highEmphasis }}
          >
            {Constants.SHARE_MODAL_TITLE}
          </MuiTypography>

          <MuiIcon
            alt="Share Modal Image"
            src={props.src}
            width="175px"
            height="126px"
          />
          <Stack direction="row" spacing={10}>
            <MuiIcon
              alt="Email Image"
              src={EmailIcon}
              width="60px"
              height="96px"
            />
            <MuiIcon
              alt="Copy Link Image"
              src={CopyLink}
              width="60px"
              height="96px"
            />
          </Stack>
          <MuiTypography
            variant="body3"
            sx={{
              color: theme.palette.Text.mediumEmphasis,
            }}
          >
            {Constants.SHARE_MODAL_DESCRIPTION}
          </MuiTypography>
        </Stack>
      </StyledModal>
    </>
  )
}

export default ShareModalComponent
