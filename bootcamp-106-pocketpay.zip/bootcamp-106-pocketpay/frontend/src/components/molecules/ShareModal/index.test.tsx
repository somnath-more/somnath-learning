import { render, screen } from '@testing-library/react'
import ShareModalComponent from '.'
import { Constants } from 'utils/constants'
import ImageIcon from 'public/assets/image/shareModalImage.svg'

const mockprops = {
  src: { ImageIcon },
  open: false,
  onClose: jest.fn(),
}

describe('ShareModal', () => {
  test('it should render Share modal with text correctly', () => {
    render(<ShareModalComponent {...mockprops} open />)
    const element = screen.getByTestId('shareModal')
    expect(element).toBeInTheDocument()
    expect(element).toHaveTextContent(Constants.SHARE_MODAL_TITLE)
    expect(element).toHaveTextContent(Constants.SHARE_MODAL_DESCRIPTION)
  })

  test('it should render Share modal with images', () => {
    render(<ShareModalComponent {...mockprops} open />)
    const element = screen.getAllByRole('img')
    expect(element).toHaveLength(3)
    const img1 = screen.getByAltText('Share Modal Image')
    expect(img1).toBeInTheDocument()
    const img2 = screen.getByAltText('Email Image')
    expect(img2).toBeInTheDocument()
    const img3 = screen.getByAltText('Copy Link Image')
    expect(img3).toBeInTheDocument()
  })
})
