import React from 'react'
import Image, { ImageProps } from 'components/atoms/Image'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { styled } from '@mui/material/styles'
import { Box, Stack } from '@mui/material'

const StyledBox = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  width: '1400px',
  height: '560px',
  background: theme.palette.Structural.white,
  boxShadow: '0px 1px 5px 0px #00000026',
})

interface ImageTypographyProps extends ImageProps {
  src: string
  alt: string
  text?: string | React.ReactNode
  variant?: 'h1' | 'body1' | 'body2' | 'body3' | 'caption1' | 'linkText'
}

const ImageTypography = ({
  text,
  variant,
  ...restProps
}: ImageTypographyProps) => {
  return (
    <StyledBox>
      <Stack sx={{ alignItems: 'center', margin: '110px' }}>
        <Image {...restProps} />
        <MuiTypography variant={variant}>{text}</MuiTypography>
      </Stack>
    </StyledBox>
  )
}

export default ImageTypography
