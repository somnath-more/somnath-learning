import React from 'react'
import { Meta, StoryFn } from '@storybook/react'
import ImageTypography from '.'
import HOMEPAGE_IMG from 'public/assets/image/Illustration.svg'
import theme from 'themes'

export default {
  title: 'Molecules/ImageTypography',
  component: ImageTypography,
  argTypes: {
    src: {
      control: 'text',
    },
    alt: {
      control: 'text',
    },
    text: {
      control: 'text',
    },
    variant: {
      options: ['h1', 'body1', 'body2', 'body3', 'caption1', 'linkText'],
      control: { type: 'radio' },
    },
  },
} as Meta

const Template: StoryFn<typeof ImageTypography> = (args) => (
  <ImageTypography {...args} />
)

export const Default = Template.bind({})
Default.args = {
  src: HOMEPAGE_IMG,
  alt: 'Example Image',
  text: (
    <div style={{ color: theme.palette.Text.mediumEmphasis }}>
      This is where you’ll see your activity and transactions.
      <br />
      Choose how you’d like to get started.
    </div>
  ),
  width: '173px',
  height: '183px',
  variant: 'body1',
}
