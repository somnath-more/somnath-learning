import React from 'react'
import { render } from '@testing-library/react'
import ImageTypography from '.'
import theme from 'themes'

describe('ImageTypography', () => {
  const props = {
    src: 'image.jpg',
    alt: 'Image Alt',
    text: 'Lorem ipsum',
  }

  test('it should render the ImageTypography component with correct props', () => {
    const { getByAltText, getByText } = render(<ImageTypography {...props} />)
    const imageElement = getByAltText(props.alt) as HTMLImageElement
    expect(imageElement).toBeInTheDocument()
    expect(imageElement.getAttribute('src')).toContain(props.src)
    const textElement = getByText(props.text)
    expect(textElement).toBeInTheDocument()
  })

  test('it should render the Box component with correct styles', () => {
    const { container } = render(<ImageTypography {...props} />)
    const boxElement = container.firstChild
    expect(boxElement).toHaveStyle(`
      display: flex;
      flex-direction: column;
      align-items: center;
      width: 1400px;
      height: 560px;
      background: ${theme.palette.Structural.white};
      box-shadow: 0px 1px 5px 0px #00000026;
    `)
  })
})
