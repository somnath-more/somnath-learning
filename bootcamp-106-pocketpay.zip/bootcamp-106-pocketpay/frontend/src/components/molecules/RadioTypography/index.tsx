import { Grid, styled } from '@mui/material'
import RadioButton from 'components/atoms/RadioButton'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'

const StyledGridContainer = styled(Grid)({
  width: '516px',
  padding: '12px',
})

const StyledGridItem = styled(Grid)({
  display: 'flex',
  alignItems: 'center',
  gap: '16px',
})

const StyledHeadingTypography = styled(MuiTypography)({
  paddingBottom: '10px',
  color: theme.palette.Text.mediumEmphasis,
  fontWeight: theme.typography.fontWeightRegular,
  fontFamily: theme.typography.fontFamily,
})

const StyledContentTypography = styled(MuiTypography)({
  width: '416px',
  textAlign: 'left',
  fontFamily: theme.typography.fontFamily,
})

export interface RadioTypographyProps {
  heading: string
  content?: string
  checked: boolean
  onClick: () => void
  hasCard?: boolean
  cardNumber?: number
  expiryDate?: string
}

const RadioTypography = ({
  heading,
  content,
  checked,
  onClick,
  hasCard,
  cardNumber,
  expiryDate,
}: RadioTypographyProps) => {
  return (
    <StyledGridContainer>
      <Grid container>
        <StyledGridItem item>
          <RadioButton
            checked={checked}
            data-testid="radio-button"
            onClick={onClick}
          />
          {hasCard ? (
            <div>
              <MuiTypography
                variant="body2"
                sx={{ color: theme.palette.Text.highEmphasis }}
              >
                {heading}
              </MuiTypography>
              <MuiTypography
                variant="body2"
                sx={{ color: theme.palette.Text.mediumEmphasis }}
              >
                Last four digits{' '}
                <span
                  style={{
                    color: theme.palette.Text.highEmphasis,
                  }}
                >
                  {cardNumber}
                </span>{' '}
                Expiry date{' '}
                <span
                  style={{
                    color: theme.palette.Text.highEmphasis,
                  }}
                >
                  {expiryDate}
                </span>
              </MuiTypography>
            </div>
          ) : (
            <div>
              <StyledHeadingTypography variant="body2">
                {heading}
              </StyledHeadingTypography>
              <StyledContentTypography variant="body2">
                {content}
              </StyledContentTypography>
            </div>
          )}
        </StyledGridItem>
      </Grid>
    </StyledGridContainer>
  )
}

export default RadioTypography
