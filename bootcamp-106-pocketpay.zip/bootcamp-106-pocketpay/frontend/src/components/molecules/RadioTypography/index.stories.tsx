import { StoryFn, Meta } from '@storybook/react'
import RadioTypography from './index'
import { Constants } from 'utils/constants'

const meta: Meta = {
  title: 'Molecules/RadioTypography',
  component: RadioTypography,
}
export default meta

const Template: StoryFn<typeof RadioTypography> = (args) => (
  <RadioTypography {...args} />
)

export const Primary = Template.bind({})

Primary.args = {
  heading: 'Address 1',
  content: Constants.RADIO_TYPOGRAPHY_CONTENT,
}
