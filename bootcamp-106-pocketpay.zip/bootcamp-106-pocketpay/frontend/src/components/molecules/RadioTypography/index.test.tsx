import { fireEvent, render, screen } from '@testing-library/react'
import RadioTypography, { RadioTypographyProps } from './index'

const testProps: RadioTypographyProps = {
  heading: 'Test Heading',
  content: 'Test Content',
  onClick: jest.fn(),
  checked: false,
}

describe('RadioTypography', () => {
  test('it should render the component with correct heading and content', () => {
    render(<RadioTypography {...testProps} />)

    const headingElement = screen.getByText(testProps.heading)
    expect(headingElement).toBeInTheDocument()

    const contentElement = screen.getByText(testProps.content)
    expect(contentElement).toBeInTheDocument()
  })

  test('it should render the RadioButton', () => {
    render(<RadioTypography {...testProps} />)

    const radioButtonElement = screen.getByRole('radio')
    expect(radioButtonElement).toBeInTheDocument()
  })

  test('it should call onClick when clicked on the radio button', () => {
    render(<RadioTypography {...testProps} />)

    const radioButton = screen.getByTestId('radio-button')
    fireEvent.click(radioButton)
    expect(testProps.onClick).toHaveBeenCalledTimes(1)
  })

  test('it should show the radio button as not checked when the checked prop is false', () => {
    render(<RadioTypography {...testProps} />)

    const radioButton = screen.getByTestId('radio-button')
    expect(radioButton).not.toBeChecked()
  })
})
