import React from 'react'
import { render, screen } from '@testing-library/react'
import ConfirmPurchase from '.'
import { Constants } from 'utils/constants'

describe('ConfirmPurchase Component', () => {
  const mockProps = {
    leftSrc: 'avatar1.png',
    rightSrc: 'avatar2.png',
    leftAlt: 'Avatar 1',
    rightAlt: 'Avatar 2',
    title: 'Purchase Confirmation',
    amount: 'GBP 100.00',
    cardEnding: 9431,
  }

  test('it should render header with avatars', () => {
    render(<ConfirmPurchase {...mockProps} />)
    const avatar1 = screen.getByAltText(mockProps.leftAlt)
    const avatar2 = screen.getByAltText(mockProps.rightAlt)
    expect(avatar1).toBeInTheDocument()
    expect(avatar2).toBeInTheDocument()
  })

  test('it should render the title', () => {
    render(<ConfirmPurchase {...mockProps} />)
    const titleElement = screen.getByText(mockProps.title)
    expect(titleElement).toBeInTheDocument()
  })

  test('it should render purchase text', () => {
    render(<ConfirmPurchase {...mockProps} />)
    const purchaseText1 = screen.getByText(mockProps.amount)
    const purchaseText2 = screen.getByText(mockProps.cardEnding)
    expect(purchaseText1).toBeInTheDocument()
    expect(purchaseText2).toBeInTheDocument()
  })

  test('it should render steps', () => {
    render(<ConfirmPurchase {...mockProps} />)
    const step1 = screen.getByText(Constants.CONFIRM_PURCHASE_STEP_1)
    const step2 = screen.getByText(Constants.CONFIRM_PURCHASE_STEP_2)
    expect(step1).toBeInTheDocument()
    expect(step2).toBeInTheDocument()
  })

  test('it should render the Complete button', () => {
    render(<ConfirmPurchase {...mockProps} />)
    const completeButton = screen.getByRole('button', { name: 'Complete' })
    expect(completeButton).toBeInTheDocument()
  })
})
