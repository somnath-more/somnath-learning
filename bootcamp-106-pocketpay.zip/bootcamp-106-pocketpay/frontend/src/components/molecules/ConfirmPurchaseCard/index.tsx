import { styled, Box, Divider } from '@mui/material'
import MyAvatar from 'components/atoms/Avatar'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import Button from 'components/atoms/Button'
import { Constants } from 'utils/constants'

const PurchaseCard = styled(Box)({
  width: '474px',
  height: '395px',
  borderRadius: '16px',
  border: `1px solid ${theme.palette.Accent.stroke2}`,
  position: 'relative',
  paddingBottom:'20px'
})

const StyledButton = styled(Box)({
  paddingBottom: '10px',
  paddingTop: '20px',
})

interface HeaderProps {
  leftSrc: string
  rightSrc: string
  leftAlt: string
  rightAlt: string
}

const Header = (props: HeaderProps) => {
  const StyledBox = styled(Box)({
    display: 'flex',
    columnGap: 350,
    padding: '20px',
  })

  return (
    <StyledBox>
      <MyAvatar src={props.leftSrc} alt={props.leftAlt} />
      <MyAvatar src={props.rightSrc} alt={props.rightAlt} />
    </StyledBox>
  )
}

interface ContentProps {
  title: string
  amount: string
  cardEnding: number
  onComplete?: () => void
}

const Content = (props: ContentProps) => {
  const StyledBox = styled(Box)({
    paddingTop: '25px',
    paddingRight: 35,
    textAlign: 'center',
  })

  const TextBox = styled(Box)({
    paddingTop: '25px',
    paddingLeft: 100,
    paddingRight: 105,
  })

  const StyledBoxStep2 = styled(Box)({
    width: '290px',
    paddingLeft: 100,
    paddingRight: 105,
    paddingTop: '10px',
  })

  const StyledBoxStep1 = styled(Box)({
    width: '270px',
    paddingLeft: 100,
    paddingRight: 105,
    paddingTop: '10px',
  })

  return (
    <Box>
      <StyledBox>
        <MuiTypography variant="body1" color={theme.palette.Text.highEmphasis}>
          {props.title}
        </MuiTypography>
      </StyledBox>
      <MuiTypography
        variant="caption1"
        color={theme.palette.Text.mediumEmphasis}
        style={{ textAlign: 'left' }}
      >
        <TextBox>
          <span style={{ color: theme.palette.Text.highEmphasis }}>
            {props.amount}
          </span>
          {Constants.CONFIRM_TEXT}
          <span style={{ color: theme.palette.Text.highEmphasis }}>
            {props.cardEnding}
          </span>
        </TextBox>
        <StyledBoxStep1>{Constants.CONFIRM_PURCHASE_STEP_1}</StyledBoxStep1>
        <StyledBoxStep2>{Constants.CONFIRM_PURCHASE_STEP_2}</StyledBoxStep2>
      </MuiTypography>
    </Box>
  )
}

interface ConfirmPurchaseProps extends ContentProps, HeaderProps {}

const ConfirmPurchase = (props: ConfirmPurchaseProps) => {
  return (
    <PurchaseCard>
      <Header
        leftSrc={props.leftSrc}
        rightSrc={props.rightSrc}
        leftAlt={props.leftAlt}
        rightAlt={props.rightAlt}
      />
      <Divider />
      <Content
        title={props.title}
        amount={props.amount}
        cardEnding={props.cardEnding}
      />
      <StyledButton>
        <center>
          <Button
            variant="contained"
            style={{ borderRadius: '56px', height: '56px', width: '135px' }}
            onClick={props.onComplete}
          >
            <MuiTypography variant="body1" style={{ textTransform: 'none' }}>
              Complete
            </MuiTypography>
          </Button>
        </center>
      </StyledButton>
    </PurchaseCard>
  )
}

export default ConfirmPurchase
