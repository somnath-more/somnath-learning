import { Meta, StoryFn } from '@storybook/react'
import ConfirmPurchase from '.'
import avatar1 from 'public/assets/image/Icon.svg'
import avatar2 from 'public/assets/image/visa.svg'

export default {
  title: 'Molecules/ConfirmPurchase',
  component: ConfirmPurchase,
} as Meta

const Template: StoryFn<typeof ConfirmPurchase> = (args) => (
  <ConfirmPurchase {...args} />
)

export const Default = Template.bind({})
Default.args = {
  leftSrc: avatar1,
  rightSrc: avatar2,
  leftAlt: 'Avatar 1',
  rightAlt: 'Avatar 2',
  title: 'Confirm your purchase',
  amount: 'GBP 100.00 ',
  cardEnding: 9313,
}
