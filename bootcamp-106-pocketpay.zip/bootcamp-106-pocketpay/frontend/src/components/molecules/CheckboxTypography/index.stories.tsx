import { StoryFn, Meta } from '@storybook/react'
import CheckboxTypography from '.'

const meta: Meta = {
  title: 'Molecules/CheckboxTypography',
  component: CheckboxTypography,
}
export default meta

const Template: StoryFn<typeof CheckboxTypography> = (args) => (
  <CheckboxTypography {...args} />
)

export const Primary = Template.bind({})

Primary.args = {
  label: 'Remember me',
}
