import CheckboxAtom from 'components/atoms/Checkbox'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'

export interface Props {
  label: string
  variant: 'h1' | 'body1' | 'body2' | 'body3' | 'caption1' | 'linkText'
}

const CheckboxTypography = ({ label, variant }: Props) => {
  return (
    <div style={{ display: 'flex', alignItems:'center' }}>
      <CheckboxAtom style={{ paddingRight: '1.5rem' }} />
      <MuiTypography
        variant={variant}
        sx={{ color: theme.palette.Text.mediumEmphasis }}
      >
        {label}
      </MuiTypography>
    </div>
  )
}

export default CheckboxTypography
