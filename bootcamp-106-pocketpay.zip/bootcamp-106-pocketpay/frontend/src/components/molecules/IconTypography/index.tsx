import React, { useState } from 'react'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { Box, SvgIcon } from '@mui/material'

export interface IconTypographyProps {
  src: any
  alt: string
  text: string | React.ReactNode
  onClick?: () => void
  disableClick?: boolean
  iconColor?: string
  textColor?: string
  variant?: 'h1' | 'body1' | 'body2' | 'body3' | 'caption1' | 'linkText'
}

const IconTypography = ({
  src,
  text,
  onClick,
  disableClick,
  iconColor,
  textColor,
  variant,
  ...restProps
}: IconTypographyProps) => {
  const [isClicked, setIsClicked] = useState(false)

  const handleClick = () => {
    if (onClick && !disableClick) {
      onClick()
    }

    if (!disableClick) {
      setIsClicked((prev) => !prev)
    }
  }

  const resolvedIconColor = isClicked
    ? theme.palette.primary.primary500
    : iconColor ?? theme.palette.Text.mediumEmphasis
  const resolvedTextColor = isClicked
    ? theme.palette.primary.primary500
    : textColor ?? theme.palette.Text.mediumEmphasis

  return (
    <Box
      onClick={handleClick}
      sx={{
        display: 'flex',
        alignItems: 'center',
        cursor: disableClick ? 'default' : 'pointer',
        gap: '2px',
      }}
    >
      {typeof src === 'string' ? (
        <svg
          data-testid="icon-svg"
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill={resolvedIconColor}
          style={{ marginRight: 6 }}
        >
          <path d={src} />
        </svg>
      ) : (
        <SvgIcon
          component={src}
          style={{ color: resolvedIconColor, marginRight: 6 }}
        />
      )}
      <MuiTypography variant={variant} sx={{ color: resolvedTextColor }}>
        {text}
      </MuiTypography>
    </Box>
  )
}

export default IconTypography
