import { render, fireEvent } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import theme from 'themes'
import IconTypography from '.'

test('it should render IconTypography correctly with text when src is a string', () => {
  const mockOnClick = jest.fn()
  const { getByText, getByTestId } = render(
    <IconTypography
      src="mock-icon-path"
      text="Mock Text"
      onClick={mockOnClick}
      alt=""
    />
  )
  expect(getByText('Mock Text')).toBeInTheDocument()
  const svgElement = getByTestId('icon-svg')
  expect(svgElement).toBeInTheDocument()
  expect(svgElement.querySelector('path')).toHaveAttribute(
    'd',
    'mock-icon-path'
  )
  expect(svgElement).toHaveAttribute('fill', theme.palette.Text.mediumEmphasis)
  expect(getByText('Mock Text')).toHaveStyle(
    `color: ${theme.palette.Text.mediumEmphasis}`
  )
  fireEvent.click(svgElement)
  expect(mockOnClick).toHaveBeenCalledTimes(1)
  expect(svgElement).toHaveAttribute(
    'fill',
    `${theme.palette.primary.primary500}`
  )
  expect(getByText('Mock Text')).toHaveStyle(
    `color: ${theme.palette.primary.primary500}`
  )
})

test('it should render IconTypography correctly with text when src is an SvgIcon component', () => {
  const mockOnClick = jest.fn()
  const MockSvgIcon = () => <div data-testid="mock-svg-icon" />
  const { getByText, getByTestId } = render(
    <IconTypography
      src={MockSvgIcon}
      text="Mock Text"
      onClick={mockOnClick}
      alt=""
    />
  )
  expect(getByText('Mock Text')).toBeInTheDocument()
  const svgIconElement = getByTestId('mock-svg-icon')
  expect(svgIconElement).toBeInTheDocument()
  expect(svgIconElement).toHaveStyle('color: inherit')
  expect(getByText('Mock Text')).toHaveStyle(
    `color: ${theme.palette.Text.mediumEmphasis}`
  )
  fireEvent.click(svgIconElement)
  expect(mockOnClick).toHaveBeenCalledTimes(1)
  const expectedColor = theme.palette.primary.primary500
  expect(getByText('Mock Text')).toHaveStyle(`color: ${expectedColor}`)
})

test('it should handle disableClick correctly', () => {
  const mockOnClick = jest.fn()
  const { getByTestId, getByText } = render(
    <IconTypography
      src="mock-icon-path"
      text="Mock Text"
      onClick={mockOnClick}
      disableClick
      alt=""
    />
  )
  const svgElement = getByTestId('icon-svg')
  const computedStyle = window.getComputedStyle(svgElement)
  expect(computedStyle.cursor).toBe('')
  expect(getByText('Mock Text')).toHaveStyle('cursor: ')
  fireEvent.click(svgElement)
  expect(mockOnClick).not.toHaveBeenCalled()
  expect(svgElement).toHaveAttribute('fill', theme.palette.Text.mediumEmphasis)
  expect(getByText('Mock Text')).toHaveStyle(
    `color: ${theme.palette.Text.mediumEmphasis}`
  )
})
