import { Meta, StoryFn } from '@storybook/react'
import IconTypography, { IconTypographyProps } from '.'
import { PersonOutlineOutlined } from '@mui/icons-material'

export default {
  title: 'Molecules/IconTypography',
  component: IconTypography,
} as Meta

const Template: StoryFn<IconTypographyProps> = (args) => (
  <IconTypography {...args} />
)

const vectorSvgPath =
  'M1.5 16.4681H5.25V10.0851H10.75V16.4681H14.5V6.51064L8 1.53191L1.5 6.51064V16.4681ZM1.5 18C1.08333 18 0.729167 17.8511 0.4375 17.5532C0.145833 17.2553 0 16.8936 0 16.4681V6.51064C0 6.27234 0.0541666 6.04255 0.1625 5.82128C0.270833 5.6 0.416667 5.42128 0.6 5.28511L7.1 0.306383C7.23333 0.204255 7.375 0.12766 7.525 0.0765958C7.675 0.025532 7.83333 0 8 0C8.16667 0 8.325 0.025532 8.475 0.0765958C8.625 0.12766 8.76667 0.204255 8.9 0.306383L15.4 5.28511C15.5833 5.42128 15.7292 5.6 15.8375 5.82128C15.9458 6.04255 16 6.27234 16 6.51064V16.4681C16 16.8936 15.8542 17.2553 15.5625 17.5532C15.2708 17.8511 14.9167 18 14.5 18H9.25V11.617H6.75V18H1.5Z'

export const Default = Template.bind({})
Default.args = {
  src: vectorSvgPath,
  alt: 'Icon',
  text: 'Home',
  variant: 'caption1',
}

export const DisabledClick = Template.bind({})
DisabledClick.args = {
  src: PersonOutlineOutlined,
  alt: 'Icon',
  text: 'Your details',
  disableClick: true,
  iconColor: 'inherit',
  textColor: 'inherit',
  variant: 'caption1',
}
