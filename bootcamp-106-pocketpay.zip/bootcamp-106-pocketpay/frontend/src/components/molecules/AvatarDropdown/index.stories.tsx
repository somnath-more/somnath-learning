import { Meta, StoryFn } from '@storybook/react'
import AvatarDropdown from '.'
import { MOBILE_NUMBER_DROPDOWN } from 'utils/constants'

export default {
  title: 'molecules/AvatarDropdown',
  component: AvatarDropdown,
} as Meta<typeof AvatarDropdown>

const template: StoryFn<typeof AvatarDropdown> = (args) => (
  <AvatarDropdown {...args} />
)

export const Primary = template.bind({})
Primary.args = {
  countriesName: MOBILE_NUMBER_DROPDOWN,
}
