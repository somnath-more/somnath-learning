import { render, fireEvent, screen } from '@testing-library/react'
import AvatarDropdown from '.'
import { formatPhoneNumber } from 'utils/mobileValidation'

const testArray = [
  { id: 1, src: 'path-to-icon1', alt: 'Icon Alt 1', start: 'Country 1' },
  { id: 2, src: 'path-to-icon2', alt: 'Icon Alt 2', start: 'Country 2' },
]

describe('AvatarDropdown', () => {
  test('it should handle input value changes', () => {
    render(<AvatarDropdown onMobileNumberChange={jest.fn()} countriesName={testArray} />)

    const inputValueWithCode = '+44 123 456 789 0'
    const textField = screen.getByLabelText('Mobile number')
    fireEvent.change(textField, { target: { value: inputValueWithCode } })

    const formattedValue = formatPhoneNumber(inputValueWithCode)
    const countryCode = ''
    const expectedValueWithCode = formattedValue.startsWith(countryCode)
      ? formattedValue.slice(countryCode.length).trim()
      : formattedValue

    expect(textField).toHaveValue(expectedValueWithCode)
  })

  test('it should render the country icons and handle click events', () => {
    render(<AvatarDropdown onMobileNumberChange={jest.fn()} countriesName={testArray} />)

    const countrySelectButton = screen.getByTestId('country-select-button')
    fireEvent.click(countrySelectButton)

    const countryIcons = screen.getAllByTestId('pop-over-click')
    expect(countryIcons).toHaveLength(testArray.length)

    fireEvent.click(countryIcons[0])

    const popover = screen.getByTestId('pop-over')
    expect(popover).toBeInTheDocument()

    fireEvent.click(countryIcons[0])
  })

  test('it should handle selecting a country icon in the popover', () => {
    render(<AvatarDropdown onMobileNumberChange={jest.fn()} countriesName={testArray} />)

    const countrySelectButton = screen.getByTestId('country-select-button')
    fireEvent.click(countrySelectButton)

    const countryIcons = screen.getAllByTestId('pop-over-click')
    fireEvent.click(countryIcons[0])

    expect(screen.getByAltText('Icon Alt 1')).toBeInTheDocument()
  })

  test('it should handle input value starts with the country code', () => {
    render(<AvatarDropdown onMobileNumberChange={jest.fn()} countriesName={testArray} />)

    const inputValueWithCode = '+44 123'
    const textField = screen.getByLabelText('Mobile number')
    fireEvent.change(textField, { target: { value: inputValueWithCode } })

    const expectedValueWithCode = inputValueWithCode
    expect(textField).toHaveValue(expectedValueWithCode)
  })

  test('it should handle input value does not start with the country code', () => {
    render(<AvatarDropdown onMobileNumberChange={jest.fn()} countriesName={testArray} />)

    const inputValueWithoutCode = '+44 123'
    const textField = screen.getByLabelText('Mobile number')
    fireEvent.change(textField, { target: { value: inputValueWithoutCode } })

    expect(textField).toHaveValue(inputValueWithoutCode)
  })

  test('it should handle input value without the country code', () => {
    render(<AvatarDropdown onMobileNumberChange={jest.fn()} countriesName={testArray} />)

    const inputValueWithoutCode = '123'
    const textField = screen.getByLabelText('Mobile number')
    fireEvent.change(textField, { target: { value: inputValueWithoutCode } })

    const expectedValueWithoutCode = '+44 123'
    expect(textField).toHaveValue(expectedValueWithoutCode)
  })
})
