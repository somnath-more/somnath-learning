import React, { useState } from 'react'
import CustomTextField from 'components/atoms/Input'
import {
  Stack,
  InputAdornment,
  IconButton,
  Popover as PopOver,
  Divider,
} from '@mui/material'
import MuiIcon from 'components/atoms/Icons'
import theme from 'themes'
import DownArrowImg from 'public/assets/image/down-arrow.svg'
import GBPImg from 'public/assets/image/uk.svg'
import MuiTypography from 'components/atoms/Typography'
import { CountryProps } from 'utils/types'
import { formatPhoneNumber, handleKeyPress } from 'utils/mobileValidation'
import { styled } from 'styled-components'
import { validateMobileNumber } from 'utils/credentials'

interface DropdownTypographyProps {
  countriesName: CountryProps[]
  onMobileNumberChange: (isValid: boolean) => void
  saveMobileNumber?: (data: string) => void
}

const StyleIconButton = styled(IconButton)({
  boxShadow: 'none',
})

const AvatarDropdown = ({
  countriesName,
  onMobileNumberChange,
  saveMobileNumber,
}: DropdownTypographyProps) => {
  const [error, setError] = useState<{ mobileNumber: string }>({
    mobileNumber: '',
  })
  const [popOverAnchorEl, setPopOverAnchorEl] =
    useState<HTMLButtonElement | null>(null)
  const [icon, setIcon] = useState<string>(GBPImg)
  const [countryCode, setCountryCode] = useState<string>('+44')
  const [value, setValue] = useState<string>('')

  const popOverOpen = Boolean(popOverAnchorEl)
  const popOverId = popOverOpen ? 'simple-popover' : undefined

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setPopOverAnchorEl(event.currentTarget)
  }

  const handleCountryClick = (src: string, code: string) => {
    setIcon(src)
    setCountryCode(code)
    setPopOverAnchorEl(null)
  }

  const handleValueChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = event.target.value
    const formattedValue = formatPhoneNumber(inputValue)

    if (formattedValue.startsWith(countryCode)) {
      setValue(formattedValue.slice(countryCode.length).trim())
      const cleanedValue = formattedValue.replace(/\s/g, '')
      const isMobileValid = validateMobileNumber(cleanedValue, countryCode)
      onMobileNumberChange(isMobileValid && !!cleanedValue)
      setError((prevErrors) => ({
        ...prevErrors,
        mobileNumber: isMobileValid ? '' : 'Invalid Mobile Number',
      }))
      if (saveMobileNumber) {
        saveMobileNumber(inputValue)
      }
    } else {
      setValue(formattedValue)
      setError((prevErrors) => ({
        ...prevErrors,
        mobileNumber: '',
      }))
    }
  }

  return (
    <>
      <PopOver
        id={popOverId}
        open={popOverOpen}
        anchorEl={popOverAnchorEl}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        data-testid="pop-over"
        disableAutoFocus
      >
        {countriesName.map((element) => (
          <Stack key={element.id} data-testid="pop-over-stack">
            <StyleIconButton
              data-testid="pop-over-click"
              onClick={() => handleCountryClick(element.src, element.start)}
            >
              <MuiIcon src={element.src} alt={element.alt} />
              <MuiTypography
                variant="body1"
                color={theme.palette.Text.highEmphasis}
                style={{ marginLeft: '10px' }}
              >
                {element.start}
              </MuiTypography>
            </StyleIconButton>
          </Stack>
        ))}
      </PopOver>
      <Stack display="flex" flexDirection="column" spacing={1}>
        <CustomTextField
          label="Mobile number"
          InputProps={{
            onKeyPress: handleKeyPress,
            startAdornment: (
              <InputAdornment position="start">
                <StyleIconButton
                  onClick={handleClick}
                  data-testid="country-select-button"
                >
                  <MuiIcon
                    src={icon}
                    alt="icon not found"
                    style={{ marginRight: '8px' }}
                  />
                  <MuiIcon src={DownArrowImg} alt="dropdown not found" />
                  <Divider orientation="vertical" flexItem />
                </StyleIconButton>
              </InputAdornment>
            ),
          }}
          onChange={handleValueChange}
          value={`${countryCode} ${value}`}
          sx={{ width: '516px' }}
        />
        {error && (
          <MuiTypography variant="caption1" color={theme.palette.Text.warning}>
            {error.mobileNumber}
          </MuiTypography>
        )}
      </Stack>
    </>
  )
}

export default AvatarDropdown
