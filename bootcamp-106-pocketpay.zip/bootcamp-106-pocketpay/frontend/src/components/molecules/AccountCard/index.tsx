import { Box, Stack, styled } from '@mui/material'
import theme from 'themes'
import MuiIcon from 'components/atoms/Icons'
import MuiTypography from 'components/atoms/Typography'

const StyledBox = styled(Box)({
  width: '516px',
  borderRadius: '8px',
  border: `1px solid ${theme.palette.Accent.stroke2}`,
  cursor: 'pointer',
  '&:hover': {
    backgroundColor: theme.palette.Text.stroke,
  },
})

const StyledStack = styled(Stack)({
  padding: '20px',
})

interface AccountCardProps {
  icon: string
  iconAlt: string
  text: string
  subText?: string
}

const AccountCard = ({ ...props }: AccountCardProps) => {
  return (
    <>
      <StyledBox data-testid="styled-box">
        <StyledStack spacing={3}>
          <Stack direction="row" sx={{ alignItems: 'center' }} spacing={3}>
            <MuiIcon
              alt={props.iconAlt}
              src={props.icon}
              width="24px"
              height="24px"
            />
            <MuiTypography
              variant="body2"
              sx={{ color: theme.palette.Text.highEmphasis }}
            >
              {props.text}
            </MuiTypography>
          </Stack>
          {props.subText && (
            <Stack>
              <MuiTypography
                variant="caption1"
                sx={{
                  color: theme.palette.Text.lowEmphasis,
                  marginLeft: '35px',
                }}
              >
                {props.subText}
              </MuiTypography>
            </Stack>
          )}
        </StyledStack>
      </StyledBox>
    </>
  )
}

export default AccountCard
