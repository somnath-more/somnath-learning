import { Meta, StoryFn } from '@storybook/react'
import AccountCard from '.'
import BusinessCard from 'public/assets/image/Business.svg'
import Doller from 'public/assets/image/Dollar.svg'
import SendMoneyIcon from 'public/assets/image/Unionsendicon.svg'
import SetUpIcon from 'public/assets/image/setup.svg'
import { Constants } from 'utils/constants'

const meta: Meta = {
  title: 'Molecules/AccountCard',
  component: AccountCard,
  argTypes: {
    onClick: {
      action: 'clicked',
    },
  },
}
export default meta

const Template: StoryFn<typeof AccountCard> = (args) => (
  <AccountCard {...args} />
)

export const MyBusiness = Template.bind({})
export const SendMoney = Template.bind({})

MyBusiness.args = {
  icon: BusinessCard,
  iconAlt: 'My Business Card',
  text: Constants.MY_BUSINESS,
}


SendMoney.args = {
  icon: SendMoneyIcon,
  iconAlt: 'Send Money Icon',
  text: Constants.SEND_MONEY,
  subText: Constants.SEND_MONEY_SUBTEXT,
}

