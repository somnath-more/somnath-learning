import { fireEvent, render, screen } from '@testing-library/react'
import AccountCard from '.'
import SetUpIcon from 'public/assets/image/setup.svg'
import { Constants } from 'utils/constants'

const mockProps = {
  icon: SetUpIcon,
  iconAlt: 'My Business Card',
  text: Constants.ACCOUNT_SETUP,
  subText: Constants.ACCOUNT_SETUP_SUBTEXT,
}

describe('Account Card', () => {
  test('it should display the main text correctly', () => {
    render(<AccountCard {...mockProps} />)
    const element = screen.getByText(mockProps.text)
    expect(element).toBeInTheDocument()
  })

  test('it should display the subText if subText exists', () => {
    const { getByText } = render(<AccountCard {...mockProps} />)
    const subTextElement = getByText(mockProps.subText)
    expect(subTextElement).toBeInTheDocument()
  })

  test('it should not display the subText if subText does not exists', () => {
    const { queryByText } = render(
      <AccountCard
        text={mockProps.text}
        icon={mockProps.icon}
        iconAlt={mockProps.iconAlt}
      />
    )
    const subTextElement = queryByText(mockProps.subText)
    expect(subTextElement).not.toBeInTheDocument()
  })
})
