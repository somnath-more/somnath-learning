import { StoryFn, Meta } from '@storybook/react'
import IconGrid from './index'
import { icons } from 'utils/constants'

const meta: Meta = {
  title: 'Molecules/IconGrid',
  component: IconGrid,
}
export default meta

const Template: StoryFn<typeof IconGrid> = (args) => <IconGrid {...args} />

export const Primary = Template.bind({})

Primary.args = {
  icons: icons,
}
