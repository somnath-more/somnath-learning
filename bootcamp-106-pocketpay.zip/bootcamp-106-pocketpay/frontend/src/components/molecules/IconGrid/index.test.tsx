import { render, fireEvent, screen } from '@testing-library/react'
import '@testing-library/jest-dom/extend-expect'
import IconGrid from '.'
import { icons } from 'utils/constants'

describe('IconGrid Component', () => {
  const mockHandleIconClick = jest.fn()
  test('it should render icons and call handleIconClick when an icon is clicked', () => {
    render(<IconGrid icons={icons} handleIconClick={mockHandleIconClick} />)

    const iconElements = screen.getAllByAltText((altText) =>
      altText.startsWith('Icon for ')
    )
    expect(iconElements).toHaveLength(3)

    iconElements.forEach((iconElement, index) => {
      expect(iconElement).toBeInTheDocument()
      fireEvent.click(iconElement)
      expect(mockHandleIconClick).toHaveBeenCalledTimes(index + 1)
      expect(mockHandleIconClick).toHaveBeenCalledWith(icons[index])
    })
  })
})
