import { Grid, styled } from '@mui/material'
import MuiIcon from 'components/atoms/Icons'
import theme from 'themes'

interface IconGridProps {
  icons: string[]
  handleIconClick: (src: string) => void
}

const StyledIconGrid = styled(Grid)({
  borderRadius: '4px',
  border: `1px solid ${theme.palette.Accent.stroke2}`,
  width: '56px',
  height: '56px',
  '&:hover': {
    backgroundColor: theme.palette.Text.main,
  },
})

const ContainerGrid = styled(Grid)({
  display: 'flex',
  gap: '94px',
  width: '380px',
})

const IconGrid = ({ icons, handleIconClick }: IconGridProps) => {
  return (
    <ContainerGrid container>
      {icons.map((src) => (
        <StyledIconGrid key={src} onClick={() => handleIconClick(src)}>
          <MuiIcon
            src={src}
            alt={`Icon for ${src}`}
            data-testid={`icon-${src}`}
            style={{ padding: '14px', cursor: 'pointer' }}
          />
        </StyledIconGrid>
      ))}
    </ContainerGrid>
  )
}

export default IconGrid
