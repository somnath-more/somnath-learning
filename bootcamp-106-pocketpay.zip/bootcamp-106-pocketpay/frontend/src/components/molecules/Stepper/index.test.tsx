import * as React from 'react'
import { render, screen, fireEvent } from '@testing-library/react'
import HorizontalStepper, { HorizontalStepperProps } from '.'

const testValues: HorizontalStepperProps['horizontalStepperValues'] = [
  'Step 1',
  'Step 2',
  'Step 3',
]

const testPresentValue = 2

describe('HorizontalStepper', () => {
  test('it should render the component with correct marks and value', () => {
    render(
      <HorizontalStepper
        presentValue={testPresentValue}
        horizontalStepperValues={testValues}
      />
    )

    testValues.forEach((value) => {
      const markElement = screen.getByText(value)
      expect(markElement).toBeInTheDocument()
    })

    const expectedValue =
      (testPresentValue - 1) * (100 / (testValues.length - 1))
    const sliderComponent = screen.getByRole('slider')
    expect(sliderComponent).toHaveAttribute(
      'aria-valuenow',
      String(expectedValue)
    )
  })

  test('it should update the Slider value when the user interacts with it', () => {
    render(
      <HorizontalStepper
        presentValue={testPresentValue}
        horizontalStepperValues={testValues}
      />
    )

    const sliderComponent = screen.getByRole('slider')
    const newValue = 50

    fireEvent.change(sliderComponent, { target: { value: newValue } })

    setTimeout(() => {
      expect(sliderComponent).toHaveAttribute('aria-valuenow', String(newValue))
    }, 0)
  })

  test('it should render the component without marks when horizontalStepperValues is not provided', () => {
    render(<HorizontalStepper presentValue={testPresentValue} />)

    const sliderComponent = screen.queryByRole('slider')
    expect(sliderComponent).toBeInTheDocument()

    expect(screen.queryAllByRole('slider-mark')).toHaveLength(0)
  })
})
