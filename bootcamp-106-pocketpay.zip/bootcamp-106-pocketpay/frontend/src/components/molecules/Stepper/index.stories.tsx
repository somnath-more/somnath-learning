import { StoryFn, Meta } from '@storybook/react'
import HorizontalStepper, { HorizontalStepperProps } from '.'
import {
  stepsForBusinessDetails,
  stepsForCreateAccount,
  stepsForTransactions,
} from 'utils/constants'

const meta: Meta = {
  component: HorizontalStepper,
  title: 'molecules/HorizontalStepper',
}

export default meta
const TEMPLATE: StoryFn<HorizontalStepperProps> = (
  args: HorizontalStepperProps
) => <HorizontalStepper {...args} />

export const BusinessDetails = TEMPLATE.bind({})
BusinessDetails.args = {
  horizontalStepperValues: stepsForBusinessDetails,
  presentValue: 2,
}

export const Transactions = TEMPLATE.bind({})
Transactions.args = {
  horizontalStepperValues: stepsForTransactions,
  presentValue: 2,
}

export const AccountCreation = TEMPLATE.bind({})
AccountCreation.args = {
  horizontalStepperValues: stepsForCreateAccount,
  presentValue: 2,
}
