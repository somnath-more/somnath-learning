import * as React from 'react'
import { Box, Slider, styled } from '@mui/material'
import theme from 'themes'
import { MarkType } from 'utils/types'
import _ from 'lodash'

const StyledBox = styled(Box)({
  width: '788px',
  '.MuiSlider-rail': {
    color: theme.palette.Structural.main,
  },
  '& .MuiSlider-thumb': {
    color: theme.palette.primary.primary300,
    width: '8px',
    height: '8px',
    ':hover': {
      boxShadow: 'none',
    },
  },
  '.MuiSlider-track': {
    color: theme.palette.primary.primary100,
  },
  '.MuiSlider-markLabel': {
    ...theme.typography.caption1,
    color: theme.palette.Text.mediumEmphasis,
  },
  '.MuiSlider-markLabelActive': {
    ...theme.typography.caption1,
    color: theme.palette.primary.primary500,
  },
})

export interface HorizontalStepperProps {
  horizontalStepperValues: string[]
  presentValue: number
}

const HorizontalStepper = ({
  presentValue,
  horizontalStepperValues,
}: HorizontalStepperProps) => {
  const marks: MarkType[] = !_.isEmpty(horizontalStepperValues)
    ? horizontalStepperValues.map((item, index) => ({
        value: index * (100 / (horizontalStepperValues.length - 1)),
        label: item,
      }))
    : []

  const activeStep = presentValue

  return (
    <center>
      <StyledBox>
        <Slider
          marks={marks}
          value={(activeStep - 1) * (100 / (marks.length - 1))}
        />
      </StyledBox>
    </center>
  )
}

HorizontalStepper.defaultProps = {
  horizontalStepperValues: [],
}

export default HorizontalStepper
