import { StoryFn, Meta } from '@storybook/react'
import AvatarTypography from '.'
import ProfileImage from 'public/assets/image/Avatar.svg'
import AustriaImage from 'public/assets/image/Austria.svg'
import IndiaImage from 'public/assets/image/IndiaLogo.svg'
import BankIcon from 'public/assets/image/bank.svg'
import theme from 'themes'

const meta: Meta = {
  title: 'Molecules/AvatarTypography',
  component: AvatarTypography,
  argTypes: {
    typoVariant: {
      options: ['h1', 'body1', 'body2', 'body3', 'caption1', 'linkText'],
      control: { type: 'radio' },
    },
  },
}
export default meta

const Template: StoryFn<typeof AvatarTypography> = (args) => (
  <AvatarTypography {...args} />
)

export const Profile = Template.bind({})
export const Balances2 = Template.bind({})

Profile.args = {
  avatar: ProfileImage,
  avatarAltText: 'Profile Not Found',
  text: 'Ross Gener',
  typoVariant: 'caption1',
  avatarHeight: '28px',
  avatarWidth: '28px',
  typoColorVariant: `${theme.palette.Text.mediumEmphasis}`,
}


Balances2.args = {
  avatar: IndiaImage,
  avatarAltText: 'Flag Not Found',
  text: '10,000.00 INR',
  typoVariant: 'caption1',
  avatarHeight: '24px',
  avatarWidth: '24px',
  boxWidth: '190px',
  boxHeight: '34px',
  typoColorVariant: `${theme.palette.Text.mediumEmphasis}`,
}


