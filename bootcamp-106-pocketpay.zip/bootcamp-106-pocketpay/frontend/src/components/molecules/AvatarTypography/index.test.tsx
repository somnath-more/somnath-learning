import { render, screen } from '@testing-library/react'
import AvatarTypography from '.'

const props = {
  avatar: './assets/image/Avatar.svg',
  text: 'Ross Gener',
  altText: 'Avatar not found',
  avatarWidth: '28px',
  avatarHeight: '28px',
  typoVariant: 'caption1',
  avatarTypoGap: '15px',
  boxWidth: '190px',
  boxHeight: '34px',
}

describe('Avatar With Typography', () => {
  test('it should render AvatarTypography with text and avatar', () => {
    render(
      <AvatarTypography
        avatar={props.avatar}
        text={props.text}
        avatarWidth={props.avatarWidth}
        avatarHeight={props.avatarHeight}
        avatarTypoGap={props.avatarTypoGap}
      />
    )
    const element = screen.getByTestId('avatarTypography')
    expect(element).toBeInTheDocument()
    expect(element).toHaveTextContent(props.text)
    expect(element).toHaveStyle('gap:15px')
    expect(element).toHaveStyle('height:28px')
  })

  test('it should render AvatarTypography with Styled Box', () => {
    render(
      <AvatarTypography
        avatar={props.avatar}
        text={props.text}
        avatarTypoGap={props.avatarTypoGap}
        boxHeight={props.boxHeight}
        boxWidth={props.boxWidth}
      />
    )
    const styledBox = screen.getByTestId('avatarTypography')
    expect(styledBox).toHaveStyle(`
      height: ${props.boxHeight};
      width: ${props.boxWidth};
      gap: ${props.avatarTypoGap};
    `)
  })

  test('it should render the component with default gap value when avatarTypoGap prop is not provided', () => {
    render(<AvatarTypography />)
    const styledBox = screen.getByTestId('avatarTypography')
    expect(styledBox).toHaveStyle(`
      height: 28px;
      width: 130px;
      gap: 10px;
    `)
  })
})
