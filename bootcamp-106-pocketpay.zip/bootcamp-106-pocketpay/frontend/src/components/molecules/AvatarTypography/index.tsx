import { Avatar, Box, styled } from '@mui/material'
import MyAvatar from 'components/atoms/Avatar'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import { AvatarTypoProps } from 'utils/types'

interface StyledBoxProps {
  avatarTypoGap?: string
  boxWidth?: string
  boxHeight?: string
}

const StyledBox = styled(Box)((props: StyledBoxProps) => ({
  display: 'flex',
  alignItems: 'center',
  padding: '5px',
  height: props.boxHeight ? props.boxHeight : '28px',
  width: props.boxWidth ? props.boxWidth : '130px',
  gap: props.avatarTypoGap ? props.avatarTypoGap : '10px',
}))

const AvatarTypography = ({ ...props }: AvatarTypoProps) => {
  return (
    <>
      <StyledBox
        avatarTypoGap={props.avatarTypoGap}
        boxHeight={props.boxHeight}
        boxWidth={props.boxWidth}
        data-testid="avatarTypography"
      >
        <Avatar sx={{ bgcolor: theme.palette.Structural.white }}>
          <MyAvatar
            src={props.avatar}
            alt={props.avatarAltText}
            variant="circular"
            sx={{
              width: props.avatarWidth,
              height: props.avatarHeight,
            }}
          />
        </Avatar>
        <MuiTypography
          variant={props.typoVariant}
          sx={{ color: `${props.typoColorVariant}` }}
        >
          {props.text}
        </MuiTypography>
      </StyledBox>
    </>
  )
}

export default AvatarTypography
