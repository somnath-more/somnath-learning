import { StoryFn, Meta } from '@storybook/react'
import Bankcard from '.'
import Swift from 'public/assets/image/Swift.svg'
import { cardData } from 'utils/constants'

const meta: Meta = {
  title: 'Molecules/Bankcard',
  component: Bankcard,
}
export default meta

const Template: StoryFn<typeof Bankcard> = (args) => <Bankcard {...args} />

export const Primary = Template.bind({})

Primary.args = {
  iconSrc: cardData[3].iconSrc,
  iconAlt: cardData[3].iconAlt,
  heading: cardData[3].heading,
  subHeading: cardData[3].subHeading,
  arrivalInfo: cardData[3].arrivalInfo,
}
