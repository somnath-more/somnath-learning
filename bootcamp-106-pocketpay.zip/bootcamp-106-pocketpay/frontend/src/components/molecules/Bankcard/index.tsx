import { Avatar, Grid, styled } from '@mui/material'
import RadioButton from 'components/atoms/RadioButton'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import MuiIcon from 'components/atoms/Icons'

const StyledContainerGrid = styled(Grid)({
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
})

const StyledTypographyGrid = styled(Grid)({
  display: 'flex',
  flexDirection: 'column',
  gap: '4px',
})

const StyledIconGrid = styled(Grid)({
  width: '40px',
  paddingTop: '10px',
  marginRight: '20px',
})

const StyledHeadingTypography = styled(MuiTypography)({
  fontFamily: theme.typography.fontFamily,
})

const StyledContentTypography = styled(MuiTypography)({
  color: theme.palette.Text.mediumEmphasis,
})

export interface BankcardProps {
  iconSrc: string
  iconAlt: string
  heading: string
  subHeading: string
  arrivalInfo: string
  checked: boolean
  onClick: () => void
}

const Bankcard = ({
  iconSrc,
  iconAlt,
  heading,
  subHeading,
  arrivalInfo,
  checked,
  onClick,
}: BankcardProps) => {
  return (
    <StyledContainerGrid container>
      <Grid item>
        <Grid container>
          <StyledIconGrid item>
            <Avatar
              sx={{ backgroundColor: `${theme.palette.Structural.blue}` }}
            >
              <MuiIcon alt={iconAlt} src={iconSrc} width="24px" height="24px" />
            </Avatar>
          </StyledIconGrid>
          <StyledTypographyGrid item>
            <StyledHeadingTypography variant="body3">
              {heading}
            </StyledHeadingTypography>
            <StyledContentTypography variant="caption1">
              {subHeading}
              <br />
              {arrivalInfo}
            </StyledContentTypography>
          </StyledTypographyGrid>
        </Grid>
      </Grid>
      <Grid item>
        <RadioButton
          data-testid="radio-button"
          checked={checked}
          onClick={onClick}
        />
      </Grid>
    </StyledContainerGrid>
  )
}

export default Bankcard
