import * as React from 'react'
import { fireEvent, render, screen } from '@testing-library/react'
import Bankcard, { BankcardProps } from './index'

const testProps: BankcardProps = {
  iconSrc: 'test-icon.png',
  iconAlt: 'Test Icon',
  heading: 'Test Heading',
  subHeading: 'Test Subheading',
  arrivalInfo: 'Test Arrival',
  checked: true,
  onClick: jest.fn(),
}

describe('Bankcard', () => {
  test('it should render the component with correct props', () => {
    render(<Bankcard {...testProps} />)

    const headingElement = screen.getByText(testProps.heading)
    expect(headingElement).toBeInTheDocument()

    const subHeadingElement = screen.queryByText((content, element) => {
      const regex = new RegExp(testProps.subHeading)
      return regex.test(content) && element?.tagName.toLowerCase() === 'span'
    })
    expect(subHeadingElement).toBeInTheDocument()

    const arriveElement = screen.queryByText((content, element) => {
      const regex = new RegExp(testProps.arrivalInfo)
      return regex.test(content)
    })
    expect(arriveElement).toBeInTheDocument()

    const iconElement = screen.getByAltText(testProps.iconAlt)
    expect(iconElement).toBeInTheDocument()

    const radioButtonElement = screen.getByRole('radio')
    expect(radioButtonElement).toBeInTheDocument()
  })

  test('it should call onClick when clicked on the radio button', () => {
    render(<Bankcard {...testProps} />)

    const radioButton = screen.getByTestId('radio-button')
    fireEvent.click(radioButton)
    expect(testProps.onClick).toHaveBeenCalledTimes(1)
  })

  test('it should show the radio button as not checked when the checked prop is false', () => {
    render(<Bankcard {...testProps} />)

    const radioButton = screen.getByTestId('radio-button')
    expect(radioButton).not.toBeChecked()
  })
})
