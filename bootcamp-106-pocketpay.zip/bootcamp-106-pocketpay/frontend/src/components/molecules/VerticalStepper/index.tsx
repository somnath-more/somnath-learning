import { Box, Step, StepLabel, styled } from '@mui/material'
import MuiTypography from 'components/atoms/Typography'
import { StyledStepper } from './styles'
import { VerticalStepperLabels } from 'utils/types'

const StyledOuterStepperBox = styled(Box)({
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-around',
  alignItems: 'center',
})

export interface VerticalStepperProps {
  steps: VerticalStepperLabels[]
  activeStep: number
}

const Circle = () => <Box className="dot"></Box>
const VerticalStepper = ({ steps, activeStep }: VerticalStepperProps) => {
  return (
    <>
      <StyledStepper
        orientation="vertical"
        activeStep={activeStep - 1}
        data-testid="vertical-stepper"
      >
        {steps.map((step, index) => (
          <Step
            key={step.LeftLabel}
            className={index === activeStep - 1 ? 'activestep' : ''}
          >
            <StyledOuterStepperBox>
              <MuiTypography variant="caption1">{step.LeftLabel}</MuiTypography>
              <StepLabel StepIconComponent={Circle} />
              <MuiTypography variant="caption1" className="right-label">
                {step.RightLabel}
              </MuiTypography>
            </StyledOuterStepperBox>
          </Step>
        ))}
      </StyledStepper>
    </>
  )
}

export default VerticalStepper
