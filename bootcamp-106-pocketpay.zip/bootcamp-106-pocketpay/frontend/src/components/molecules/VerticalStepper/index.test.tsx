import { render } from '@testing-library/react'
import VerticalStepper from '.'
import { StepsForVerticalStepper as steps } from 'utils/constants'

const activeStep = 2

describe('VerticalStepper', () => {
  test('it should render all steps with correct labels', () => {
    const { getByText } = render(
      <VerticalStepper steps={steps} activeStep={activeStep} />
    )

    steps.forEach((step) => {
      expect(getByText(step.LeftLabel)).toBeInTheDocument()
      expect(getByText(step.RightLabel)).toBeInTheDocument()
    })
  })

  test('it should highlight the active step correctly', () => {
    const { container } = render(
      <VerticalStepper steps={steps} activeStep={activeStep} />
    )
    const activeStepElement = container.querySelector('.activestep')
    expect(activeStepElement).toBeInTheDocument()
  })
})
