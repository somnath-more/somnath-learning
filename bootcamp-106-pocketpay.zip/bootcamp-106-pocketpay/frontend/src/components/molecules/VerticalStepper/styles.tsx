import styled from '@emotion/styled'
import { Stepper } from '@mui/material'
import theme from '../../../themes'

export const StyledStepper = styled(Stepper)({
  width: '420px',
  '& .MuiStepConnector-line.MuiStepConnector-lineVertical': {
    width: '2px',
    background: theme.palette.primary.primary500,
    borderLeft: 'none',
    height: '31px',
    marginRight: '61px',
  },
  '& .MuiStepLabel-iconContainer.Mui-disabled': {
    '& .dot': {
      background: theme.palette.Accent.stroke2,
    },
  },
  '& .MuiStepConnector-root.MuiStepConnector-vertical.Mui-disabled': {
    '& span': {
      background: theme.palette.Accent.stroke2,
    },
  },
  '& .MuiStepConnector-root.MuiStepConnector-vertical': {
    display: 'flex',
    justifyContent: 'center',
    marginLeft: '0',
    width: '100%',
    margin: '0 auto',
  },
  '& .MuiStepLabel-root.MuiStepLabel-vertical': {
    padding: 0,
  },
  '& .MuiStepLabel-iconContainer': {
    padding: 0,
  },
  '& .MuiTypography-root': {
    lineHeight: 0,
    width: '150px',
    textAlign: 'right',
    color: theme.palette.Text.lowEmphasis,
  },
  '& .MuiTypography-root.right-label': {
    width: '210px',
    textAlign: 'left',
  },
  '& .dot': {
    borderRadius: '100%',
    background: theme.palette.primary.primary500,
    width: '8px',
    height: '8px',
  },

  '& .MuiStep-root.MuiStep-vertical.Mui-completed': {
    '& .MuiTypography-root': {
      color: theme.palette.Text.highEmphasis,
    },
  },
  '& .activestep .MuiTypography-root': {
    color: theme.palette.primary.primary500,
  },
})
