import { Meta, StoryFn } from '@storybook/react'
import VerticalStepper, { VerticalStepperProps } from '.'
import { StepsForVerticalStepper } from 'utils/constants'

const meta: Meta = {
  title: 'Molecules/VerticalStepper',
  component: VerticalStepper,
}
export default meta

const Template: StoryFn<VerticalStepperProps> = (
  args: VerticalStepperProps
) => <VerticalStepper {...args} />

export const Primary = Template.bind({})

Primary.args = {
  steps: StepsForVerticalStepper,
  activeStep: 3,
}
