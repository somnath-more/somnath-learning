import { ChangeEvent, CSSProperties, useState } from 'react'
import { Box, Grid, Paper, Stack, styled } from '@mui/material'
import MuiIcon from 'components/atoms/Icons'
import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'
import chevronDown from 'public/assets/image/down-arrow.svg'
import CustomTextField from 'components/atoms/Input'
import { CurrencyType, currencies } from 'utils/constants'

const StyledCard = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1),
  position: 'relative',
}))

const currencyOptionStyle: CSSProperties = {
  height: '12.8rem',
  overflowY: 'scroll',
  borderRadius: '0.5rem',
}

const CurrencyContainer = styled(Stack)({
  border: 'none',
  cursor: 'pointer',
})

const CurrencyListGrid = styled(Grid)({
  padding: '0.8rem 0rem 0.3rem 0.8rem',
  border: `1px solid ${theme.palette.Accent.stroke2}`,
  borderRadius: '0.5rem',
  position: 'absolute',
  zIndex: 2,
  backgroundColor: theme.palette.Structural.white,
  boxShadow: theme.shadows[4],
})

const selectCurrencyOptionStyle = {
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  paddingRight: '1rem',
  height: '3.5rem',
  '&:hover': {
    background: theme.palette.Structural.cardHover,
  },
}

const StyledHeader = styled(Paper)({
  all: 'unset',
  position: 'sticky',
  marginBottom: '1.5rem',
})

const MenuItemWithCursor = styled(Stack)<{ active: boolean }>(({ active }) => ({
  // cursor: active ? 'pointer' : 'auto',
}))

export interface TextfieldDropdownProps {
  label: string
  amount: string
  selectedCurrency: CurrencyType
  width?: string
  onAmountChange: (amount: string) => void
  onCurrencyChange: (currency: CurrencyType) => void
}

const TextfieldDropdown = ({
  label,
  amount,
  selectedCurrency,
  width,
  onAmountChange,
  onCurrencyChange,
}: TextfieldDropdownProps) => {
  const [isCurrencyInputVisible, setIsCurrencyInputVisible] =
    useState<boolean>(false)

  const handleAmountChange = (event: ChangeEvent<HTMLInputElement>) => {
    const inputNumber = event.target.value
    const numbersOnly = inputNumber.replace(/\D/g, '')
    onAmountChange(numbersOnly)
  }

  const handleCurrencyClick = () => {
    setIsCurrencyInputVisible(!isCurrencyInputVisible)
  }

  const handleMenuItemClick = (currency: CurrencyType) => {
    if (currency.active) {
      onCurrencyChange(currency)
      setIsCurrencyInputVisible(false)
    }
  }

  return (
    <StyledCard>
      {!isCurrencyInputVisible && (
        <CustomTextField
          sx={{ width: width }}
          data-testid="amount-textfield"
          label={label}
          value={amount}
          onChange={handleAmountChange}
          InputProps={{
            inputMode: 'numeric',
            endAdornment: (
              <Box
                data-testid="selected-currency"
                onClick={handleCurrencyClick}
              >
                <CurrencyContainer direction="row" spacing={0.4}>
                  <MuiIcon src={selectedCurrency.icon} alt="loading" />
                  <MuiTypography
                    variant="body2"
                    color={theme.palette.Text.highEmphasis}
                    style={{ marginLeft: '10px', marginTop: '5px' }}
                  >
                    {selectedCurrency.code}
                  </MuiTypography>
                  <MuiIcon src={chevronDown} alt="loading" />
                </CurrencyContainer>
              </Box>
            ),
          }}
        />
      )}
      {isCurrencyInputVisible && (
        <CurrencyListGrid
          container
          flexDirection="column"
          sx={{ width: width }}
        >
          <StyledHeader>
            <MuiTypography
              variant="body2"
              color={theme.palette.Text.mediumEmphasis}
            >
              Select Currency
            </MuiTypography>
          </StyledHeader>
          <Box style={currencyOptionStyle}>
            {currencies.map((currency) => (
              <MenuItemWithCursor
                data-testid="currency-item-list"
                key={currency.code}
                active={currency.active}
                onClick={() => handleMenuItemClick(currency)}
              >
                <Box>
                  <Stack sx={selectCurrencyOptionStyle}>
                    <Stack direction="row" spacing={2} alignItems="center">
                      <MuiIcon src={currency.icon} alt="loading" />
                      <MuiTypography
                        variant="body2"
                        color={theme.palette.Text.highEmphasis}
                      >
                        {currency.label}
                      </MuiTypography>
                    </Stack>
                    <MuiTypography
                      variant="body2"
                      color={theme.palette.Text.mediumEmphasis}
                    >
                      {currency.code}
                    </MuiTypography>
                  </Stack>
                </Box>
              </MenuItemWithCursor>
            ))}
          </Box>
        </CurrencyListGrid>
      )}
    </StyledCard>
  )
}

export default TextfieldDropdown
