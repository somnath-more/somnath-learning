import { Meta, StoryFn } from '@storybook/react'
import TextfieldDropdown, { TextfieldDropdownProps } from '.'
import { action } from '@storybook/addon-actions'
import { CurrencyType, currencies } from 'utils/constants'
import React from 'react'

export default {
  title: 'Molecules/TextfieldDropdown',
  component: TextfieldDropdown,
} as Meta

export const Template: StoryFn<TextfieldDropdownProps> = (args) => {
  const [amount, setAmount] = React.useState<string>('100')
  const [selectedCurrency, setSelectedCurrency] = React.useState(currencies[1])

  const handleAmountChange = (newAmount: string) => {
    setAmount(newAmount)
    action('Amount field changed...')(newAmount)
  }

  const handleCurrencyChange = (newCurrency: CurrencyType) => {
    setSelectedCurrency(newCurrency)
    action('Currency option changed...')(newCurrency)
  }

  return (
    <TextfieldDropdown
      {...args}
      amount={amount}
      selectedCurrency={selectedCurrency}
      onAmountChange={handleAmountChange}
      onCurrencyChange={handleCurrencyChange}
      width="35%"
    />
  )
}
export const Default = Template.bind({})
Default.args = {
  label: 'You send',
}
