import { fireEvent, render, screen } from '@testing-library/react'
import EmptyDashboardPage from '.'
import { BrowserRouter, useNavigate } from 'react-router-dom'
import '@testing-library/jest-dom/extend-expect'

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}))

const handleClick = jest.fn()

describe('Empty Dashboard Page', () => {
  let navigateMock = jest.fn()
  beforeEach(() => {
    (useNavigate as jest.Mock).mockReturnValue(navigateMock)
    render(
      <BrowserRouter>
        <EmptyDashboardPage />
      </BrowserRouter>
    )
  })

  test('it should render the empty dashboard template correctly', () => {
    const dashboardTemplate = screen.getByTestId('dashboard-template')
    expect(dashboardTemplate).toBeInTheDocument()
  })

  test('it should handle when "Send Money" button is clicked', () => {
    const sendMoneyBtn = screen.getByText('Send Money')
    sendMoneyBtn.addEventListener('click', handleClick)
    expect(sendMoneyBtn).toBeInTheDocument()
    fireEvent.click(sendMoneyBtn)
    expect(handleClick).toHaveBeenCalledTimes(1)
    expect(navigateMock).toHaveBeenCalledWith('/transfer-options')
  })
})
