import ImageTypography from 'components/molecules/ImageTypography'
import AvatarDialogueBox from 'components/organisms/ApplicationHeader/AvatarDialogueBox'
import NavBar from 'components/organisms/NavigationBar'
import DashboardTemplate from 'components/templates/Dashboard'
import theme from 'themes'
import {
  balancesConstants,
  JarsConstants,
  SideNav,
  Constants,
  Navigation_Paths,
} from 'utils/constants'
import PocketPayLogo from 'public/assets/image/PocketPay.svg'
import HOMEPAGE_IMG from 'public/assets/image/Illustration.svg'
import { useNavigate } from 'react-router-dom'

const EmptyDashboardPage = () => {
  const navigate = useNavigate()

  const onPayment = () => {
    navigate(Navigation_Paths.TRANSFEROPTIONS)
  }

  return (
    <>
      <DashboardTemplate
        sideNav={
          <NavBar
            logoUrl={PocketPayLogo}
            balances={balancesConstants}
            jars={JarsConstants}
            sideNav={SideNav}
            balanceHeader={Constants.BALANCES}
            jarHeader={Constants.JARS}
            hasBalances={false}
          />
        }
        header={<AvatarDialogueBox />}
        main={
          <ImageTypography
            src={HOMEPAGE_IMG}
            alt={'Home-image'}
            text={
              <div style={{ color: theme.palette.Text.mediumEmphasis }}>
                This is where you’ll see your activity and transactions.
                <br />
                Choose how you’d like to get started.
              </div>
            }
            width="173px"
            height="183px"
            variant="body1"
          />
        }
        onSendMoney={onPayment}
      />
    </>
  )
}

export default EmptyDashboardPage
