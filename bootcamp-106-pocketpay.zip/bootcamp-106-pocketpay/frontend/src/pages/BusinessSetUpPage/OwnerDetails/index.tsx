import MuiIcon from 'components/atoms/Icons'
import HorizontalStepper from 'components/molecules/Stepper'
import AccountOwnerDetail from 'components/organisms/AccountOwnerDetail'
import { StepperTemplate } from 'components/templates/Stepper'
import {
  stepsForBusinessDetails,
  FILL_YOUR_DETAILS,
  options,
} from 'utils/constants'
import LOGO from 'public/assets/image/Brand.svg'
import CLOSE from 'public/assets/image/close.svg'
import { useContext, useState } from 'react'
import { UserInformation } from 'utils/types'
import { postUser } from '../../../services'
import { UserContext } from 'utils/hooks/contexts'

const OwnerDetailsPage = () => {
  const [accountHolder, setAccountHolders] = useState<UserInformation>({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    dateOfBirth: null,
    phone_no: '',
    countryOfResidence: 'United Kingdom',
    homeAddress: '',
    city: '',
    pinCode: '',
    accountType: ''
  })

  const { userData, setUserData } = useContext(UserContext)

  const onNextPage = async () => {
    const updatedUserDetails = {
      ...userData,
      firstName: accountHolder.firstName,
      lastName: accountHolder.lastName,
      dateOfBirth: accountHolder.dateOfBirth,
      countryOfResidence: accountHolder.countryOfResidence,
      homeAddress: accountHolder.homeAddress,
      city: accountHolder.city,
      pinCode: accountHolder.pinCode,
      accountType: 'BUSINESS',
    }
    setUserData(updatedUserDetails)
    console.log(updatedUserDetails)
    await postUser(updatedUserDetails)
  }

  return (
    <>
      <StepperTemplate
        headerImage={
          <MuiIcon
            src={LOGO}
            alt="pocketPay-logo"
            width="103px"
            height="22px"
          />
        }
        headerStepper={
          <HorizontalStepper
            data-testid="header-stepper"
            horizontalStepperValues={stepsForBusinessDetails}
            presentValue={3}
          />
        }
        headerClose={
          <MuiIcon src={CLOSE} alt="close-icon" width="103px" height="22px" />
        }
        content={
          <AccountOwnerDetail
            ownerHeading={FILL_YOUR_DETAILS.HEADING}
            subOwnerHeading={FILL_YOUR_DETAILS.SUB_HEADING}
            options={options}
            onClick={onNextPage}
            saveOwnerDetails={(data) => setAccountHolders(data)}
          />
        }
      />
    </>
  )
}

export default OwnerDetailsPage
