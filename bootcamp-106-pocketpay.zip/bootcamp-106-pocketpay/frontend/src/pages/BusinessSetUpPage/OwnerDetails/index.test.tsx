import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import OwnerDetailsPage from '.'
import { BrowserRouter } from 'react-router-dom'
import '@testing-library/jest-dom/extend-expect'
import * as Router from 'react-router'
import axios from 'axios'

jest.mock("axios");
jest.mock('../../../services', () => ({
  postUser: jest.fn(),
}));
describe('Owner Details Page', () => {
  let navigateMock = jest.fn()
  const postUser = jest.fn();
  beforeEach(() => {
    jest.mock('react-router-dom', () => ({
      ...jest.requireActual('react-router-dom'),
    }));
    jest.spyOn(Router, 'useNavigate').mockImplementation(()=>navigateMock);
    jest.spyOn(axios, "post").mockResolvedValue({ postUser });
    render(
      <BrowserRouter>
        <OwnerDetailsPage />
      </BrowserRouter>
    )
  })

  test('it should render the page with correct template', () => {
    expect(screen.getByAltText('pocketPay-logo')).toBeInTheDocument()
    expect(screen.getByRole('slider')).toBeInTheDocument()
    expect(screen.getByAltText('close-icon')).toBeInTheDocument()
  })

  test('it should render stepper correctly', () => {
    expect(screen.getByText('Your business')).toBeInTheDocument()
    expect(screen.getByText('Business activity')).toBeInTheDocument()
    expect(screen.getByText('Your details')).toBeInTheDocument()
  })

  test('it should render the account owner details form and update the text fields when input values change and navigate to /transfer-options', () => {
    expect(screen.getByText('Fill in your details')).toBeInTheDocument()
    expect(
      screen.getByText(
        'Since you’re opening the account, we need to know a bit more about you.'
      )
    ).toBeInTheDocument()
    const firstNameInputValue = screen.getByLabelText('First name')
    const lastNameInputValue = screen.getByLabelText('Last name')
    const dateInputValue = screen.getByLabelText('Date of birth')
    const dropdownInputValue = screen.getByLabelText('Country of residence')
    const homeAddressInputValue = screen.getByLabelText('Home address')
    const cityInputValue = screen.getByLabelText('City')
    const pincodeInputValue = screen.getByLabelText('Pincode')

    fireEvent.change(firstNameInputValue, { target: { value: 'John' } })
    expect(firstNameInputValue).toHaveValue('John')

    fireEvent.change(lastNameInputValue, { target: { value: 'Reddy' } })
    expect(lastNameInputValue).toHaveValue('Reddy')

    fireEvent.change(dateInputValue, { target: { value: '31-07-2023' } })
    expect(dateInputValue).toHaveValue('31-07-2023')

    fireEvent.change(dropdownInputValue, { target: { value: 'A' } })
    expect(screen.getByTestId('option-image-Austria')).toBeInTheDocument()

    fireEvent.change(homeAddressInputValue, {
      target: { value: '43 Bishophthorpe Road' },
    })
    expect(homeAddressInputValue).toHaveValue('43 Bishophthorpe Road')

    fireEvent.change(cityInputValue, { target: { value: 'Pencoed' } })
    expect(cityInputValue).toHaveValue('Pencoed')

    fireEvent.change(pincodeInputValue, { target: { value: 'CF3534' } })
    expect(pincodeInputValue).toHaveValue('CF3534')

    const countrySelect = screen.getAllByLabelText('Country of residence')
    fireEvent.change(countrySelect[0] as HTMLInputElement, {
      target: { value: 'In' },
    })
    fireEvent.click(screen.getByText('India'))
    expect(countrySelect[0]).toHaveValue('India')

    const continueBtn = screen.getByRole('button', { name: 'Continue' })
    expect(continueBtn).toBeEnabled

    const clickBtn = jest.fn()
    continueBtn.addEventListener('click', clickBtn)
    fireEvent.click(continueBtn)

    expect(clickBtn).toHaveBeenCalledTimes(1)
    waitFor(()=>{
      expect(postUser).toHaveBeenCalledTimes(1)

    })
  })
})
