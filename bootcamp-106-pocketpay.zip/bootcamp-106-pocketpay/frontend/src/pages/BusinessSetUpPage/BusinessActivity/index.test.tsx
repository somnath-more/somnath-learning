import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import BusinessActivity from '.'
import { BrowserRouter, useNavigate } from 'react-router-dom'
import '@testing-library/jest-dom/extend-expect'
import axios from "axios";
import { postBusinessActivity } from '../../../services';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
  useLocation: jest.fn(),
}))
jest.mock("axios");

jest.mock('../../../services', () => ({
  postBusinessActivity: jest.fn(() => Promise.resolve({ success: true })),
}));

describe('Business Activity Page', () => {
  const businessActivityDetails = {
    business_name: 'Zemoso technologies pvt ltd',
    category: '',
    registration_number: '2020ZEN5367GJ',
    size_of_business: '',
    sub_category: '',
  };
  const businessAddresses = {
    address:
      '#2097, Triveni Main Rd, Gokula 1st Stage, Nanjappa Reddy Colony, Yeswanthpur, Bengaluru, Karnataka 560054',
    id: 1,
  };
  let navigateMock = jest.fn()
  const mockPost = jest.fn();
  beforeEach(() => {
    const mockLocation = {
      state: {
        businessActivityDetails,
        businessAddresses,
      },
    };
    require('react-router-dom').useLocation.mockReturnValue(mockLocation);
    (useNavigate as jest.Mock).mockReturnValue(navigateMock)
    jest.spyOn(axios, "post").mockResolvedValue({ mockPost });
    render(
      <BrowserRouter>
        <BusinessActivity />
      </BrowserRouter>
    )
  })

  test('it should render the page with correct template', () => {
    expect(screen.getByAltText('pocketPay-logo')).toBeInTheDocument()
    expect(screen.getByRole('slider')).toBeInTheDocument()
    expect(screen.getByAltText('close-icon')).toBeInTheDocument()
  })

  test('it should render stepper correctly', () => {
    expect(screen.getByText('Your business')).toBeInTheDocument()
    expect(screen.getByText('Business activity')).toBeInTheDocument()
    expect(screen.getByText('Your details')).toBeInTheDocument()
  })

  test('it should render verify business account and navigate to /account-owner ', () => {
    expect(
      screen.getByText('Help us verify your account faster')
    ).toBeInTheDocument()

    const category = screen.getByLabelText('Category')

    fireEvent.mouseDown(category)
    const categoryOption = screen.getByText('Real estate or construction')
    fireEvent.click(categoryOption)

    const subCategory = screen.getByLabelText('Subcategory')

    fireEvent.mouseDown(subCategory)
    const subCategoryOption = screen.getByText(
      'Real estate sale, purchase and management'
    )
    fireEvent.click(subCategoryOption)

    const sizeOfBusiness = screen.getByLabelText('Size of your business')

    fireEvent.mouseDown(sizeOfBusiness)
    const sizeOfBusinessOption = screen.getByText('50-100')
    fireEvent.click(sizeOfBusinessOption)

    const continueBtn = screen.getByRole('button', { name: 'Continue' })
    expect(continueBtn).toBeEnabled

    const clickBtn = jest.fn()
    continueBtn.addEventListener('click', clickBtn, { once: true })
    fireEvent.click(continueBtn)
    expect(clickBtn).toHaveBeenCalledTimes(1)
    waitFor(() => {
      expect(postBusinessActivity).toHaveBeenCalledWith(expect.objectContaining(businessActivityDetails));
      expect(mockPost).toHaveBeenCalledTimes(1)
      expect(navigateMock).toHaveBeenCalledWith('/account-owner')
    })
  })
})
