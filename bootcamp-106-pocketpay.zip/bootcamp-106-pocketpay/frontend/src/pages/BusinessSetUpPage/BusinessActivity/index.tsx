import MuiIcon from 'components/atoms/Icons'
import HorizontalStepper from 'components/molecules/Stepper'
import VerifyBusinessAccount, {
  SelectedOptions,
} from 'components/organisms/VerifyBusinessAccount'
import { StepperTemplate } from 'components/templates/Stepper'
import {
  stepsForBusinessDetails,
  CategoryOptions,
  SubCategoryOptions,
  SizeOfBusinessOptions,
  Navigation_Paths,
} from 'utils/constants'
import LOGO from 'public/assets/image/Brand.svg'
import CLOSE from 'public/assets/image/close.svg'
import { useLocation, useNavigate } from 'react-router-dom'
import { postBusinessActivity } from '../../../services'
import { useState } from 'react'

const BusinessActivity = () => {
  const navigate = useNavigate()
  const location = useLocation()

  const [selectedOptions, setSelectedOptions] = useState<SelectedOptions>({
    selectedCategory: null,
    selectedSubCategory: null,
    selectedSizeOfBusiness: null,
  })

  let businessActivityDetails = location.state?.businessActivityDetails

  const onNextPage = async () => {
    if (businessActivityDetails) {
      businessActivityDetails.category = selectedOptions.selectedCategory?.label
      businessActivityDetails.subCategory =
        selectedOptions.selectedSubCategory?.label
      businessActivityDetails.sizeOfBusiness =
        selectedOptions.selectedSizeOfBusiness?.label
    }

    try {
      console.log(businessActivityDetails)
      await postBusinessActivity(businessActivityDetails)
    } catch (err) {
    }

    navigate(Navigation_Paths.ACCOUNT_OWNER)
  }

  return (
    <StepperTemplate
      headerImage={
        <MuiIcon src={LOGO} alt="pocketPay-logo" width="103px" height="22px" />
      }
      headerStepper={
        <HorizontalStepper
          data-testid="header-stepper"
          horizontalStepperValues={stepsForBusinessDetails}
          presentValue={2}
        />
      }
      headerClose={
        <MuiIcon src={CLOSE} alt="close-icon" width="103px" height="22px" />
      }
      content={
        <VerifyBusinessAccount
          categoryOptions={CategoryOptions}
          subCategoryOptions={SubCategoryOptions}
          sizeOfBusinessOptions={SizeOfBusinessOptions}
          onContinueClick={onNextPage}
          saveBusinessActivity={(data) => setSelectedOptions(data)}
        />
      }
    />
  )
}

export default BusinessActivity
