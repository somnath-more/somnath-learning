import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import BusinessSearchPage from '.'
import {
  CONFIRM_BUSINESS_DETAILS,
  CONFIRM_TRADING_ADDRESS,
  Constants,
  Navigation_Paths,
  SEARCH_BUSINESS_CAPTION,
  SEARCH_BUSINESS_TITLE,
} from 'utils/constants'
import { BrowserRouter, useNavigate } from 'react-router-dom'
import '@testing-library/jest-dom/extend-expect'

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
  useLocation: () => ({
    state: { businessActivityDetails: {} },
  }),
}))

describe('Search Business Page', () => {
  let navigateMock = jest.fn()
  beforeEach(() => {
    ;(useNavigate as jest.Mock).mockReturnValue(navigateMock)
    render(
      <BrowserRouter>
        <BusinessSearchPage />
      </BrowserRouter>
    )
  })

  test('it should render the page with correct template', () => {
    expect(screen.getByAltText('pocketPay-logo')).toBeInTheDocument()
    expect(screen.getByRole('slider')).toBeInTheDocument()
    expect(screen.getByAltText('close-icon')).toBeInTheDocument()
    expect(screen.getByTestId('ArrowBackIcon')).toBeInTheDocument()
  })

  test('it should render stepper correctly', () => {
    expect(screen.getByText('Your business')).toBeInTheDocument()
    expect(screen.getByText('Business activity')).toBeInTheDocument()
    expect(screen.getByText('Your details')).toBeInTheDocument()
  })

  test('it should render search business screen and go to business details screen and should handle the back arrow', () => {
    expect(screen.getByText(SEARCH_BUSINESS_TITLE)).toBeInTheDocument()
    expect(screen.getByText(SEARCH_BUSINESS_CAPTION)).toBeInTheDocument()

    const searchInput = screen.getByLabelText('Search your business')
    fireEvent.change(searchInput, {
      target: { value: 'Zemoso technologies pvt ltd' },
    })

    const dropdown = screen.getByTestId('autocomplete-dropdown')
    fireEvent.mouseDown(dropdown)

    const option = screen.getAllByTestId('business-options')
    fireEvent.click(option[0])

    expect(
      screen.getByText('Confirm your business details')
    ).toBeInTheDocument()
    expect(screen.getByText('Zemoso technologies pvt ltd')).toBeInTheDocument()

    const Edit = screen.getByText('Edit')
    expect(Edit).toBeInTheDocument()
    fireEvent.click(Edit)

    const businessNameChangeEvent = {
      target: { value: 'New Business Name' },
    }

    const registrationNumberChangeEvent = {
      target: { value: '0123456789' },
    }

    const registeredAddressChangeEvent = {
      target: { value: 'New Address' },
    }

    fireEvent.change(
      screen.getByLabelText(CONFIRM_BUSINESS_DETAILS.BUSINESS_NAME),
      businessNameChangeEvent
    )

    fireEvent.change(
      screen.getByLabelText(CONFIRM_BUSINESS_DETAILS.REGISTRATION_NUMBER),
      registrationNumberChangeEvent
    )

    fireEvent.change(
      screen.getByLabelText(CONFIRM_BUSINESS_DETAILS.REGISTERED_ADDRESS),
      registeredAddressChangeEvent
    )

    fireEvent.click(screen.getByText(Constants.SAVE))

    expect(screen.getByText('New Business Name')).toBeInTheDocument()
    expect(screen.getByText('0123456789')).toBeInTheDocument()
    expect(screen.getByText('New Address')).toBeInTheDocument()

    const backButton = screen.getByTestId('ArrowBackIcon')
    fireEvent.click(backButton)
    expect(screen.getByText(SEARCH_BUSINESS_TITLE)).toBeInTheDocument()
  })

  test('it should render search business screen and go to trading address screen and should handle the back arrow', () => {
    expect(screen.getByText(SEARCH_BUSINESS_TITLE)).toBeInTheDocument()
    expect(screen.getByText(SEARCH_BUSINESS_CAPTION)).toBeInTheDocument()

    const searchInput = screen.getByLabelText('Search your business')
    fireEvent.change(searchInput, {
      target: { value: 'Zemoso technologies pvt ltd' },
    })

    const dropdown = screen.getByTestId('autocomplete-dropdown')
    fireEvent.mouseDown(dropdown)

    const option = screen.getAllByTestId('business-options')
    fireEvent.click(option[0])

    expect(
      screen.getByText('Confirm your business details')
    ).toBeInTheDocument()
    expect(screen.getByText('Zemoso technologies pvt ltd')).toBeInTheDocument()

    const continueButton = screen.getByText('Continue')
    fireEvent.click(continueButton)
    expect(screen.getByText('Confirm trading address')).toBeInTheDocument()

    const confirmButton = screen.getByText('Confirm')
    fireEvent.click(confirmButton)

    const backButton = screen.getByTestId('ArrowBackIcon')
    fireEvent.click(backButton)
    expect(
      screen.getByText('Confirm your business details')
    ).toBeInTheDocument()
    fireEvent.click(backButton)
    expect(screen.getByText(SEARCH_BUSINESS_TITLE)).toBeInTheDocument()
  })

  test('it should render search business screen and navigate to next screens "/business-details", "/business-address" and then next page "/business-activity" ', () => {
    expect(screen.getByText(SEARCH_BUSINESS_TITLE)).toBeInTheDocument()
    expect(screen.getByText(SEARCH_BUSINESS_CAPTION)).toBeInTheDocument()

    const searchInput = screen.getByLabelText('Search your business')
    fireEvent.change(searchInput, {
      target: { value: 'Zemoso technologies pvt ltd' },
    })

    const dropdown = screen.getByTestId('autocomplete-dropdown')
    fireEvent.mouseDown(dropdown)
    const option = screen.getAllByTestId('business-options')
    fireEvent.click(option[0])

    expect(navigateMock).toHaveBeenCalledWith('/business-details')

    expect(
      screen.getByText('Confirm your business details')
    ).toBeInTheDocument()
    expect(screen.getByText('Zemoso technologies pvt ltd')).toBeInTheDocument()
    const continueButton = screen.getByText('Continue')
    fireEvent.click(continueButton)

    expect(navigateMock).toHaveBeenCalledWith('/business-address')

    expect(screen.getByText('Confirm trading address')).toBeInTheDocument()
  })

  test('it should save confirm trading address" ', () => {
    const searchInput = screen.getByLabelText('Search your business')
    fireEvent.change(searchInput, {
      target: { value: 'Zemoso technologies pvt ltd' },
    })

    const dropdown = screen.getByTestId('autocomplete-dropdown')
    fireEvent.mouseDown(dropdown)
    const option = screen.getAllByTestId('business-options')
    fireEvent.click(option[0])

    expect(
      screen.getByText('Confirm your business details')
    ).toBeInTheDocument()
    const continueButton = screen.getByText('Continue')
    fireEvent.click(continueButton)

    expect(screen.getByText('Confirm trading address')).toBeInTheDocument()
    const addAddressButton = screen.getByText('Add trading address')
    fireEvent.click(addAddressButton)
    const modalAddressInput = screen.getByLabelText('Trading Address 2')
    fireEvent.change(modalAddressInput, { target: { value: 'New Address 3' } })

    const saveModalButton = screen.getByText('Add')
    fireEvent.click(saveModalButton)

    const addressCards = screen.getAllByTestId('radio-button')
    fireEvent.click(addressCards[1])
    const confirmButton = screen.getByText('Confirm')
    fireEvent.click(confirmButton)

    expect(navigateMock).toHaveBeenCalledWith(Navigation_Paths.BUSINESS_DETAILS)
  })
})

const mockTradingAddressList = [
  {
    address:
      '#2097, Triveni Main Rd, Gokula 1st Stage, Nanjappa Reddy Colony, Yeswanthpur, Bengaluru, Karnataka 560054',
      addressId: 1,
  },
]
