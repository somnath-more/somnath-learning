import MuiIcon from 'components/atoms/Icons'
import HorizontalStepper from 'components/molecules/Stepper'
import SearchBusiness from 'components/organisms/SearchBusiness'
import { StepperTemplate } from 'components/templates/Stepper'
import React, { useState } from 'react'
import {
  CONFIRM_BUSINESS_DETAILS,
  CONFIRM_TRADING_ADDRESS,
  Constants,
  Navigation_Paths,
  stepsForBusinessDetails,
} from 'utils/constants'
import LOGO from 'public/assets/image/Brand.svg'
import CLOSE from 'public/assets/image/close.svg'
import ArrowBackIcon from '@mui/icons-material/ArrowBack'
import ConfirmBusinessDetails, {
  BusinessDetailsProps,
} from 'components/organisms/ConfirmBusinessDetails'
import ConfirmTradingAddress from 'components/organisms/ConfirmTradingAddress'
import { IconButton } from '@mui/material'
import { useNavigate } from 'react-router-dom'
import { TradingAddress, tradingAddresses } from 'utils/types'

const BusinessSearchPage: React.FC = () => {
  const [hasTradingAddress, setHasTradingAddress] = useState<boolean>(false)

  const [businessName, setBusinessName] = useState<string>('')

  const [editedContent, setEditedContent] = useState<BusinessDetailsProps>()

  const [tradingAddressList, setTradingAddressList] =
    useState<TradingAddress[]>(tradingAddresses)

  const navigate = useNavigate()

  let businessActivityDetails: {
    businessId: number
    name: string
    registrationNumber: string | undefined
    category: string
    subCategory: string
    sizeOfBusiness: string
    address: {
      addressId: number
      address: string
    }[]
  }

  const onNextPage = () => {
    businessActivityDetails = {
      businessId: 10,
      name: editedContent
        ? editedContent.businessNameContent
        : businessName,
      registrationNumber: editedContent?.registrationNumberContent,
      category: '',
      subCategory: '',
      sizeOfBusiness: '',
      address: tradingAddressList
    }
    navigate(Navigation_Paths.BUSINESS_ACTIVITY, {
      state: { businessActivityDetails:businessActivityDetails },
    })
  }

  const onPreviousScreen = () => {
    if (hasTradingAddress) {
      setHasTradingAddress(false)
      navigate(Navigation_Paths.BUSINESS_DETAILS)
    } else {
      setBusinessName('')
      navigate(Navigation_Paths.PASSWORD)
    }
  }

  const handleBusinessDetails = (str: string) => {
    setBusinessName(str)
    navigate(Navigation_Paths.BUSINESS_DETAILS)
  }

  const handleTradingAddress = () => {
    setHasTradingAddress(true)
    navigate(Navigation_Paths.BUSINESS_ADDRESS)
  }

  const getComponent = () => {
    let component

    if (hasTradingAddress) {
      component = (
        <ConfirmTradingAddress
          title={CONFIRM_TRADING_ADDRESS.TITLE}
          subtitle={CONFIRM_TRADING_ADDRESS.SUBTITLE}
          tradingAddresses={CONFIRM_TRADING_ADDRESS.TRADING_ADRESSES}
          onConfirmAddress={onNextPage}
          saveAddress={(data) => setTradingAddressList(data)}
        />
      )
    } else if (businessName) {
      component = (
        <ConfirmBusinessDetails
          title={CONFIRM_BUSINESS_DETAILS.TITLE}
          subtitle={CONFIRM_BUSINESS_DETAILS.SUBTITLE}
          businessAddress={CONFIRM_BUSINESS_DETAILS.BUSINESS_DETAILS}
          businessName={CONFIRM_BUSINESS_DETAILS.BUSINESS_NAME}
          registrationNumber={CONFIRM_BUSINESS_DETAILS.REGISTRATION_NUMBER}
          registeredAddress={CONFIRM_BUSINESS_DETAILS.REGISTERED_ADDRESS}
          businessNameContent={businessName}
          registrationNumberContent={
            CONFIRM_BUSINESS_DETAILS.REGISTRATION_NUMBER_CONTENT
          }
          registeredAddressContent={Constants.RADIO_TYPOGRAPHY_CONTENT}
          onContinueClick={handleTradingAddress}
          onSaveDetails={(data) => setEditedContent(data)}
        />
      )
    } else {
      component = <SearchBusiness handleSearchNext={handleBusinessDetails} />
    }

    return component
  }

  return (
    <StepperTemplate
      headerImage={
        <MuiIcon src={LOGO} alt="pocketPay-logo" width="103px" height="22px" />
      }
      headerStepper={
        <HorizontalStepper
          data-testid="header-stepper"
          horizontalStepperValues={stepsForBusinessDetails}
          presentValue={1}
        />
      }
      headerClose={
        <MuiIcon src={CLOSE} alt="close-icon" width="103px" height="22px" />
      }
      backButton={
        <IconButton onClick={onPreviousScreen}>
          <ArrowBackIcon />
        </IconButton>
      }
      content={getComponent()}
    />
  )
}
export default BusinessSearchPage
