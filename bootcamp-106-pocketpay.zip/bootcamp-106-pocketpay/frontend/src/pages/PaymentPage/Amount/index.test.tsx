import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import { TRANSFER_HEADING, LABEL_RECEIVE, SEND_LABEL } from 'utils/constants'
import '@testing-library/jest-dom/extend-expect'
import Amount from '.'
import { BrowserRouter } from 'react-router-dom'
import * as Router from 'react-router'

describe('Amount Page', () => {
  let navigateMock = jest.fn()

  beforeEach(() => {
    jest.mock('react-router-dom', () => ({
      ...jest.requireActual('react-router-dom'),
    }))
    jest.spyOn(Router, 'useNavigate').mockImplementation(() => navigateMock)
    render(
      <BrowserRouter>
        <Amount />
      </BrowserRouter>
    )
  })

  test('it should render the page without errors', () => {
    expect(screen.getByText(TRANSFER_HEADING)).toBeInTheDocument()
    const selectedCurrency = screen.getAllByTestId('selected-currency')
    selectedCurrency.forEach((element) => {
      expect(element).toBeInTheDocument()
    })
  })

  test('it should update the amount state correctly', () => {
    const amountInput = screen.getByLabelText(SEND_LABEL) as HTMLInputElement
    fireEvent.change(amountInput, { target: { value: '100' } })
    expect(amountInput.value).toBe('100')
  })

  test('it should update the convertedAmount state correctly when the amount is changed', () => {
    const amountInput = screen.getByLabelText(SEND_LABEL) as HTMLInputElement
    fireEvent.change(amountInput, { target: { value: '100' } })
    expect(screen.getByLabelText(LABEL_RECEIVE)).toHaveValue('100.00')
  })

  test('it should navigate to Transfer option page when "back" button is clicked', () => {
    const backButton = screen.getByTestId('ArrowBackIcon')
    fireEvent.click(backButton)
    expect(navigateMock).toHaveBeenCalledWith('/transfer-options')
  })

  test('it should handle modal open', () => {
    const modalCards = screen.getAllByTestId('modal-click')
    fireEvent.click(modalCards[0])
    expect(modalCards[0]).toBeInTheDocument()
    const okButton = screen.getByText('Ok')

    fireEvent.click(okButton)
    waitFor(() => {
      expect(okButton).toHaveBeenCalledTimes(1)
    })
  })

  test('it should update selectedCurrency1 state correctly when currency is changed', () => {
    const selectedCurrency = screen.getAllByTestId('selected-currency')

    fireEvent.click(selectedCurrency[0])
    const activeEle1 = screen.getByText('INR')
    fireEvent.click(activeEle1)
    fireEvent.click(selectedCurrency[1])
    const activeEle2 = screen.getByText('AUD')
    fireEvent.click(activeEle2)
    expect(selectedCurrency[1]).not.toBeInTheDocument()
  })

  test('it should navigate to /recipient on continue button click', () => {
    const amountInput = screen.getByLabelText(SEND_LABEL) as HTMLInputElement
    fireEvent.change(amountInput, { target: { value: '100' } })

    const continueButton = screen.getByText('Continue')
    expect(continueButton).toBeInTheDocument()

    const clickHandlerMock = jest.fn()
    continueButton.addEventListener('click', clickHandlerMock, { once: true })
    fireEvent.click(continueButton)

    expect(clickHandlerMock).toHaveBeenCalledTimes(1)
    expect(navigateMock).toHaveBeenCalledWith('/recipient', {
      state: {
        transferDetail: {
          amountReceived: '100.00',
          amountSent: '100',
          fromCountry: '',
          guaranteedRate: '1.20048',
          purposeOfPayment: 'Paying for goods or services abroad',
          recipientId: 1,
          status: 'Sending',
          toCountry: '',
          transferNo: '#3227627272',
          userId: 1,
        },
        recipientDetail: {
          email: '',
          accountNumber: '',
          accountType: '',
          firstName: '',
          ifscCode: '',
          lastName: '',
        },
      },
    })
  })
})
