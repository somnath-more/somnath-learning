import Image from 'components/atoms/Image'
import HorizontalStepper from 'components/molecules/Stepper'
import TransferDetailCard from 'components/organisms/TransferDetailCard'
import { StepperTemplate } from 'components/templates/Stepper'
import { Navigation_Paths, stepsForTransactions } from 'utils/constants'
import LOGO from 'public/assets/image/Brand.svg'
import CLOSE from 'public/assets/image/close.svg'
import { useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { IconButton } from '@mui/material'
import ArrowBackIcon from '@mui/icons-material/ArrowBack'

const Amount = () => {
  const navigate = useNavigate()
  const [amountSend, setAmountSend] = useState<string>('')
  const [amountReceive, setAmountReceive] = useState<string>('')
  const [fromCurrency, setFromCurrency] = useState<string>('')
  const [toCurrency, setToCurrency] = useState<string>('')

  const handleAmountSendChange = (newAmount: string) => {
    setAmountSend(newAmount)
  }

  const handleAmountReceiveChange = (newAmount: string) => {
    setAmountReceive(newAmount)
  }

  const handleCurrencyCodeChange = (
    fromCurrency: string,
    toCurrency: string
  ) => {
    setFromCurrency(fromCurrency)
    setToCurrency(toCurrency)
  }

  const onBack = () => {
    navigate(Navigation_Paths.TRANSFEROPTIONS)
  }

  const onContinue = () => {
    let transferDetail = {
      fromCountry: fromCurrency,
      toCountry: toCurrency,
      amountSent: amountSend,
      amountReceived: amountReceive,
      purposeOfPayment: 'Paying for goods or services abroad',
      guaranteedRate: '1.20048',
      status: 'Sending',
      transferNo: '#3227627272',
      userId: 1,
      recipientId: 1,
    }
    let recipientDetail = {
      email: '',
      firstName: '',
      lastName: '',
      accountNumber: '',
      accountType: '',
      ifscCode: '',
    }
    navigate(Navigation_Paths.RECIPIENTS, {
      state: {
        transferDetail: transferDetail,
        recipientDetail: recipientDetail,
      },
    })
  }

  return (
    <StepperTemplate
      headerImage={<Image src={LOGO} alt="logo" width="103px" height="22px" />}
      headerClose={<Image src={CLOSE} alt="logo" width="103px" height="22px" />}
      headerStepper={
        <HorizontalStepper
          horizontalStepperValues={stepsForTransactions}
          presentValue={1}
        />
      }
      backButton={
        <IconButton onClick={onBack}>
          <ArrowBackIcon />
        </IconButton>
      }
      content={
        <TransferDetailCard
          onAmountSendChange={handleAmountSendChange}
          onAmountReceiveChange={handleAmountReceiveChange}
          setFromToCurrencyCode={handleCurrencyCodeChange}
          onContinue={onContinue}
        />
      }
    />
  )
}

export default Amount
