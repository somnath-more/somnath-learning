import MuiTypography from 'components/atoms/Typography'
import theme from 'themes'

const Page404 = () => {
  return (
    <MuiTypography
      children="Error 404 Page not found"
      style={{
        color: theme.palette.Accent.warning,
        marginLeft: '40%',
      }}
    />
  )
}

export default Page404
