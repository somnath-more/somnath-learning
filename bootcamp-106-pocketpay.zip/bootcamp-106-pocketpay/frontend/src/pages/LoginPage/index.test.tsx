import { render, fireEvent, screen } from '@testing-library/react'
import LogInPage from '.'
import { BrowserRouter } from 'react-router-dom'

describe('LogIn Page', () => {
  beforeEach(() => {
    render(
      <BrowserRouter>
        <LogInPage />
      </BrowserRouter>
    )
  })
  test('it should handle input changes', () => {
    const emailInput = screen.getByLabelText('Email') as HTMLInputElement
    const passwordInput = screen.getByLabelText('Password') as HTMLInputElement
    expect(emailInput.value).toBe('')
    expect(passwordInput.value).toBe('')

    fireEvent.change(emailInput, { target: { value: 'test@example.com' } })
    fireEvent.change(passwordInput, { target: { value: 'password123' } })

    expect(emailInput.value).toBe('test@example.com')
    expect(passwordInput.value).toBe('password123')
  })

  test('it should enable the "Log in" button when email and password are valid', () => {
    const emailInput = screen.getByLabelText('Email') as HTMLInputElement
    const passwordInput = screen.getByLabelText('Password') as HTMLInputElement
    const loginButton = screen.getByRole('button', {
      name: 'Log in',
    }) as HTMLButtonElement

    const validEmail = 'user@example.com'
    const validPassword = 'P@ssw0rd!'
    fireEvent.change(emailInput, { target: { value: validEmail } })
    fireEvent.change(passwordInput, { target: { value: validPassword } })

    expect(loginButton).not.toBeDisabled()
  })

  test('it should toggle password visibility using the visibility icon', () => {
    const passwordField = screen.getByLabelText('Password')
    expect(passwordField).toHaveAttribute('type', 'password')

    let visibilityIcon = screen.getByTestId('toggle-password-visibility-icon')
    fireEvent.click(visibilityIcon)
    expect(passwordField).toHaveAttribute('type', 'text')
    visibilityIcon = screen.getByTestId('toggle-password-visibility-icon')
    expect(visibilityIcon).toBeInTheDocument()

    fireEvent.click(visibilityIcon)
    expect(passwordField).toHaveAttribute('type', 'password')
  })

  test('renders logo image', () => {
    const logoImage = screen.getByAltText('logo')
    expect(logoImage).toBeInTheDocument()
    expect(logoImage).toHaveAttribute('width', '103px')
    expect(logoImage).toHaveAttribute('height', '22px')
  })
})
