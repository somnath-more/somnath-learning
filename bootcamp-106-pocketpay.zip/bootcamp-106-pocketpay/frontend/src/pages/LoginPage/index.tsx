import LoginSignUp from 'components/templates/LoginSignup'
import Image from 'components/atoms/Image'
import LOGO from 'public/assets/image/Brand.svg'
import LogIn from 'components/organisms/LogIn'
import { Constants } from 'utils/constants'

const LogInPage = () => {
  return (
    <LoginSignUp
      children={
        <LogIn
          loginHeading={Constants.LOG_IN_HEADING}
          troubleLogin={Constants.TROUBLE_LOGIN}
          loginWith={Constants.LOG_IN_WITH}
        />
      }
      image={<Image src={LOGO} alt="logo" width="103px" height="22px" />}
    />
  )
}

export default LogInPage
