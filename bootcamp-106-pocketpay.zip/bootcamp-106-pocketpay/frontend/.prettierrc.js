module.exports = {
  semi: false,
  trailingComma: 'es5',
  singleQuote: true,
  jsxSingleQuote: false,
  tabWidth: 2,
  endOfLine: 'auto',
}
