import { StyledEngineProvider } from "@mui/styled-engine"
import { ThemeProvider } from "@mui/material"
import theme from "../src/themes/index"
import "./preview.css"

export const parameters = {

  actions: { argTypesRegex: '^on[A-Z].*' },
  controls: {
    matchers: {
      color: /(background|color)$/i,
      date: /Date$/,
    },
  },

}
export const decorators = [
  (Story) => (
    <StyledEngineProvider injectFirst>
      <ThemeProvider theme={theme}>
        <Story />
      </ThemeProvider>
    </StyledEngineProvider>
  ),
]
