package com.pocketpay.apigateway.filter;

import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.http.server.reactive.ServerHttpRequest;


import java.util.List;
import java.util.function.Predicate;

@Component
@NoArgsConstructor
public class RouteValidator {
    public static final List<String> openApiEndpoints = List.of(
            "/user?email={email}",
            "/user/add",
            "/user/token",
            "/eureka"
    );

    public static final Predicate<ServerHttpRequest> isSecured =
            request -> openApiEndpoints
                    .stream()
                    .noneMatch(uri -> request.getURI().getPath().equals(uri))
                    && !request.getQueryParams().containsKey("email");

}
