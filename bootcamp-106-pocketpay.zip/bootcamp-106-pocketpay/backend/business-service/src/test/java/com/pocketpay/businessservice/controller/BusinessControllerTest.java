package com.pocketpay.businessservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pocketpay.businessservice.dto.BusinessDto;
import com.pocketpay.businessservice.dto.ResponseTemplateDto;
import com.pocketpay.businessservice.service.BusinessService;
import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;


import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.hamcrest.Matchers.*;

@WebMvcTest(BusinessController.class)
@RunWith(MockitoJUnitRunner.class)
class BusinessControllerTest {

    @MockBean
    private BusinessService businessService;

    @Autowired
    private MockMvc mockMvc;

    @InjectMocks
    private BusinessController businessController;

    @BeforeEach
    void setUp() {
            MockitoAnnotations.openMocks(this);
        mockMvc= MockMvcBuilders.standaloneSetup(businessController).build();
    }

    @Test
    void testFindAllBusinesses_givenBusinessDto_thenResponseAllBusiness() throws Exception {

        List<BusinessDto> businessList =new ArrayList<>();

        when(businessService.getAllBusiness()).thenReturn(businessList);

        mockMvc.perform(get("/business"))
                .andExpect(status().isOk())
                .andExpect(content().json("[]"));
    }

    @Test
    void testGetBusinessByID_whenGivenId_thenGetBusinessDetailsById() throws Exception {
        BusinessDto sampleBusinessDto ;

        sampleBusinessDto = new BusinessDto();
        sampleBusinessDto.setBusinessId(1);
        sampleBusinessDto.setName("Zentech solutions");

        when(businessService.getBusinessById(1)).thenReturn(sampleBusinessDto);

        mockMvc.perform(get("/business/{id}",1))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name",is("Zentech solutions")));

    }

    @Test
    void testSaveBusiness_whenGivenBusinessDetails_thenSaveBusiness() throws Exception {
        BusinessDto newBusiness = new BusinessDto();
        newBusiness.setBusinessId(1);
        newBusiness.setName("Zentech solutions");

        when(businessService.saveBusiness(newBusiness)).thenReturn(newBusiness);

        mockMvc.perform(post("/business")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(newBusiness)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").exists());
    }

    @Test
    void testGetBusinessWithUsers() throws Exception {
        ResponseTemplateDto responseTemplateVO = new ResponseTemplateDto();

        when(businessService.getBusinessWithUsers(1)).thenReturn(responseTemplateVO);

        mockMvc.perform(get("/business/1/users"))
                .andExpect(status().isOk());
    }

}
