package com.pocketpay.businessservice.service;

import com.pocketpay.businessservice.dto.AddressDto;
import com.pocketpay.businessservice.dto.BusinessDto;
import com.pocketpay.businessservice.dto.ResponseTemplateDto;
import com.pocketpay.businessservice.dto.UserDto;
import com.pocketpay.businessservice.entity.Address;
import com.pocketpay.businessservice.entity.Business;
import com.pocketpay.businessservice.exception.BusinessNotFoundException;
import com.pocketpay.businessservice.repository.BusinessRepository;
import com.pocketpay.businessservice.util.RestTemplateUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;


class BusinessServiceImplTest {

    @Mock
    private BusinessRepository businessRepository;

    @Mock
    private ModelMapper modelMapper;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private BusinessServiceImpl businessService;

    private Business sampleBusiness ;

    private BusinessDto sampleBusinessDto ;

    private AddressDto sampleAddressDto;

    private Address sampleAddress;


    private UserDto sampleUserDto;

    private ResponseTemplateDto sampleResponseTemplateDto;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        List<AddressDto> addressDtoList=new ArrayList<>();
        sampleAddressDto =new AddressDto();
        sampleAddressDto.setAddressId(1);
        sampleAddressDto.setAddress("Hyd");


        List<Address> addressList=new ArrayList<>();
        sampleAddress =new Address();
        sampleAddress.setAddressId(1);
        sampleAddress.setAddress("Hyd");

        List<UserDto> userDtoList=new ArrayList<>();
        sampleUserDto=new UserDto();


        sampleBusiness = new Business();
        sampleBusiness.setBusinessId(1);
        sampleBusiness.setName("Zentech solutions");
        sampleBusiness.setCategory("sample Category");
        sampleBusiness.setRegistrationNumber("12345");
        sampleBusiness.setSubCategory("sample Sub-category");
        sampleBusiness.setSizeOfBusiness("50-100");
        sampleBusiness.setAddress(addressList);


        sampleBusinessDto = new BusinessDto();
        sampleBusinessDto.setBusinessId(1);
        sampleBusinessDto.setName("Zentech solutions");
        sampleBusinessDto.setCategory("sample Category");
        sampleBusinessDto.setRegistrationNumber("12345");
        sampleBusinessDto.setSubCategory("sample Sub-category");
        sampleBusinessDto.setSizeOfBusiness("50-100");
        sampleBusinessDto.setAddress(addressDtoList);

        sampleResponseTemplateDto = new ResponseTemplateDto();
        sampleResponseTemplateDto.setBusinessId(1);
        sampleResponseTemplateDto.setName("Zentech solutions");
        sampleResponseTemplateDto.setCategory("sample Category");
        sampleResponseTemplateDto.setRegistrationNumber("12345");
        sampleResponseTemplateDto.setSubCategory("sample Sub-category");
        sampleResponseTemplateDto.setSizeOfBusiness("50-100");
        sampleResponseTemplateDto.setAddress(addressDtoList);
        sampleResponseTemplateDto.setUsers(userDtoList);
    }

    @Test
    void testFindAllBusiness_whenGetAllBusiness_thenReturnListOfAllBusiness() {
        List<Business> businesses = Collections.singletonList(sampleBusiness);
        when(businessRepository.findAll()).thenReturn(businesses);
        when(modelMapper.map(sampleBusiness, BusinessDto.class)).thenReturn(sampleBusinessDto);

        List<BusinessDto> result = businessService.getAllBusiness();

        assertEquals(1, result.size());
        assertEquals(sampleBusinessDto,result.get(0));

    }

    @Test
    void testGetBusinessById_GivenBusinessId_thenGetBusinessById() {

        when(businessRepository.findById(anyInt())).thenReturn(Optional.of(sampleBusiness));

        when(modelMapper.map(sampleBusiness,BusinessDto.class)).thenReturn(sampleBusinessDto);

        BusinessDto result = businessService.getBusinessById(1);

        assertEquals(sampleBusinessDto,result);
    }

    @Test
    void testSaveBusiness_GivenBusinessDto_thenReturnsBusinessDto() {
        when(modelMapper.map(sampleBusinessDto, Business.class)).thenReturn(sampleBusiness);
        when(businessRepository.save(sampleBusiness)).thenReturn(sampleBusiness);
        when(modelMapper.map(sampleBusiness, BusinessDto.class)).thenReturn(sampleBusinessDto);

        BusinessDto result = businessService.saveBusiness(sampleBusinessDto);

        assertEquals(sampleBusinessDto, result);
    }


    @Test
    void testGetBusinessWithUser_ValidBusinessId_ReturnsResponseTemplateDTO() {
        List<UserDto> users = Collections.singletonList( new UserDto());
        ResponseEntity<List<UserDto>> responseEntity = new ResponseEntity<>(users, HttpStatus.OK);

        when(businessRepository.findById(anyInt())).thenReturn(Optional.of(sampleBusiness));
        when(modelMapper.map(sampleBusiness, ResponseTemplateDto.class)).thenReturn(sampleResponseTemplateDto);

        RestTemplateUtil.initializeRestTemplate(restTemplate);
        when(restTemplate.exchange(eq("http://localhost:9001/user/1"), eq(HttpMethod.GET),
                isNull(), any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity<>(users, HttpStatus.OK));

        ResponseTemplateDto result = businessService.getBusinessWithUsers(1);

        assertEquals(sampleResponseTemplateDto, result);
        assertEquals(users, result.getUsers());
    }

    @Test
    void testGetBusinessById_BusinessNotFound_ThrowsException() {

        when(businessRepository.findById(anyInt())).thenReturn(Optional.empty());

        assertThrows(BusinessNotFoundException.class, () -> businessService.getBusinessById(1));
    }

    @Test
    void testGetBusinessWithUser_BusinessNotFound_ThrowsException() {

        when(businessRepository.findById(anyInt())).thenReturn(Optional.empty());

        assertThrows(BusinessNotFoundException.class, () -> businessService.getBusinessWithUsers(1));
    }

}
