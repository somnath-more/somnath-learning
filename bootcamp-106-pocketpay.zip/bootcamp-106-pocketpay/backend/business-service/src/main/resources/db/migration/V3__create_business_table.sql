CREATE TABLE IF NOT EXISTS `pocketpay_final`.`business` (
  `business_id` int AUTO_INCREMENT PRIMARY KEY,
  `category` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `registration_number` varchar(255) DEFAULT NULL,
  `size_of_business` varchar(255) DEFAULT NULL,
  `sub_category` varchar(255) DEFAULT NULL
);





