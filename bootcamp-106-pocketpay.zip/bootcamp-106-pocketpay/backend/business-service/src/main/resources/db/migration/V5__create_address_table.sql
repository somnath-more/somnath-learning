CREATE TABLE IF NOT EXISTS `pocketpay_final`.`address` (
  `address_id` int AUTO_INCREMENT PRIMARY KEY,
  `business_address` varchar(255) DEFAULT NULL,
  `fk_business_id` int DEFAULT NULL,
  FOREIGN KEY (`fk_business_id`) REFERENCES `pocketpay_final`.`business` (`business_id`)
);
