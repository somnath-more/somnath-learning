package com.pocketpay.businessservice.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.pocketpay.businessservice.Enum.AccountType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserDto {

    private int id;
    private String firstName;
    private String lastName;
    private String email;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-mm-dd", timezone = "UTC")
    private Date dateOfBirth;
    private String phoneNo;
    private String countryOfResidence;
    private String homeAddress;
    private String city;
    private String pinCode;
    private AccountType accountType;
}
