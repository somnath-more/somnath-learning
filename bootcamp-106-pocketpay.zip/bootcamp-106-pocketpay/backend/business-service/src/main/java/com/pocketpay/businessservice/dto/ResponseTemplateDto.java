package com.pocketpay.businessservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseTemplateDto {

    private int businessId;
    private String name;
    private String registrationNumber;
    private String category;
    private String subCategory;
    private String sizeOfBusiness;
    private List<AddressDto> address;
    private List<UserDto> users;

}
