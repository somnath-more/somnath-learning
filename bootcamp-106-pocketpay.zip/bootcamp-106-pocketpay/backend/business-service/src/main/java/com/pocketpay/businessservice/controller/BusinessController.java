package com.pocketpay.businessservice.controller;

import com.pocketpay.businessservice.dto.BusinessDto;
import com.pocketpay.businessservice.dto.ResponseTemplateDto;
import com.pocketpay.businessservice.service.BusinessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/business")
public class BusinessController {

    @Autowired
    private BusinessService businessService;

   @PostMapping
    public ResponseEntity<BusinessDto> saveBusiness(@RequestBody BusinessDto businessDto){
        BusinessDto savedBusiness = businessService.saveBusiness(businessDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedBusiness);
    }

    @GetMapping
    public ResponseEntity<List<BusinessDto>> getAllBusiness(){
       List<BusinessDto> businessDto =businessService.getAllBusiness();
       return ResponseEntity.ok(businessDto);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BusinessDto> getBusinessById(@PathVariable("id") int businessId){
       BusinessDto businessDto =businessService.getBusinessById(businessId);
        return ResponseEntity.ok(businessDto);
    }


    @GetMapping("/{businessId}/users")
    public ResponseEntity<ResponseTemplateDto> getBusinessWithUsers(@PathVariable("businessId") int businessId){
        ResponseTemplateDto responseTemplateDTO =businessService.getBusinessWithUsers(businessId);
        return ResponseEntity.ok(responseTemplateDTO);
    }

}
