package com.pocketpay.businessservice.exception;

public class BusinessNotFoundException extends RuntimeException{

    public BusinessNotFoundException(String message){
        super(message);
    }
}
