package com.pocketpay.businessservice.service;

import com.pocketpay.businessservice.dto.BusinessDto;
import com.pocketpay.businessservice.dto.ResponseTemplateDto;
import com.pocketpay.businessservice.dto.UserDto;
import com.pocketpay.businessservice.entity.Business;
import com.pocketpay.businessservice.exception.BusinessNotFoundException;
import com.pocketpay.businessservice.repository.BusinessRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.pocketpay.businessservice.util.RestTemplateUtil;

import java.util.List;

@Service
public class BusinessServiceImpl implements BusinessService{

    private final ModelMapper modelMapper;

    private BusinessRepository businessRepository;

    @Autowired
    public BusinessServiceImpl(ModelMapper modelMapper, BusinessRepository businessRepository, RestTemplate restTemplate) {
        this.modelMapper = modelMapper;
        this.businessRepository = businessRepository;
        RestTemplateUtil.initializeRestTemplate(restTemplate);
    }


    @Override
    public BusinessDto saveBusiness(BusinessDto businessDto) {
        Business newBusiness = convertDtoToEntity(businessDto);
        return convertEntityToDto(businessRepository.save(newBusiness));
    }


    @Override
    public List<BusinessDto> getAllBusiness() {
        List<Business> businesses =businessRepository.findAll();
        return businesses.stream().map(this::convertEntityToDto).toList();
    }

    @Override
    public BusinessDto getBusinessById(int businessId) {
        return convertEntityToDto(businessRepository.findById(businessId)
                .orElseThrow(()->new BusinessNotFoundException("Did not find Business with id : " + businessId)));
    }

    @Override
    public ResponseTemplateDto getBusinessWithUsers(int businessId) {
        Business business =businessRepository.findById(businessId)
                .orElseThrow(()->new BusinessNotFoundException("Did not find Business with id : " + businessId));

        List<UserDto> users= getUserForBusiness(businessId);

        ResponseTemplateDto responseTemplateDTO =convertToResponseTemplateDTO(business);
        responseTemplateDTO.setUsers(users);

        return responseTemplateDTO;
    }

    private List<UserDto> getUserForBusiness(int businessId) {
        String apiUrl = "http://localhost:9001/user/" + businessId;
        ParameterizedTypeReference<List<UserDto>> responseType = new ParameterizedTypeReference<List<UserDto>>() {};
        return RestTemplateUtil.callApiForList(apiUrl, HttpMethod.GET, responseType);
    }

    private Business convertDtoToEntity(BusinessDto businessDto){
        return modelMapper.map(businessDto, Business.class);
    }

    private BusinessDto convertEntityToDto(Business business){
        return modelMapper.map(business,BusinessDto.class);
    }

    private ResponseTemplateDto convertToResponseTemplateDTO(Business business) {
        return modelMapper.map(business,ResponseTemplateDto.class);
    }

}
