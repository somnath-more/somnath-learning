package com.pocketpay.businessservice.Enum;

public enum AccountType {
    SAVINGS,
    CHECKING
}
