package com.pocketpay.businessservice.service;

import com.pocketpay.businessservice.dto.BusinessDto;
import com.pocketpay.businessservice.dto.ResponseTemplateDto;

import java.util.List;

public interface BusinessService {

    BusinessDto saveBusiness(BusinessDto businessDto);

    List<BusinessDto> getAllBusiness();

    BusinessDto getBusinessById(int businessId);

    ResponseTemplateDto getBusinessWithUsers(int businessId);

}
