package com.pocketpay.businessservice.util;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Collections;
import java.util.List;

public class RestTemplateUtil {
    private static org.springframework.web.client.RestTemplate restTemplate;

    public static void initializeRestTemplate(org.springframework.web.client.RestTemplate restTemplate) {
        RestTemplateUtil.restTemplate = restTemplate;
    }

    public static <T> List<T> callApiForList(String apiUrl, HttpMethod httpMethod, ParameterizedTypeReference<List<T>> responseType) {
        ResponseEntity<List<T>> response = restTemplate.exchange(
                apiUrl,
                httpMethod,
                null,
                responseType
        );

        if (response.getStatusCode() == HttpStatus.OK) {
            return response.getBody();
        } else {
            return Collections.emptyList();
        }
    }
}
