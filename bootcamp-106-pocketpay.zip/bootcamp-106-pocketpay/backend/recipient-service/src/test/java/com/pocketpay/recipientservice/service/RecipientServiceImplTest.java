package com.pocketpay.recipientservice.service;

import com.pocketpay.recipientservice.Enum.AccountType;
import com.pocketpay.recipientservice.dto.RecipientDto;
import com.pocketpay.recipientservice.entity.Recipient;
import com.pocketpay.recipientservice.exception.RecipientNotFoundException;
import com.pocketpay.recipientservice.repository.RecipientRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RecipientServiceImplTest {

    @Mock
    private RecipientRepository recipientRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private RecipientServiceImpl recipientService;

    private Recipient sampleRecipient;
    private RecipientDto sampleRecipientDto;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        sampleRecipient = new Recipient();
        sampleRecipient.setId(1);
        sampleRecipient.setFirstName("John");
        sampleRecipient.setLastName("Doe");

        sampleRecipientDto = new RecipientDto();
        sampleRecipientDto.setId(1);
        sampleRecipientDto.setFirstName("John");
        sampleRecipientDto.setLastName("Doe");
    }

    @Test
    void testGetById_RecipientExists_ReturnsRecipientDto() {
        when(recipientRepository.findById(anyInt())).thenReturn(java.util.Optional.of(sampleRecipient));
        when(modelMapper.map(sampleRecipient, RecipientDto.class)).thenReturn(sampleRecipientDto);

        RecipientDto result = recipientService.getById(1);

        assertEquals(sampleRecipientDto, result);
    }

    @Test
    void testGetById_RecipientNotFound_ThrowsRecipientNotFoundException() {
        when(recipientRepository.findById(anyInt())).thenReturn(java.util.Optional.empty());

        assertThrows(RecipientNotFoundException.class, () -> recipientService.getById(1));
    }

    @Test
    void testFindAll_ReturnsListOfRecipientDto() {
        List<Recipient> sampleRecipientList = Arrays.asList(
                sampleRecipient,
                new Recipient(2, "Alice", "Johnson","","",2L, AccountType.SAVING),
                new Recipient(3, "Bob", "Smith","","",2L, AccountType.CHECKING)
        );

        when(recipientRepository.findAll()).thenReturn(sampleRecipientList);
        when(modelMapper.map(any(Recipient.class), eq(RecipientDto.class)))
                .thenAnswer(invocation -> {
                    Recipient recipient = invocation.getArgument(0);
                    RecipientDto recipientDto = new RecipientDto();
                    recipientDto.setId(recipient.getId());
                    recipientDto.setFirstName(recipient.getFirstName());
                    recipientDto.setLastName(recipient.getLastName());
                    return recipientDto;
                });

        List<RecipientDto> result = recipientService.findAll();

        assertEquals(sampleRecipientList.size(), result.size());
        assertEquals(sampleRecipientDto, result.get(0));
        assertEquals("Alice", result.get(1).getFirstName());
        assertEquals("Bob", result.get(2).getFirstName());
    }
    @Test
    void testAdd_ValidRecipientDto_ReturnsRecipientDto() {
        when(modelMapper.map(sampleRecipientDto, Recipient.class)).thenReturn(sampleRecipient);
        when(recipientRepository.save(sampleRecipient)).thenReturn(sampleRecipient);
        when(modelMapper.map(sampleRecipient, RecipientDto.class)).thenReturn(sampleRecipientDto);

        RecipientDto result = recipientService.add(sampleRecipientDto);

        assertEquals(sampleRecipientDto, result);
    }

    @Test
    void testUpdate_RecipientExists_ReturnsUpdatedRecipientDto() {
        RecipientDto updatedRecipientDto = new RecipientDto();
        updatedRecipientDto.setFirstName("UpdatedFirstName");
        updatedRecipientDto.setLastName("UpdatedLastName");
        Recipient updatedRecipient = new Recipient();
        updatedRecipient.setFirstName("UpdatedFirstName");
        updatedRecipient.setLastName("UpdatedLastName");
        when(recipientRepository.findById(anyInt())).thenReturn(java.util.Optional.of(sampleRecipient));
        when(recipientRepository.save(sampleRecipient)).thenReturn(updatedRecipient);
        when(modelMapper.map(updatedRecipient, RecipientDto.class)).thenReturn(updatedRecipientDto);

        RecipientDto result = recipientService.update(1, updatedRecipientDto);

        assertEquals("UpdatedFirstName", result.getFirstName());
        assertEquals("UpdatedLastName", result.getLastName());
    }

    @Test
    void testUpdate_RecipientNotFound_ThrowsRecipientNotFoundException() {
        when(recipientRepository.findById(anyInt())).thenReturn(Optional.empty());

        try {
            recipientService.update(1, new RecipientDto());
            fail("Expected a RecipientNotFoundException to be thrown");
        } catch (RecipientNotFoundException e) {
            assertEquals("Recipient not found of 1", e.getMessage());
        }
    }
}

