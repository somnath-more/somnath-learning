package com.pocketpay.recipientservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pocketpay.recipientservice.Enum.AccountType;
import com.pocketpay.recipientservice.dto.RecipientDto;
import com.pocketpay.recipientservice.service.RecipientService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class RecipientControllerTest {

    @Mock
    private RecipientService recipientService;

    @InjectMocks
    private RecipientController recipientController;

    private ObjectMapper objectMapper = new ObjectMapper();

    private RecipientDto sampleRecipientDto;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        sampleRecipientDto = new RecipientDto();
        sampleRecipientDto.setId(1);
        sampleRecipientDto.setFirstName("John");
        sampleRecipientDto.setLastName("Doe");
        sampleRecipientDto.setAccountType(AccountType.CHECKING);

    }

    @Test
    void testGetById_ReturnsRecipientDto() {
        int recipientId = 1;
        when(recipientService.getById(recipientId)).thenReturn(sampleRecipientDto);

        ResponseEntity<RecipientDto> responseEntity = recipientController.getById(recipientId);

        assertEquals(sampleRecipientDto, responseEntity.getBody());
    }

    @Test
    void testAdd_ReturnsRecipientDto() throws Exception {
        when(recipientService.add(any(RecipientDto.class))).thenReturn(sampleRecipientDto);

        ResponseEntity<RecipientDto> responseEntity = recipientController.add(sampleRecipientDto);

        assertEquals(sampleRecipientDto, responseEntity.getBody());
    }

    @Test
    void testGetAll_ReturnsListOfRecipientDto() {
        List<RecipientDto> sampleRecipientList = Arrays.asList(
                sampleRecipientDto,
                new RecipientDto(2, "Alice", "Johnson","","",2L, AccountType.SAVING),
                new RecipientDto(3, "Bob", "Smith","","",2L, AccountType.CHECKING)
        );

        when(recipientService.findAll()).thenReturn(sampleRecipientList);

        ResponseEntity<List<RecipientDto>> responseEntity = recipientController.getAll();

        assertEquals(sampleRecipientList, responseEntity.getBody());
    }

    @Test
    void testUpdate_ReturnsUpdatedRecipientDto() {
        int recipientId = 1;
        when(recipientService.update(eq(recipientId), any(RecipientDto.class))).thenReturn(sampleRecipientDto);

        ResponseEntity<RecipientDto> responseEntity = recipientController.update(recipientId, sampleRecipientDto);

        assertEquals(sampleRecipientDto, responseEntity.getBody());
    }
}
