package com.pocketpay.recipientservice.controller;

import com.pocketpay.recipientservice.dto.RecipientDto;
import com.pocketpay.recipientservice.service.RecipientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/recipient")
public class RecipientController {

    private RecipientService recipientService;
    @Autowired
    public RecipientController(RecipientService recipientService){
        this.recipientService = recipientService;
    }

    @GetMapping("/{recipientId}")
    public ResponseEntity<RecipientDto> getById(@PathVariable int recipientId){
        RecipientDto recipientDto = recipientService.getById(recipientId);
        return ResponseEntity.ok(recipientDto);
    }

    @GetMapping
    public ResponseEntity<List<RecipientDto>> getAll(){
        List<RecipientDto> recipientDto = recipientService.findAll();
        return ResponseEntity.ok(recipientDto);
    }

    @PostMapping
    public ResponseEntity<RecipientDto> add(@RequestBody RecipientDto newRecipient){
        RecipientDto recipientDto = recipientService.add(newRecipient);
        return ResponseEntity.ok(recipientDto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<RecipientDto> update(@PathVariable int id, @RequestBody RecipientDto updatedRecipientDto) {
        RecipientDto updatedRecipient = recipientService.update(id, updatedRecipientDto);
        return ResponseEntity.ok(updatedRecipient);
    }
}
