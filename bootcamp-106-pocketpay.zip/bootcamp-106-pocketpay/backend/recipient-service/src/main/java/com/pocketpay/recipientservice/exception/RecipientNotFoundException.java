package com.pocketpay.recipientservice.exception;

public class RecipientNotFoundException extends RuntimeException{
    public RecipientNotFoundException(String message) {
        super(message);
    }
}
