package com.pocketpay.recipientservice.service;

import com.pocketpay.recipientservice.dto.RecipientDto;
import com.pocketpay.recipientservice.entity.Recipient;
import com.pocketpay.recipientservice.exception.RecipientNotFoundException;
import com.pocketpay.recipientservice.repository.RecipientRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecipientServiceImpl implements RecipientService {

    private RecipientRepository recipientRepository;
    private ModelMapper modelMapper;
    @Autowired
    public RecipientServiceImpl(RecipientRepository recipientRepository, ModelMapper modelMapper){
        this.recipientRepository = recipientRepository;
        this.modelMapper = modelMapper;
    }
    @Override
    public RecipientDto getById(int id) {
        Recipient recipient = recipientRepository.findById(id).orElseThrow(()->new RecipientNotFoundException("Recipient not found of "+id));
        return convertToDto(recipient);
    }

    @Override
    public RecipientDto add(RecipientDto newRecipient) {
        Recipient recipient = recipientRepository.save(convertToEntity(newRecipient));
        return convertToDto(recipient);
    }

    @Override
    public RecipientDto update(int id, RecipientDto updatedRecipientDto) {
        Recipient existingRecipient = recipientRepository.findById(id)
                .orElseThrow(() -> new RecipientNotFoundException("Recipient not found of " + id));

        existingRecipient.setFirstName(updatedRecipientDto.getFirstName());
        existingRecipient.setLastName(updatedRecipientDto.getLastName());
        existingRecipient.setAccountNumber(updatedRecipientDto.getAccountNumber());
        existingRecipient.setAccountType(updatedRecipientDto.getAccountType());

        Recipient updatedRecipient = recipientRepository.save(existingRecipient);
        return convertToDto(updatedRecipient);
    }

    @Override
    public List<RecipientDto> findAll() {
        List<Recipient> recipient = recipientRepository.findAll();
        return recipient.stream().map(this::convertToDto).toList();
    }

    private RecipientDto convertToDto(Recipient recipient){
        return modelMapper.map(recipient, RecipientDto.class);
    }

    private Recipient convertToEntity(RecipientDto recipientDto){
        return modelMapper.map(recipientDto, Recipient.class);
    }
}
