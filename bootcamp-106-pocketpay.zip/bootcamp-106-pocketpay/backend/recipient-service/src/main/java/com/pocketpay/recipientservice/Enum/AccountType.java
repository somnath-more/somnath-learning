package com.pocketpay.recipientservice.Enum;

public enum AccountType {
    SAVING,
    CHECKING
}
