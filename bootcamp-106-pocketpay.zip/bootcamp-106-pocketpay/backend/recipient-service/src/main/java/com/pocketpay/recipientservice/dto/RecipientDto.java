package com.pocketpay.recipientservice.dto;

import com.pocketpay.recipientservice.Enum.AccountType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecipientDto {
    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private String ifscCode;
    private long accountNumber;
    private AccountType accountType;
}
