package com.pocketpay.recipientservice.service;

import com.pocketpay.recipientservice.dto.RecipientDto;

import java.util.List;

public interface RecipientService {
    RecipientDto getById(int id);
    RecipientDto add(RecipientDto newRecipient);
    RecipientDto update(int id, RecipientDto updatedRecipientDto);

    List<RecipientDto> findAll();
}
