CREATE TABLE IF NOT EXISTS `pocketpay_final`.`recipient` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NULL,
  `last_name` VARCHAR(45) NULL,
  `email` VARCHAR(45) NULL,
  `account_no` VARCHAR(45) NULL,
  `account_type` ENUM('SAVING', 'CHECKING') NULL,
  `ifsc_code` VARCHAR(45) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;