CREATE TABLE IF NOT EXISTS `pocketpay_final`.`transaction` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `status` VARCHAR(45) NULL,
  `amount_sent` VARCHAR(45) NULL,
  `amount_received` VARCHAR(45) NULL,
  `from_country` VARCHAR(45) NULL,
  `to_country` VARCHAR(45) NULL,
  `purpose_of_payment` VARCHAR(45) NULL,
  `guaranteed_rate` VARCHAR(45) NULL,
  `transfer_no` VARCHAR(45) NULL,
  `user_id` INT NOT NULL,
  PRIMARY KEY (`id`, `user_id`),
  INDEX `fk_transaction_user_idx` (`user_id` ASC) VISIBLE,
  CONSTRAINT `fk_transaction_user`
    FOREIGN KEY (`user_id`)
    REFERENCES `pocketpay_final`.`user` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;