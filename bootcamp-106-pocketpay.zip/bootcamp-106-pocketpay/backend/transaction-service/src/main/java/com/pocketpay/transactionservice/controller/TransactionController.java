package com.pocketpay.transactionservice.controller;

import com.pocketpay.transactionservice.dto.TransactionDTO;
import com.pocketpay.transactionservice.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/transaction")
public class TransactionController {
    @Autowired
    private TransactionService transactionService;
    @GetMapping("/{userId}")
    public List<TransactionDTO> getTransactionsByUserId(@PathVariable Long userId){
        return transactionService.getTransactionsByUserId(userId);
    }
    @GetMapping
    public ResponseEntity<List<TransactionDTO>> getAll(){
        return ResponseEntity.ok(transactionService.getAll());
    }

    @PostMapping
    public ResponseEntity<TransactionDTO> saveTransaction(@RequestHeader("userId")Long userId,@RequestBody TransactionDTO transactionDTO)
    {
        TransactionDTO savedTransaction= transactionService.saveTransaction(userId,transactionDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedTransaction);
    }
    @PutMapping("/{id}")
    public ResponseEntity<TransactionDTO> updateTransaction(@RequestHeader("userId")Long userId,@PathVariable Long id,@RequestBody Map<String,Object> updates){
        TransactionDTO updatedTransactionDTO=transactionService.updateTransactionStatus(id,updates,userId);
        return ResponseEntity.ok(updatedTransactionDTO);
    }
}
