package com.pocketpay.transactionservice.exception;

public class TransactionNotFound extends RuntimeException{
    public TransactionNotFound(String message){super(message);}

}
