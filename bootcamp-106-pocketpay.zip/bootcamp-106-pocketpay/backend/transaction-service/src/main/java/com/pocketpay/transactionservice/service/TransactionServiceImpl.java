package com.pocketpay.transactionservice.service;

import com.pocketpay.transactionservice.dto.TransactionDTO;
import com.pocketpay.transactionservice.entity.Transaction;
import com.pocketpay.transactionservice.exception.PostException;
import com.pocketpay.transactionservice.exception.TransactionNotFound;
import com.pocketpay.transactionservice.repository.TransactionRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class TransactionServiceImpl implements TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;
    private ModelMapper modelMapper;
    public TransactionServiceImpl(){
        modelMapper=new ModelMapper();
    }

    @Override
    public List<TransactionDTO> getTransactionsByUserId(Long userId) {
        List<Transaction> transactions=transactionRepository.findByUserId(userId);
        return transactions.stream().map(this::mapTransactionToDTO).toList();
    }

    @Override
    public TransactionDTO updateTransactionStatus(Long id, Map<String, Object> changeStatus, Long userId) {
        List<TransactionDTO> transactions = getTransactionsByUserId(userId);
        Optional<TransactionDTO> optionalTransaction = transactions.stream().filter(transaction -> transaction.getId().equals(id)).findFirst();
        if (optionalTransaction.isPresent()) {
            Transaction transactionToUpdate = modelMapper.map(optionalTransaction.get(),Transaction.class);
            applyChanges(transactionToUpdate, changeStatus);
            Transaction updatedTransaction = modelMapper.map(transactionToUpdate, Transaction.class);
            updatedTransaction.setUserId(userId);
            return modelMapper.map(transactionRepository.save(updatedTransaction), TransactionDTO.class);
        } else {
            throw new TransactionNotFound("Transaction not found with ID: " + id + " and userId: " + userId);

        }
    }

    @Override
    public TransactionDTO saveTransaction(Long userId,TransactionDTO transactionDTO) {
        try{
            Transaction transaction=modelMapper.map(transactionDTO, Transaction.class);
            transaction.setUserId(userId);
            return modelMapper.map(transactionRepository.save(transaction),TransactionDTO.class);
        }
        catch (Exception e){
            throw new PostException("Transaction cannot be saved"+e.getMessage());
        }
    }

    @Override
    public TransactionDTO getTransactionById(Long id) {
        Optional<Transaction> transaction=transactionRepository.findById(id);
        if(transaction.isEmpty())
        {
            throw new TransactionNotFound("transaction not found");
        }
        return modelMapper.map(transaction,TransactionDTO.class);
    }

    @Override
    public List<TransactionDTO> getAll() {
        return transactionRepository.findAll().stream().map(transaction -> modelMapper.map(transaction,TransactionDTO.class)).toList();
    }

    public TransactionDTO mapTransactionToDTO(Transaction transaction){
        return modelMapper.map(transaction,TransactionDTO.class);
    }
    private void applyChanges(Transaction transaction, Map<String, Object> changeStatus) {
        if (changeStatus.containsKey("status")) {
            transaction.setStatus((String) changeStatus.get("status"));
        }
    }
}
