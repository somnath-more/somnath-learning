package com.pocketpay.transactionservice.service;

import com.pocketpay.transactionservice.dto.TransactionDTO;

import java.util.List;
import java.util.Map;

public interface TransactionService {
    List<TransactionDTO> getTransactionsByUserId(Long userId);
    TransactionDTO updateTransactionStatus(Long id, Map<String,Object> changeStatus, Long userId);
    TransactionDTO saveTransaction(Long userId,TransactionDTO transactionDTO);
    TransactionDTO getTransactionById(Long id);

    List<TransactionDTO> getAll();
}
