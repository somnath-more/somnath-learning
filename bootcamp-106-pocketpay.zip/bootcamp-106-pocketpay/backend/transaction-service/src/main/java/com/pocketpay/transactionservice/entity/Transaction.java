package com.pocketpay.transactionservice.entity;

import jakarta.persistence.*;
import lombok.*;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "transaction")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "status")
    private String status;

    @Column(name = "amount_sent")
    private String amountSent;

    @Column(name = "amount_received")
    private String amountReceived;

    @Column(name = "from_country")
    private String fromCountry;

    @Column(name = "to_country")
    private String toCountry;

    @Column(name = "transfer_no")
    private String transferNo;

    @Column(name = "guaranteed_rate")
    private String guaranteedRate;

    @Column(name = "purpose_of_payment")
    private String purposeOfPayment;

    @Column(name = "user_id")
    private Long userId;
    @Column(name = "recipient_id")
    private Long recipientId;
}
