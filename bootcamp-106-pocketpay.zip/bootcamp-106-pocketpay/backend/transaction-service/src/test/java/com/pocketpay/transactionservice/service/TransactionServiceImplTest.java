package com.pocketpay.transactionservice.service;
import com.pocketpay.transactionservice.dto.TransactionDTO;
import com.pocketpay.transactionservice.entity.Transaction;
import com.pocketpay.transactionservice.exception.PostException;
import com.pocketpay.transactionservice.exception.TransactionNotFound;
import com.pocketpay.transactionservice.repository.TransactionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
class TransactionServiceImplTest {
    @Mock
    private TransactionRepository transactionRepository;
    @InjectMocks
    private TransactionServiceImpl transactionService;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    @Test
    void getTransactionsByUserId_Success() {
        Long userId = 123L;
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(1L,"SUCCESS", "100.0", "90.0", "USD", "EUR", "567465","1.23", "For goods", userId,1L));
        transactions.add(new Transaction(1L,"SUCCESS", "100.0", "90.0", "USD", "EUR", "373663","1.23", "For goods", userId,1L));
        when(transactionRepository.findByUserId(userId)).thenReturn(transactions);
        List<TransactionDTO> result = transactionService.getTransactionsByUserId(userId);
        assertEquals(2, result.size());
        verify(transactionRepository, times(1)).findByUserId(userId);
    }
    @Test
    void updateTransactionStatus_Success() {
        Long userId = 123L;
        Long transactionId = 1L;
        Map<String, Object> updates = new HashMap<>();
        updates.put("status", "PENDING");
        TransactionDTO originalTransactionDTO = new TransactionDTO(1L,"SUCCESS", "100.0", "90.0", "USD", "EUR", "567465","1.23", "For goods", userId,1L);
        Transaction originalTransaction = new Transaction(1L,"SUCCESS", "100.0", "90.0", "USD", "EUR", "567465","1.23", "For goods", userId,1L);
        when(transactionRepository.findByUserId(userId)).thenReturn(Collections.singletonList(originalTransaction));
        when(transactionRepository.save(any(Transaction.class))).thenReturn(originalTransaction);
        TransactionDTO result = transactionService.updateTransactionStatus(transactionId, updates, userId);
        assertEquals("SUCCESS", result.getStatus());
        assertEquals(transactionId, result.getId());
        assertEquals("100.0", result.getAmountSent());
        assertEquals("90.0", result.getAmountReceived());
        assertEquals("USD", result.getFromCountry());
        assertEquals("EUR", result.getToCountry());
//        assertNull(result.getToCountry());
        assertEquals(userId, result.getUserId());
        verify(transactionRepository, times(1)).findByUserId(userId);
        verify(transactionRepository, times(1)).save(any(Transaction.class));
    }
    @Test
    void updateTransactionStatus_TransactionNotFound() {
        Long id = 1L;
        Map<String, Object> updates = new HashMap<>();
        updates.put("status", "PENDING");
        Long userId=12L;
        when(transactionRepository.findById(id)).thenReturn(Optional.empty());
        assertThrows(TransactionNotFound.class, () -> transactionService.updateTransactionStatus(id, updates,userId));
    }
    @Test
    void saveTransaction_Success() {
        Long userId = 123L;
        TransactionDTO transactionDTO = new TransactionDTO();
        transactionDTO.setAmountSent("100.0");
        transactionDTO.setFromCountry("USD");
        transactionDTO.setToCountry("EUR");
        transactionDTO.setStatus("SUCCESS");
        Transaction transaction = new Transaction();
        transaction.setId(1L);
        transaction.setAmountSent("100.0");
        transaction.setFromCountry("USD");
        transaction.setToCountry("EUR");
        transaction.setStatus("SUCCESS");
        transaction.setUserId(userId);
        when(transactionRepository.save(any(Transaction.class))).thenReturn(transaction);
        TransactionDTO resultTransactionDTO = transactionService.saveTransaction(userId, transactionDTO);
        assertNotNull(resultTransactionDTO.getId());
        assertEquals(transactionDTO.getAmountSent(), resultTransactionDTO.getAmountSent());
        assertEquals(transactionDTO.getFromCountry(), resultTransactionDTO.getFromCountry());
        assertEquals(transactionDTO.getToCountry(), resultTransactionDTO.getToCountry());
        assertEquals(transactionDTO.getStatus(), resultTransactionDTO.getStatus());
        assertEquals(userId, resultTransactionDTO.getUserId());
        verify(transactionRepository, times(1)).save(any(Transaction.class));
    }
    @Test
    void saveTransaction_Failure() {
        Long userId = 123L;
        TransactionDTO transactionDTO = new TransactionDTO();
        when(transactionRepository.save(any(Transaction.class))).thenThrow(new PostException("post not done "));
        assertThrows(PostException.class, () -> transactionService.saveTransaction(userId, transactionDTO));
        verify(transactionRepository, times(1)).save(any(Transaction.class));
    }
    @Test
    void getTransactionById_Success() {
        Long id = 1L;
        Long userId=1L;
        Transaction transaction = new Transaction(1L,"SUCCESS", "100.0", "90.0", "USD", "EUR", "567465","1.23", "For goods", userId,1L);

        when(transactionRepository.findById(id)).thenReturn(Optional.of(transaction));
        TransactionDTO result = transactionService.getTransactionById(id);
        assertNotNull(result);
        assertEquals(id, transaction.getId());
        assertEquals("SUCCESS", transaction.getStatus());
        assertEquals("100.0", transaction.getAmountSent());
        assertEquals("90.0", transaction.getAmountReceived());
        assertEquals("USD", transaction.getFromCountry());
        assertEquals("EUR", transaction.getToCountry());
        assertEquals("567465", transaction.getTransferNo());
        assertEquals("1.23", transaction.getGuaranteedRate());
        assertEquals("For goods", transaction.getPurposeOfPayment());
        assertEquals(userId, transaction.getUserId());

        verify(transactionRepository, times(1)).findById(id);
    }
    @Test
    void getTransactionById_TransactionNotFound() {
        Long id = 1L;
        when(transactionRepository.findById(id)).thenReturn(Optional.empty());
        assertThrows(TransactionNotFound.class, () -> transactionService.getTransactionById(id));
        verify(transactionRepository, times(1)).findById(id);
    }

    @Test
    void testGetAll_ReturnsListOfTransactionDTO() {
        List<Transaction> sampleTransactions = List.of(
                new Transaction(1L,"SUCCESS", "100.0", "90.0", "USD", "EUR", "567465","1.23", "For goods", 123L, 1L),
                new Transaction(2L,"SUCCESS", "200.0", "180.0", "EUR", "USD", "987654","1.50", "For services", 456L, 2L)
        );

        when(transactionRepository.findAll()).thenReturn(sampleTransactions);

        List<TransactionDTO> result = transactionService.getAll();

        assertEquals(2, result.size());
    }
}