package com.pocketpay.transactionservice.controller;

import com.pocketpay.transactionservice.dto.TransactionDTO;
import com.pocketpay.transactionservice.service.TransactionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

class TransactionControllerTest {

    @Mock
    private TransactionService transactionService;

    @InjectMocks
    private TransactionController transactionController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetTransactionsByUserId() {
        Long userId = 123L;
        List<TransactionDTO> transactions = new ArrayList<>();
        when(transactionService.getTransactionsByUserId(userId)).thenReturn(transactions);

        List<TransactionDTO> result = transactionController.getTransactionsByUserId(userId);

        assertEquals(transactions, result);
    }

    @Test
    void testGetAll_ReturnsListOfTransactionDTO() {
        List<TransactionDTO> sampleTransactions = Arrays.asList(
                new TransactionDTO(),
                new TransactionDTO(),
                new TransactionDTO()
        );

        when(transactionService.getAll()).thenReturn(sampleTransactions);

        ResponseEntity<List<TransactionDTO>> responseEntity = transactionController.getAll();

        assertEquals(sampleTransactions, responseEntity.getBody());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }

    @Test
    void testSaveTransaction() {
        Long userId = 123L;
        TransactionDTO inputTransactionDTO = new TransactionDTO();
        TransactionDTO savedTransaction = new TransactionDTO();

        when(transactionService.saveTransaction(userId, inputTransactionDTO)).thenReturn(savedTransaction);

        ResponseEntity<TransactionDTO> responseEntity = transactionController.saveTransaction(userId, inputTransactionDTO);

        assertEquals(savedTransaction, responseEntity.getBody());
        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
    }

    @Test
     void testUpdateTransaction() {
        Long userId = 123L;
        Long transactionId = 456L;
        Map<String, Object> updates = new HashMap<>();
        TransactionDTO updatedTransaction = new TransactionDTO();

        when(transactionService.updateTransactionStatus(eq(transactionId), anyMap(), eq(userId))).thenReturn(updatedTransaction);

        ResponseEntity<TransactionDTO> responseEntity = transactionController.updateTransaction(userId, transactionId, updates);

        assertEquals(updatedTransaction, responseEntity.getBody());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }
}
