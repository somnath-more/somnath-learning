package com.pocketpay.userservice.controller;

import com.pocketpay.userservice.config.JwtService;
import com.pocketpay.userservice.dto.Auth;
import com.pocketpay.userservice.dto.ResponseTemplateDTO;
import com.pocketpay.userservice.dto.UserDto;
import com.pocketpay.userservice.service.UserService;
import jakarta.ws.rs.core.MediaType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class UserControllerTest {
    @Mock
    private MockMvc mockMvc;
    @Mock
    private UserService userService;
    @Mock
    private JwtService jwtService;
    @InjectMocks
    private UserController userController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
    }

    @Test
    void testGetAll() {
        List<UserDto> userDtoList = List.of(new UserDto(), new UserDto());

        when(userService.getAll()).thenReturn(userDtoList);

        ResponseEntity<List<UserDto>> responseEntity = userController.getAll();

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(userDtoList, responseEntity.getBody());
        verify(userService, times(1)).getAll();
    }

    @Test
    void testGetById() {
        UserDto userDto = new UserDto();
        int userId = 1;

        when(userService.getById(userId)).thenReturn(userDto);

        ResponseEntity<UserDto> responseEntity = userController.getById(userId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(userDto, responseEntity.getBody());
        verify(userService, times(1)).getById(userId);
    }

    @Test
    void testAdd() {
        UserDto newUser = new UserDto();
        UserDto addedUser = new UserDto();

        when(userService.add(newUser)).thenReturn(addedUser);

        ResponseEntity<UserDto> responseEntity = userController.add(newUser);

        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        assertEquals(addedUser, responseEntity.getBody());
        verify(userService, times(1)).add(newUser);
    }

    @Test
    void testGetUserWithTransactions() {
        ResponseTemplateDTO responseTemplateVO = new ResponseTemplateDTO();
        int userId = 1;

        when(userService.getUserWithTransactions(userId)).thenReturn(responseTemplateVO);

        ResponseEntity<ResponseTemplateDTO> responseEntity = userController.getUserWithTransactions(userId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(responseTemplateVO, responseEntity.getBody());
        verify(userService, times(1)).getUserWithTransactions(userId);
    }

    @Test
    void testGetUserByEmail() throws Exception {

        when(userService.getByEmail(anyString())).thenReturn(new UserDto());

        mockMvc.perform(get("/user").param("email", "test@example.com"))
                .andExpect(status().isOk());
    }
    @Test
    void testValidateToken() {
        String email = "test@gmail.com";
        String generatedToken = "validtoken";
        jwtService.validateToken(generatedToken);
        assertEquals("Token is valid",userController.validateToken(generatedToken));
    }
    @Test
    void testGetToken() throws Exception {
        Auth auth = new Auth("test@example.com", "password123");
        String expectedToken = "test-token";

        when(jwtService.generateToken(auth.getEmail(), auth.getPassword())).thenReturn(expectedToken);

        mockMvc.perform(MockMvcRequestBuilders
                        .post("/user/token")
                        .content("{\"email\":\"test@example.com\",\"password\":\"password123\"}")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(expectedToken));
    }
    @Test
    void testGetTokenWithInvalidCredentials() {
        Auth auth = new Auth(null, null);
        String responseEntity = userController.getToken(auth);
        assertEquals("Not able to generate token", responseEntity);
    }
}
