package com.pocketpay.userservice.service;


import com.pocketpay.userservice.dto.ResponseTemplateDTO;
import com.pocketpay.userservice.dto.TransactionDto;
import com.pocketpay.userservice.dto.UserDto;
import com.pocketpay.userservice.entity.User;
import com.pocketpay.userservice.exception.UserNotFoundException;
import com.pocketpay.userservice.repository.UserRepository;
import com.pocketpay.userservice.util.RestTemplateUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private ModelMapper modelMapper;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private UserServiceImpl userService;

    private User sampleUser;
    private UserDto sampleUserDto;
    private ResponseTemplateDTO sampleResponseTemplateDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        sampleUser = new User();
        sampleUser.setId(1L);
        sampleUser.setFirstName("John");
        sampleUser.setLastName("Doe");
        sampleUser.setEmail("john@example.com");

        sampleUserDto = new UserDto();
        sampleUserDto.setId(1);
        sampleUserDto.setFirstName("John");
        sampleUserDto.setLastName("Doe");
        sampleUserDto.setEmail("john@example.com");

        sampleResponseTemplateDTO = new ResponseTemplateDTO();
        sampleResponseTemplateDTO.setId(1);
        sampleResponseTemplateDTO.setFirstName("John");
        sampleResponseTemplateDTO.setLastName("Doe");
    }

    @Test
    void testGetById_UserExists_ReturnsUserDto() {
        when(userRepository.findById(anyInt())).thenReturn(Optional.of(sampleUser));
        when(modelMapper.map(sampleUser, UserDto.class)).thenReturn(sampleUserDto);

        UserDto result = userService.getById(1);

        assertEquals(sampleUserDto, result);
    }

    @Test
    void testGetById_UserNotFound_ThrowsUserNotFoundException() {
        when(userRepository.findById(anyInt())).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> {
            userService.getById(1);
        });
    }


    @Test
    void testAdd_ValidUserDto_ReturnsUserDto() {
        when(modelMapper.map(sampleUserDto, User.class)).thenReturn(sampleUser);
        when(userRepository.save(sampleUser)).thenReturn(sampleUser);
        when(modelMapper.map(sampleUser, UserDto.class)).thenReturn(sampleUserDto);

        UserDto result = userService.add(sampleUserDto);

        assertEquals(sampleUserDto, result);
    }

    @Test
    void testGetByEmail_UserExists_ReturnsUserDto() {
        String email = "john@example.com";

        when(userRepository.findByEmail(email)).thenReturn(Optional.of(sampleUser));
        when(modelMapper.map(sampleUser, UserDto.class)).thenReturn(sampleUserDto);

        UserDto result = userService.getByEmail(email);

        assertEquals(sampleUserDto, result);
    }

    @Test
    void testGetByEmail_UserNotFound_ThrowsUserNotFoundException() {
        String email = "nonexistent@example.com";

        when(userRepository.findByEmail(email)).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> {
            userService.getByEmail(email);
        });
    }

    @Test
    void testGetAll_ReturnsListOfUserDtos() {
        List<User> users = Collections.singletonList(sampleUser);
        when(userRepository.findAll()).thenReturn(users);
        when(modelMapper.map(sampleUser, UserDto.class)).thenReturn(sampleUserDto);

        List<UserDto> result = userService.getAll();

        assertEquals(1, result.size());
        assertEquals(sampleUserDto, result.get(0));
    }

    @Test
    void testGetUserWithTransactions_ValidUserId_ReturnsResponseTemplateDTO() {
        List<TransactionDto> transactions = Collections.singletonList(new TransactionDto());
        ResponseEntity<List<TransactionDto>> responseEntity = new ResponseEntity<>(transactions, HttpStatus.OK);

        when(userRepository.findById(anyInt())).thenReturn(Optional.of(sampleUser));
        when(modelMapper.map(sampleUser, ResponseTemplateDTO.class)).thenReturn(sampleResponseTemplateDTO);

        RestTemplateUtil.initializeRestTemplate(restTemplate);
        int userId = 1;
        String apiUrl = "https://bc106api.bootcamp64.tk/transaction/" + userId;
        when(restTemplate.exchange(
                eq(apiUrl),
                eq(HttpMethod.GET),
                any(),
                eq(new ParameterizedTypeReference<List<TransactionDto>>() {})))
                .thenReturn(responseEntity);

        ResponseTemplateDTO result = userService.getUserWithTransactions(1);

        assertEquals(sampleResponseTemplateDTO, result);
        assertEquals(transactions, result.getTransactions());
    }


    @Test
    void testGetUserWithTransactions_UserNotFound_ThrowsUserNotFoundException() {
        when(userRepository.findById(anyInt())).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> userService.getUserWithTransactions(1));
    }
}
