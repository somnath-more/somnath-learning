package com.pocketpay.userservice.dto;

import com.pocketpay.userservice.Enum.AccountType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {
    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private Date dateOfBirth;
    private String password;
    private String phone_no;
    private String countryOfResidence;
    private String homeAddress;
    private String city;
    private String pinCode;
    private AccountType accountType;
}
