package com.pocketpay.userservice.controller;

import com.pocketpay.userservice.config.JwtService;
import com.pocketpay.userservice.dto.Auth;
import com.pocketpay.userservice.dto.ResponseTemplateDTO;
import com.pocketpay.userservice.dto.UserDto;
import com.pocketpay.userservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;
    private JwtService jwtService;

    @Autowired
    public UserController(UserService userService, JwtService jwtService) {
        this.userService = userService;
        this.jwtService = jwtService;
    }
    @GetMapping
    public ResponseEntity<List<UserDto>> getAll() {
        List<UserDto> users = userService.getAll();
        return ResponseEntity.ok(users);
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getById(@PathVariable("id") int id) {
        UserDto userDto = userService.getById(id);
        return ResponseEntity.ok(userDto);
    }
    @GetMapping(params = "email")
    public ResponseEntity<UserDto> getByEmail(@RequestParam String email) {
        UserDto userResponse = userService.getByEmail(email);
        return new ResponseEntity<>(userResponse, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<UserDto> add(@RequestBody UserDto newUser) {
        UserDto addedUser = userService.add(newUser);
        return ResponseEntity.status(HttpStatus.CREATED).body(addedUser);
    }

    @GetMapping("/{userId}/transaction")
    public ResponseEntity<ResponseTemplateDTO> getUserWithTransactions(@PathVariable int userId) {
        ResponseTemplateDTO responseTemplateDTO = userService.getUserWithTransactions(userId);
        return ResponseEntity.ok(responseTemplateDTO);
    }

    @PostMapping("/token")
    public String getToken(@RequestBody Auth auth){
        if(auth.getEmail()!=null && auth.getPassword()!=null){
            return jwtService.generateToken(auth.getEmail(), auth.getPassword());
        }else{
            return "Not able to generate token";
        }
    }

    @GetMapping("/validate")
    public String validateToken(@RequestParam("token") String token) {
        jwtService.validateToken(token);
        return "Token is valid";
    }
}
