package com.pocketpay.userservice.service;

import com.pocketpay.userservice.dto.ResponseTemplateDTO;
import com.pocketpay.userservice.dto.UserDto;

import java.util.List;

public interface UserService {
    UserDto getById(int id);
    UserDto add(UserDto newUser);
    List<UserDto> getAll();
    ResponseTemplateDTO getUserWithTransactions(int userId);
    UserDto getByEmail(String email);
}
