package com.pocketpay.userservice.Enum;

public enum AccountType {
    BUSINESS,
    PERSONAL
}
