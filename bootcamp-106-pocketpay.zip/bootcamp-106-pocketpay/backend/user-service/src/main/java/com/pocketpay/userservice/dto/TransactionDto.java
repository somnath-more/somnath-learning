package com.pocketpay.userservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransactionDto {
    private int id;
    private String status;
    private String amountSent;
    private String amountReceived;
    private String fromCountry;
    private String toCountry;
    private String transferNo;
    private String guaranteedRate;
    private String purposeOfPayment;
    private Long userId;
    private Long recipientId;
}
