package com.pocketpay.userservice.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.pocketpay.userservice.Enum.AccountType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Entity
@Getter
@Setter
@Table(name = "user")
@AllArgsConstructor
@NoArgsConstructor
public class User {
    @Column(name = "id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "email")
    private String email;
    @Column(name = "password")
    private String password;
    @Column(name = "date_of_birth")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-mm-dd", timezone = "UTC")
    private Date dateOfBirth;

    @Column(name = "phone_no")
    private String phone_no;

    @Column(name = "country_of_residence")
    private String countryOfResidence;

    @Column(name = "home_address")
    private String homeAddress;

    @Column(name = "city")
    private String city;

    @Column(name = "pin_code")
    private String pinCode;

    @Column(name = "account_type")
    @Enumerated(EnumType.STRING)
    private AccountType accountType;
}
