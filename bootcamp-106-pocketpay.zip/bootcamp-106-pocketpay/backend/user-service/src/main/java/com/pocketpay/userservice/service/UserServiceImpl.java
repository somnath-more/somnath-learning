package com.pocketpay.userservice.service;

import com.pocketpay.userservice.dto.ResponseTemplateDTO;
import com.pocketpay.userservice.dto.TransactionDto;
import com.pocketpay.userservice.dto.UserDto;
import com.pocketpay.userservice.entity.User;
import com.pocketpay.userservice.exception.UserNotFoundException;
import com.pocketpay.userservice.repository.UserRepository;
import com.pocketpay.userservice.util.RestTemplateUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class UserServiceImpl implements UserService{

    private UserRepository userRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, RestTemplate restTemplate){
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        RestTemplateUtil.initializeRestTemplate(restTemplate);
    }

    @Override
    public UserDto getById(int id) {
        return convertToDto(userRepository.findById(id)
                .orElseThrow(()->new UserNotFoundException("user not found of id: "+id)));
    }

    @Override
    public UserDto add(UserDto newUserDto) {
        User newUser=convertToEntity(newUserDto);
        return convertToDto(userRepository.save(newUser));
    }

    @Override
    public List<UserDto> getAll() {
        List<User> users = userRepository.findAll();
        return users.stream().map(this::convertToDto).toList();
    }

    private List<TransactionDto> getTransactionsForUser(int userId) {
        String apiUrl = "https://bc106api.bootcamp64.tk/transaction/" + userId;
        ParameterizedTypeReference<List<TransactionDto>> responseType = new ParameterizedTypeReference<List<TransactionDto>>() {};
        return RestTemplateUtil.callApiForList(apiUrl, HttpMethod.GET, responseType);
    }

    @Override
    public UserDto getByEmail(String email) {
        User user = userRepository.findByEmail(email).orElseThrow(() ->
                new UserNotFoundException("User not found with email: " + email)
        );
        return convertToDto(user);
    }

    @Override
    public ResponseTemplateDTO getUserWithTransactions(int userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " + userId));

        List<TransactionDto> transactions = getTransactionsForUser(userId);

        ResponseTemplateDTO responseTemplateDTO = convertToResponseTemplateDTO(user);
        responseTemplateDTO.setTransactions(transactions);

        return responseTemplateDTO;
    }

    private ResponseTemplateDTO convertToResponseTemplateDTO(User user) {
        return modelMapper.map(user, ResponseTemplateDTO.class);
    }

    private UserDto convertToDto(User user){
        return modelMapper.map(user,UserDto.class);
    }

    private User convertToEntity(UserDto userDto){
        return modelMapper.map(userDto,User.class);
    }
}
