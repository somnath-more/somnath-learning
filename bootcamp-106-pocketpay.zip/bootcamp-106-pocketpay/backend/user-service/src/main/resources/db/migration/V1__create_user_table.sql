CREATE TABLE IF NOT EXISTS `pocketpay_final`.`user` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NULL,
  `last_name` VARCHAR(45) NULL,
  `email` VARCHAR(45) NULL,
  `date_of_birth` VARCHAR(45) NULL,
  `phone_no` VARCHAR(45) NULL,
  `country_of_residence` VARCHAR(45) NULL,
  `home_address` VARCHAR(45) NULL,
  `city` VARCHAR(45) NULL,
  `pin_code` VARCHAR(45) NULL,
  `account_type` ENUM('SAVING', 'CHECKING') NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;