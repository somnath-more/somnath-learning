import React from 'react';
import theme from './themes';
import { ThemeProvider } from '@emotion/react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './pages/Home';
import SignInPage from './pages/SignIn';
import SignUpPage from './pages/Signup';
import { useAuth0 } from '@auth0/auth0-react';
import PDFPage from './pages/PDF';
import { addAuthUser } from './service';
import AuthRoute from './AuthRoute';
import ResetPasswordPage from './pages/ResetPassword';
import CreateNewPasswordPage from './pages/CreateNewPassword';
import PasswordResetConfirmationPage from './pages/PasswordResetConfirmation';
import {
  NAVIGATE_CONFIRM_NEW_PASSWORD,
  NAVIGATE_CREATE_NEW_PASSWORD,
  NAVIGATE_FILE,
  NAVIGATE_HOME,
  NAVIGATE_PDF,
  NAVIGATE_RESET_PASSWORD,
  NAVIGATE_SIGNIN,
  NAVIGATE_SIGNUP
} from './utils/constants';
import FilePage from './pages/FilePage';

const App = () => {
  const { isAuthenticated, user } = useAuth0();

  if (isAuthenticated && user && user.name && user.email) {
    addAuthUser(user.name, user.email, 'Test@1234');
  }

  return (
    <ThemeProvider theme={theme}>
      <Router>
        <Routes>
          <Route path={NAVIGATE_SIGNIN} element={<SignInPage />} />
          <Route path={NAVIGATE_SIGNUP} element={<SignUpPage />} />
          <Route path={NAVIGATE_RESET_PASSWORD} element={<ResetPasswordPage />} />
          <Route path={NAVIGATE_CREATE_NEW_PASSWORD} element={<CreateNewPasswordPage />} />
          <Route path={NAVIGATE_CONFIRM_NEW_PASSWORD} element={<PasswordResetConfirmationPage />} />
          <Route path={NAVIGATE_HOME} element={<Home />} />
          <Route
            path={NAVIGATE_FILE}
            element={
              <AuthRoute>
                <FilePage />
              </AuthRoute>
            }
          />
          <Route
            path={NAVIGATE_PDF}
            element={
              <AuthRoute>
                <PDFPage />
              </AuthRoute>
            }
          />
        </Routes>
      </Router>
    </ThemeProvider>
  );
};
export default App;
