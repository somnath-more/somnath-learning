import { FILE_URL, USER_URL, NOTIFICATION_URL } from '@src/utils/urls';
import axios from 'axios';
import { FileType } from '@src/utils/types';
import {
  formatDate,
  getUserID,
  getUserId,
  sortNotificationsByCreatedTimeDesc
} from '@src/utils/functions';

const BearerToken = {
  headers: {
    Authorization: `Bearer ${JSON.parse(localStorage.getItem('user')!)?.token}`
  }
};

export const fetchUsers = async () => {
  try {
    const response = await axios.get(USER_URL);
    const users = response?.data;
    return users;
  } catch (error) {
    console.error('Error occurred while fetching data:', error);
    throw new Error('Failed to fetch user data');
  }
};

export const fetchUserNotificationCount = async () => {
  try {
    const userID = getUserID();
    const response = await axios.get(USER_URL);
    const users = response?.data;
    const user = users.find((user: { id: number }) => user.id === userID);
    if (user) {
      return user.notificationCount;
    } else {
      throw new Error(`User with ID ${userID} not found`);
    }
  } catch (error) {
    console.error('Error occurred while fetching data:', error);
    throw new Error('Failed to fetch user data');
  }
};

export const updateNotificationCount = async (count: number) => {
  try {
    const userID = getUserID();
    const updatedCount = { notificationCount: count };
    await axios.patch(`${USER_URL}${userID}/update-notification`, updatedCount);
    return true;
  } catch (error) {
    console.error('Error updating user notification count:', error);
    return false;
  }
};

export const fetchFiles = async (userId: number) => {
  try {
    const response = await axios.get(FILE_URL + `user/${userId}`);
    const files = response?.data;
    return files;
  } catch (error) {
    console.error('Error fetching files:', error);
    throw error;
  }
};

export const fetchNotificationData = async () => {
  try {
    const response = await axios.get(NOTIFICATION_URL, BearerToken);
    const notifications = response?.data;

    const sortedNotifications = sortNotificationsByCreatedTimeDesc(notifications);

    if (Array.isArray(sortedNotifications) && sortedNotifications.length > 0) {
      return sortedNotifications;
    } else {
      console.warn('No data available from the server.');
      return [];
    }
  } catch (error) {
    console.error('Error occurred while fetching Notification data:', error);
    throw new Error('Failed to fetch notifications');
  }
};

export const fetchRecentFiles = async (userId: number) => {
  try {
    const response = await axios.get(FILE_URL + `user/${userId}`);
    const allFiles = response?.data;

    if (allFiles && allFiles.length > 0) {
      const currentDate = new Date();
      const fifteenDaysAgo = new Date();
      fifteenDaysAgo.setDate(currentDate.getDate() - 15);

      const filteredFiles = allFiles.filter((file: FileType) => {
        const fileCreatedAt = new Date(file.createdAt);
        return fileCreatedAt >= fifteenDaysAgo;
      });

      return filteredFiles;
    } else {
      return [];
    }
  } catch (error) {
    console.error('Error fetching files:', error);
    throw error;
  }
};

// fetching a file by ID
export const fetchFileById = async (fileId: string) => {
  try {
    const response = await axios.get(FILE_URL + `${fileId}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching file by ID:', error);
    return null;
  }
};

export const uploadLocalFile = async (file: File) => {
  const userId = getUserId();

  try {
    const formData = new FormData();
    formData.append('file', file);
    userId && formData.append('userId', userId.toString());

    const response = await axios.post(FILE_URL, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });

    return response.data;
  } catch (error) {
    console.error('Error occurred while uploading file:', error);
    throw new Error('Failed to upload file');
  }
};

export const uploadGoogleDriveFile = async (fileId: string) => {
  const userId = getUserId();

  try {
    const response = await axios.post(FILE_URL + 'drive', null, {
      params: {
        fileId: fileId,
        userId: userId
      }
    });

    return response.data;
  } catch (error) {
    console.error('Error occurred while uploading Google Drive file:', error);
    throw new Error('Failed to upload Google Drive file');
  }
};

export const AddNotificationData = async (fileName: string, action: string) => {
  try {
    const userID = getUserID();
    const response = await axios.post(
      NOTIFICATION_URL,
      {
        userId: userID,
        filename: fileName,
        action: action,
        createdTime: formatDate(new Date())
      },
      BearerToken
    );

    return response.data;
  } catch (error) {
    console.error('Error occurred while adding data:', error);
    throw new Error('Failed to add data');
  }
};

export const fetchFileByName = async (fileName: string) => {
  try {
    const userId = getUserId();
    const filesResponse = await axios.get(FILE_URL + `user/${userId}`);
    const fileToDelete = filesResponse.data.find(
      (file: { name: string }) => file.name === fileName
    );

    return fileToDelete;
  } catch (error) {
    console.error('Error finding file:', error);
  }
};

export const deleteFileById = async (filename: string) => {
  try {
    const userId = getUserId();
    const filesResponse = await axios.get(FILE_URL + `user/${userId}`);
    const fileToDelete = filesResponse.data.find(
      (file: { name: string }) => file.name === filename
    );
    await axios.delete(`${FILE_URL}/${fileToDelete.id}`);
  } catch (error) {
    console.error('Error deleting file:', error);
  }
};

// checking if the user is authenticated
export const checkUsers = async (email: string, password: string) => {
  try {
    const loginResponse = await axios.post(`${USER_URL}login`, {
      email: email,
      password: password
    });

    const response = await axios.get(`${USER_URL}${email}`);
    const user = response.data;

    if (user && loginResponse) {
      const newUser = {
        name: user.name,
        id: user.id,
        token: loginResponse.data.token
      };
      localStorage.setItem('user', JSON.stringify(newUser));
      return true;
    }

    return false;
  } catch (error) {
    console.error('Error fetching users:', error);
    return false;
  }
};

// adding new user to the database if he/she is not already a user
export const addUser = async (name: string, email: string, password: string) => {
  let existingUser = null;

  try {
    const existingUserResponse = await axios.get(`${USER_URL}${email}`);
    existingUser = existingUserResponse.data;

    if (existingUser.length > 0) {
      return false;
    }
  } catch (error) {
    console.error('Error getting existing user:', error);
  }

  try {
    const userResponse = await axios.post(USER_URL, {
      name: name,
      email: email,
      password: password
    });

    return userResponse.data;
  } catch (error) {
    console.error('Error adding user:', error);
    return false;
  }
};

// adding auth0 user to the database
export const addAuthUser = async (name: string, email: string, password: string) => {
  const userExists = await checkUsers(email, password);

  if (userExists) {
    return true;
  }

  const newUserCreated = await addUser(name, email, password);

  if (newUserCreated) {
    const loginResponse = await axios.post(`${USER_URL}login`, { email, password });
    const response = await axios.get(`${USER_URL}/${email}`);
    const user = response.data;

    if (user) {
      const newUser = {
        name: user.name,
        id: user.id,
        token: loginResponse.data.token
      };
      localStorage.setItem('user', JSON.stringify(newUser));
      return true;
    }
  }

  return false;
};

// verifing is email is present in the database
export const checkEmailPresent = async (email: string) => {
  try {
    const existingUserResponse = await axios.get(`${USER_URL}${email}`);
    const existingUser = existingUserResponse.data;

    return existingUser;
  } catch (error) {
    console.error('Error checking email presence:', error);
    return false;
  }
};

// verifing is email is present in the database
export const updatePassword = async (email: string, newPassword: string) => {
  try {
    const existingUserResponse = await axios.get(`${USER_URL}${email}`);
    const existingUser = existingUserResponse.data;

    if (existingUser.password === newPassword) {
      return false;
    }

    const updatedUser = { password: newPassword };

    await axios.patch(`${USER_URL}${existingUser.id}/reset-password`, updatedUser);

    return true;
  } catch (error) {
    console.error('Error updating password:', error);
    return false;
  }
};

// elastic search api call
export const searchFiles = async (userId: number, keyword: string) => {
  try {
    const response = await axios.get(FILE_URL + '/search', {
      params: {
        keyword: keyword,
        userId: userId
      }
    });

    return response.data;
  } catch (error) {
    console.error('Error occurred while searching files:', error);
    throw new Error('Failed to search files');
  }
};
