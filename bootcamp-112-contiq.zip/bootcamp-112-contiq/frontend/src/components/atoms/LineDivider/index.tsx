import React from 'react';
import { Divider, SxProps, styled } from '@mui/material';
import { Theme } from '@emotion/react';
import theme from '../../../themes';
import TypographyComponent from '../Typography';

export interface LineDividerProps {
  orientation?: 'vertical' | 'horizontal';
  children?: React.ReactNode;
  textAlign?: 'left' | 'right' | 'center';
  sx?: SxProps<Theme>;
  variant?: 'fullWidth' | 'inset' | 'middle';
  light?: boolean;
  dataTestId?: string;
}

const StyledDiv = styled(Divider)({
  color: theme.palette.grays.gray200,
  '& .MuiDivider-wrapper': { paddingLeft: '19.5px', paddingRight: '19.5px' }
});

const LineDivider = (props: LineDividerProps) => {
  const defaultProps: LineDividerProps = {
    orientation: 'horizontal',
    textAlign: 'center',
    variant: 'fullWidth',
    ...props
  };
  return (
    <StyledDiv
      orientation={defaultProps.orientation}
      data-testid="lineDividerComponent"
      light={defaultProps.light}
      textAlign={defaultProps.textAlign}
      variant={defaultProps.variant}>
      <TypographyComponent children="OR" variant="caption1" />
    </StyledDiv>
  );
};

export default LineDivider;
