import React from 'react';
import { screen, render } from '@testing-library/react';
import '@testing-library/jest-dom';
import LineDivider from '.';

describe('test for the line divider component', () => {
  test('should render the line divider', () => {
    render(<LineDivider />);
    const ele = screen.getByTestId('lineDividerComponent');
    expect(ele).toBeInTheDocument();
  });
});
