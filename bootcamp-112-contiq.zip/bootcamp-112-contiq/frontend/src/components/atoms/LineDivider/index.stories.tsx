import React from 'react';
import { StoryObj, Meta } from '@storybook/react';
import LineDivider from '.';

const meta: Meta<typeof LineDivider> = {
  title: 'atoms/lineDivider',
  component: LineDivider,
  argTypes: {
    sx: { control: { type: 'object' } },
    orientation: {
      options: ['horizontal', 'vertical'],
      control: { type: 'radio' }
    },
    variant: {
      options: ['fullWidth', 'inset', 'middle'],
      control: { type: 'select' }
    },
    textAlign: {
      options: ['center', 'left', 'right'],
      control: { type: 'radio' }
    }
  }
};
export default meta;

type story = StoryObj<typeof LineDivider>;

export const InLogin: story = {
  render: () => {
    return (
      <LineDivider light={false} sx={{ width: '356px', color: '#BFC4CD' }}>
        OR
      </LineDivider>
    );
  }
};

export const dashedDivider: story = {
  render: (args) => {
    return (
      <LineDivider
        orientation={args.orientation}
        variant={args.variant}
        textAlign={args.textAlign}
        light={args.light}
        sx={args.sx}>
        {args.children}
      </LineDivider>
    );
  },
  args: {
    sx: {
      height: '50px'
    },
    textAlign: 'left',
    children: '',
    orientation: 'vertical'
  }
};
