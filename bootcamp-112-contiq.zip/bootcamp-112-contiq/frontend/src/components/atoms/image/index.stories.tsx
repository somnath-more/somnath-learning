import ImageComponent from '.';
import type { Meta, StoryObj } from '@storybook/react';
import NoFilesImage from '../../../../public/assets/images/NoFiles.svg';
import PDFImage from '../../../../public/assets/images/DigitalTransformation.svg';
import { NOT_FOUND } from '../../../utils/constants';

const meta = {
  title: 'atoms/Image',
  component: ImageComponent
} satisfies Meta<typeof ImageComponent>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Image: Story = {
  args: {
    imgSrc: NoFilesImage,
    imgAlt: NOT_FOUND,
    sx: { width: '300px', height: '300px' }
  }
};

export const ImageWithBorder: Story = {
  args: {
    imgSrc: PDFImage,
    imgAlt: NOT_FOUND,
    radius: '8px',
    borderWidth: '15px',
    borderColor: '#F4F5F5',
    sx: { width: '258px', height: '160px' }
  }
};
