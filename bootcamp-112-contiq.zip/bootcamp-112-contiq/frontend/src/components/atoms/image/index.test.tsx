import React from 'react';
import ImageComponent from '.';
import { render } from '@testing-library/react';
import NoFilesImage from '../../../../public/assets/images/NoFiles.svg';
import { NOT_FOUND } from '../../../utils/constants';

test('render image', () => {
  const element = render(<ImageComponent imgAlt={NOT_FOUND} imgSrc={NoFilesImage} />);
  expect(element).toBeDefined();
});
