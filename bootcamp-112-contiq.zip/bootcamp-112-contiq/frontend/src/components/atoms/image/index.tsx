import React from 'react';
import { Box } from '@mui/material';
interface ImageProps {
  imgSrc?: string;
  imgAlt?: string;
  testId?: string;
  sx?: object;
  radius?: string;
  borderWidth?: string;
  borderColor?: string;
}

const ImageComponent = ({
  imgSrc,
  imgAlt,
  testId,
  radius,
  borderWidth,
  borderColor,
  sx
}: ImageProps) => {
  const imageStyle = {
    ...sx,
    borderRadius: radius,
    border: `${borderWidth} solid ${borderColor}`
  };
  return <Box component="img" src={imgSrc} alt={imgAlt} style={imageStyle} data-testid={testId} />;
};
export default ImageComponent;
