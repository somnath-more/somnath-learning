import React from 'react';
import ImageComponent from '../image';
import { TextField, InputAdornment, styled, useTheme } from '@mui/material';

interface InputFieldProps {
  startIcon?: string;
  value?: string;
  type?: string;
  placeholder: string;
  handleChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
  sx?: React.CSSProperties;
}

export const StyledInput = styled(TextField)(({ theme }) => ({
  '& .MuiOutlinedInput-root': {
    '& fieldset': {
      borderColor: theme.palette.grays.gray100
    },
    '&:hover fieldset': {
      borderColor: theme.palette.grays.gray100
    },
    '&.Mui-focused fieldset': {
      borderColor: theme.palette.grays.gray100
    }
  },
  '& .MuiOutlinedInput-input': {
    ...theme.typography.body2,
    padding: 0
  },
  '& .MuiInputBase-root': {
    borderRadius: theme.spacing(1),
    background: theme.palette.structuralColor.background1
  }
}));

const InputField = ({ startIcon, placeholder, value, type, handleChange, sx }: InputFieldProps) => {
  const theme = useTheme();

  return (
    <StyledInput
      data-testid="input-field"
      fullWidth
      placeholder={placeholder}
      variant="outlined"
      value={value}
      type={type}
      onChange={handleChange}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            {startIcon && <ImageComponent imgSrc={startIcon} imgAlt="icon" />}
          </InputAdornment>
        )
      }}
      sx={{
        ...sx,
        '& .MuiInputBase-root': {
          color: startIcon ? theme.palette.text.white : theme.palette.text.black
        },
        '& .MuiOutlinedInput-root': {
          padding: startIcon
            ? `${theme.spacing(2.5)} ${theme.spacing(3)}`
            : `${theme.spacing(3)} ${theme.spacing(4)}`
        },
        '& .MuiOutlinedInput-notchedOutline': {
          border: startIcon ? 'none' : undefined
        }
      }}
    />
  );
};

export default InputField;
