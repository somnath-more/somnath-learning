import type { Meta, StoryObj } from '@storybook/react'

import InputField from './index'
import search from '../../../../public/assets/icons/search.svg'

const meta: Meta<typeof InputField> = {
  title: 'atoms/InputField',
  component: InputField,
}

export default meta
type Story = StoryObj<typeof InputField>

export const Basic: Story = {
  args: {
    placeholder: 'john@example.com',
  },
}

export const SearchBar: Story = {
  args: {
    placeholder: 'Search',
    startIcon: search,
  },
}
