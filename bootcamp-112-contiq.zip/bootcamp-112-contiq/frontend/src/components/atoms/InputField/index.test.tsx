import * as React from 'react';
import { render, screen } from '@testing-library/react';
import InputField from './index';
import { ThemeProvider } from '@emotion/react';
import search from '../../../../public/assets/icons/search.svg';
import theme from '../../../themes';

describe('Testing the InputField', () => {
  test('InputField search bar', () => {
    render(
      <ThemeProvider theme={theme}>
        <InputField placeholder="Search cards" value="Airline" startIcon={search} />
      </ThemeProvider>
    );
    const Test = screen.getByTestId('input-field');
    expect(Test).toBeInTheDocument();
  });

  test('InputField basic', () => {
    render(
      <ThemeProvider theme={theme}>
        <InputField value="Airline" placeholder="email" />
      </ThemeProvider>
    );
    const Test = screen.getByTestId('input-field');
    expect(Test).toBeInTheDocument();
  });
});
