import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import Loader from '.';

export default {
  title: 'atoms/Loader',
  component: Loader,
  argTypes: {}
} as Meta;

const Template: StoryFn = (args) => <Loader {...args} />;

export const Default = Template.bind({});
Default.args = {};
