import React, { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';
import theme from '../../../themes';

const Loader = () => {
  const [progress, setProgress] = useState(10);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prevProgress) => (prevProgress >= 100 ? 100 : prevProgress + 10));
    }, 200);
    return () => {
      clearInterval(timer);
    };
  });

  return (
    <Box>
      <LinearProgress
        value={progress}
        variant="determinate"
        sx={{
          height: '8px',
          borderRadius: '5px',
          backgroundColor: '#D7DFE9',
          '& .MuiLinearProgress-bar': {
            backgroundColor: theme.palette.primary.dark
          }
        }}
      />
    </Box>
  );
};

export default Loader;
