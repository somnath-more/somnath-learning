import React from 'react';
import { Box, Button } from '@mui/material';
import { styled } from '@mui/system';
import theme from '@src/themes';

interface IMuiButtonProps {
  text: React.ReactNode;
  endIcon?: React.ReactNode;
  fullWidth?: boolean;
  disabled?: boolean;
  size?: 'small' | 'medium' | 'large';
  startIcon?: React.ReactNode;
  sx?: object;
  variant: 'contained' | 'outlined' | 'text';
  onClick?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  testId?: string;
}

const StyledButton = styled(Button)(({ disabled }) => ({
  '&.MuiButton-root': {
    textTransform: 'none',
    borderRadius: '4px',
    color: '#FFFFFF',
    boxShadow: 'none',
    ':disabled': {
      backgroundColor: theme.palette.primary.light
    },
    '&:hover': {
      backgroundColor: '#9747FF !important'
    }
  },
  '& .MuiButton-startIcon svg, .MuiButton-endIcon svg': {
    display: 'flex',
    placeContent: 'center'
  }
}));

const MuiButton = ({ text, testId, ...props }: IMuiButtonProps) => {
  return (
    <Box>
      <StyledButton {...props} data-testid={testId}>
        {text}
      </StyledButton>
    </Box>
  );
};

export default MuiButton;
