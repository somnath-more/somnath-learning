import type { Meta, StoryObj } from '@storybook/react';
import AddIcon from '../../../../public/assets/icons/addIcon.svg';
import MuiButton from '.';

const meta = {
  title: 'atoms/button',
  component: MuiButton
} satisfies Meta<typeof MuiButton>;

export default meta;
type Story = StoryObj<typeof meta>;

const ButtonProperties={
    backgroundColor: '#9747FF',
}

export const Primary: Story = {
  args: {
    text: 'Add files',
    variant: 'contained',
    sx: { ...ButtonProperties, }
  }
};

export const WithStartIcon: Story = {
  args: {
    text: 'Add files',
    startIcon: <img src={AddIcon} />,
    variant: 'contained',
    sx: { ...ButtonProperties, }
  }
};

export const SignIn: Story = {
  args: {
    text: 'Sign in',
    variant: 'contained',
    sx: { ...ButtonProperties, width: '300px', height: '48px' }
  }
};

export const DisabledButton: Story = {
  args: {
    text: 'Sign in',
    variant: 'contained',
    sx: {...ButtonProperties, width: '350px', height: '50px', color: '#FFFFFF' },
    disabled: true
  }
};
