import React from 'react';
import { StoryFn } from '@storybook/react';
import TypographyComponent from '.';

export default {
  title: 'atoms/Typography',
  component: TypographyComponent
};

const Template: StoryFn<typeof TypographyComponent> = (args) => (
  <TypographyComponent {...args}></TypographyComponent>
);

export const heading1 = Template.bind({});
heading1.args = {
  variant: 'h1',
  children: 'Files'
};

export const heading2 = Template.bind({});
heading2.args = {
  variant: 'h2',
  children: 'Sign In'
};

export const body1 = Template.bind({});
body1.args = {
  variant: 'body1',
  children: 'Email ID'
};

export const caption1 = Template.bind({});
caption1.args = {
  variant: 'overline1',
  children: 'SLIDE 1/5',
  color: '#959596',
};
