import React from 'react';
import { render, screen } from '@testing-library/react';
import TypographyComponent from './index';
import 'jest';
import '@testing-library/jest-dom';

describe('to test the Typography Component', () => {
  it('should render Typography', () => {
    render(<TypographyComponent>Files</TypographyComponent>);

    const typography = screen.getByText('Files');
    expect(typography).toBeInTheDocument();
  });
});
