import React, { ReactNode } from 'react';
import { Typography, TypographyProps } from '@mui/material';

interface TypographyComponentProps extends TypographyProps {
  children?: ReactNode;
}

const TypographyComponent = (props: TypographyComponentProps) => {
  return (
    <Typography variant={props.variant} {...props}>
      {props.children}
    </Typography>
  );
};

export default TypographyComponent;
