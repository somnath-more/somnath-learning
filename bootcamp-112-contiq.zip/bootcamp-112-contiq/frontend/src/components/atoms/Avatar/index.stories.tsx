import { Meta, StoryFn } from '@storybook/react';
import MuiAvatar from '.';
import { AvatarProps } from '.';
import avatar from '../../../../public/assets/images/avatar.svg';
import theme from '../../../themes';
import { AVATAR_ALT_TEXT } from '../../../utils/constants';

export default {
  title: 'Atoms/Avatar',
  component: MuiAvatar
} as Meta;

const Template: StoryFn<AvatarProps> = (args) => <MuiAvatar {...args} />;

export const Avatar = Template.bind({});
Avatar.args = {
  src: avatar,
  alt: AVATAR_ALT_TEXT,
  sx: {
    height: theme.spacing(9),
    width: theme.spacing(9)
  }
};
