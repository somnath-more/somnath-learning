import React from 'react';
import { Avatar, SxProps } from '@mui/material';

export interface AvatarProps {
  src?: string;
  alt?: string;
  sx?: SxProps;
  onClick?: () => void;
}

const MuiAvatar = ({ src, alt, sx, onClick }: AvatarProps) => {
  return <Avatar sx={sx} src={src} alt={alt} onClick={onClick} />;
};

export default MuiAvatar;
