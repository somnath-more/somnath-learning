import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import avatar from '../../../../public/assets/images/avatar.svg';
import MuiAvatar from '.';
import { AVATAR_ALT_TEXT } from '../../../utils/constants';

test('Renders correctly', () => {
  render(<MuiAvatar src={avatar} alt={AVATAR_ALT_TEXT} />);
  const element = screen.getByAltText(AVATAR_ALT_TEXT);
  expect(element).toBeInTheDocument();
});
