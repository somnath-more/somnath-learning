import React from 'react';
import Loader from '../../../../public/assets/images/loader.gif';
import { Grid } from '@mui/material';
import { NOT_FOUND } from '../../../utils/constants';
import ImageComponent from '../image';

const MuiLoader = () => {
  const loaderStyles = {
    width: '30px',
    height: '30px'
  };

  return (
    <Grid item>
      <ImageComponent imgAlt={NOT_FOUND} imgSrc={Loader} sx={loaderStyles} />
    </Grid>
  );
};

export default MuiLoader;