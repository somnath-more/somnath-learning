import React from 'react';
import MuiLoader from '.';
import { render } from '@testing-library/react';

test('render MuiLoader', () => {
  const element = render(<MuiLoader/>);
  expect(element).toBeDefined();
});