import type { Meta, StoryObj } from '@storybook/react';
import MuiRadioButton from '.';
import React from 'react';
import TypographyComponent from '../Typography';
import theme from '../../../themes';
import { SYNCDRIVE, SYNCFOLDER } from '../../../utils/constants';

const meta = {
  title: 'atoms/RadioButton',
  component: MuiRadioButton
} satisfies Meta<typeof MuiRadioButton>;

export default meta;
type Story = StoryObj<typeof meta>;

export const RadioButtonChecked: Story = {
  args: {
    isChecked: true,
    label: SYNCFOLDER,
  }
};

export const RadioButtonUnChecked: Story = {
  args: {
    isChecked: false,
    label: SYNCFOLDER,
  }
};
