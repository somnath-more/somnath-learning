import React from 'react';
import { styled } from '@mui/material/styles';
import { Radio, FormControlLabel, useTheme } from '@mui/material';
import TypographyComponent from '../Typography';

interface RadioButtonProps {
  label?: string;
  isChecked?: boolean;
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
  value?: string;
}

const StyledFormControlLabel = styled(FormControlLabel)(({ theme }) => ({
  '& .MuiTypography-root': {
    paddingLeft: theme.spacing(1.5)
  }
}));

const MuiRadioButton = ({ label, isChecked, onChange, value }: RadioButtonProps) => {
  const theme = useTheme();

  const mainColor = isChecked ? theme.palette.text.white : theme.palette.text.mediumEmphasis;
  const backgroundColor = isChecked ? theme.palette.grays.gray400 : 'transparent';
  const border = isChecked
    ? `1px solid ${theme.palette.text.white}`
    : `1px solid ${theme.palette.text.mediumEmphasis}`;

  return (
    <StyledFormControlLabel
      data-testid="radio-button"
      control={
        <Radio
          style={{
            color: mainColor,
            backgroundColor: backgroundColor,
            borderRadius: '50%',
            width: theme.spacing(5),
            height: theme.spacing(5),
            padding: 0,
            border: border
          }}
          checked={isChecked}
          onChange={onChange}
          value={value}
        />
      }
      label={<TypographyComponent children={label} variant="body1" color={mainColor} />}
    />
  );
};

export default MuiRadioButton;
