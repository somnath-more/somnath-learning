import { fireEvent, render } from '@testing-library/react';
import React from 'react';
import MuiRadioButton from './index';
import { ThemeProvider } from '@emotion/react';
import theme from '../../../themes';

test('render radio button with label', () => {
  const element = render(
    <ThemeProvider theme={theme}>
      <MuiRadioButton label="one" isChecked={true} />
    </ThemeProvider>
  );
  expect(element).toBeDefined();
});

test('check clicking radio button', () => {
  const onChange = jest.fn();
  const { getByRole } = render(
    <ThemeProvider theme={theme}>
      <MuiRadioButton onChange={onChange} />
    </ThemeProvider>
  );
  fireEvent.click(getByRole('radio'));
  expect(onChange).toHaveBeenCalled();
});
