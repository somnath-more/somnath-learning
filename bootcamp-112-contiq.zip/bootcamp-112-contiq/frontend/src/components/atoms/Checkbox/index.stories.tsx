import { Meta, StoryFn } from '@storybook/react';
import CheckboxComponent from '.';
import { CheckboxCostumeProps } from '.';
import theme from '../../../themes';

export default {
  title: 'Atoms/Checkbox',
  component: CheckboxComponent
} as Meta;

const Template: StoryFn<CheckboxCostumeProps> = (args) => <CheckboxComponent {...args} />;

export const Default = Template.bind({});
Default.args = {
  disabled: true
};

export const Custome = Template.bind({});
Custome.args = {
  disabled: false
};
