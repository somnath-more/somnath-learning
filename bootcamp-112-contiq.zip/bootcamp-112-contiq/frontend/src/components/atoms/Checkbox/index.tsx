import React from 'react';
import { Checkbox, SxProps, CheckboxProps, FormControlLabel, styled } from '@mui/material';
import theme from '../../../themes';
import { checkboxClasses } from '@mui/material/Checkbox';
import { CheckBoxOutlineBlankOutlined, CheckBoxOutlined } from '@mui/icons-material';


export interface CheckboxCostumeProps extends CheckboxProps {
  style?: React.CSSProperties;
  sx?: SxProps;
  label?: string;
  onChange?: (event: React.ChangeEvent) => void;
  disabled?: boolean;
  testId?: any;
}

const CheckboxComponent: React.FC<CheckboxCostumeProps> = ({
  style,
  sx,
  label,
  onChange,
  disabled,
  testId
}) => {

  const CustomCheckbox = styled(Checkbox)({
    [`&.${checkboxClasses.colorPrimary}`]: {
      color: disabled ? theme.palette.grays.gray100 : theme.palette.text.white
    }
  });

  return (
    <FormControlLabel
      control={
        <CustomCheckbox
          icon={<CheckBoxOutlineBlankOutlined />}
          checkedIcon={<CheckBoxOutlined />}
          disableRipple
          onChange={onChange}
          style={style}
          sx={sx}
          disabled={disabled}
          data-testid={testId}
        />
      }
      label={label}
    />
  );
};

export default CheckboxComponent;
