import React from 'react';
import { Grid, Box, useTheme } from '@mui/material';
import TypographyComponent from '@components/atoms/Typography';
import InputField from '@components/atoms/InputField';

interface IMuiEmailProps {
  text: string;
  placeholder: string;
  value?: string;
  type?: string;
  handleChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

const InputFieldWithTypography: React.FC<IMuiEmailProps> = ({
  text,
  placeholder,
  value,
  type,
  handleChange
}) => {
  const theme = useTheme();

  return (
    <Box data-testid="input-field-typography">
      <Grid item container spacing={1} alignItems="center">
        <Grid item xs={12}>
          <TypographyComponent variant="body1" children={text} color={theme.palette.text.black} />
        </Grid>
        <Grid item xs={12}>
          <InputField
            placeholder={placeholder}
            handleChange={handleChange}
            value={value}
            type={type}
          />
        </Grid>
      </Grid>
    </Box>
  );
};

export default InputFieldWithTypography;
