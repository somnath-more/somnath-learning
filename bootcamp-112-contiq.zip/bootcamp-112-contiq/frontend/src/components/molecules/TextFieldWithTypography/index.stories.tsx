import type { Meta, StoryObj } from '@storybook/react';
import InputFieldWithTypography from './index';
import React from 'react';
import { EMAIL, EMAIL_PLACEHOLDER, PASSWORD, PASSWORD_PLACEHOLDER } from '@utils/constants';

const meta = {
  title: 'molecules/InputFieldWithTypography',
  component: InputFieldWithTypography
} satisfies Meta<typeof InputFieldWithTypography>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Email: Story = {
  args: {
    text: EMAIL,
    placeholder: EMAIL_PLACEHOLDER
  }
};

export const Password: Story = {
  args: {
    text: PASSWORD,
    placeholder: PASSWORD_PLACEHOLDER
  }
};
