import React from 'react';
import { render, screen } from '@testing-library/react';
import InputFieldWithTypography from './index';
import { ThemeProvider } from '@emotion/react';
import theme from '@src/themes';

describe('InputFieldWithTypography component', () => {
  it('renders the email label and text field', () => {
    render(
      <ThemeProvider theme={theme}>
        <InputFieldWithTypography text={'Email Label'} placeholder={'Enter your email'} />
      </ThemeProvider>
    );
    expect(screen.getByPlaceholderText('Enter your email')).toBeInTheDocument();
  });
});