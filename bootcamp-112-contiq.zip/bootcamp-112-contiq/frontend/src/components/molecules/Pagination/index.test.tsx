import React from 'react';
import PaginationComponent from './index';
import { fireEvent, render, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import theme from '../../../themes/index'

describe('Testing the PaginationComponent', () => {
  test('PaginationComponent', () => {
    render(
      <ThemeProvider theme={theme}>
        <PaginationComponent
          startPage={1}
          endPage={5}
          zoomValue={85}
          handleZoomOut={() => {}}
          handleZoomIn={() => {}}
        />
      </ThemeProvider>
    );
    const Test = screen.getByTestId('pagination-component');
    expect(Test).toBeInTheDocument();

    const zoomIn = screen.getByTestId('zoom-in');
    expect(zoomIn).toBeInTheDocument();
    fireEvent.click(zoomIn);

    const zoomOut = screen.getByTestId('zoom-out');
    expect(zoomOut).toBeInTheDocument();
    fireEvent.click(zoomOut);
  });
});
