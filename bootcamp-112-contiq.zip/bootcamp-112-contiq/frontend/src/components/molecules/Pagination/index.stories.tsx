import type { Meta, StoryObj } from '@storybook/react';

import PaginationComponent from './index';

const meta: Meta<typeof PaginationComponent> = {
  title: 'molecules/PaginationComponent',
  component: PaginationComponent
};

export default meta;
type Story = StoryObj<typeof PaginationComponent>;

export const Basic: Story = {
  args: {
    startPage: 1,
    endPage: 5,
    zoomValue: 85
  }
};
