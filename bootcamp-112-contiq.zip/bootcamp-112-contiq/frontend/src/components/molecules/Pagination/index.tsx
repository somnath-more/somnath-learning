import React from 'react';
import { Box, styled, useTheme } from '@mui/material';
import TypographyComponent from '../../atoms/Typography';
import IconComponent from '../../atoms/Icon';
import minus from '../../../../public/assets/icons/minus.svg';
import plus from '../../../../public/assets/icons/plus.svg';

interface PaginationComponentProps {
  startPage: number;
  endPage: number;
  zoomValue: number;
  handleZoomOut: (zoomValue: number) => void;
  handleZoomIn: (zoomValue: number) => void;
}

const RootBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  background: theme.palette.grays.gray400,
  padding: `${theme.spacing(2)} ${theme.spacing(7.5)}`,
  borderRadius: theme.spacing(2),
  width: theme.spacing(78.5)
}));

const TypoBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  gap: theme.spacing(1)
}));

const ZoomBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(2.5),
  background: theme.palette.grays.gray300,
  padding: `${theme.spacing(1.5)} ${theme.spacing(3)}`,
  borderRadius: theme.spacing(2.5)
}));

const IconBox = styled(Box)({
  cursor: 'pointer'
});

const PaginationComponent = ({
  startPage,
  endPage,
  zoomValue,
  handleZoomOut,
  handleZoomIn
}: PaginationComponentProps) => {
  const theme = useTheme();

  const zoomOut = () => {
    handleZoomOut(zoomValue);
  };
  const zoomIn = () => {
    handleZoomIn(zoomValue);
  };

  return (
    <RootBox data-testid="pagination-component">
      <TypoBox>
        <TypographyComponent
          variant="body1"
          color={theme.palette.text.highEmphasis}
          children={`Page ${startPage} of ${endPage}`}
        />
      </TypoBox>
      <ZoomBox>
        <IconBox data-testid="zoom-out" onClick={zoomOut}>
          <IconComponent src={minus} />
        </IconBox>
        <TypographyComponent
          variant="body1"
          color={theme.palette.text.white}
          children={`${zoomValue} %`}
        />
        <IconBox data-testid="zoom-in" onClick={zoomIn}>
          <IconComponent src={plus} />
        </IconBox>
      </ZoomBox>
    </RootBox>
  );
};

export default PaginationComponent;
