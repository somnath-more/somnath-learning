import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import DropDown from '.';

describe('DropDown', () => {
  test('renders without errors', () => {
    render(
      <DropDown
        menuItems={{ key1: 'Item 1', key2: 'Item 2' }}
        placeholder="Select an item"
        label="Select Label"
      />
    );
  });

  test('updates the value when an item is selected', () => {
    const { getByRole, getByText, getByAltText } = render(
      <DropDown
        menuItems={{ key1: 'Item 1', key2: 'Item 2' }}
        placeholder="Select an item"
        label="Select Label"
      />
    );
    const selectButton = getByRole('button', { name: 'Select an item' });
    fireEvent.mouseDown(selectButton);

    const item1 = getByText('Item 1');
    fireEvent.click(item1);

    expect(selectButton.textContent).toBe('Item 1');
    const closeIcon = getByAltText('not found close image');
    expect(closeIcon).toBeInTheDocument();
    fireEvent.click(closeIcon);
  });
});
