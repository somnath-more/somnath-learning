import React, { useState } from 'react';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { Divider, styled } from '@mui/material';
import CloseIcon from '../../../../public/assets/icons/close.svg';
import UpArrow from '../../../../public/assets/icons/uparrow.svg';
import DownArrow from '../../../../public/assets/icons/downarrow.svg';
import TypographyComponent from '../../atoms/Typography';
import theme from '../../../themes';
import { CLOSE_NOT_FOUND, NOT_FOUND } from '../../../utils/constants';

const StyledSelect = styled(Select)`
  && {
    height: 36px;
    width: fit-content;
    border-radius: 4px;
    padding-left: 0px !important;
    padding-right: 5px !important;
    .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
      padding-right: 12px !important;
    }
    border: ${({ value }) =>
      value === '' ? `1px solid ${theme.palette.grays.gray100}` : `1px solid #BFBFBF`};
    & .MuiOutlinedInput-notchedOutline {
      border-color: transparent;
    }
    &:hover .MuiOutlinedInput-notchedOutline {
      border-color: transparent;
    }
    &.Mui-focused .MuiOutlinedInput-notchedOutline {
      border-color: transparent;
    }
    background-color: ${({ value }) =>
      value ? theme.palette.primary.light : theme.palette.text.white};
  }
`;

export interface IMenuItem {
  [key: string]: string;
}

type SelectLabelsProps = {
  menuItems: IMenuItem;
  placeholder: string;
  label: string;
};
const DropDown: React.FC<SelectLabelsProps> = ({ menuItems, placeholder, label }) => {
  const [value, setValue] = useState('');

  const handleChange = (event: any) => {
    setValue(event.target.value);
  };

  const [isOpen, setIsOpen] = useState(false);

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const handleReset = () => {
    setValue('');
  };

  const renderIcon = () => {
    if (value !== '' && !isOpen) {
      return (
        <img
          src={CloseIcon}
          alt={CLOSE_NOT_FOUND}
          style={{ cursor: 'pointer' }}
          onClick={handleReset}
        />
      );
    } else if (isOpen) {
      return <img src={UpArrow} alt={NOT_FOUND} style={{ cursor: 'pointer' }} />;
    } else {
      return <img src={DownArrow} alt={NOT_FOUND} style={{ cursor: 'pointer' }} />;
    }
  };
  const paperStyle = {
    backgroundColor: theme.palette.text.black,
    color: theme.palette.text.white,
    width: '259px',
    marginTop: '8px',
    boxShadow: 'none'
  };
  return (
    <div>
      <FormControl>
        <StyledSelect
          value={value}
          displayEmpty
          data-testid="select"
          onChange={handleChange}
          onOpen={toggleDropdown}
          onClose={toggleDropdown}
          MenuProps={{
            PaperProps: {
              style: paperStyle
            },
            anchorOrigin: {
              vertical: "bottom",
              horizontal: "left",
            },
            transformOrigin: {
              vertical: "top",
              horizontal: "left",
            },
          }}
          IconComponent={() => renderIcon()}>
          <MenuItem value="" disabled style={{ display: 'none' }}>
            <TypographyComponent variant="body1" children={placeholder} />
          </MenuItem>
          <MenuItem style={{ pointerEvents: 'none' }}>
            <TypographyComponent variant="body1" children={label} />
          </MenuItem>
          <Divider sx={{ backgroundColor: 'grey' }} />
          {Object.entries(menuItems).map(([key, value]) => (
            <MenuItem key={key} value={key}>
              <TypographyComponent variant="body1" children={value} />
            </MenuItem>
          ))}
        </StyledSelect>
      </FormControl>
    </div>
  );
};

export default DropDown;
