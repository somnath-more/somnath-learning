import type { Meta, StoryObj } from '@storybook/react';
import DropDown from '.';
import {
  FILE_ITEM1,
  FILE_ITEM2,
  FILE_ITEM3,
  FILE_TYPE,
  PUBLISH_ITEM1,
  PUBLISH_ITEM2,
  PUBLISH_ITEM3,
  PUBLISH_LABEL,
  PUBLISH_PLACEHOLDER
} from '../../../utils/constants';

const meta = {
  title: 'molecules/DropDown',
  component: DropDown
} satisfies Meta<typeof DropDown>;

export default meta;
type Story = StoryObj<typeof meta>;

export const FileType: Story = {
  args: {
    placeholder: FILE_TYPE,
    label: FILE_TYPE,
    menuItems: {
      item1: FILE_ITEM1,
      item2: FILE_ITEM2,
      item3: FILE_ITEM3
    }
  }
};
export const PublishSetting: Story = {
  args: {
    placeholder: PUBLISH_PLACEHOLDER,
    label: PUBLISH_LABEL,
    menuItems: {
      item1: PUBLISH_ITEM1,
      item2: PUBLISH_ITEM2,
      item3: PUBLISH_ITEM3
    }
  }
};
