import { Meta, StoryFn } from '@storybook/react';
import IconWithTypography from '.';
import { IconWithTypographyProps } from '.';
import { SIDE_BAR_LABELS } from '../../../utils/constants';
import HomeIcon from '../../../../public/assets/icons/Home.svg';
import FileIcon from '../../../../public/assets/icons/Files.svg';
import theme from '../../../themes';

export default {
  title: 'Molecules/IconWithTypography',
  component: IconWithTypography
} as Meta;

const Template: StoryFn<IconWithTypographyProps> = (args) => <IconWithTypography {...args} />;

export const Home = Template.bind({});
Home.args = {
  iconSrc: HomeIcon,
  text: SIDE_BAR_LABELS[0],
  textColor: theme.palette.grays.gray200
};

export const File = Template.bind({});
File.args = {
  iconSrc: FileIcon,
  text: SIDE_BAR_LABELS[4],
  textColor: theme.palette.grays.gray200
};
