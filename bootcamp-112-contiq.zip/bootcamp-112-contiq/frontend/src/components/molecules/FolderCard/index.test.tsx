import { render, screen } from "@testing-library/react";
import React from "react";
import FolderCard from ".";
import "@testing-library/jest-dom";

test("render folder variant", () => {
  const element = render(<FolderCard folderName="Zemoso decks" />);
  expect(element).toBeDefined();
  expect(
    screen.queryByTestId("ArrowForwardIosOutlinedIcon")
  ).toBeInTheDocument();
  expect(screen.queryByText("Zemoso decks")).toBeInTheDocument();
});
test("render file variant", () => {
  const element = render(
    <FolderCard folderName="Company overview" isFile={true} isChecked={true}/>
  );
  expect(element).toBeDefined();
  expect(screen.getByRole("checkbox")).toBeInTheDocument();
  expect(
    screen.queryByTestId("ArrowForwardIosOutlinedIcon")
  ).not.toBeInTheDocument();
});
