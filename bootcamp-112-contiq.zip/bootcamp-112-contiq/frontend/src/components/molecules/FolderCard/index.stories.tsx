import FolderCard from '.';
import type { Meta, StoryObj } from '@storybook/react';

const meta = {
  title: 'molecules/FolderCard',
  component: FolderCard
} satisfies Meta<typeof FolderCard>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Folder: Story = {
  args: {
    folderName: 'Zemoso docs'
  }
};

export const File1: Story = {
  args: {
    folderName: 'Sample data',
    isFile: true,
  }
};

export const File2: Story = {
  args: {
    folderName: 'Company overview',
    isFile: true,
    isChecked: true
  }
};
