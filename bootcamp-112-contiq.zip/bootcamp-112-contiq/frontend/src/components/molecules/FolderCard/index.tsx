import {
  ArrowForwardIosOutlined,
  CheckBoxOutlineBlankOutlined,
  CheckBoxOutlined,
  FolderOutlined,
  InsertDriveFileOutlined
} from '@mui/icons-material';
import React from 'react';
import { Checkbox, styled } from '@mui/material';
import { checkboxClasses } from '@mui/material/Checkbox';
import TypographyComponent from '../../atoms/Typography';
import theme from '../../../themes';

type Props = {
  folderName: string;
  isFile?: boolean;
  onClick?: () => void;
  onchange?: () => void;
  isChecked?: boolean;
};

const FolderCard = (props: Props) => {
  const { folderName, isFile = false, onClick, onchange, isChecked } = props;

  const CustomCheckbox = styled(Checkbox)({
    [`&.${checkboxClasses.colorPrimary}`]: {
      color: isChecked ? theme.palette.text.white : theme.palette.grays.gray100
    }
  });

  const CardWrapper = styled('div')({
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '12px 16px',
    background: theme.palette.grays.gray400,
    border: `1px solid ${theme.palette.grays.gray300}`,
    borderRadius: '4px',
    color: theme.palette.text.white,
    width: '100%'
  });
  const IconWrapper = styled('div')({
    background: theme.palette.grays.gray300,
    border: `1px solid ${theme.palette.grays.gray100}`,
    borderRadius: '8px',
    padding: '12px 16px'
  });
  const FolderWrapper = styled('div')({
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
    cursor: 'pointer'
  });
  const FileWrapper = styled('div')({
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
    paddingLeft: '15px'
  });

  return (
    <CardWrapper data-testid="folder-card">
      {isFile ? (
        <FileWrapper>
          <CustomCheckbox
            icon={<CheckBoxOutlineBlankOutlined />}
            checkedIcon={<CheckBoxOutlined />}
            onChange={onchange}
            disableRipple
            checked={isChecked}
          />
          <IconWrapper>
            <InsertDriveFileOutlined />
          </IconWrapper>
          <TypographyComponent variant="body1" children={folderName} />
        </FileWrapper>
      ) : (
        <>
          <FolderWrapper onClick={onClick}>
            <IconWrapper>
              <FolderOutlined />
            </IconWrapper>
            <TypographyComponent variant="body1" children={folderName} />
          </FolderWrapper>
          <ArrowForwardIosOutlined />
        </>
      )}
    </CardWrapper>
  );
};

export default FolderCard;
