import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import ProgressBarModal, { ProgressBarModalProps } from '.';

export default {
  title: 'molecules/ProgressBarModal',
  component: ProgressBarModal,
} as Meta;

const Template: StoryFn<ProgressBarModalProps> = (args) => <ProgressBarModal {...args} />;

export const ProgressBar = Template.bind({});
ProgressBar.args = {
  fileName: 'Contract agreement.pdf',
  onClose: () => {
    console.log('Modal closed.');
  },
};
