import React from 'react';
import { render, screen } from '@testing-library/react';
import ProgressBarModal from '.';

describe('ProgressBarModal', () => {
    const defaultProps = {
      fileName: 'example.pdf',
    };
  
    it('should not render the closeButton for loader variant', () => {
      render(<ProgressBarModal fileName='example.pdf'/>);
      
      expect(screen.queryByRole('img', { name: 'Close' })).toBeNull();
    });
  
  });