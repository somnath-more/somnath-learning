import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import theme from '../../../themes';
import MuiTabs, { MuiTabsProps } from '.';

export default {
  title: 'molecules/MuiTabs',
  component: MuiTabs
} as Meta;

const Template: StoryFn<MuiTabsProps> = (args) => <MuiTabs {...args} />;

export const StandardVariant = Template.bind({});
StandardVariant.args = {
  variant: 'standard',
  tabNames: ['All files', 'Slides', 'Docs'],
  selectedColor: theme.palette.primary.main,
  backgroundColor: theme.palette.text.white,
  notSelectedColor: theme.palette.text.mediumEmphasis,
  borderBottom: `1px solid ${theme.palette.grays.gray600}`,
  isTabDisabled: true,
  selectedTab: 'All files',
  onSelectTab: (tabName) => {
    console.log(`Selected tab: ${tabName}`);
  }
};

export const FullWidthVariant = Template.bind({});
FullWidthVariant.args = {
  variant: 'fullWidth',
  tabNames: ['Uploads', 'Cloud storage'],
  selectedColor: theme.palette.text.white,
  backgroundColor: theme.palette.grays.gray400,
  notSelectedColor: theme.palette.text.mediumEmphasis,
  borderBottom: `2px solid ${theme.palette.grays.gray200}`,
  isTabDisabled: false,
  selectedTab: 'Uploads',
  onSelectTab: (tabName) => {
    console.log(`Selected tab: ${tabName}`);
  }
};
