import type { Meta, StoryObj } from '@storybook/react';

import ImageWithTypography from './index';
import NoFile from '../../../../public/assets/images/NoFiles.svg';
import { NO_FILES, START_SYNC_CONTIQ } from '../../../utils/constants';

const meta: Meta<typeof ImageWithTypography> = {
  title: 'molecules/ImageWithTypography',
  component: ImageWithTypography
};

export default meta;
type Story = StoryObj<typeof ImageWithTypography>;

export const Basic: Story = {
  args: {
    image: NoFile,
    heading: NO_FILES,
    value: START_SYNC_CONTIQ
  }
};
