import { Box, styled, useTheme } from '@mui/material';
import React from 'react';
import ImageComponent from '../../atoms/image';
import TypographyComponent from '../../atoms/Typography';

interface ImageWithTypographyProps {
  image: string;
  heading: string;
  value: string;
}

const RootBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  width: theme.spacing(85),
  gap: theme.spacing(3),
  alignItems: 'center'
}));

const TypoBox = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center'
});

const ImageWithTypography = ({ image, heading, value }: ImageWithTypographyProps) => {
  const theme = useTheme();

  return (
    <RootBox data-testid="image-typography">
      <ImageComponent imgSrc={image} imgAlt={heading} />
      <TypoBox>
        <TypographyComponent
          variant="subtitle1"
          color={theme.palette.text.black}
          children={heading}
        />
        <TypographyComponent
          variant="body2"
          color={theme.palette.text.lowEmphasis}
          children={value}
        />
      </TypoBox>
    </RootBox>
  );
};

export default ImageWithTypography;
