import React from 'react';
import ImageWithTypography from './index';
import { render, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import NoFile from '../../../../public/assets/images/NoFiles.svg';
import theme from '../../../themes';
import { NO_FILES, START_SYNC_CONTIQ } from '../../../utils/constants';

describe('Testing the ImageWithTypography', () => {
  test('ImageWithTypography', () => {
    render(
      <ThemeProvider theme={theme}>
        <ImageWithTypography image={NoFile} heading={NO_FILES} value={START_SYNC_CONTIQ} />
      </ThemeProvider>
    );
    const Test = screen.getByTestId('image-typography');
    expect(Test).toBeInTheDocument();
  });
});
