import type { Meta, StoryObj } from '@storybook/react';

import RadioButtonGroup from './index';
import { RADIO_BUTTON_GROUP } from '../../../utils/constants';

const meta: Meta<typeof RadioButtonGroup> = {
  title: 'molecules/RadioButtonGroup',
  component: RadioButtonGroup
};

export default meta;
type Story = StoryObj<typeof RadioButtonGroup>;

export const Basic: Story = {
  args: {
    radioButtons: RADIO_BUTTON_GROUP
  }
};
