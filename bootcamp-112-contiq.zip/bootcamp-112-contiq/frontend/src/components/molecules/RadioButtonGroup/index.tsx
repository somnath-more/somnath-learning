import { Box, styled } from '@mui/material';
import React from 'react';
import MuiRadioButton from '../../atoms/radioButton';
import { RadioButtons } from '../../../utils/types';

interface RadioButtonGroupProps {
  radioButtons: RadioButtons[];
}

const RadioBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  gap: theme.spacing(4)
}));

const RadioButtonGroup = ({ radioButtons }: RadioButtonGroupProps) => {
  return (
    <RadioBox data-testid="radio-btn-grp">
      {radioButtons.map((item: RadioButtons) => {
        return (
          <MuiRadioButton
            key={item.label}
            label={item.label}
            isChecked={item.isChecked}
            value={item.label}
          />
        );
      })}
    </RadioBox>
  );
};

export default RadioButtonGroup;
