import React from 'react';
import RadioButtonGroup from './index';
import { render, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import theme from '../../../themes';
import { RADIO_BUTTON_GROUP } from '../../../utils/constants';

describe('Testing the RadioButtonGroup', () => {
  test('RadioButtonGroup', () => {
    render(
      <ThemeProvider theme={theme}>
        <RadioButtonGroup radioButtons={RADIO_BUTTON_GROUP} />
      </ThemeProvider>
    );
    const Test = screen.getByTestId('radio-btn-grp');
    expect(Test).toBeInTheDocument();
  });
});
