import { styled } from '@mui/system';
import React from 'react';
import MuiAvatar from '../../atoms/Avatar';
import TypographyComponent from '../../atoms/Typography';
import theme from '../../../themes';

const MainContainer = styled('div')({
  padding: '12px',
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  gap: '12px',
  backgroundColor: theme.palette.structuralColor.background1,
  Width: '420px'
});

const DetailContainer = styled('div')({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'flex-start',
  flexDirection: 'column'
});

const InfoContainer = styled('div')({
  display: 'flex',
  alignItems: 'center',
  gap: '4px',
  alignSelf: 'stretch',
  maxWidth: '290px'
});

const Paragraph = styled('p')({
  fontFamily: 'Manrope',
  fontSize: '14px',
  fontWeight: '600',
  color: theme.palette.text.black,
  margin: '0px'
});

const Span = styled('span')({
  fontFamily: 'Manrope',
  fontSize: '14px',
  fontWeight: '400',
  lineHeight: '22px',
  color: theme.palette.text.lowEmphasis
});
export interface INotificationProps {
 file_name: string;
 user_action:string;
  dateTime: string;
  avatarSrc: string;
  avatarAlt: string;
  name: string;
}

const Notification = ({file_name, user_action,dateTime, avatarSrc, avatarAlt, name }: INotificationProps) => {
  return (
    <MainContainer>
      <MuiAvatar src={avatarSrc} alt={avatarAlt} />
      <DetailContainer>
        <InfoContainer>
          <Paragraph>
            {name}
            <Span>{` has ${user_action.toLowerCase()} ${file_name}`}</Span>
          </Paragraph>
        </InfoContainer>
        <TypographyComponent
          children={dateTime}
          style={{ color: theme.palette.text.mediumEmphasis }}
          variant="caption1"
        />
      </DetailContainer>
    </MainContainer>
  );
};

export default Notification;
