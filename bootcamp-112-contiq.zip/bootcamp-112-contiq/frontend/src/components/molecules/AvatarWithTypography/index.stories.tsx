import React from 'react';
import { Meta, Story } from '@storybook/react';
import Notification, { INotificationProps } from '.';
import avatar from '../../../../public/assets/images/avatar.svg';

export default {
  title: 'Molecules/Notification',
  component: Notification
} as Meta;

const Template: Story<INotificationProps> = (args) => <Notification {...args} />;

export const Default = Template.bind({});
Default.args = {
  file_name: 'company agreement.pdf',
  user_action: 'UPLOAD',
  dateTime: '20 June 10:30 AM',
  avatarSrc: avatar,
  avatarAlt: 'Avatar Alt Text',
  name: 'Vamsi'
};
