import React from 'react';
import { render } from '@testing-library/react';
import Notification from '.';
import { Avatarprops } from '../../../utils/constants';

describe('Notification component', () => {

  it('renders the notification with correct Avatarprops', () => {
    const { getByText, getByAltText } = render(<Notification {...Avatarprops} />);
    const dateElement = getByText(Avatarprops.dateTime);
    const avatarElement = getByAltText(Avatarprops.avatarAlt);

    expect(dateElement).toBeInTheDocument();
    expect(avatarElement).toBeInTheDocument();
  });
});
