import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import { SearchDataProp } from './index';
import SearchCard from './index';
import { FILE_DATA } from '@src/utils/constants';

export default {
  title: 'molecules/SearchCard',
  component: SearchCard
};

const Template: StoryFn<SearchDataProp> = (args) => <SearchCard {...args} />;

export const Default = Template.bind({});
Default.args = {
  data: FILE_DATA
};
