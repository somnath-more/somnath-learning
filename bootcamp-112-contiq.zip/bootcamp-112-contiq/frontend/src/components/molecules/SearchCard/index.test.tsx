import React from 'react';
import { fireEvent, render } from '@testing-library/react';
import SearchCard from './index';

const fileData = [
  {
    id: '8Bg9aYoBhziX7cUbFmqj',
    userId: 3,
    name: 'Company agreement.pdf',
    type: 'application/pdf',
    path: './file-service/uploads/3/TheY.M.C.A.BoysonBassIslandProjectGutenberg.pdf',
    content: 'content',
    createdAt: 1693982724923
  }
];

describe('SearchCard Component', () => {
  it('should render without errors for empty data', () => {
    const { getByTestId } = render(<SearchCard data={[]} />);
    const card = getByTestId('search-card');
    expect(card).toBeInTheDocument();
  });

  it('should render without errors with data', () => {
    const { getByTestId } = render(<SearchCard data={fileData} />);
    const card = getByTestId('search-card');
    expect(card).toBeInTheDocument();
  });

  it('should handle item click', () => {
    const { getByText } = render(<SearchCard data={fileData} />);
    const item1 = getByText('Company agreement.pdf');
    fireEvent.click(item1);
  });
});
