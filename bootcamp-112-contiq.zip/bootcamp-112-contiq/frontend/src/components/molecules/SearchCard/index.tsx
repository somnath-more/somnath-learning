import React, { useState } from 'react';
import { styled } from '@mui/system';
import { List, ListItem, ListItemButton } from '@mui/material';
import theme from '@src/themes';
import ImageComponent from '@components/atoms/image';
import TypographyComponent from '@components/atoms/Typography';
import {
  SEARCH_RESULT,
  OTHER_DOCUMENTS_TXT,
  DOCUMENT_IMG1_ALT,
  DOCUMENT_IMG2_ALT
} from '@src/utils/constants';
import LearnBasics from '@assets/images/LearnBasics.svg';
import PowerUser from '@assets/images/PowerUser.svg';
import { FileType } from '@src/utils/types';

export interface SearchDataProp {
  data: FileType[];
  onListItemClick?: (id: string, label: string) => void;
}

const RootContainer = styled('div')({
  height: '282px',
  width: '352px',
  display: 'flex',
  flexDirection: 'column',
  border: `1px solid ${theme.palette.grays.gray100}`,
  borderRadius: '7px',
  boxSizing: 'border-box',
  backgroundColor: theme.palette.text.white,
  overflow: 'hidden',
  position: 'relative',
  boxShadow: `0px ${theme.spacing(5.25)} ${theme.spacing(8)} 0px ${theme.palette.grays.gray700}`
});

const HeaderContainer = styled('div')({
  height: '40px',
  width: '330px',
  display: 'flex',
  boxSizing: 'border-box',
  borderRadius: '7px',
  paddingLeft: '12px',
  position: 'fixed',
  background: theme.palette.background.default,
  zIndex: '1'
});

const Scrollbar = styled('div')({
  flex: 1,
  overflowY: 'auto',
  scrollbarWidth: 'thin',
  marginRight: '3px',
  marginTop: '2px',
  marginBottom: '3px',
  '&::-webkit-scrollbar': {
    width: '14px'
  },
  '&::-webkit-scrollbar-track': {
    background: '#F0F0F0',
    borderRadius: '12px',
    height: '286px'
  },
  '&::-webkit-scrollbar-thumb': {
    backgroundColor: '#D9D9D9',
    borderRadius: '16px',
    width: '6px',
    height: '196px',
    border: ' 4px solid transparent',
    backgroundClip: 'content-box'
  }
});

const ListItemContainer = styled('div')({
  height: 'auto',
  maxHeight: '120px'
});

const BodyContainer = styled('div')({
  display: 'flex',
  flexDirection: 'column',
  marginLeft: '12px',
  backgroundColor: theme.palette.text.white
});

const ImageContainer = styled('div')({
  display: 'flex',
  flexDirection: 'row',
  gap: '16px',
  paddingBottom: '15px'
});
const StyledListItem = styled(ListItem)({
  marginBottom: '16px',
  paddingLeft: '12px'
});
const StyledListItemButton = styled(ListItemButton)({
  '&.MuiButtonBase-root': {
    boxSizing: 'border-box',
    textAlign: 'left',
    padding: '0px'
  }
});
export default function SearchCard(props: SearchDataProp) {
  const [data] = useState<FileType[]>(props.data);

  return (
    <>
      <RootContainer data-testid="search-card">
        <HeaderContainer>
          <TypographyComponent
            children={SEARCH_RESULT}
            variant="caption1"
            color={theme.palette.text.black}
            sx={{ marginTop: '12px' }}
          />
        </HeaderContainer>
        <Scrollbar>
          <List sx={{ width: '100%', marginTop: '35px', marginBottom: '100px' }}>
            {data.length === 0 ? (
              <ListItemContainer>
                <StyledListItem>
                  <TypographyComponent
                    children="Not found"
                    variant="body2"
                    sx={{
                      color: theme.palette.text.lowEmphasis
                    }}
                  />
                </StyledListItem>
              </ListItemContainer>
            ) : (
              data.map((item) => (
                <ListItemContainer key={item.id}>
                  <StyledListItem disablePadding>
                    <StyledListItemButton
                      onClick={() => props.onListItemClick?.(item.id, item.name)}>
                      <TypographyComponent
                        children={item.name}
                        variant="body2"
                        sx={{
                          color: theme.palette.text.lowEmphasis
                        }}
                      />
                    </StyledListItemButton>
                  </StyledListItem>
                </ListItemContainer>
              ))
            )}
          </List>
        </Scrollbar>
        <BodyContainer
          sx={{
            position: 'absolute',
            top: '158px'
          }}>
          <TypographyComponent
            children={OTHER_DOCUMENTS_TXT}
            variant="caption1"
            sx={{ marginBottom: '8px', height: '20px' }}
          />
          <ImageContainer>
            <ImageComponent imgAlt={DOCUMENT_IMG1_ALT} imgSrc={PowerUser} />
            <ImageComponent imgAlt={DOCUMENT_IMG2_ALT} imgSrc={LearnBasics} />
          </ImageContainer>
        </BodyContainer>
      </RootContainer>
    </>
  );
}
