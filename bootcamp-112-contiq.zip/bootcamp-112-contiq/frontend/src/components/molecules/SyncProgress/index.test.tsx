import React from 'react';
import { render, screen } from '@testing-library/react';
import SyncProgress from '.';

describe('SyncProgress Component', () => {
  test('renders correctly', () => {
    render(<SyncProgress />);
    expect(screen.getByTestId('syncProgress')).toBeInTheDocument();
  });
});
