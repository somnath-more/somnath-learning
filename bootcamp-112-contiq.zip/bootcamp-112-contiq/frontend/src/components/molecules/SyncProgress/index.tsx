import React from 'react';
import MuiLoader from '../../atoms/Spinner';
import TypographyComponent from '../../atoms/Typography';
import IconComponent from '../../atoms/Icon';
import GooleDrive from '../../../../public/assets/images/GoogleDrive.svg';
import Close from '../../../../public/assets/icons/closeWhiteColor.svg';
import { styled, Box, Stack } from '@mui/material';
import { SYNC_PROGRESS_MODEL } from '../../../utils/constants';
import theme from '../../../themes';

export interface SyncProgressProps {
  handleCloseModel?: () => void;
}

const MainContainer = styled('div')({
  position: 'fixed',
  top: 0,
  left: 0,
  bottom: 0,
  right: 0,
  backgroundColor: theme.palette.structuralColor.overlay,
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  zIndex: 99
});

const RootBox = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
  width: theme.spacing(174),
  height: theme.spacing(127),
  borderRadius: theme.spacing(1),
  backgroundColor: theme.palette.grays.gray400,
  padding: theme.spacing(8)
});

const HeaderComponent = styled(Box)({
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'flex-end',
  height: '10%'
});

const MainComponent = styled('div')({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  height: '80%',
  gap: theme.spacing(4)
});

const FooterComponent = styled('div')({
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-between'
});

const TextComponent = styled('div')({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center'
});

const SyncProgress = ({ handleCloseModel }: SyncProgressProps) => {
  return (
    <MainContainer data-testid="syncProgress">
      <RootBox>
        <HeaderComponent>
          <IconComponent src={Close} onclick={handleCloseModel} />
        </HeaderComponent>
        <MainComponent>
          <IconComponent src={GooleDrive} />
          <Stack direction="row" gap={2}>
            <MuiLoader />
            <TypographyComponent
              children={SYNC_PROGRESS_MODEL[0]}
              variant="h3"
              color={theme.palette.text.white}
            />
          </Stack>
          <TextComponent>
            <TypographyComponent
              children={SYNC_PROGRESS_MODEL[1]}
              variant="body2"
              color={theme.palette.text.highEmphasis}
            />
            <TypographyComponent
              children={SYNC_PROGRESS_MODEL[2]}
              variant="body2"
              color={theme.palette.text.highEmphasis}
            />
          </TextComponent>
        </MainComponent>
        <FooterComponent>
          <TypographyComponent
            children={SYNC_PROGRESS_MODEL[3]}
            variant="body2"
            color={theme.palette.text.highEmphasis}
          />
          <TypographyComponent
            children={SYNC_PROGRESS_MODEL[4]}
            variant="body2"
            color={theme.palette.text.highEmphasis}
          />
        </FooterComponent>
      </RootBox>
    </MainContainer>
  );
};

export default SyncProgress;
