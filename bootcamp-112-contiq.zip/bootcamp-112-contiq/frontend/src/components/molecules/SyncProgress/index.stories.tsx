import { Meta, StoryFn } from '@storybook/react';
import SyncProgress from '.';
import { SyncProgressProps } from '.';

export default {
  title: 'Molecules/Sync Progress',
  component: SyncProgress
} as Meta;

const Template: StoryFn<SyncProgressProps> = (args) => <SyncProgress {...args} />;

export const Default = Template.bind({});
Default.args = {};

