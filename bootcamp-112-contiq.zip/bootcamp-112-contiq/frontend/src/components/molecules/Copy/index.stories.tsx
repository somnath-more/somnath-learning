import { Meta, StoryFn } from '@storybook/react';
import CopyComponent, { CopyComponentProps } from '.';

export default {
  title: 'Molecules/CopyComponent',
  component: CopyComponent
} as Meta;

const Template: StoryFn<CopyComponentProps> = (args) => <CopyComponent {...args} />;

export const Default = Template.bind({});
Default.args = {};
