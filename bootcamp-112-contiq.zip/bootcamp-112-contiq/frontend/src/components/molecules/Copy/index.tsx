import React from 'react';
import { Box, styled, useTheme } from '@mui/material';
import TypographyComponent from '../../atoms/Typography';
import IconComponent from '../../atoms/Icon';
import Complete from '../../../../public/assets/icons/complete.svg';
import Close from '../../../../public/assets/icons/closeWhiteColor.svg';
import { COPY_TEXT } from '../../../utils/constants';

export interface CopyComponentProps {
  handleClose?: (event: any) => void;
}

const RootBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  background: theme.palette.grays.gray400,
  padding: `${theme.spacing(2)} ${theme.spacing(3)}`,
  borderRadius: theme.spacing(1),
  width: theme.spacing(50),
  zIndex: 20
}));

const TypoBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  gap: theme.spacing(3)
}));

const CopyComponent = ({ handleClose }: CopyComponentProps) => {
  const theme = useTheme();

  return (
    <RootBox data-testid="copy-component">
      <TypoBox>
        <IconComponent src={Complete} />
        <TypographyComponent
          children={COPY_TEXT}
          variant="body1"
          color={theme.palette.text.white}
        />
      </TypoBox>
      <IconComponent src={Close} onclick={handleClose} />
    </RootBox>
  );
};

export default CopyComponent;
