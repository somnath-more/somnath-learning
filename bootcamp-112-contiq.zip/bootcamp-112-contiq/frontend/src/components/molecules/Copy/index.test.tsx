import React from 'react';
import { render, screen } from '@testing-library/react';
import CopyComponent from '.';
import { ThemeProvider } from '@emotion/react';
import theme from '../../../themes';

describe('SyncProgress Component', () => {
  test('renders correctly', () => {
    render(
      <ThemeProvider theme={theme}>
        <CopyComponent />
      </ThemeProvider>
    );

    expect(screen.getByTestId('copy-component')).toBeInTheDocument();
  });
});
