import React from 'react';
import { Box, styled, useTheme } from '@mui/material';
import ImageComponent from '../../atoms/image';
import IconComponent from '../../atoms/Icon';
import PDFIcon from '../../../../public/assets/icons/PDFIcon.svg';
import TypographyComponent from '../../atoms/Typography';

interface PresentationCardProps {
  cardImage: string;
  pdfName: string;
}

const RootBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(3),
  width: theme.spacing(72.5)
}));

const TypoBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  gap: theme.spacing(3)
}));

const PresentationCard = ({ cardImage, pdfName }: PresentationCardProps) => {
  const theme = useTheme();

  return (
    <RootBox data-testid="presentation-card">
      <ImageComponent
        imgSrc={cardImage}
        radius={theme.spacing(2)}
        borderWidth={theme.spacing(3.75)}
        borderColor={theme.palette.grays.gray600}
      />
      <TypoBox>
        <IconComponent src={PDFIcon} />
        <TypographyComponent variant="body1" children={pdfName} />
      </TypoBox>
    </RootBox>
  );
};

export default PresentationCard;
