import React from 'react';
import PresentationCard from './index';
import { render, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import NoFilesImage from '../../../../public/assets/images/NoFiles.svg';
import theme from '../../../themes';

describe('Testing the PresentationCard', () => {
  test('PresentationCard', () => {
    render(
      <ThemeProvider theme={theme}>
        <PresentationCard cardImage={NoFilesImage} pdfName="Company transformation.pdf" />
       </ThemeProvider>
    );
    const Test = screen.getByTestId('presentation-card');
    expect(Test).toBeInTheDocument();
  });

});
