import type { Meta, StoryObj } from '@storybook/react'

import PresentationCard from './index'
import cardImage from '../../../../public/assets/images/DigitalTransformation.svg';

const meta: Meta<typeof PresentationCard> = {
  title: 'molecules/PresentationCard',
  component: PresentationCard,
}

export default meta
type Story = StoryObj<typeof PresentationCard>

export const Basic: Story = {
  args: {
    cardImage: cardImage,
    pdfName: 'Company transformation.pdf'
  },
}
