import React from 'react';
import { Stack, Box, styled } from '@mui/material';
import Image from '@components/atoms/image';

interface TemplateProps {
  src: string;
  RightComponent: React.ReactNode;
}

export const SignInRootBox = styled(Box)({
  width: '41.44%',
  height: '100%'
});

export const SignInBox = styled(Box)(({ theme }) => ({
  marginTop: theme.spacing(20),
  marginLeft: theme.spacing(20)
}));

const LoginTemplate = (props: TemplateProps) => {
  return (
    <Box
      data-testid="login-template"
      sx={{
        position: 'absolute',
        top: 0,
        right: 0,
        left: 0,
        bottom: 0
      }}>
      <Stack direction="row" sx={{ width: '100%', height: '100%' }}>
        <Stack sx={{ width: '58.56%', height: '100%', objectFit: 'cover' }}>
          <Image
            imgSrc={props.src}
            sx={{ width: '100%', height: '100%', imageStyle: { objectFit: 'cover' } }}
          />
        </Stack>
        <SignInRootBox>
          <SignInBox>{props.RightComponent}</SignInBox>
        </SignInRootBox>
      </Stack>
    </Box>
  );
};
export default LoginTemplate;
