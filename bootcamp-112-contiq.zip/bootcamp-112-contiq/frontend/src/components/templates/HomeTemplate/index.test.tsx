import React from 'react';
import HomeTemplate from '.';
import { screen, render } from '@testing-library/react';
import '@testing-library/jest-dom';

describe('test for the home template', () => {
  test('should render the home template', () => {
    render(
      <HomeTemplate navComponent={'nav'} headerComponent={'header'} middleComponent={'middel'} />
    );
    const template = screen.getByTestId('homeTemplate');
    expect(template).toBeInTheDocument();
  });
});
