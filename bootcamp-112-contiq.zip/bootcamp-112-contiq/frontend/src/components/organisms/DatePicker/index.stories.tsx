import type { ComponentStory, Meta, StoryObj } from '@storybook/react';
import DatePicker from '.';
import { START_DATE } from '../../../utils/constants';
import { useState } from 'react';
import React from 'react';

const meta = {
  title: 'organisms/DatePicker',
  component: DatePicker
} satisfies Meta<typeof DatePicker>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Template: ComponentStory<typeof DatePicker> = (args) => {
  const [date, setDate] = useState<string>('');
  return <DatePicker {...args} date={date} setDate={setDate} />;
};
Template.args = {
  label: START_DATE
};
