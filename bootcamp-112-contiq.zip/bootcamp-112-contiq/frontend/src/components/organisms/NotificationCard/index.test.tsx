import React from 'react';
import { fireEvent, render, screen, waitFor, act } from '@testing-library/react';
import NotificationCard from '.';
import '@testing-library/jest-dom/extend-expect';
import { mockNotifications } from '@src/utils/constants';

describe('NotificationCard Component', () => {
  test('renders loading indicator when loading', async () => {
    render(<NotificationCard onClose={() => { } } Notificationdata={mockNotifications} />);
    expect(screen.getByTestId('loading-indicator')).toBeInTheDocument();
  });

  test('renders notifications when loaded', async () => {
    render(<NotificationCard onClose={() => { } } Notificationdata={mockNotifications} />);

    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 2000));
    });

    expect(screen.queryByTestId('loading-indicator')).toBeNull();
    expect(screen.queryByTestId('notification-list')).toBeInTheDocument();
  });

  test('calls onClose when close icon is clicked', async () => {
    const handleClose = jest.fn();
    const { getByAltText } = render(<NotificationCard onClose={handleClose} Notificationdata={mockNotifications} />);

    const closeButton = getByAltText('Close');
    fireEvent.click(closeButton);

    await waitFor(() => {
      expect(handleClose).toHaveBeenCalledTimes(1);
    });
  });
});
