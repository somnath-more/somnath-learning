import React, { useEffect, useState } from 'react';
import { Box, Divider, Grid } from '@mui/material';
import { styled } from '@mui/system';
import close from '../../../../public/assets/icons/close.svg';
import avatar from '../../../../public/assets/images/avatar.svg';
import loader from '../../../../public/assets/icons/notification_loader.gif';
import { NOT_FOUND } from '../../../utils/constants';
import theme from '../../../themes';
import TypographyComponent from '../../atoms/Typography';
import ImageComponent from '../../atoms/image';
import Notification from '../../molecules/AvatarWithTypography';

export interface NotificationProp {
  Notificationdata: Array<IMockNotifactions>;
  onClose?: () => void;
}

export interface IMockNotifactions {
  file_name: string;
  user_action: string;
  id: number;
  date: string;
  name: string;
}

const StyledBox = styled(Grid)`
  /* height: 443px; */
  width: 400px;
  border: 1px solid ${theme.palette.grays.gray100};
  background-color: ${theme.palette.text.white};
  border-radius: ${theme.spacing(1)};
  box-shadow: ${theme.spacing(1)} ${theme.spacing(4)} ${theme.spacing(8)} 0
    ${theme.palette.grays.gray700};
`;

const ScrollableContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  overflow-x: hidden;
  overflow-y: auto;
  max-height: calc(448px - 60px);
  ::-webkit-scrollbar {
    width: 7px;
    padding: 10px;
  }
  ::-webkit-scrollbar-track {
    background: ${theme.palette.grays.gray600};
  }
  ::-webkit-scrollbar-thumb {
    background: ${theme.palette.grays.gray100};
    border-radius: 16px;
  }
  ::-webkit-scrollbar-thumb:hover {
    background: #555;
  }
`;

const TextContainer = styled(Box)`
  padding: 12px;
`;

const CloseIconContainer = styled(Grid)`
  cursor: pointer;
`;

const NotificationCard = ({ onClose , Notificationdata }: NotificationProp ) => {
  const [loading, setLoading] = useState(true);
  const[mockNotifications]= useState<IMockNotifactions[]>(Notificationdata);

  useEffect(() => {
    setLoading(true);
    const loadingTimeout = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => {
      clearTimeout(loadingTimeout);
    };
  }, []);

  return (
    <StyledBox>
      <TextContainer>
        <Grid
          container
          spacing={32}
          direction="row"
          justifyContent="space-between"
          alignItems="center">
          <Grid item>
            <TypographyComponent children="Notifications" variant="h3" />
          </Grid>
          <CloseIconContainer item onClick={onClose} data-testid="notication-close-button">
            <ImageComponent imgSrc={close} imgAlt="Close" />
          </CloseIconContainer>
        </Grid>
      </TextContainer>
      <Grid item>
        <Divider />
      </Grid>
      {loading ? (
        <>
          <Grid
            item
            display="flex"
            justifyContent="center"
            alignItems="center"
            data-testid="loading-indicator">
            <ImageComponent
              imgSrc={loader}
              imgAlt={'not found'}
              sx={{ width: '230px', height: '220px', paddingTop: '50px' }}
            />
          </Grid>
        </>
      ) : (
        <Grid onClick={onClose}>
          {' '}
          <ScrollableContainer data-testid="notification-list">
            {mockNotifications.map((notification) => (
              <React.Fragment key={notification.id}>
                <Notification
                  name={notification.name}
                  user_action={notification.user_action}
                  file_name={notification.file_name}
                  dateTime={notification.date}
                  avatarSrc={avatar}
                  avatarAlt={NOT_FOUND}
                />
                {notification.id !== mockNotifications[mockNotifications.length - 1].id && (
                  <Divider sx={{ width: '100%' }} />
                )}
              </React.Fragment>
            ))}
          </ScrollableContainer>
        </Grid>
      )}
    </StyledBox>
  );
};

export default NotificationCard;
