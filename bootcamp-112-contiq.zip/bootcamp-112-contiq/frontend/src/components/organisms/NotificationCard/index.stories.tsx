import { mockNotifications } from '@src/utils/constants';
import NotificationCard, { NotificationProp } from '.';
import { StoryFn } from '@storybook/react';

export default {
  title: 'organisms/NotificationCard',
  component: NotificationCard
};

const Template: StoryFn<NotificationProp> = (args) => <NotificationCard {...args} />;

export const Default = Template.bind({});
Default.args = {
  Notificationdata: mockNotifications
};
