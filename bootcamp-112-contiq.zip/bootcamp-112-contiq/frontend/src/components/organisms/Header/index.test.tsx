import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import Header from './index';
import { ThemeProvider } from '@emotion/react';
import theme from '@src/themes';
import { useAuth0 } from '@auth0/auth0-react';
import { searchFiles, fetchNotificationData, fetchUsers } from '@src/service';
import { BrowserRouter as Router } from 'react-router-dom';

jest.mock('@auth0/auth0-react', () => ({
  useAuth0: jest.fn()
}));

jest.mock('@src/service', () => ({
  searchFiles: jest.fn(),
  fetchNotificationData: jest.fn(),
  fetchUsers: jest.fn(),
  updateNotificationCount: jest.fn()
}));

jest.mock('axios');

const logoutMock = jest.fn();
(useAuth0 as jest.Mock).mockReturnValue({
  logout: logoutMock
});
describe('Header component', () => {
  beforeEach(() => {
    const mockResponse = {
      data: [
        {
          id: 1,
          user_id: 1,
          file_name: 'Company Presentation.pdf',
          is_read: false,
          user_action: 'UPLOAD',
          created_at: '2023-08-16 09:00:00'
        }
      ],
      files: [
        {
          id: '1',
          userId: 1,
          name: 'Company Presentation',
          type: 'PDF',
          path: '/path/to/company_presentation.ppt',
          content: 'some random content',
          createdAt: 1231351654
        },
        {
          id: '2',
          userId: 2,
          name: 'Financial Report',
          type: 'PDF',
          path: '/path/to/financial_report.pdf',
          content: 'some random content',
          createdAt: 1231351654
        }
      ],
      username: 'root'
    };

    (fetchNotificationData as jest.Mock).mockResolvedValue(mockResponse.data);
    (searchFiles as jest.Mock).mockResolvedValue(mockResponse.files);
    (fetchUsers as jest.Mock).mockResolvedValue(mockResponse.username);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('renders without errors', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <Header />
        </Router>
      </ThemeProvider>
    );
  });

  it('opens user menu when avatar is clicked', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <Header />
        </Router>
      </ThemeProvider>
    );

    const manageUserMenu = screen.getByTestId('Manage-User-Menu');
    fireEvent.click(manageUserMenu);

    const userMenu = screen.getAllByTestId('user-menu');
    userMenu.map((menu) => {
      expect(menu).toBeInTheDocument();
    });
  });

  test('shows search card when search text is entered', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <Header />
        </Router>
      </ThemeProvider>
    );

    const searchInput = screen.getByPlaceholderText('Search');
    fireEvent.change(searchInput, { target: { value: 'example' } });

    const searchCard = screen.getByTestId('search-card');
    expect(searchCard).toBeInTheDocument();
  });

  it('should show notification and reset notification count on integration click', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <Header />
        </Router>
      </ThemeProvider>
    );

    const integrationButton = screen.getByTestId('integration-button');
    fireEvent.click(integrationButton);

    const closeNotificationButton = screen.getByTestId('notication-close-button');
    fireEvent.click(closeNotificationButton);
  });

  it('logout button', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <Header />
        </Router>
      </ThemeProvider>
    );

    const manageUserMenu = screen.getByTestId('Manage-User-Menu');
    fireEvent.click(manageUserMenu);

    const button = screen.getAllByTestId('user-menu');
    const logoutButton = button[3];
    fireEvent.click(logoutButton);
    expect(logoutMock).toBeCalledTimes(1);
  });
});
