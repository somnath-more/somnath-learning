import React, { useCallback, useEffect, useState } from 'react';
import { CircularProgress, Grid, styled } from '@mui/material';
import HelpIcon from '@assets/icons/help.svg';
import AddUsersIcon from '@assets/icons/add user.svg';
import NotificationIcon from '@assets/icons/notification.svg';
import theme from '@src/themes';
import TypographyComponent from '@components/atoms/Typography';
import InputField from '@components/atoms/InputField';
import IconComponent from '@components/atoms/Icon';
import Avatar from '@assets/images/avatar.svg';
import search from '@assets/icons/search.svg';
import AvatarArrow from '@assets/images/avatarArrow.svg';
import UserMenu from '../UserMenu';
import NotificationCard, { IMockNotifactions } from '../NotificationCard';
import SearchCard from '@components/molecules/SearchCard';
import { fetchAndProcessNotifications, getUserId } from '@src/utils/functions';
import { NAVIGATE_PDF } from '@src/utils/constants';
import { searchFiles, updateNotificationCount } from '@src/service';
import { FileType } from '@src/utils/types';
import { useAuth0 } from '@auth0/auth0-react';
import { useNavigate } from 'react-router-dom';

const HeaderContainer = styled(Grid)({
  height: '8vh',
  background: `linear-gradient(90deg, #05BDCD 10.18%, #7C2BE8 108.2%)`,
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  paddingLeft: '20px',
  paddingRight: '20px'
});
const IconContainer = styled(Grid)({
  minWidth: '44px',
  height: '44px',
  borderRadius: '8px',
  background: theme.palette.text.white,
  marginLeft: '20px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-around',
  opacity: 0.2
});
const IconContainer1 = styled(Grid)({
  minWidth: '353px',
  height: '40px',
  borderRadius: '8px',
  background: theme.palette.text.white,
  marginLeft: '20px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-around',
  opacity: 0.2
});
const IconWrapper = styled(Grid)({
  display: 'inline-flex',
  justifyContent: 'space-around',
  alignItems: 'center'
});
const CustomIcon = styled(Grid)({
  position: 'absolute',
  marginLeft: '20px',
  marginTop: '2px',
  cursor: 'pointer'
});
const LeftContainer = styled(Grid)({
  float: 'left'
});
const RightContainer = styled(Grid)({
  float: 'right',
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  padding: '2px'
});

const StyledMuiSearchResult = styled(Grid)({
  position: 'absolute',
  top: '70px',
  right: '17%',
  zIndex: 1,

  '@media (max-width: 1080px)': {
    right: '22%'
  }
});

const StyledNotification = styled(Grid)({
  padding: '2px',
  paddingLeft: '1075px',
  position: 'absolute',
  top: '60px',
  right: '4.5%',
  zIndex: 1,

  '@media (max-width: 1080px)': {
    right: '8%'
  }
});
const Header = () => {
  const [searchText, setSearchText] = useState('');
  const [notificationCount, setNotificationCount] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [notificationsData, setNotificationsData] = useState<IMockNotifactions[]>();
  const [files, setFiles] = useState<FileType[]>([]);
  const [debounceTimeoutId, setDebounceTimeoutId] = useState<NodeJS.Timeout | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [totalCount, setTotalCount] = useState(0);

  const userId: number | null = getUserId();

  useEffect(() => {
    const fetchData = async () => {
      await fetchAndProcessNotifications(setNotificationCount, setNotificationsData, setTotalCount);
    };
    const intervalId = setInterval(() => {
      fetchData();
    }, 6000);
    return () => clearInterval(intervalId);
  }, []);

  const { logout } = useAuth0();
  const navigate = useNavigate();

  const handleGridClick = (event: any) => {
    setMenuOpen(!menuOpen);
    setAnchorEl(event.currentTarget);
  };

  const handleSearchChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const newValue = event.target.value;
      setSearchText(newValue);

      if (debounceTimeoutId) {
        clearTimeout(debounceTimeoutId);
      }

      const newTimeoutId = setTimeout(() => {
        setIsLoading(true);
        if (userId) {
          searchFiles(userId, newValue).then((result) => {
            setFiles(result);
            setIsLoading(false);
          });
        }
      }, 300);

      setDebounceTimeoutId(newTimeoutId);
    },
    [userId, debounceTimeoutId]
  );

  const handleIntegrationClick = async () => {
    setShowNotification(true);
    setNotificationCount(0);
    await updateNotificationCount(totalCount);
  };

  const handleCloseNotification = () => {
    setShowNotification(false);
  };

  const handlePDFRender = useCallback(
    (id: string) => {
      const dataObject = {
        id: id,
        searchKey: searchText
      };
      setSearchText('');
      navigate(NAVIGATE_PDF, { state: { dataObject } });
      window.location.reload();
    },
    [searchText]
  );

  const ShowSearchResults = searchText.length >= 1;
  return (
    <Grid data-testid="Header">
      <HeaderContainer>
        <LeftContainer>
          <TypographyComponent
            children="CONTIQ"
            variant="h3"
            sx={{ color: theme.palette.text.white }}
          />
        </LeftContainer>
        <RightContainer>
          <IconWrapper>
            <IconContainer1></IconContainer1>
            <CustomIcon>
              <InputField
                placeholder="Search"
                value={searchText}
                startIcon={search}
                sx={{
                  width: '352px'
                }}
                handleChange={handleSearchChange}
              />
            </CustomIcon>
          </IconWrapper>
          <IconWrapper>
            <IconContainer></IconContainer>
            <CustomIcon>
              <IconComponent src={HelpIcon} />
            </CustomIcon>
          </IconWrapper>
          <IconWrapper>
            <IconContainer></IconContainer>
            <CustomIcon>
              <IconComponent src={AddUsersIcon} />
            </CustomIcon>
          </IconWrapper>
          <IconWrapper>
            <IconContainer></IconContainer>
            <CustomIcon>
              <div data-testid="integration-button" onClick={handleIntegrationClick}>
                <IconComponent src={NotificationIcon} />
                {notificationCount > 0 && (
                  <div
                    data-testid="notification-count"
                    style={{
                      position: 'absolute',
                      top: '-2px',
                      right: '-2px',
                      background: 'red',
                      color: 'white',
                      borderRadius: '50%',
                      fontSize: '10px',
                      padding: '0px 4px'
                    }}>
                    {notificationCount}
                  </div>
                )}
              </div>
            </CustomIcon>
          </IconWrapper>
          <Grid
            paddingLeft={4}
            data-testid="Manage-User-Menu"
            sx={{
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center'
            }}
            onClick={(e) => handleGridClick(e)}>
            {menuOpen ? (
              <img src={AvatarArrow} alt="Other Image" />
            ) : (
              <IconComponent src={Avatar} />
            )}
            {menuOpen && (
              <UserMenu
                userName={JSON.parse(localStorage.getItem('user')!)?.name}
                userId={1238}
                isOpen={true}
                anchorEl={anchorEl}
                handleLogOut={() => {
                  logout();
                  localStorage.removeItem('user');
                }}
              />
            )}
          </Grid>
        </RightContainer>
      </HeaderContainer>

      {ShowSearchResults && (
        <StyledMuiSearchResult>
          {isLoading ? (
            <CircularProgress />
          ) : (
            <SearchCard
              data-testid="search-card"
              data={files}
              onListItemClick={(id) => handlePDFRender(id)}
            />
          )}
        </StyledMuiSearchResult>
      )}
      {showNotification && (
        <StyledNotification>
          <NotificationCard
            onClose={handleCloseNotification}
            Notificationdata={notificationsData!}
          />
        </StyledNotification>
      )}
    </Grid>
  );
};

export default Header;
