import type { Meta, StoryObj } from '@storybook/react';

import UserMenu from './index';

const meta: Meta<typeof UserMenu> = {
  title: 'organisms/UserMenu',
  component: UserMenu
};

export default meta;
type Story = StoryObj<typeof UserMenu>;

export const Basic: Story = {
  args: {
    isOpen: true,
    userName: 'John Ross',
    userId: 292
  }
};
