import * as React from 'react';
import { styled } from '@mui/material/styles';
import { Box, Menu, useTheme } from '@mui/material';
import TypographyComponent from '../../atoms/Typography';
import { USER_ID, USER_PROFILE_OPTIONS } from '../../../utils/constants';
import { convertToFiveDigits } from '../../../utils/functions';
import IconComponent from '../../atoms/Icon';

interface UserMenuProps {
  isOpen: boolean;
  anchorEl?: any;
  userName: string;
  userId: number;
  handleLogOut?: () => void;
}

const RootBox = styled(Box)({
  display: 'flex',
  flexDirection: 'column'
});

const StyledMenu = styled(Menu)(({ theme }) => ({
  marginTop: '10px',
  '& .MuiMenu-paper': {
    minWidth: theme.spacing(44.75),
    border: `${theme.spacing(0.25)} solid ${theme.palette.grays.gray100}`,
    borderRadius: theme.spacing(1),
    boxShadow: `${theme.spacing(1)} ${theme.spacing(4)} ${theme.spacing(8)} 0 ${
      theme.palette.grays.gray700
    }`
  },
  '& .MuiMenu-list': {
    paddingBottom: 0
  }
}));

const HeadingBox = styled(Box)(({ theme }) => ({
  padding: `${theme.spacing(1)} ${theme.spacing(3)}`,
  borderBottom: `${theme.spacing(0.25)} solid ${theme.palette.grays.gray100}`
}));

const OptionsBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(3),
  padding: theme.spacing(3)
}));

const MenuItemBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(2)
}));

const IconBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'center',
  height: theme.spacing(6),
  width: theme.spacing(6)
}));

const UserMenu = ({ isOpen, anchorEl, userName, userId, handleLogOut }: UserMenuProps) => {
  const theme = useTheme();

  return (
    <RootBox data-testid="user-menu">
      <StyledMenu open={isOpen} anchorEl={anchorEl}>
        <HeadingBox>
          <TypographyComponent
            variant="body1"
            color={theme.palette.text.black}
            children={userName}
          />
          <TypographyComponent
            variant="overline1"
            color={theme.palette.text.lowEmphasis}
            children={USER_ID + convertToFiveDigits(userId)}
          />
        </HeadingBox>
        <OptionsBox>
          {USER_PROFILE_OPTIONS.map((option) => {
            const isLogoutOption = option.name === 'Logout';
            return (
              <MenuItemBox
                data-testId="user-menu"
                key={option.id}
                onClick={isLogoutOption ? handleLogOut : undefined}
                sx={{ cursor: isLogoutOption ? 'pointer' : 'default' }}>
                <IconBox>
                  <IconComponent src={option.icon} />
                </IconBox>
                <TypographyComponent
                  variant="body2"
                  color={theme.palette.text.black}
                  children={option.name}
                />
              </MenuItemBox>
            );
          })}
        </OptionsBox>
      </StyledMenu>
    </RootBox>
  );
};

export default UserMenu;
