import React from 'react';
import UserMenu from './index';
import { render, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import theme from '../../../themes';

describe('Testing the UserMenu', () => {
  test('UserMenu', () => {
    render(
      <ThemeProvider theme={theme}>
        <UserMenu isOpen={true} userName={'John Ross'} userId={299} />
      </ThemeProvider>
    );
    const Test = screen.getAllByTestId('user-menu');
    Test.map((TestId) => {
      expect(TestId).toBeInTheDocument();
    });
  });
});
