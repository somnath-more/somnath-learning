import React, { useCallback, useEffect, useState } from 'react';
import { useTheme } from '@mui/material';
import TypographyComponent from '@components/atoms/Typography';
import {
  CREATE_NEW_PASSWORD,
  CREATE_NEW_PASSWORD_MESSAGE,
  CREATE_NEW_PASSWORD_BUTTON,
  CONFIRM_NEW_PASSWORD_PLACEHOLDER,
  NEW_PASSWORD_PLACEHOLDER,
  PASSWORD_ERROR,
  CONFIRM_PASSWORD_ERROR,
  NEW_PASSWORD,
  CONFIRM_NEW_PASSWORD
} from '@utils/constants';
import InputFieldWithTypography from '@components/molecules/TextFieldWithTypography';
import { PASSWORD_REGEX } from '@utils/regex';
import { inputValidator, passwordValidator } from '@utils/functions';
import { RootBox, ContentBox, HeaderBox, MessageBox, SendButton } from '../ResetPassword';

interface CreateNewPasswordProps {
  onResetPassword?: any;
}

const CreateNewPassword = ({ onResetPassword }: CreateNewPasswordProps) => {
  const theme = useTheme();

  const [password, setPassword] = useState<string>('');
  const [passwordError, setPasswordError] = useState<string>(' ');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [confirmPasswordError, setConfirmPasswordError] = useState<string>(' ');

  const handlePassword = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const newPassword = event.target.value;
    setPassword(newPassword);
  }, []);

  const handleConfirmPassword = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const newConfirmPassword = event.target.value;
    setConfirmPassword(newConfirmPassword);
  }, []);

  useEffect(() => {
    if (password.length > 0) {
      setPasswordError(inputValidator(password, PASSWORD_REGEX) ? '' : PASSWORD_ERROR);
    }
    if (confirmPassword.length > 0) {
      setConfirmPasswordError(
        passwordValidator(password, confirmPassword) ? '' : CONFIRM_PASSWORD_ERROR
      );
    }
  }, [password, confirmPassword]);

  const isButtonEnabled = passwordError.length == 0 && confirmPasswordError.length == 0;

  const handleReset = () => {
    onResetPassword(password);
  };

  return (
    <RootBox data-testid="create-new-password">
      <HeaderBox>
        <TypographyComponent
          variant="h2"
          children={CREATE_NEW_PASSWORD}
          color={theme.palette.text.black}
        />
        <MessageBox>
          <TypographyComponent
            variant="overline1"
            children={CREATE_NEW_PASSWORD_MESSAGE}
            color={theme.palette.text.mediumEmphasis}
          />
        </MessageBox>
      </HeaderBox>
      <ContentBox>
        <InputFieldWithTypography
          text={NEW_PASSWORD}
          value={password}
          placeholder={NEW_PASSWORD_PLACEHOLDER}
          type="password"
          handleChange={handlePassword}
        />
        <TypographyComponent
          variant="overline1"
          children={passwordError}
          color={theme.palette.structuralColor.main}
        />
        <InputFieldWithTypography
          text={CONFIRM_NEW_PASSWORD}
          value={confirmPassword}
          placeholder={CONFIRM_NEW_PASSWORD_PLACEHOLDER}
          type="password"
          handleChange={handleConfirmPassword}
        />
        <TypographyComponent
          variant="overline1"
          children={confirmPasswordError}
          color={theme.palette.structuralColor.main}
        />
      </ContentBox>
      <SendButton
        data-testid="confirm-btn"
        variant="contained"
        onClick={handleReset}
        disabled={!isButtonEnabled}>
        {CREATE_NEW_PASSWORD_BUTTON}
      </SendButton>
    </RootBox>
  );
};

export default CreateNewPassword;
