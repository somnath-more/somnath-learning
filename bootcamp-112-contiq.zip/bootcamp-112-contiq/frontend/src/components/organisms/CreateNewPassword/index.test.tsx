import React from 'react';
import CreateNewPassword from '.';
import { fireEvent, render, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import theme from '@src/themes';
import {
  CONFIRM_NEW_PASSWORD_PLACEHOLDER,
  NEW_PASSWORD_PLACEHOLDER,
  PASSWORD_ERROR,
  CONFIRM_PASSWORD_ERROR
} from '@utils/constants';

const onResetPassword = jest.fn();

describe('Testing the CreateNewPassword component', () => {
  test('renders CreateNewPassword component', () => {
    render(
      <ThemeProvider theme={theme}>
        <CreateNewPassword onResetPassword={onResetPassword} />
      </ThemeProvider>
    );
    const createNewPasswordRoot = screen.getByTestId('create-new-password');
    expect(createNewPasswordRoot).toBeInTheDocument();
  });

  test('validates password input and confirm password input, then updates password', () => {
    window.alert = jest.fn();
    render(
      <ThemeProvider theme={theme}>
        <CreateNewPassword onResetPassword={onResetPassword} />
      </ThemeProvider>
    );

    const newPasswordInput = screen.getByPlaceholderText(NEW_PASSWORD_PLACEHOLDER);
    const confirmPasswordInput = screen.getByPlaceholderText(CONFIRM_NEW_PASSWORD_PLACEHOLDER);
    const resetButton = screen.getByTestId('confirm-btn');

    fireEvent.change(newPasswordInput, { target: { value: 'Valid@1234' } });
    expect(resetButton).toBeDisabled();

    fireEvent.change(confirmPasswordInput, { target: { value: 'Valid@1234' } });
    expect(resetButton).toBeEnabled();

    fireEvent.click(resetButton);
  });

  test('displays error messages for invalid password and mismatched confirm password', () => {
    window.alert = jest.fn();
    render(
      <ThemeProvider theme={theme}>
        <CreateNewPassword onResetPassword={onResetPassword} />
      </ThemeProvider>
    );

    const newPasswordInput = screen.getByPlaceholderText(NEW_PASSWORD_PLACEHOLDER);
    const confirmPasswordInput = screen.getByPlaceholderText(CONFIRM_NEW_PASSWORD_PLACEHOLDER);
    const resetButton = screen.getByTestId('confirm-btn');

    fireEvent.change(newPasswordInput, { target: { value: 'invalid' } });
    const newPasswordError = screen.getByText(PASSWORD_ERROR);
    expect(newPasswordError).toBeInTheDocument();
    fireEvent.change(confirmPasswordInput, { target: { value: 'invalid123' } });
    const confirmPasswordError = screen.getByText(CONFIRM_PASSWORD_ERROR);

    expect(confirmPasswordError).toBeInTheDocument();

    fireEvent.change(newPasswordInput, { target: { value: 'Test@1234' } });
    fireEvent.change(confirmPasswordInput, { target: { value: 'Test@1234' } });
    fireEvent.click(resetButton);
  });
});
