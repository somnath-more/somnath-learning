import type { Meta, StoryFn } from '@storybook/react';
import CreateNewPassword from '.';

export default {
  title: 'Organisms/Create New Password',
  component: CreateNewPassword
} as Meta;

const Template: StoryFn = (args) => <CreateNewPassword {...args} />;

export const Basic = Template.bind({});
