import type { Meta, StoryObj } from '@storybook/react';

import SignInOrganism from './index';
import { BrowserRouter as Router } from 'react-router-dom';

const meta: Meta<typeof SignInOrganism> = {
  title: 'organisms/SignInOrganism',
  component: SignInOrganism,
  decorators: [
    (Story) => (
      <Router>
        <Story />
      </Router>
    )
  ]
};

export default meta;
type Story = StoryObj<typeof SignInOrganism>;

export const SignIn: Story = {
  args: {}
};
