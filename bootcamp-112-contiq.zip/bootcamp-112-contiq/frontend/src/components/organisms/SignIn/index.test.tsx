import React from 'react';
import SignInOrganism from './index';
import { fireEvent, render, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import theme from '@src/themes';
import { useAuth0 } from '@auth0/auth0-react';
import { BrowserRouter as Router } from 'react-router-dom';

jest.mock('@auth0/auth0-react', () => ({
  useAuth0: jest.fn()
}));

const loginWithRedirectMock = jest.fn();
(useAuth0 as jest.Mock).mockReturnValue({
  loginWithRedirect: loginWithRedirectMock
});

const mockOnSignIn = jest.fn();

describe('Testing the SignInOrganism', () => {
  test('SignInOrganism test', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <SignInOrganism onSignIn={mockOnSignIn} />
        </Router>
      </ThemeProvider>
    );
    const Test = screen.getByTestId('sign-in-organism');
    expect(Test).toBeInTheDocument();
  });

  test('SignInOrganism test input fields', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <SignInOrganism onSignIn={mockOnSignIn} />
        </Router>
      </ThemeProvider>
    );

    const emailIP = screen.getByPlaceholderText('john@example.com');
    expect(emailIP).toBeInTheDocument();
    fireEvent.change(emailIP);
    fireEvent.change(emailIP, {
      target: { value: 'test@gmail.com' }
    });
    fireEvent.change(emailIP, { target: { value: '' } });

    const passIP = screen.getByPlaceholderText('Create a password');
    expect(passIP).toBeInTheDocument();
    fireEvent.change(passIP);
    fireEvent.change(passIP, {
      target: { value: 'Test@1234' }
    });
    fireEvent.change(passIP, { target: { value: '' } });
  });

  test('SignInOrganism test buttons', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <SignInOrganism onSignIn={mockOnSignIn} />
        </Router>
      </ThemeProvider>
    );

    const emailIP = screen.getByPlaceholderText('john@example.com');
    const passIP = screen.getByPlaceholderText('Create a password');
    const signInBtn = screen.getByTestId('signIn-btn');
    expect(signInBtn).toBeDisabled();

    fireEvent.change(emailIP, {
      target: { value: 'test@gmail.com' }
    });
    expect(emailIP).toHaveValue('test@gmail.com');

    fireEvent.change(passIP, {
      target: { value: 'Test@1234' }
    });
    expect(passIP).toHaveValue('Test@1234');

    expect(signInBtn).toBeEnabled();
    fireEvent.click(signInBtn);

    const googleBtn = screen.getByTestId('gooble-btn');
    expect(googleBtn).toBeInTheDocument();
    fireEvent.click(googleBtn);
  });

  test('SignInOrganism test for text click', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <SignInOrganism onSignIn={mockOnSignIn} />
        </Router>
      </ThemeProvider>
    );

    const resetText = screen.getByText('Forgot password?');
    expect(resetText).toBeInTheDocument();
    fireEvent.click(resetText);

    const signUpText = screen.getByText('Sign Up');
    expect(signUpText).toBeInTheDocument();
    fireEvent.click(signUpText);
  });
});
