import React, { useCallback, useState } from 'react';
import { Box, Button, styled, useTheme } from '@mui/material';
import TypographyComponent from '@components/atoms/Typography';
import {
  DOESNT_HAVE_ACCOUNT,
  EMAIL,
  EMAIL_ERROR,
  EMAIL_PLACEHOLDER,
  FORGOT_PASSWORD,
  NAVIGATE_RESET_PASSWORD,
  NAVIGATE_SIGNUP,
  PASSWORD,
  PASSWORD_ERROR,
  PASSWORD_PLACEHOLDER,
  REMEMBER_ME,
  SIGN_IN,
  SIGN_UP,
  WITH_GOOGLE
} from '@utils/constants';
import InputFieldWithTypography from '@components/molecules/TextFieldWithTypography';
import CheckboxComponent from '@components/atoms/Checkbox';
import LineDivider from '@components/atoms/LineDivider';
import { EMAIL_REGEX, PASSWORD_REGEX } from '@utils/regex';
import { inputValidator } from '@utils/functions';
import GoogleLogo from '@assets/icons/googleLogo.svg';
import IconComponent from '@components/atoms/Icon';
import { useAuth0 } from '@auth0/auth0-react';
import { useNavigate } from 'react-router-dom';

interface SignInProps {
  onSignIn?: any;
}

export const RootBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(8),
  width: theme.spacing(89)
}));

export const ContentBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(5)
}));

const RemeberBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginTop: theme.spacing(2),
  height: theme.spacing(5),
  '& .MuiFormControlLabel-root': {
    marginLeft: 0,
    marginRight: 0
  },
  '& .MuiCheckbox-root': {
    padding: 0
  },
  '& .MuiTypography-root': {
    marginLeft: theme.spacing(1)
  }
}));

export const StyledBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(7)
}));

export const SignInButton = styled(Button)(({ theme }) => ({
  height: theme.spacing(12),

  '&.MuiButton-root': {
    ...theme.typography.body1,
    color: theme.palette.text.white,
    textTransform: 'none',
    boxShadow: 'none'
  },
  ':disabled': {
    backgroundColor: theme.palette.primary.light
  },
  '&:hover': {
    backgroundColor: `${theme.palette.primary.main} !important`
  }
}));

export const GoogleButton = styled(Button)(({ theme }) => ({
  height: theme.spacing(12),

  '&.MuiButton-root': {
    ...theme.typography.body1,
    textTransform: 'none',
    color: theme.palette.text.black,
    background: theme.palette.grays.gray600,
    boxShadow: 'none'
  }
}));

export const TypoBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  gap: theme.spacing(1),
  justifyContent: 'center'
}));

const SignInOrganism = ({ onSignIn }: SignInProps) => {
  const theme = useTheme();
  const { loginWithRedirect } = useAuth0();
  const navigate = useNavigate();

  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [emailError, setEmailError] = useState<string>(' ');
  const [passwordError, setPasswordError] = useState<string>(' ');

  const handleEmail = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const newEmail = event.target.value;
    setEmail(newEmail);
    setEmailError(inputValidator(newEmail, EMAIL_REGEX) ? '' : EMAIL_ERROR);
  }, []);

  const renderResetPassword = useCallback(() => {
    navigate(NAVIGATE_RESET_PASSWORD);
  }, []);

  const renderSignUp = useCallback(() => {
    navigate(NAVIGATE_SIGNUP);
  }, []);

  const handlePassword = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const newPassword = event.target.value;
    setPassword(newPassword);
    setPasswordError(inputValidator(newPassword, PASSWORD_REGEX) ? '' : PASSWORD_ERROR);
  }, []);

  const handleSignIn = useCallback(() => {
    onSignIn(email, password);
  }, [email, password]);

  const handleGoogleSignIn = useCallback(() => {
    loginWithRedirect().then((response) => {
      console.log('Majju');
    });
  }, []);

  const isSignInEnabled = passwordError.length == 0 && emailError.length == 0;

  return (
    <RootBox data-testid="sign-in-organism">
      <TypographyComponent variant="h2" children={SIGN_IN} color={theme.palette.text.black} />
      <ContentBox>
        <Box>
          <InputFieldWithTypography
            text={EMAIL}
            value={email}
            placeholder={EMAIL_PLACEHOLDER}
            handleChange={handleEmail}
          />
          <TypographyComponent
            variant="overline1"
            children={emailError}
            color={theme.palette.structuralColor.main}
          />
        </Box>
        <Box>
          <InputFieldWithTypography
            text={PASSWORD}
            value={password}
            placeholder={PASSWORD_PLACEHOLDER}
            type="password"
            handleChange={handlePassword}
          />
          <TypographyComponent
            variant="overline1"
            children={passwordError}
            color={theme.palette.structuralColor.main}
          />
          <RemeberBox>
            <Box>
              <CheckboxComponent disabled={true} />
              <TypographyComponent
                variant="caption1"
                children={REMEMBER_ME}
                color={theme.palette.text.lowEmphasis}
              />
            </Box>

            <TypographyComponent
              variant="caption1"
              children={FORGOT_PASSWORD}
              color={theme.palette.primary.main}
              onClick={renderResetPassword}
              sx={{ cursor: 'pointer' }}
            />
          </RemeberBox>
        </Box>
      </ContentBox>
      <StyledBox>
        <SignInButton
          data-testid="signIn-btn"
          variant="contained"
          onClick={handleSignIn}
          disabled={!isSignInEnabled}>
          {SIGN_IN}
        </SignInButton>
        <LineDivider />
        <GoogleButton
          data-testid="gooble-btn"
          variant="contained"
          onClick={handleGoogleSignIn}
          startIcon={<IconComponent src={GoogleLogo} />}>
          {WITH_GOOGLE}
        </GoogleButton>
        <TypoBox>
          <TypographyComponent
            variant="caption1"
            children={DOESNT_HAVE_ACCOUNT}
            color={theme.palette.text.mediumEmphasis}
          />
          <TypographyComponent
            variant="caption1"
            children={SIGN_UP}
            color={theme.palette.primary.main}
            onClick={renderSignUp}
            sx={{ cursor: 'pointer' }}
          />
        </TypoBox>
      </StyledBox>
    </RootBox>
  );
};

export default SignInOrganism;
