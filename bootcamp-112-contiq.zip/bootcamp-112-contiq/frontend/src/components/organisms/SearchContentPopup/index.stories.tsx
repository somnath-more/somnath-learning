import type { Meta, StoryObj } from '@storybook/react';

import SearchContentPopup from './index';

const meta: Meta<typeof SearchContentPopup> = {
  title: 'organisms/SearchContentPopup',
  component: SearchContentPopup
};

export default meta;
type Story = StoryObj<typeof SearchContentPopup>;

export const Basic: Story = {
  args: {
    searchKey: 'Repair business',
    pdfName: 'Company agreement',
    content: [
      'Since being established in 1908 as a sewing machine repair business, the brother group has pursued the diversification and globalization of business in its history of more...',
      'Repair business some text',
      'Some text repair business some text'
    ]
  }
};
