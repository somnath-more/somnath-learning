import React, { useCallback, useState } from 'react';
import { Box, Divider, styled, useTheme } from '@mui/material';
import TypographyComponent from '@components/atoms/Typography';
import IconComponent from '@components/atoms/Icon';
import UpArrowGrey from '@assets/icons/uparrow-grey.svg';
import UpArrow from '@assets/icons/uparrow.svg';
import DownArrow from '@assets/icons/downarrow.svg';
import DownArrowGrey from '@assets/icons/downarrow-grey.svg';
import Minimize from '@assets/icons/minimize.svg';
import Maximize from '@assets/icons/maximize.svg';
import CopyIcon from '@assets/icons/copy.svg';
import MoreIcon from '@assets/icons/more.svg';
import { SLIDE } from '@src/utils/constants';
import CopyComponent from '@components/molecules/Copy';
import { useCopyToClipboard } from 'usehooks-ts';

interface SearchContentPopupProps {
  searchKey: string;
  pdfName: string;
  content: string[];
}

const PopupBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(4),
  alignItems: 'flex-end'
}));

const RootBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  width: theme.spacing(96.5),
  boxShadow: '0px 2px 16px 0px #00000026',
  border: `1px solid ${theme.palette.grays.gray100}`,
  borderRadius: theme.spacing(1),
  background: theme.palette.grays.gray600
}));

const HeadBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  padding: `${theme.spacing(1.25)} ${theme.spacing(3)}`
}));

const RightBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(4)
}));

const ContentBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(3),
  padding: `${theme.spacing(5)} ${theme.spacing(6)}`,
  borderTop: `1px solid ${theme.palette.grays.gray100}`,
  wordBreak: 'break-all'
}));

const ContentHeadBox = styled(Box)({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center'
});

const TypoBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(1)
}));

const IconBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  gap: theme.spacing(2)
}));

const HoverIconBox = styled(Box)({
  cursor: 'pointer'
});

const SearchContentPopup = ({ searchKey, pdfName, content }: SearchContentPopupProps) => {
  const theme = useTheme();
  const [isMax, setIsMax] = useState(true);
  const [isCopied, setIsCopied] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [value, copy] = useCopyToClipboard();

  const toggleMinMax = useCallback(() => {
    setIsMax(!isMax);
  }, [isMax]);

  const closeCopyWindow = useCallback(() => {
    setIsCopied(false);
  }, []);

  const nextContent = useCallback(() => {
    setCurrentIndex((prevIndex) => {
      const newIndex = prevIndex + 1;
      return newIndex < content.length ? newIndex : prevIndex;
    });
  }, [content]);

  const prevContent = useCallback(() => {
    setCurrentIndex((prevIndex) => {
      const newIndex = prevIndex - 1;
      return newIndex >= 0 ? newIndex : prevIndex;
    });
  }, []);

  const handleCopyClick = (text: any) => {
    if (text === undefined) return;

    setIsCopied(true);
    copy(text);
    console.log('copied text to clipboard: ', value);
  };

  const boldOccurrences = (text: string, searchKey: string) => {
    if (text === undefined) return;

    const parts = text.split(new RegExp(`(${searchKey})`, 'gi'));

    return parts.map((part) =>
      part.toLowerCase() === searchKey.toLowerCase() ? (
        <TypographyComponent
          key={part}
          color={theme.palette.text.black}
          children={part}
          variant="caption1"
        />
      ) : (
        part
      )
    );
  };

  const formattedContent = boldOccurrences(content[currentIndex], searchKey);
  return (
    <PopupBox data-testid="search-content-popup">
      <RootBox>
        <HeadBox>
          <TypographyComponent
            variant="body2"
            color={theme.palette.text.black}
            children={searchKey}
          />
          <RightBox>
            <Box display="flex">
              <TypographyComponent
                variant="body2"
                color={theme.palette.text.black}
                children={`${currentIndex + 1}/`}
              />
              <TypographyComponent
                variant="body2"
                color={theme.palette.text.lowEmphasis}
                children={content.length.toString()}
              />
            </Box>

            <Divider orientation="vertical" flexItem />

            <HoverIconBox data-testid="up-arrow" onClick={nextContent}>
              {currentIndex >= content.length - 1 ? (
                <IconComponent src={UpArrow} />
              ) : (
                <IconComponent src={UpArrowGrey} />
              )}
            </HoverIconBox>
            <HoverIconBox data-testid="down-arrow" onClick={prevContent}>
              {currentIndex <= 0 ? (
                <IconComponent src={DownArrow} />
              ) : (
                <IconComponent src={DownArrowGrey} />
              )}
            </HoverIconBox>
            <HoverIconBox data-testid="min-max-icon" onClick={toggleMinMax}>
              {isMax ? <IconComponent src={Minimize} /> : <IconComponent src={Maximize} />}
            </HoverIconBox>
          </RightBox>
        </HeadBox>
        {isMax && (
          <ContentBox>
            <ContentHeadBox>
              <TypoBox>
                <TypographyComponent
                  variant="body1"
                  color={theme.palette.text.black}
                  children={pdfName}
                />
                <Box>
                  <TypographyComponent
                    variant="overline1"
                    color={theme.palette.text.mediumEmphasis}
                    children={SLIDE}
                  />
                  <TypographyComponent
                    variant="overline1"
                    color={theme.palette.text.black}
                    children={` ${currentIndex + 1}/`}
                  />
                  <TypographyComponent
                    variant="overline1"
                    color={theme.palette.text.mediumEmphasis}
                    children={content.length.toString()}
                  />
                </Box>
              </TypoBox>
              <IconBox>
                <HoverIconBox
                  data-testid="copy-icon"
                  onClick={() => handleCopyClick(content[currentIndex])}>
                  <IconComponent src={CopyIcon} />
                </HoverIconBox>
                <IconComponent src={MoreIcon} />
              </IconBox>
            </ContentHeadBox>
            <TypographyComponent
              variant="h4"
              color={theme.palette.text.lowEmphasis}
              children={formattedContent}
            />
          </ContentBox>
        )}
      </RootBox>
      {isCopied && <CopyComponent handleClose={closeCopyWindow} />}
    </PopupBox>
  );
};

export default SearchContentPopup;
