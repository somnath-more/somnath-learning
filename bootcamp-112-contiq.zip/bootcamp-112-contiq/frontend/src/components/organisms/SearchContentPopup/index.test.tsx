import React from 'react';
import SearchContentPopup from './index';
import { fireEvent, render, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import theme from '@src/themes';

describe('Testing the SearchContentPopup', () => {
  test('SearchContentPopup test', () => {
    render(
      <ThemeProvider theme={theme}>
        <SearchContentPopup searchKey={'Repair business'} pdfName={'some content'} content={[]} />
      </ThemeProvider>
    );
    const Test = screen.getByTestId('search-content-popup');
    expect(Test).toBeInTheDocument();

    const CopyIcon = screen.getByTestId('copy-icon');
    expect(CopyIcon).toBeInTheDocument();
    fireEvent.click(CopyIcon);

    const MinMax = screen.getByTestId('min-max-icon');
    expect(MinMax).toBeInTheDocument();
    fireEvent.click(MinMax);
  });

  test('SearchContentPopup test with content data', () => {
    render(
      <ThemeProvider theme={theme}>
        <SearchContentPopup
          searchKey={'Repair business'}
          pdfName={'some content'}
          content={[
            'Since being established in 1908 as a sewing machine repair business, the brother group has pursued the diversification and globalization of business in its history of more...',
            'Repair business some text',
            'Some text repair business some text'
          ]}
        />
      </ThemeProvider>
    );
    const Test = screen.getByTestId('search-content-popup');
    expect(Test).toBeInTheDocument();

    const UpArrow = screen.getByTestId('up-arrow');
    expect(UpArrow).toBeInTheDocument();
    fireEvent.click(UpArrow);

    const downArrow = screen.getByTestId('down-arrow');
    expect(downArrow).toBeInTheDocument();
    fireEvent.click(downArrow);

    const CopyIcon = screen.getByTestId('copy-icon');
    expect(CopyIcon).toBeInTheDocument();
    fireEvent.click(CopyIcon);
  });
});
