import React from 'react';
import '@testing-library/jest-dom/extend-expect';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { PRESENTATION_CARD } from '../../../utils/constants';
import FileDrop from '.';
describe('testing the file drop component', () => {
  test('Should render upload file', async () => {
    render(<FileDrop files={PRESENTATION_CARD} />);
    const file = new File(['file contents'], 'agreement.pdf', {
      type: 'application/pdf'
    });

    const inputFile = screen.getByTestId('file-drop');
    fireEvent.change(inputFile, { target: { files: [file] } });
  });
});
