import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import FileDrop, { IFileDropProps } from '.';

export default {
  title: 'organisms/FileDrop',
  component: FileDrop
} as Meta;

const Template: StoryFn<IFileDropProps> = (args) => <FileDrop {...args} />;

export const Default = Template.bind({});
Default.args = {
  files: []
};
