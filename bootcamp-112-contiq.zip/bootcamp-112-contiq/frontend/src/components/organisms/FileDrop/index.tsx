import React, { useState } from 'react';
import { Box, Button } from '@mui/material';
import { styled } from '@mui/system';
import { useDropzone } from 'react-dropzone';
import { CHOOSE_FILE_BUTTON, DROP_FILES_TEXT, UPLOAD_FILE_BUTTON } from '@utils/constants';
import theme from '@src/themes';
import Icon from '@components/atoms/Icon';
import MuiTypography from '@components/atoms/Typography';
import Upload from '@assets/icons/upload.svg';
import FileIcon from '@assets/images/pdf.svg';
import UploadConfimationModel from '../UploadConfirmationModel';
import ProgressBarModal from '@components/molecules/ProgressBarModal';
import { handleUploadButton, handleUpload } from '@src/utils/functions';

export interface IFilesType {
  id?: string;
  img: string;
  imgAlt: string;
  name: string;
  Date: string;
  icon: string;
  iconAlt: string;
}

export interface IFileDropProps {
  files: IFilesType[];
}

const RootContainer = styled(Box)({
  boxSizing: 'border-box',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  gap: '40px',
  height: '414px',
  maxWidth: '648px',
  padding: '32px 97px',
  borderRadius: '4px',
  border: `1px dashed ${theme.palette.grays.gray400}`,
  background: theme.palette.grays.gray400,
  borderImage: `repeating-linear-gradient(
    45deg,
    grey,
    grey 13px,
    transparent 13px,
    transparent 20px
  ) 1`
});

const MainContainer = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  gap: '18.67px'
});

const ChooseButtonStyles = {
  padding: '12px 41px',
  border: `1px solid ${theme.palette.grays.gray100}`,
  color: theme.palette.text.white,
  '&:hover': {
    border: `1px solid ${theme.palette.grays.gray100}`,
    color: theme.palette.text.white,
    background: theme.palette.grays.gray400
  },
  fontFamily: theme.typography.body1,
  textTransform: 'none'
};

const UploadButtonStyles = {
  padding: '8px 47px',
  background: theme.palette.primary.main,
  '&:hover': {
    background: theme.palette.primary.main
  },
  fontFamily: theme.typography.body1,
  textTransform: 'none'
};

const FileDrop = ({ files }: IFileDropProps) => {
  const [choose, setChoose] = useState<boolean>(true);
  const [text, setText] = useState<string>(DROP_FILES_TEXT);
  const [icon, setIcon] = useState<string>(Upload);
  const [uploadTriggered, setUploadTriggered] = useState<boolean>(false);
  const [showModal, setModal] = useState<any>(false);
  const [chosenFile, setChosenFile] = useState<File | null>(null)

  const handleFiles = (acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      setChoose(false);
      setChosenFile(acceptedFiles[0]);
      setText(acceptedFiles[0]?.name);
      setIcon(FileIcon);
    }
  };

  const { getRootProps, getInputProps } = useDropzone({
    onDrop: handleFiles
  });

  const handleCancelButton = (state: boolean) => {
    setUploadTriggered(!state);
  };

  return (
    <RootContainer>
      <MainContainer>
        <Icon src={icon} />
        <MuiTypography
          children={text}
          variant={choose ? 'subtitle2' : 'body1'}
          sx={{ color: theme.palette.text.white }}
        />
      </MainContainer>
      {choose ? (
        <>
          <Button
            {...getRootProps()}
            variant={'outlined'}
            children={CHOOSE_FILE_BUTTON}
            sx={ChooseButtonStyles}
          />
          <input data-testid="file-drop" {...getInputProps()} />
        </>
      ) : (
        <>
          {uploadTriggered ? (
            showModal ? (
              <UploadConfimationModel
                pdfName={text}
                handleCancel={handleCancelButton}
                handleUpload={() => handleUploadButton(text, chosenFile)}
              />
            ) : (
              <ProgressBarModal fileName={text} />
            )
          ) : (
            <Button
              variant={'contained'}
              children={UPLOAD_FILE_BUTTON}
              onClick={() => handleUpload(text, chosenFile, setModal, setUploadTriggered)}
              sx={UploadButtonStyles}
            />
          )}
        </>
      )}
    </RootContainer>
  );
};

export default FileDrop;
