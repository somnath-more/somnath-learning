import { Meta, StoryFn } from '@storybook/react';
import UploadConfimationModel, { UploadConfimationModelProps } from '.';
import { UPLOAD_MODEL_PDF_NAME } from '@utils/constants';

export default {
  title: 'Organisms/Confirmation Model',
  component: UploadConfimationModel
} as Meta;

const Template: StoryFn<UploadConfimationModelProps> = (args) => (
  <UploadConfimationModel {...args} />
);

export const Basic = Template.bind({});
Basic.args = {
  pdfName: UPLOAD_MODEL_PDF_NAME
};
