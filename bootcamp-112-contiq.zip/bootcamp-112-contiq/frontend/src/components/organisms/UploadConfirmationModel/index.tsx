import React from 'react';
import TypographyComponent from '@components/atoms/Typography';
import { styled, Box, Button } from '@mui/material';
import theme from '@src/themes';
import MuiButton from '@components/atoms/button';
import {
  UPLOAD_MODEL_HEADING,
  UPLOAD_MODEL_BODY,
  UPLOAD_MODEL_BUTTON1,
  UPLOAD_MODEL_BUTTON2
} from '@utils/constants';

export interface UploadConfimationModelProps {
  handleCancel?: any;
  handleUpload?: any;
  pdfName?: string;
}

const MainContainer = styled('div')({
  position: 'fixed',
  top: 0,
  left: 0,
  bottom: 0,
  right: 0,
  backgroundColor: theme.palette.structuralColor.overlay,
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  zIndex: 99
});

const RootBox = styled(Box)({
  width: theme.spacing(121),
  height: theme.spacing(61.5),
  borderRadius: theme.spacing(1),
  backgroundColor: theme.palette.grays.gray400
});

const BaseComponent = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
  padding: theme.spacing(8),
  gap: theme.spacing(5)
});

const FooterComponent = styled(Box)({
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'flex-end',
  gap: theme.spacing(4)
});

const UploadConfimationModel = ({
  handleCancel,
  handleUpload,
  pdfName
}: UploadConfimationModelProps) => {
  const handleUploadButton = () => {
    handleUpload(true);
  };

  const handleCancelButton = () => {
    handleCancel(true);
  };
  return (
    <MainContainer data-testid="confirmaiton-Model">
      <RootBox>
        <BaseComponent>
          <Box>
            <TypographyComponent
              children={UPLOAD_MODEL_HEADING}
              variant="h3"
              color={theme.palette.text.white}
            />
          </Box>
          <Box>
            <TypographyComponent
              children={pdfName}
              variant="subtitle2"
              color={theme.palette.text.white}
              display="inline"
            />
            <TypographyComponent
              children={UPLOAD_MODEL_BODY}
              variant="subtitle2"
              color={theme.palette.text.highEmphasis}
              display="inline"
            />
          </Box>
          <FooterComponent>
            <Button
              variant="outlined"
              onClick={handleCancelButton}
              sx={{
                textTransform: 'none',
                borderColor: theme.palette.grays.gray100,
                '&:hover': { borderColor: theme.palette.grays.gray100 },
                width: theme.spacing(15.75)
              }}>
              <TypographyComponent
                children={UPLOAD_MODEL_BUTTON1}
                variant="body1"
                color={theme.palette.text.white}
              />
            </Button>
            <MuiButton
              text={<TypographyComponent children={UPLOAD_MODEL_BUTTON2} variant="body1" />}
              variant="contained"
              onClick={handleUploadButton}
              sx={{
                width: theme.spacing(24)
              }}
            />
          </FooterComponent>
        </BaseComponent>
      </RootBox>
    </MainContainer>
  );
};

export default UploadConfimationModel;
