import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import UploadConfimationModel from '.';
import { ThemeProvider } from '@emotion/react';
import theme from '@src/themes';
import {
  UPLOAD_MODEL_HEADING,
  UPLOAD_MODEL_BUTTON1,
  UPLOAD_MODEL_BUTTON2,
  UPLOAD_MODEL_PDF_NAME
} from '@utils/constants';

describe('UploadConfimationModel Component', () => {
  const mockHandleCancel = jest.fn();
  const mockHandleUpload = jest.fn();
  const mockPdfName = UPLOAD_MODEL_PDF_NAME;

  test('renders the component with provided props', () => {
    render(
      <ThemeProvider theme={theme}>
        <UploadConfimationModel
          handleCancel={mockHandleCancel}
          handleUpload={mockHandleUpload}
          pdfName={mockPdfName}
        />
      </ThemeProvider>
    );

    const headingElement = screen.getByText(UPLOAD_MODEL_HEADING);
    const pdfNameElement = screen.getByText(mockPdfName);
    const cancelButton = screen.getByRole('button', { name: UPLOAD_MODEL_BUTTON1 });
    const uploadButton = screen.getByRole('button', { name: UPLOAD_MODEL_BUTTON2 });

    expect(headingElement).toBeInTheDocument();
    expect(pdfNameElement).toBeInTheDocument();
    expect(cancelButton).toBeInTheDocument();
    expect(uploadButton).toBeInTheDocument();
  });

  it('calls handleCancel when Cancel button is clicked', () => {
    render(
      <ThemeProvider theme={theme}>
        <UploadConfimationModel handleCancel={mockHandleCancel} handleUpload={mockHandleUpload} />
      </ThemeProvider>
    );

    const cancelButton = screen.getByRole('button', { name: UPLOAD_MODEL_BUTTON1 });
    fireEvent.click(cancelButton);

    expect(mockHandleCancel).toHaveBeenCalledTimes(1);
    expect(mockHandleUpload).not.toHaveBeenCalled();
  });

  it('calls handleUpload when Upload button is clicked', () => {
    render(
      <ThemeProvider theme={theme}>
        <UploadConfimationModel handleCancel={mockHandleCancel} handleUpload={mockHandleUpload} />
      </ThemeProvider>
    );

    const uploadButton = screen.getByRole('button', { name: UPLOAD_MODEL_BUTTON2 });
    fireEvent.click(uploadButton);

    expect(mockHandleUpload).toHaveBeenCalledTimes(1);
    expect(mockHandleCancel).not.toHaveBeenCalled();
  });
});
