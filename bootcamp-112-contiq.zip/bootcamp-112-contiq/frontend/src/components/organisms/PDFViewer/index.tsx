import React, { useRef, useEffect, useState, useCallback } from 'react';
import WebViewer from '@pdftron/pdfjs-express-viewer';
import { Box, styled, useTheme } from '@mui/material';
import { DEFAULT_ZOOM, MAX_ZOOM, MIN_ZOOM, NAVIGATE_FILE, PDF_LICENSE, PDF_STYLE } from '@src/utils/constants';
import TypographyComponent from '@components/atoms/Typography';
import IconComponent from '@components/atoms/Icon';
import BackIcon from '@assets/icons/chevron.svg';
import PaginationComponent from '@components/molecules/Pagination';
import SearchContentPopup from '../SearchContentPopup';
import { useNavigate } from 'react-router-dom';

interface PdfViewerProps {
  fileName: string;
  searchKey: string;
  fileRender: string;
}

const RootBox = styled(Box)({
  display: 'flex',
  flexDirection: 'column'
});

const TopBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'flex-start',
  padding: `${theme.spacing(7)} ${theme.spacing(6)}`
}));

const HeadBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'flex-end',
  gap: theme.spacing(1),
  marginBottom: theme.spacing(2)
}));

const IconBox = styled(Box)({
  cursor: 'pointer'
});

const WebViewerBox = styled(Box)({
  height: '90vh'
});

const PaginationBox = styled(Box)(({ theme }) => ({
  position: 'fixed',
  bottom: theme.spacing(5),
  zIndex: 25,
  left: '50%',
  transform: 'translateX(-50%)'
}));

const PdfViewer = ({ fileName, searchKey, fileRender }: PdfViewerProps) => {
  const viewerRef = useRef<HTMLDivElement | null>(null);
  const [searchResults, setSearchResults] = useState([]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [currentZoomLevel, setCurrentZoomLevel] = useState<number>(DEFAULT_ZOOM);
  const [docViewerState, setDocViewerState] = useState<any>({
    getZoomLevel: () => DEFAULT_ZOOM,
    getPageCount: () => 1,
    getCurrentPage: () => 1,
    zoomTo: () => Object,
    setCurrentPage: (pageNum: number) => Object
  });

  const theme = useTheme();
  const navigate = useNavigate()

  useEffect(() => {
    const webViewerElement = viewerRef.current;
    const webViewerIframe = document.querySelector(
      "iframe[title='webviewer']"
    ) as HTMLIFrameElement;

    webViewerIframe === null &&
      WebViewer(
        {
          path: '/webviewer/lib',
          initialDoc: fileRender,
          licenseKey: PDF_LICENSE,
          disabledElements: [
            'ribbons',
            'toolsHeader',
            'header',
            'leftPanelTabs',
            'thumbnailsSizeSlider',
            'leftPanelResizeBar',
            'contextMenuPopup',
            'textPopup',
            'pageNavOverlay',
            'searchPanel'
          ]
        },
        webViewerElement
      ).then((instance: any) => {
        const { documentViewer } = instance.Core;
        const iframeDoc = instance.UI.iframeWindow.document;
        instance.UI.openElements(['leftPanel']);

        const searchListener = function (searchValue: any, options: any, results: any) {
          const dhResults = results.map((element: { DH: any }) => element.DH);
          setSearchResults(dhResults);
        };

        documentViewer.setSearchHighlightColors({
          searchResult: 'rgba(255,215,73,0.25)',
          activeSearchResult: 'rgba(255,215,73,0.25)'
        });

        documentViewer.addEventListener('pageNumberUpdated', (pageNumber: number) => {
          setCurrentPage(pageNumber);
        });

        documentViewer.addEventListener('documentLoaded', async () => {
          setDocViewerState(documentViewer);
          const searchPattern = `[A-z][^.!?]*\\b${searchKey}\\b[^.!?]*\\.`;
          instance.UI.addSearchListener(searchListener);
          setCurrentZoomLevel(instance.UI.getZoomLevel());

          instance.UI.searchTextFull(searchPattern, {
            regex: true,
            wholeWord: true
          });
        });

        const iframeStyle = document.createElement('style');
        iframeStyle.innerHTML = PDF_STYLE;
        iframeDoc.head.appendChild(iframeStyle);
      });
  }, [searchKey]);

  const getFileNameWithoutExtension = (fileName: string): string => {
    const index = fileName.lastIndexOf('.');
    return index !== -1 ? fileName.substring(0, index) : fileName;
  };

  const handleBackIcon = useCallback(() => {
    navigate(NAVIGATE_FILE)
  }, []);

  const handleZoom = useCallback(
    (newZoomLevel: number) => {
      newZoomLevel = Math.min(Math.max(newZoomLevel, MIN_ZOOM), MAX_ZOOM);
      setCurrentZoomLevel(newZoomLevel);
      docViewerState.zoomTo(newZoomLevel);
    },
    [docViewerState]
  );

  const handleZoomOut = useCallback(() => {
    handleZoom(currentZoomLevel - 0.1);
  }, [currentZoomLevel, handleZoom]);

  const handleZoomIn = useCallback(() => {
    handleZoom(currentZoomLevel + 0.1);
  }, [currentZoomLevel, handleZoom]);

  return (
    <RootBox data-testid="Pdf-viewer">
      <TopBox>
        <HeadBox>
          <IconBox onClick={handleBackIcon}>
            <IconComponent src={BackIcon} />
          </IconBox>
          <TypographyComponent variant="h2" children={fileName} color={theme.palette.text.black} />
        </HeadBox>
        <Box sx={{ position: 'absolute', right: theme.spacing(6) }}>
          <SearchContentPopup
            searchKey={searchKey}
            pdfName={getFileNameWithoutExtension(fileName)}
            content={searchResults}
          />
        </Box>
      </TopBox>
      <Box>
        <WebViewerBox data-testid="webviewer" ref={viewerRef}></WebViewerBox>
      </Box>
      <PaginationBox>
        <PaginationComponent
          startPage={currentPage}
          endPage={docViewerState.getPageCount()}
          zoomValue={Math.round(currentZoomLevel * 100)}
          handleZoomOut={handleZoomOut}
          handleZoomIn={handleZoomIn}
        />
      </PaginationBox>
    </RootBox>
  );
};

export default PdfViewer;
