import type { Meta, StoryObj } from '@storybook/react';

import PdfViewer from './index';
import HooksPDF from '@assets/files/hooks.pdf';
import { BrowserRouter as Router } from 'react-router-dom';


const meta: Meta<typeof PdfViewer> = {
  title: 'organisms/PdfViewer',
  component: PdfViewer,
  decorators: [
    (Story) => (
      <Router>
        <Story />
      </Router>
    )
  ]
};

export default meta;
type Story = StoryObj<typeof PdfViewer>;

export const Basic: Story = {
  args: {
    fileName: 'React Hooks Cheatsheet.pdf',
    searchKey: 'State Variables',
    fileRender: HooksPDF
  }
};
