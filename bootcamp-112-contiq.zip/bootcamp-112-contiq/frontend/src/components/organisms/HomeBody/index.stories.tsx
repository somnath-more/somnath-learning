import { Meta, StoryFn } from '@storybook/react';
import HomeBody, { HomeBodyProps } from '.';
import { RECENT_FILE_DATA } from '@src/utils/constants';

export default {
  title: 'Organisms/HomeBody',
  component: HomeBody
} as Meta;

const Template: StoryFn<HomeBodyProps> = (args) => <HomeBody {...args} />;

export const WithOutData = Template.bind({});
WithOutData.args = {
  data: []
};

export const WithData = Template.bind({});
WithData.args = {
  data: RECENT_FILE_DATA
};
