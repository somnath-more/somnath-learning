import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import theme from '@src/themes';
import HomeBody from '.';
import { NO_FILES, START_SYNC_CONTIQ, HOME, RECENT, RECENT_FILE_DATA } from '@utils/constants';

describe('HomeBody Component', () => {
  test('renders HomeBody with no data', () => {
    const data: never[] = [];

    render(
      <ThemeProvider theme={theme}>
        <HomeBody data={data} />
      </ThemeProvider>
    );

    const homeHeader = screen.getByText('Home');
    expect(homeHeader).toBeInTheDocument();

    const noFilesHeading = screen.getByText(NO_FILES);
    expect(noFilesHeading).toBeInTheDocument();

    const startSyncText = screen.getByText(START_SYNC_CONTIQ);
    expect(startSyncText).toBeInTheDocument();

    expect(screen.getByTestId('home-body')).toBeInTheDocument();
  });

  test('renders HomeBody with data', () => {
    const data = RECENT_FILE_DATA;

    render(
      <ThemeProvider theme={theme}>
        <HomeBody data={data} />
      </ThemeProvider>
    );

    const homeHeader = screen.getByText(HOME);
    expect(homeHeader).toBeInTheDocument();

    const recentHeading = screen.getByText(RECENT);
    expect(recentHeading).toBeInTheDocument();

    const presentationCards = screen.getAllByTestId('presentation-card');
    expect(presentationCards).toHaveLength(data.length);

    jest.spyOn(console, 'log').mockImplementation(() => {});
    fireEvent.click(presentationCards[0]);
    expect(console.log).toHaveBeenCalledWith(data[0].name);
  });
});
