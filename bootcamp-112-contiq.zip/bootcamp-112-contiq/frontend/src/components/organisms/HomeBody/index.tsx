import React from 'react';
import { Box, styled, useTheme } from '@mui/material';
import TypographyComponent from '@components/atoms/Typography';
import ImageWithTypography from '@components/molecules/ImageWithTypography';
import PresentationCard from '@components/molecules/PresentationCard';
import NOFIle from '@assets/images/NoFiles.svg';
import { NO_FILES, START_SYNC_CONTIQ, HOME, RECENT } from '@utils/constants';
import CardImg from '@assets/images/DigitalTransformation.svg';

interface DataDetails {
  id: number;
  name: string;
}

export interface HomeBodyProps {
  data: Array<DataDetails>;
}

const RootBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  width: '93.9vw',
  height: '92vh',
  backgroundColor: theme.palette.text.white
}));

const HeaderBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  paddingLeft: `${theme.spacing(6)}`,
  height: '12vh'
}));

const ImageBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  height: '80vh'
}));

const TemplateBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(4),
  padding: `${theme.spacing(6)}`,
  height: '80vh'
}));

const CardBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'row',
  flexWrap: 'wrap',
  gap: theme.spacing(4)
}));

const SingleCardBox = styled(Box)(({ theme }) => ({
  cursor: 'pointer'
}));

const HomeBody = ({ data }: HomeBodyProps) => {
  const theme = useTheme();

  const handleCardClick = (name: string) => {
    console.log(name);
  };
  return (
    <RootBox data-testid="home-body">
      <HeaderBox>
        <TypographyComponent children={HOME} variant="h2" color={theme.palette.text.black} />
      </HeaderBox>
      {data.length != 0 ? (
        <TemplateBox>
          <TypographyComponent
            children={RECENT}
            variant="h3"
            color={theme.palette.text.lowEmphasis}
          />
          <CardBox>
            {data.map((data) => (
              <SingleCardBox
                key={data.id}
                onClick={() => {
                  handleCardClick(data.name);
                }}>
                <PresentationCard cardImage={CardImg} pdfName={data.name} />
              </SingleCardBox>
            ))}
          </CardBox>
        </TemplateBox>
      ) : (
        <ImageBox>
          <ImageWithTypography image={NOFIle} heading={NO_FILES} value={START_SYNC_CONTIQ} />
        </ImageBox>
      )}
    </RootBox>
  );
};

export default HomeBody;
