import type { Meta, StoryFn } from '@storybook/react';
import PasswordReset from './index';
import { BrowserRouter as Router } from 'react-router-dom';

export default {
  title: 'Organisms/Password Reset',
  component: PasswordReset,
  decorators: [
    (Story) => (
      <Router>
        <Story />
      </Router>
    )
  ]
} as Meta;

const Template: StoryFn = (args) => <PasswordReset {...args} />;

export const Basic = Template.bind({});
