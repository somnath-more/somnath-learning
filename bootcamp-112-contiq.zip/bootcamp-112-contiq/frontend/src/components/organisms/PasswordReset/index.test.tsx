import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import { ThemeProvider } from '@mui/material/styles';
import theme from '@src/themes';
import PasswordReset from '.';
import {
  PASSWORD_RESET,
  PASSWORD_RESET_MESSAGE1,
  PASSWORD_RESET_MESSAGE2,
  PASSWORD_RESET_BUTTON
} from '@utils/constants';
import { BrowserRouter as Router } from 'react-router-dom';

describe('Testing the PasswordReset component', () => {
  test('renders PasswordReset component', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <PasswordReset />
        </Router>
      </ThemeProvider>
    );

    const passwordResetRoot = screen.getByTestId('password-reset');
    expect(passwordResetRoot).toBeInTheDocument();

    const headerText = screen.getByText(PASSWORD_RESET);
    expect(headerText).toBeInTheDocument();

    const message1 = screen.getByText(PASSWORD_RESET_MESSAGE1);
    expect(message1).toBeInTheDocument();

    const message2 = screen.getByText(PASSWORD_RESET_MESSAGE2);
    expect(message2).toBeInTheDocument();

    const resetButton = screen.getByTestId('password-reset-btn');
    expect(resetButton).toBeInTheDocument();
    expect(resetButton).toHaveTextContent(PASSWORD_RESET_BUTTON);
    expect(resetButton).toBeEnabled();
  });

  test('clicking the reset button triggers handlePasswordReset', () => {
    window.alert = jest.fn();

    render(
      <ThemeProvider theme={theme}>
        <Router>
          <PasswordReset />
        </Router>
      </ThemeProvider>
    );

    const resetButton = screen.getByTestId('password-reset-btn');
    fireEvent.click(resetButton);
  });
});
