import React from 'react';
import { Box, Button, styled, useTheme } from '@mui/material';
import TypographyComponent from '@components/atoms/Typography';
import {
  PASSWORD_RESET,
  PASSWORD_RESET_MESSAGE1,
  PASSWORD_RESET_MESSAGE2,
  PASSWORD_RESET_BUTTON,
  NAVIGATE_SIGNIN
} from '@utils/constants';
import ImageComponent from '@components/atoms/image';
import Complete from '../../../../public/assets/images/verified.gif';
import { useNavigate } from 'react-router-dom';

export const RootBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(8),
  width: theme.spacing(89)
}));

export const HeaderBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(2)
}));

export const SubHeaderBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  gap: theme.spacing(4)
}));

export const MessageBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column'
}));

export const ResetButton = styled(Button)(({ theme }) => ({
  height: theme.spacing(12),

  '&.MuiButton-root': {
    ...theme.typography.body1,
    color: theme.palette.text.white,
    textTransform: 'none',
    boxShadow: 'none'
  },
  ':disabled': {
    backgroundColor: theme.palette.primary.light
  },
  '&:hover': {
    backgroundColor: `${theme.palette.primary.main} !important`
  }
}));

const PasswordReset = () => {
  const theme = useTheme();
  const navigate = useNavigate();

  const handlePasswordReset = () => {
    navigate(NAVIGATE_SIGNIN);
  };

  return (
    <RootBox data-testid="password-reset">
      <HeaderBox>
        <SubHeaderBox>
          <TypographyComponent
            variant="h2"
            children={PASSWORD_RESET}
            color={theme.palette.text.black}
          />
          <ImageComponent
            imgSrc={Complete}
            sx={{ width: theme.spacing(6), height: theme.spacing(5.85) }}
          />
        </SubHeaderBox>
        <MessageBox>
          <TypographyComponent
            variant="overline1"
            children={PASSWORD_RESET_MESSAGE1}
            color={theme.palette.text.mediumEmphasis}
          />
          <TypographyComponent
            variant="overline1"
            children={PASSWORD_RESET_MESSAGE2}
            color={theme.palette.text.mediumEmphasis}
          />
        </MessageBox>
      </HeaderBox>
      <ResetButton
        data-testid="password-reset-btn"
        variant="contained"
        onClick={handlePasswordReset}
        disabled={false}>
        {PASSWORD_RESET_BUTTON}
      </ResetButton>
    </RootBox>
  );
};

export default PasswordReset;
