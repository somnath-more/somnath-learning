import React, { useCallback, useState } from 'react';
import { Box, useTheme } from '@mui/material';
import TypographyComponent from '@components/atoms/Typography';
import {
  ALREADY_ACCOUNT,
  CREATE_ACCOUNT,
  EMAIL,
  EMAIL_ERROR,
  EMAIL_PLACEHOLDER,
  NAME,
  NAME_ERROR,
  NAME_PLACEHOLDER,
  NAVIGATE_SIGNIN,
  PASSWORD,
  PASSWORD_ERROR,
  PASSWORD_PLACEHOLDER,
  SIGN_IN,
  SIGN_UP,
  WITH_GOOGLE
} from '@utils/constants';
import InputFieldWithTypography from '@components/molecules/TextFieldWithTypography';
import LineDivider from '@components/atoms/LineDivider';
import { EMAIL_REGEX, PASSWORD_REGEX, USERNAME_REGEX } from '@utils/regex';
import { inputValidator } from '@utils/functions';
import GoogleLogo from '@assets/icons/googleLogo.svg';
import IconComponent from '@components/atoms/Icon';
import {
  RootBox,
  ContentBox,
  StyledBox,
  SignInButton as CreateAccountButton,
  GoogleButton,
  TypoBox
} from '../SignIn';
import { useNavigate } from 'react-router-dom';
import { useAuth0 } from '@auth0/auth0-react';

interface SignUpProps {
  onSignUp?: any;
}

const SignUpOrganism = ({ onSignUp }: SignUpProps) => {
  const theme = useTheme();
  const { loginWithRedirect } = useAuth0();

  const navigate = useNavigate();

  const [name, setname] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [emailError, setEmailError] = useState<string>(' ');
  const [passwordError, setPasswordError] = useState<string>(' ');
  const [nameError, setNameError] = useState<string>(' ');

  const handleName = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const newName = event.target.value;
    setname(newName);
    setNameError(inputValidator(newName, USERNAME_REGEX) ? '' : NAME_ERROR);
  }, []);

  const handleEmail = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const newEmail = event.target.value;
    setEmail(newEmail);
    setEmailError(inputValidator(newEmail, EMAIL_REGEX) ? '' : EMAIL_ERROR);
  }, []);

  const renderSignIn = useCallback(() => {
    navigate(NAVIGATE_SIGNIN);
  }, []);

  const handlePassword = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const newPassword = event.target.value;
    setPassword(newPassword);
    setPasswordError(inputValidator(newPassword, PASSWORD_REGEX) ? '' : PASSWORD_ERROR);
  }, []);

  const handleSignUp = useCallback(() => {
    onSignUp(name, email, password);
  }, [email, password]);

  const handleGoogleSignIn = useCallback(() => {
    loginWithRedirect();
  }, []);

  const formFields = [
    {
      label: NAME,
      value: name,
      placeholder: NAME_PLACEHOLDER,
      error: nameError,
      handleChange: handleName
    },
    {
      label: EMAIL,
      value: email,
      placeholder: EMAIL_PLACEHOLDER,
      error: emailError,
      handleChange: handleEmail
    },
    {
      label: PASSWORD,
      value: password,
      placeholder: PASSWORD_PLACEHOLDER,
      error: passwordError,
      handleChange: handlePassword,
      type: 'password'
    }
  ];

  const isSignUpEnabled = [nameError, passwordError, emailError].every(
    (errorArray) => errorArray.length === 0
  );

  return (
    <RootBox data-testid="sign-up-organism">
      <TypographyComponent variant="h2" children={SIGN_UP} color={theme.palette.text.black} />
      <ContentBox>
        {formFields.map((field) => (
          <Box key={field.label}>
            <InputFieldWithTypography
              text={field.label}
              value={field.value}
              placeholder={field.placeholder}
              type={field.type}
              handleChange={field.handleChange}
            />
            <TypographyComponent
              variant="overline1"
              children={field.error}
              color={theme.palette.structuralColor.main}
            />
          </Box>
        ))}
      </ContentBox>

      <StyledBox>
        <CreateAccountButton
          data-testid="signUp-btn"
          variant="contained"
          onClick={handleSignUp}
          disabled={!isSignUpEnabled}>
          {CREATE_ACCOUNT}
        </CreateAccountButton>

        <LineDivider />

        <GoogleButton
          data-testid="gooble-btn"
          variant="contained"
          onClick={handleGoogleSignIn}
          startIcon={<IconComponent src={GoogleLogo} />}>
          {WITH_GOOGLE}
        </GoogleButton>

        <TypoBox>
          <TypographyComponent
            variant="caption1"
            children={ALREADY_ACCOUNT}
            color={theme.palette.text.mediumEmphasis}
          />
          <TypographyComponent
            variant="caption1"
            children={SIGN_IN}
            color={theme.palette.primary.main}
            onClick={renderSignIn}
            sx={{ cursor: 'pointer' }}
          />
        </TypoBox>
      </StyledBox>
    </RootBox>
  );
};

export default SignUpOrganism;
