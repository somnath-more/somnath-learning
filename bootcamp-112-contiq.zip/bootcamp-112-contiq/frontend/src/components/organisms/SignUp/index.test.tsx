import React from 'react';
import SignUpOrganism from './index';
import { fireEvent, render, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import theme from '@src/themes';
import { BrowserRouter as Router } from 'react-router-dom';
import { useAuth0 } from '@auth0/auth0-react';

jest.mock('@auth0/auth0-react', () => ({
  useAuth0: jest.fn()
}));

const loginWithRedirectMock = jest.fn();
(useAuth0 as jest.Mock).mockReturnValue({
  loginWithRedirect: loginWithRedirectMock
});

const mockOnSignUp = jest.fn();

describe('Testing the SignUpOrganism', () => {
  test('SignUpOrganism test', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <SignUpOrganism onSignUp={mockOnSignUp} />
        </Router>
      </ThemeProvider>
    );
    const Test = screen.getByTestId('sign-up-organism');
    expect(Test).toBeInTheDocument();
  });

  test('SignUpOrganism test input fields', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <SignUpOrganism onSignUp={mockOnSignUp} />
        </Router>
      </ThemeProvider>
    );

    const mameIP = screen.getByPlaceholderText('John Cena');
    expect(mameIP).toBeInTheDocument();
    fireEvent.change(mameIP);
    fireEvent.change(mameIP, {
      target: { value: 'John Cena' }
    });
    fireEvent.change(mameIP, { target: { value: '' } });

    const emailIP = screen.getByPlaceholderText('john@example.com');
    expect(emailIP).toBeInTheDocument();
    fireEvent.change(emailIP);
    fireEvent.change(emailIP, {
      target: { value: 'test@gmail.com' }
    });
    fireEvent.change(emailIP, { target: { value: '' } });

    const passIP = screen.getByPlaceholderText('Create a password');
    expect(passIP).toBeInTheDocument();
    fireEvent.change(passIP);
    fireEvent.change(passIP, {
      target: { value: 'Test@1234' }
    });
    fireEvent.change(passIP, { target: { value: '' } });
  });

  test('SignUpOrganism test buttons', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <SignUpOrganism onSignUp={mockOnSignUp} />
        </Router>
      </ThemeProvider>
    );

    const mameIP = screen.getByPlaceholderText('John Cena');
    const emailIP = screen.getByPlaceholderText('john@example.com');
    const passIP = screen.getByPlaceholderText('Create a password');
    const signInBtn = screen.getByTestId('signUp-btn');
    expect(signInBtn).toBeDisabled();

    fireEvent.change(mameIP, {
      target: { value: 'John Cena' }
    });
    expect(mameIP).toHaveValue('John Cena');

    fireEvent.change(emailIP, {
      target: { value: 'test@gmail.com' }
    });
    expect(emailIP).toHaveValue('test@gmail.com');

    fireEvent.change(passIP, {
      target: { value: 'Test@1234' }
    });
    expect(passIP).toHaveValue('Test@1234');

    expect(signInBtn).toBeEnabled();
    fireEvent.click(signInBtn);

    const googleBtn = screen.getByTestId('gooble-btn');
    expect(googleBtn).toBeInTheDocument();
    fireEvent.click(googleBtn);
  });

  test('SignUpOrganism test for text click', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <SignUpOrganism onSignUp={mockOnSignUp} />
        </Router>
      </ThemeProvider>
    );

    const signUpText = screen.getByText('Sign In');
    expect(signUpText).toBeInTheDocument();
    fireEvent.click(signUpText);
  });
});
