import type { Meta, StoryObj } from '@storybook/react';

import SignUpOrganism from './index';
import { BrowserRouter as Router } from 'react-router-dom';

const meta: Meta<typeof SignUpOrganism> = {
  title: 'organisms/SignUpOrganism',
  component: SignUpOrganism,
  decorators: [
    (Story) => (
      <Router>
        <Story />
      </Router>
    )
  ]
};

export default meta;
type Story = StoryObj<typeof SignUpOrganism>;

export const SignUp: Story = {
  args: {}
};
