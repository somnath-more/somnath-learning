import React from 'react';
import TypographyComponent from '@components/atoms/Typography';
import IconComponent from '@components/atoms/Icon';
import GooleDrive from '@assets/images/GoogleDrive.svg';
import DropBox from '@assets/images/DropBox.svg';
import TeraBox from '@assets/images/TeraBox.svg';
import Cloud from '@assets/images/Cloud.svg';
import { styled, Box } from '@mui/material';
import { DRAG_MEDIA_CONTENT, DISCOVERY_DOCS, SCOPE } from '@utils/constants';
import theme from '@src/themes';
import { gapi } from 'gapi-script';

interface CloudStorageProps {
  onDataReceived: (folderData: any[], files: any[]) => void;
}

const RootBox = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
  alignItems: 'center',
  height: theme.spacing(103.5),
  borderRadius: theme.spacing(2),
  backgroundColor: theme.palette.grays.gray400,
  padding: theme.spacing(35),
  boxSizing: 'border-box',
  border: `1px dashed ${theme.palette.grays.gray200}`,
  maxWidth: theme.spacing(162),
  borderImage: `repeating-linear-gradient(
    45deg,
    grey,
    grey 11px,
    transparent 11px,
    transparent 20px
  )1`
});

const TextComponent = styled('div')({
  display: 'flex',
  flexDirection: 'column',
  width: theme.spacing(54),
  height: theme.spacing(12.75),
  justifyContent: 'center',
  alignItems: 'center'
});

const ImageContainer = styled('div')({
  display: 'flex',
  flexDirection: 'row',
  width: theme.spacing(74),
  height: theme.spacing(12.5),
  justifyContent: 'space-between',
  gap: theme.spacing(8),
  cursor:'pointer'
});

const CloudStorage: React.FC<CloudStorageProps> = ({ onDataReceived }) => {

  const initClient = () => {
    gapi.client
      .init({
        apiKey: process.env.REACT_APP_API_KEY,
        clientId: process.env.REACT_APP_CLIENT_ID,
        discoveryDocs: DISCOVERY_DOCS,
        scope: SCOPE
      })
      .then(
        (data: any) => {
          gapi.auth2.getAuthInstance().isSignedIn.listen(updateSigninStatus);
          updateSigninStatus(gapi.auth2.getAuthInstance().isSignedIn.get());
        },
        (error: any) => console.log(error)
      );
  };

  const updateSigninStatus = (isSignedIn: boolean) => {
    if (isSignedIn) {
      listFiles();
    } else {
      gapi.auth2.getAuthInstance().signIn();
    }
  };

  const listFiles = (searchTerm = null) => {
    gapi.client.drive.files
      .list({
        fields: 'files'
      })
      .then((response: any) => {
        const res = JSON.parse(response.body);
        const folderData = res.files.filter(
          (file: any) => file?.mimeType.split('.').pop()?.toLowerCase() === 'folder'
        );
        const files = res.files.filter((file: any) =>
          file?.mimeType.split('.').pop()?.toLowerCase().includes('pdf')
        );
        onDataReceived(folderData, files);
      })
      .catch((error: any) => console.log(error));
  };

  const handleClientLoad = () => {
    gapi.load('client:auth2', initClient);
  };

  return (
    <Box>
      <RootBox>
        <TextComponent>
          <TypographyComponent
            children={DRAG_MEDIA_CONTENT[0]}
            variant="subtitle2"
            sx={{ color: theme.palette.text.white }}
          />
          <TypographyComponent
            children={DRAG_MEDIA_CONTENT[1]}
            variant="subtitle2"
            sx={{ color: theme.palette.text.white }}
          />
        </TextComponent>
        <ImageContainer>
          <IconComponent src={GooleDrive} height="50px" width="50px" onclick={handleClientLoad} />
          <IconComponent src={DropBox} height="50px" width="50px" />
          <IconComponent src={Cloud} height="50px" width="50px" />
          <IconComponent src={TeraBox} height="50px" width="50px" />
        </ImageContainer>
      </RootBox>
    </Box>
  );
};

export default CloudStorage;
