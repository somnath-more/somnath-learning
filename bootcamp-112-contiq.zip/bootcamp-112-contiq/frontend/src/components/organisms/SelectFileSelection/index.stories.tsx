import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import SelectFileSelection, { SelectFolderProps } from './index';

export default {
  title: 'organisms/SelectFileSelection',
  component: SelectFileSelection
} as Meta;

const Template: StoryFn<SelectFolderProps> = (args) => <SelectFileSelection {...args} />;

export const Default = Template.bind({});
Default.args = {
  folderData: [{ name: 'prasad' }, { name: 'sai' }, { name: 'veera' }, { name: 'zemoso' }],
  fileData: [{ name: 'company' }],
  callBackFromParent: () => {}
};
