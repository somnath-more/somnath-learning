import React, { useEffect, useState } from 'react';
import { Divider, List, ListItem, ListItemButton, Button, Box } from '@mui/material';
import IconComponent from '@components/atoms/Icon';
import FolderCard from '@components/molecules/FolderCard';
import RadioButtonGroup from '@components/molecules/RadioButtonGroup';
import { styled } from '@mui/system';
import theme from '@src/themes';
import LeftArrow from '@assets/icons/LeftArrow.svg';
import CloseWhite from '@assets/icons/closeWhiteColor.svg';
import {
  BACK_BUTTON,
  SYNC_BUTTON,
  FOLDER_TITLE,
  FORM_CONTENT,
  RADIO_BUTTON_GROUP
} from '@utils/constants';
import TypographyComponent from '@components/atoms/Typography';
import {
  uploadGoogleDriveFile,
  AddNotificationData,
  deleteFileById,
  fetchFileByName
} from '@src/service';

export interface SelectFolderProps {
  folderData: any[];
  fileData: any[];
  callBackFromParent: any;
}

const CenteredContainer = styled(Box)({
  position: 'fixed',
  top: 0,
  left: 0,
  bottom: 0,
  right: 0,
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: theme.palette.structuralColor.overlay
});

const RootContainer = styled(Box)({
  width: '696px',
  height: '598px',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
  background: theme.palette.grays.gray400
});

const HeaderContainer = styled(Box)({
  cursor: 'pointer',
  display: 'flex',
  justifyContent: 'space-between',
  padding: '24px 29px 28px 33px',
  borderBottom: `1px solid ${theme.palette.grays.gray400}`,
  position: 'relative'
});

const HeaderBox = styled(Box)({
  display: 'flex',
  gap: '12px'
});

const ButtonGroup = styled(Box)({
  display: 'flex',
  justifyContent: 'flex-end'
});

const RadioContainer = styled(Box)({
  padding: '16px 40px 16px 40px'
});

const MainContainer = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  height: '400px'
});

const ButtonContainer = styled('div')({
  display: 'flex',
  alignItems: 'flex-start',
  gap: '12px',
  padding: '45px 45px 40px 0px'
});

const Scrollbar = styled(Box)({
  overflowY: 'scroll',
  maxHeight: '444px',
  scrollbarWidth: 'none',
  '&::-webkit-scrollbar': {
    width: '0.4em',
    height: '0.4em'
  },
  '&::-webkit-scrollbar-thumb': {
    backgroundColor: 'rgba(0, 0, 0, 0)'
  },
  '&::-webkit-scrollbar-track': {
    backgroundColor: 'transparent'
  }
});

const SelectFileSelection = ({ folderData, fileData, callBackFromParent }: SelectFolderProps) => {
  const [title, setTitle] = useState(FOLDER_TITLE);
  const [showFolder, setShowFolder] = useState(true);
  const [titleId, setTitleId] = useState<string>();
  const [files, setFiles] = useState<object>({});
  const [disable, setDisable] = useState(true);
  const [showModal, setShowModal] = useState(true);
  const [selectedFiles, setSelectedFiles] = useState<Array<{ fileId: string; fileName: string }>>(
    []
  );
  const handleClickFolder = () => {
    setShowFolder(false);
    setFiles(fileData);
  };

  const handleClose = () => {
    setShowModal(false);
    window.location.reload();
  };

  const handleArrow = () => {
    setTitle(FOLDER_TITLE);
    setShowFolder(true);
  };

  const handleCheckbox = (fileId: string, fileName: string) => {
    const itemExists = selectedFiles.some(
      (file) => file.fileId === fileId && file.fileName === fileName
    );

    if (itemExists) {
      setSelectedFiles((prevSelectedFiles) =>
        prevSelectedFiles.filter((file) => !(file.fileId === fileId && file.fileName === fileName))
      );
    } else {
      setSelectedFiles((prevSelectedFiles) => [...prevSelectedFiles, { fileId, fileName }]);
    }

    setDisable(false);
  };

  useEffect(() => {
    callBackFromParent(selectedFiles);
  }, [selectedFiles, callBackFromParent]);

  const handleSyncButtonClick = async () => {
    try {
      const uploadPromises = selectedFiles.map(async ({ fileId, fileName }) => {
        const check = await fetchFileByName(fileName);
        if (!check) {
          await uploadGoogleDriveFile(fileId);
          await AddNotificationData(fileName, 'UPLOADED');
        } else {
          await deleteFileById(fileName);
          await uploadGoogleDriveFile(fileId);
          await AddNotificationData(fileName, 'UPDATED');
        }
      });

      await Promise.all(uploadPromises);

      window.location.reload();
    } catch (error) {
      console.error('An error occurred:', error);
    }
  };

  return (
    <CenteredContainer
      sx={{
        display: showModal ? '' : 'none'
      }}>
      <RootContainer>
        <HeaderContainer>
          <HeaderBox>
            <IconComponent
              src={LeftArrow}
              onclick={() => (showFolder ? handleClose() : handleArrow())}
            />
            <TypographyComponent
              children={title}
              variant="h3"
              sx={{ color: theme.palette.text.white }}
            />
          </HeaderBox>
          <IconComponent src={CloseWhite} onclick={handleClose} />
        </HeaderContainer>
        <Divider variant="fullWidth" sx={{ color: theme.palette.grays.gray300, height: '1px' }} />
        <MainContainer>
          {showFolder && (
            <>
              <TypographyComponent
                children={FORM_CONTENT}
                variant="body2"
                sx={{ color: theme.palette.text.white }}
                paddingLeft={'24px'}
                paddingTop={'16px'}
              />
              <RadioContainer>
                <RadioButtonGroup radioButtons={RADIO_BUTTON_GROUP} />
              </RadioContainer>
            </>
          )}
          <Scrollbar>
            {showFolder ? (
              <List sx={{ paddingTop: '10px' }}>
                {folderData.map((item: any) => (
                  <ListItem key={item.name}>
                    <ListItemButton
                      data-testid="listItemButton"
                      onClick={() => {
                        setTitle(item.name);
                        setTitleId(item.id);
                        handleClickFolder();
                      }}>
                      <FolderCard folderName={item.name} isFile={false} />
                    </ListItemButton>
                  </ListItem>
                ))}
              </List>
            ) : (
              <List sx={{ paddingTop: '32px' }}>
                {fileData
                  .filter((file) => file.parents.includes(titleId))
                  .filter(async (file) => {
                    if (file.trashed && (await fetchFileByName(file.name))) {
                      deleteFileById(file.name);
                      AddNotificationData(file.name, 'DELETED');
                      return false;
                    }
                    return !file.trashed;
                  })
                  .filter((file) => file.trashed === false)
                  .map((item) => {
                    return (
                      <ListItem key={item.id}>
                        <ListItemButton>
                          <FolderCard
                            folderName={item.name}
                            isFile={true}
                            onchange={() => {
                              handleCheckbox(item.id, item.name);
                            }}
                            isChecked={selectedFiles.some(
                              (file) => file.fileId === item.id && file.fileName === item.name
                            )}
                          />
                        </ListItemButton>
                      </ListItem>
                    );
                  })}
              </List>
            )}
          </Scrollbar>
        </MainContainer>
        <ButtonGroup>
          <ButtonContainer>
            <Button
              children={BACK_BUTTON}
              variant={'outlined'}
              onClick={() => {
                showFolder ? handleClose() : handleArrow();
              }}
              sx={{
                fontFamily: theme.typography.body1,
                textTransform: 'none',
                fontSize: '12px',
                border: `1px solid ${theme.palette.grays.gray200}`,
                color: theme.palette.grays.gray200,
                background: theme.palette.grays.gray400,
                '&:hover': {
                  border: `1px solid ${theme.palette.grays.gray200}`,
                  color: theme.palette.grays.gray200,
                  background: theme.palette.grays.gray400
                }
              }}
            />
            <Button
              children={SYNC_BUTTON}
              variant={'contained'}
              disabled={disable}
              sx={{
                fontFamily: theme.typography.body1,
                fontSize: '12px',
                textTransform: 'none',
                '&.Mui-disabled': {
                  background: theme.palette.primary.light
                },
                '&:hover': {
                  background: theme.palette.primary.main
                }
              }}
              onClick={handleSyncButtonClick}
            />
          </ButtonContainer>
        </ButtonGroup>
      </RootContainer>
    </CenteredContainer>
  );
};

export default SelectFileSelection;
