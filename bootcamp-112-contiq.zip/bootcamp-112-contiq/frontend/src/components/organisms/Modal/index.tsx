import React, { useState } from 'react';
import { styled } from '@mui/system';
import theme from '@src/themes';
import { Box, Divider } from '@mui/material';
import LeftArrow from '@assets/icons/LeftArrow.svg';
import CloseWhite from '@assets/icons/closeWhiteColor.svg';
import IconComponent from '@components/atoms/Icon';
import TypographyComponent from '@components/atoms/Typography';
import MuiTabs from '@components/molecules/MuiTabs';
import CloudStorage from '../CloudStorage';
import FileDrop from '../FileDrop';
import SelectFileSelection from '@components/organisms/SelectFileSelection';
import SyncProgress from '@components/molecules/SyncProgress';

interface ModalProps {
  handleClose: () => void;
}

const CenteredContainer = styled(Box)({
  position: 'fixed',
  top: 0,
  bottom: 0,
  left: 0,
  right: 0,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: theme.palette.structuralColor.overlay
});

const RootContainer = styled(Box)({
  width: '696px',
  display: 'flex',
  flexDirection: 'column',
  background: theme.palette.grays.gray400
});

const HeaderContainer = styled(Box)({
  display: 'flex',
  justifyContent: 'space-between',
  padding: '24px 24px 24px 24px',
  borderBottom: `1px solid ${theme.palette.grays.gray400}`,
  cursor: 'pointer'
});

const HeaderBox = styled(Box)({
  display: 'flex',
  gap: '12px'
});

const MainContainer = styled(Box)({
  display: 'block',
  alignItems: 'center',
  padding: '25px'
});

const Modal = ({ handleClose }: ModalProps) => {
  const [selectedTab, setSelectedTab] = useState('Uploads');
  const [isSyncProgressVisible, setIsSyncProgressVisible] = useState(false);
  const [isFileSectionVisible, setIsFileSectionVisible] = useState(false);
  const [cloudFolderData, setCloudFolderData] = useState<any[]>([]);
  const [cloudFilesData, setCloudFilesData] = useState<any[]>([]);

  const handleTabChange = (tabName: string) => {
    setSelectedTab(tabName);
  };
  const handleCancelButton = () => {
    handleClose();
  };
  const handleDataFromChild = (folderData: any, filesData: any) => {
    setIsSyncProgressVisible(true);

    setTimeout(() => {
      setIsSyncProgressVisible(false);
      setIsFileSectionVisible(true);
      setCloudFolderData(folderData);

      setCloudFilesData(filesData);
    }, 1000);
  };

  const handleDataFromChildTwo = (items: string[]) => {
    console.log(items);
  };

  return (
    <CenteredContainer>
      <RootContainer>
        {isSyncProgressVisible && <SyncProgress />}
        {isFileSectionVisible ? (
          <SelectFileSelection
            folderData={cloudFolderData}
            fileData={cloudFilesData}
            callBackFromParent={handleDataFromChildTwo}
          />
        ) : (
          <>
            <HeaderContainer>
              <HeaderBox>
                <IconComponent src={LeftArrow} onclick={handleCancelButton} />
                <TypographyComponent
                  children={'Upload files'}
                  variant="h3"
                  sx={{ color: theme.palette.text.white }}
                />
              </HeaderBox>
              <IconComponent src={CloseWhite} onclick={handleCancelButton} />
            </HeaderContainer>
            <Divider
              variant="fullWidth"
              sx={{ color: theme.palette.grays.gray300, height: '1px' }}
            />
            <MuiTabs
              variant="fullWidth"
              tabNames={['Uploads', 'Cloud storage']}
              selectedColor={theme.palette.text.white}
              backgroundColor={theme.palette.grays.gray400}
              notSelectedColor={theme.palette.text.mediumEmphasis}
              borderBottom={`2px solid ${theme.palette.grays.gray200}`}
              onSelectTab={handleTabChange}
              selectedTab={selectedTab}
            />
            <MainContainer>
              {selectedTab === 'Uploads' ? (
                <FileDrop files={[]} />
              ) : (
                <CloudStorage onDataReceived={handleDataFromChild} />
              )}
            </MainContainer>
          </>
        )}
      </RootContainer>
    </CenteredContainer>
  );
};

export default Modal;
