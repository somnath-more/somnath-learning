import React from 'react';
import { StoryFn, Meta } from '@storybook/react';
import Modal from './index';

export default {
  title: 'organisms/Modal',
  component: Modal
} as Meta;

const Template: StoryFn = (args) => <Modal handleClose={function (): void {
  throw new Error('Function not implemented.');
} } {...args} />;

export const Default = Template.bind({});
Default.args = {};
