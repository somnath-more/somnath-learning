import React from 'react';
import SideBar from './index';
import { render, fireEvent, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import theme from '@src/themes';
import { BrowserRouter as Router } from 'react-router-dom';

describe('Testing the SideBar', () => {
  test('renders SideBar with initial state', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <SideBar />
        </Router>
      </ThemeProvider>
    );

    const homeIcon = screen.getByText('Home');
    const fileIcon = screen.getByText('Files');

    expect(homeIcon).toBeInTheDocument();
    expect(fileIcon).toBeInTheDocument();

    expect(screen.getByTestId('SideBar')).toBeInTheDocument();
  });

  test('Footer icon is rendered', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <SideBar />
        </Router>
      </ThemeProvider>
    );

    const icons = screen.getAllByRole('img');
    const footerIcon = icons[6];
    expect(footerIcon).toBeInTheDocument();
  });

  test('clicking on Home icon and File icon', () => {
    render(
      <ThemeProvider theme={theme}>
        <Router>
          <SideBar />
        </Router>
      </ThemeProvider>
    );

    const icons = screen.getAllByRole('img');
    const homeIcon = icons[0];
    const fileIcon = icons[4];
    const homeText = screen.getByText('Home');
    const fileText = screen.getByText('Files');

    fireEvent.click(homeIcon);
    expect(homeText).toHaveStyle(`color: ${theme.palette.text.white}`);
    expect(fileText).toHaveStyle(`color: ${theme.palette.grays.gray200}`);

    fireEvent.click(fileIcon);
    expect(fileText).toHaveStyle(`color: ${theme.palette.text.white}`);
    expect(homeText).toHaveStyle(`color: ${theme.palette.grays.gray200}`);
  });
});
