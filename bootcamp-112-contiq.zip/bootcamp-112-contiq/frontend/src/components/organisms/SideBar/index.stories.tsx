import { Meta, StoryFn } from '@storybook/react';
import SideBar from './index';
import { BrowserRouter as Router } from 'react-router-dom';

export default {
  title: 'Organisms/Sidebar',
  component: SideBar,
  decorators: [
    (Story) => (
      <Router>
        <Story />
      </Router>
    )
  ]
} as Meta;

const Template: StoryFn = (args) => <SideBar {...args} />;

export const Basic = Template.bind({});
