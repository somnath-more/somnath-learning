import React, { useCallback, useState } from 'react';
import { Box, Button, styled, useTheme } from '@mui/material';
import TypographyComponent from '@components/atoms/Typography';
import {
  RESET_PASSWORD,
  RESET_PASSWORD_MESSAGE1,
  RESET_PASSWORD_MESSAGE2,
  RESET_PASSWORD_BUTTON,
  EMAIL,
  EMAIL_ERROR,
  EMAIL_PLACEHOLDER
} from '@utils/constants';
import InputFieldWithTypography from '@components/molecules/TextFieldWithTypography';
import { EMAIL_REGEX } from '@utils/regex';
import { inputValidator } from '@utils/functions';

interface ResetPasswordProps {
  onResetPassword?: any;
}

export const RootBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(8),
  width: theme.spacing(89)
}));

export const ContentBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(2)
}));

export const HeaderBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(2)
}));
export const MessageBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column'
}));

export const SendButton = styled(Button)(({ theme }) => ({
  height: theme.spacing(12),

  '&.MuiButton-root': {
    ...theme.typography.body1,
    color: theme.palette.text.white,
    textTransform: 'none',
    boxShadow: 'none'
  },
  ':disabled': {
    backgroundColor: theme.palette.primary.light
  },
  '&:hover': {
    backgroundColor: `${theme.palette.primary.main} !important`
  }
}));

const ResetPassword = ({ onResetPassword }: ResetPasswordProps) => {
  const theme = useTheme();

  const [email, setEmail] = useState<string>('');
  const [emailError, setEmailError] = useState<string>(' ');

  const handleEmail = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const newEmail = event.target.value;
    setEmail(newEmail);
    setEmailError(inputValidator(newEmail, EMAIL_REGEX) ? '' : EMAIL_ERROR);
  }, []);

  const handleSend = () => {
    onResetPassword(email);
  };

  const isSignInEnabled = emailError.length == 0;

  return (
    <RootBox data-testid="reset-password">
      <HeaderBox>
        <TypographyComponent
          variant="h2"
          children={RESET_PASSWORD}
          color={theme.palette.text.black}
        />
        <MessageBox>
          <TypographyComponent
            variant="overline1"
            children={RESET_PASSWORD_MESSAGE1}
            color={theme.palette.text.mediumEmphasis}
          />
          <TypographyComponent
            variant="overline1"
            children={RESET_PASSWORD_MESSAGE2}
            color={theme.palette.text.mediumEmphasis}
          />
        </MessageBox>
      </HeaderBox>
      <ContentBox>
        <InputFieldWithTypography
          text={EMAIL}
          value={email}
          placeholder={EMAIL_PLACEHOLDER}
          handleChange={handleEmail}
        />
        <TypographyComponent
          variant="overline1"
          children={emailError}
          color={theme.palette.structuralColor.main}
        />
      </ContentBox>
      <SendButton
        data-testid="send-btn"
        variant="contained"
        onClick={handleSend}
        disabled={!isSignInEnabled}>
        {RESET_PASSWORD_BUTTON}
      </SendButton>
    </RootBox>
  );
};

export default ResetPassword;
