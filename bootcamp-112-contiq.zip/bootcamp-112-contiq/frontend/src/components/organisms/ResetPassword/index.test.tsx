import React from 'react';
import ResetPassword from '.';
import { fireEvent, render, screen } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import { EMAIL_ERROR, EMAIL_PLACEHOLDER } from '@utils/constants';
import theme from '@src/themes';

const onResetPassword = jest.fn();

describe('Testing the ResetPassword component', () => {
  test('renders ResetPassword component', () => {
    render(
      <ThemeProvider theme={theme}>
        <ResetPassword onResetPassword={onResetPassword} />
      </ThemeProvider>
    );
    const resetPasswordRoot = screen.getByTestId('reset-password');
    expect(resetPasswordRoot).toBeInTheDocument();
  });

  test('validates email input and sends email', () => {
    render(
      <ThemeProvider theme={theme}>
        <ResetPassword onResetPassword={onResetPassword} />
      </ThemeProvider>
    );

    const emailInput = screen.getByPlaceholderText(EMAIL_PLACEHOLDER);
    const sendButton = screen.getByTestId('send-btn');

    fireEvent.change(emailInput, { target: { value: 'testgmail.com' } });
    expect(sendButton).toBeDisabled();

    const emailError = screen.getByText(EMAIL_ERROR);
    expect(emailError).toBeInTheDocument();

    fireEvent.change(emailInput, { target: { value: 'test@gmail.com' } });
    expect(sendButton).not.toBeDisabled();

    fireEvent.click(sendButton);
  });
});
