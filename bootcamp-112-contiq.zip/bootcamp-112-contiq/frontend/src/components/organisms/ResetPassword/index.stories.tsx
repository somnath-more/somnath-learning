import type { Meta, StoryFn } from '@storybook/react';
import ResetPassword from '.';

export default {
  title: 'Organisms/Reset Password',
  component: ResetPassword
} as Meta;

const Template: StoryFn = (args) => <ResetPassword {...args} />;

export const Basic = Template.bind({});
