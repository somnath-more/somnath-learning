import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import LoginImage from '@assets/images/image.png';
import theme from '@src/themes';
import { ThemeProvider } from '@emotion/react';
import ResetPasswordPage from './index';
import { BrowserRouter as Router } from 'react-router-dom';
import { checkEmailPresent } from '@src/service';

jest.mock('@src/service', () => ({
  checkEmailPresent: jest.fn()
}));

test('should renders the Reset password Page component', () => {
  render(
    <ThemeProvider theme={theme}>
      <Router>
        <ResetPasswordPage />
      </Router>
    </ThemeProvider>
  );

  const reset_password_screen = screen.getByTestId('ResetPassword');
  expect(reset_password_screen).toBeInTheDocument();
  expect(LoginImage).toBeInTheDocument;
});

test('handles successful reset-password', async () => {
  (checkEmailPresent as jest.Mock).mockResolvedValue(true);

  render(
    <ThemeProvider theme={theme}>
      <Router>
        <ResetPasswordPage />
      </Router>
    </ThemeProvider>
  );

  const emailInput = screen.getByPlaceholderText('john@example.com');
  const signInButton = screen.getByTestId('send-btn');
  fireEvent.change(emailInput, { target: { value: 'majahar@gmail.com' } });
  fireEvent.click(signInButton);
});

test('handles failed reset-password', async () => {
  (checkEmailPresent as jest.Mock).mockResolvedValue(false);

  render(
    <ThemeProvider theme={theme}>
      <Router>
        <ResetPasswordPage />
      </Router>
    </ThemeProvider>
  );

  const emailInput = screen.getByPlaceholderText('john@example.com');
  const signInButton = screen.getByTestId('send-btn');
  fireEvent.change(emailInput, { target: { value: 'majahar846@gmail.com' } });
  fireEvent.click(signInButton);
});
