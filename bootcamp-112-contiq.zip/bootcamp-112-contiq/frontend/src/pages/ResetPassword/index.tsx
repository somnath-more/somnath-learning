import React from 'react';
import LoginTemplate from '@components/templates/LoginTemplate';
import LoginImage from '@assets/images/image.png';
import { Box } from '@mui/material';
import ResetPassword from '@components/organisms/ResetPassword';
import { useNavigate } from 'react-router-dom';
import { checkEmailPresent } from '@src/service';
import { EMAIL_NOT_EXIST, NAVIGATE_CREATE_NEW_PASSWORD } from '@src/utils/constants';

const ResetPasswordPage = () => {
  const navigate = useNavigate();

  const handleResetPassword = async (email: string) => {
    const emailCheck = await checkEmailPresent(email);

    if (emailCheck) {
      navigate(NAVIGATE_CREATE_NEW_PASSWORD, { state: { email } });
    } else {
      window.alert(EMAIL_NOT_EXIST);
    }
  };

  return (
    <Box data-testid="ResetPassword">
      <LoginTemplate
        src={LoginImage}
        RightComponent={<ResetPassword onResetPassword={handleResetPassword} />}
      />
    </Box>
  );
};

export default ResetPasswordPage;
