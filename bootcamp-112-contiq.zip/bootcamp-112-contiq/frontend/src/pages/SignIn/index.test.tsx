import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import SignInPage from '.';
import LoginImage from '@assets/images/image.png';
import theme from '@src/themes';
import { checkUsers } from '@src/service';
import { ThemeProvider } from '@emotion/react';
import { BrowserRouter as Router } from 'react-router-dom';

jest.mock('@src/service', () => ({
  checkUsers: jest.fn()
}));

test('renders the SignInPage component', () => {
  render(
    <ThemeProvider theme={theme}>
      <Router>
        <SignInPage />
      </Router>
    </ThemeProvider>
  );

  const login_screen = screen.getByTestId('loginPage');
  expect(login_screen).toBeInTheDocument();
  expect(LoginImage).toBeInTheDocument;
});

test('handles successful sign-in', async () => {
  (checkUsers as jest.Mock).mockResolvedValue('user123');

  render(
    <ThemeProvider theme={theme}>
      <Router>
        <SignInPage />
      </Router>
    </ThemeProvider>
  );

  const emailInput = screen.getByPlaceholderText('john@example.com');
  const passwordInput = screen.getByPlaceholderText('Create a password');
  const signInButton = screen.getByTestId('signIn-btn');
  fireEvent.change(emailInput, { target: { value: 'majahar@gmail.com' } });
  fireEvent.change(passwordInput, { target: { value: 'Test@1234' } });
  fireEvent.click(signInButton);
});

test('handles failed sign-in', async () => {
  (checkUsers as jest.Mock).mockResolvedValue(null);

  render(
    <ThemeProvider theme={theme}>
      <Router>
        <SignInPage />
      </Router>
    </ThemeProvider>
  );

  const emailInput = screen.getByPlaceholderText('john@example.com');
  const passwordInput = screen.getByPlaceholderText('Create a password');
  const signInButton = screen.getByTestId('signIn-btn');

  fireEvent.change(emailInput, { target: { value: 'majahar@gmail.com' } });
  fireEvent.change(passwordInput, { target: { value: 'Test@123456' } });
  fireEvent.click(signInButton);
});
