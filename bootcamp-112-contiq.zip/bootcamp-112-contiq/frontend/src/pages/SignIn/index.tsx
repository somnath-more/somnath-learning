import React from 'react';
import LoginTemplate from '@components/templates/LoginTemplate';
import SignInOrganism from '@components/organisms/SignIn';
import LoginImage from '@assets/images/image.png';
import { Box } from '@mui/material';
import { checkUsers } from '@src/service';
import { useNavigate } from 'react-router-dom';
import { LOGIN_FILED, NAVIGATE_HOME } from '@src/utils/constants';

const SignInPage = () => {
  const navigate = useNavigate();

  const handleSignIn = async (email: string, password: string) => {
    const user = await checkUsers(email, password);

    if (user) {
      navigate(NAVIGATE_HOME);
    } else {
      window.alert(LOGIN_FILED);
    }
  };

  return (
    <Box data-testid="loginPage">
      <LoginTemplate src={LoginImage} RightComponent={<SignInOrganism onSignIn={handleSignIn} />} />
    </Box>
  );
};

export default SignInPage;
