import React from 'react';
import LoginTemplate from '@components/templates/LoginTemplate';
import LoginImage from '@assets/images/image.png';
import { Box } from '@mui/material';
import CreateNewPassword from '@components/organisms/CreateNewPassword';
import { updatePassword } from '@src/service';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  NAVIGATE_CONFIRM_NEW_PASSWORD,
  WINDOW_ALERT_NEW_PASSWORD_ALREADY_EXIST
} from '@src/utils/constants';

const CreateNewPasswordPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const email = location.state?.email;

  const handleConfirmPassword = async (password: string) => {
    const createNewPassword = await updatePassword(email, password);

    if (createNewPassword) {
      navigate(NAVIGATE_CONFIRM_NEW_PASSWORD);
    } else {
      window.alert(WINDOW_ALERT_NEW_PASSWORD_ALREADY_EXIST);
    }
  };

  return (
    <Box data-testid="CreatePassword">
      <LoginTemplate
        src={LoginImage}
        RightComponent={<CreateNewPassword onResetPassword={handleConfirmPassword} />}
      />
    </Box>
  );
};

export default CreateNewPasswordPage;
