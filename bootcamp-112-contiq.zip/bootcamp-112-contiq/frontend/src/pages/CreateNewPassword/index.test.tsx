import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import LoginImage from '@assets/images/image.png';
import theme from '@src/themes';
import { ThemeProvider } from '@emotion/react';
import CreateNewPasswordPage from './index';
import { BrowserRouter as Router } from 'react-router-dom';
import { updatePassword } from '@src/service';

jest.mock('@src/service', () => ({
  updatePassword: jest.fn()
}));

test('should renders the Create New Password Page component', () => {
  render(
    <ThemeProvider theme={theme}>
      <Router>
        <CreateNewPasswordPage />
      </Router>
    </ThemeProvider>
  );

  const create_new_password_screen = screen.getByTestId('CreatePassword');
  expect(create_new_password_screen).toBeInTheDocument();
  expect(LoginImage).toBeInTheDocument;
});

test('handles successful create-new-password', async () => {
  (updatePassword as jest.Mock).mockResolvedValue(true);

  render(
    <ThemeProvider theme={theme}>
      <Router>
        <CreateNewPasswordPage />
      </Router>
    </ThemeProvider>
  );

  const password = screen.getByPlaceholderText('Enter new password');
  const confirmPassword = screen.getByPlaceholderText('Confirm new password');
  const createNewPasswordButton = screen.getByTestId('confirm-btn');
  fireEvent.change(password, { target: { value: 'Test@12345' } });
  fireEvent.change(confirmPassword, { target: { value: 'Test@12345' } });
  fireEvent.click(createNewPasswordButton);
});

test('handles failed create-new-password', async () => {
  (updatePassword as jest.Mock).mockResolvedValue(false);

  render(
    <ThemeProvider theme={theme}>
      <Router>
        <CreateNewPasswordPage />
      </Router>
    </ThemeProvider>
  );

  const password = screen.getByPlaceholderText('Enter new password');
  const confirmPassword = screen.getByPlaceholderText('Confirm new password');
  const createNewPasswordButton = screen.getByTestId('confirm-btn');
  fireEvent.change(password, { target: { value: 'Test@1234' } });
  fireEvent.change(confirmPassword, { target: { value: 'Test@1234' } });
  fireEvent.click(createNewPasswordButton);
});
