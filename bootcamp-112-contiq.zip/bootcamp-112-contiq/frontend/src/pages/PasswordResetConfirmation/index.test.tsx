import React from 'react';
import { render, screen } from '@testing-library/react';
import LoginImage from '@assets/images/image.png';
import theme from '@src/themes';
import { ThemeProvider } from '@emotion/react';
import PasswordResetConfirmationPage from './index';
import { BrowserRouter as Router } from 'react-router-dom';

test('should renders the PasswordResetPage component', () => {
  render(
    <ThemeProvider theme={theme}>
      <Router>
        <PasswordResetConfirmationPage />
      </Router>
    </ThemeProvider>
  );

  const password_reset_screen = screen.getByTestId('PasswordReset');
  expect(password_reset_screen).toBeInTheDocument();
  expect(LoginImage).toBeInTheDocument;
});
