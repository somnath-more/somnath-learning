import React from 'react';
import LoginTemplate from '@components/templates/LoginTemplate';
import LoginImage from '@assets/images/image.png';
import { Box } from '@mui/material';
import PasswordReset from '@components/organisms/PasswordReset';

const PasswordResetConfirmationPage = () => {
  return (
    <Box data-testid="PasswordReset">
      <LoginTemplate src={LoginImage} RightComponent={<PasswordReset/>} />
    </Box>
  );
};

export default PasswordResetConfirmationPage;