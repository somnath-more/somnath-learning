import React from 'react';
import Home from './index';
import { render, screen, waitFor } from '@testing-library/react';
import { ThemeProvider } from '@emotion/react';
import theme from '@src/themes';
import { fetchRecentFiles, fetchNotificationData } from '@src/service';
import { BrowserRouter as Router } from 'react-router-dom';

jest.mock('@src/service', () => ({
  fetchRecentFiles: jest.fn(),
  fetchNotificationData: jest.fn(),
  fetchUsers: jest.fn()
}));

const files = [
  {
    id: '1',
    userId: 1,
    name: 'Company Presentation',
    type: 'PDF',
    path: '/path/to/company_presentation.ppt',
    content: 'some random content',
    createdAt: 1231351654
  },
  {
    id: '2',
    userId: 2,
    name: 'Financial Report',
    type: 'PDF',
    path: '/path/to/financial_report.pdf',
    content: 'some random content',
    createdAt: 1231351654
  }
];
const data = [
  {
    id: 1,
    user_id: 1,
    file_name: 'Company Presentation.pdf',
    is_read: false,
    user_action: 'UPLOAD',
    content: '',
    createdAt: '2023-08-16 09:00:00'
  }
];

describe('Testing the Home', () => {
  test('Home test', async () => {
    (fetchRecentFiles as jest.Mock).mockResolvedValue(files);
    (fetchNotificationData as jest.Mock).mockResolvedValue(data);

    render(
      <ThemeProvider theme={theme}>
        <Router>
          <Home />
        </Router>
      </ThemeProvider>
    );

    await waitFor(() => {
      const Test = screen.getByTestId('home-page');
      expect(Test).toBeInTheDocument();
    });
  });
});
