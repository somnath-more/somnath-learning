import React, { useEffect, useState } from 'react';
import TypographyComponent from '@components/atoms/Typography';
import Header from '@components/organisms/Header';
import SideBar from '@components/organisms/SideBar';
import HomeTemplate from '@components/templates/HomeTemplate';
import { Box, styled, useTheme } from '@mui/material';
import PresentationCard from '@components/molecules/PresentationCard';
import CardImage from '@assets/images/DigitalTransformation.svg';
import { fetchRecentFiles } from '@src/service';
import { FileType } from '@src/utils/types';
import ImageWithTypography from '@components/molecules/ImageWithTypography';
import { NO_FILES, START_SYNC_CONTIQ } from '@src/utils/constants';
import NOFIle from '@assets/images/NoFiles.svg';
import { getUserId } from '@src/utils/functions';

const HeadingBox = styled(Box)(({ theme }) => ({
  padding: `${theme.spacing(7)} 0`
}));

const ContentBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(6),
  paddingLeft: theme.spacing(6)
}));

const CenterImageBox = styled(Box)({
  display: 'flex',
  justifyContent: 'center',
  height: '70vh',
  alignItems: 'center'
});

const ImageBox = styled(Box)(({ theme }) => ({
  width: theme.spacing(75),
  height: theme.spacing(75)
}));

const PresentationBox = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexWrap: 'wrap',
  gap: theme.spacing(6)
}));

const Home = () => {
  const theme = useTheme();
  const [files, setFiles] = useState<FileType[]>([]);

  const userId: number | null = getUserId();

  useEffect(() => {
    userId &&
      fetchRecentFiles(userId).then((result) => {
        setFiles(result);
      });
  }, []);

  return (
    <Box data-testid="home-page">
      <HomeTemplate
        navComponent={<SideBar />}
        headerComponent={<Header />}
        middleComponent={
          <ContentBox>
            <HeadingBox>
              <TypographyComponent variant="h2" children="Home" color={theme.palette.text.black} />
            </HeadingBox>

            {files.length === 0 ? (
              <CenterImageBox>
                <ImageBox>
                  <ImageWithTypography
                    image={NOFIle}
                    heading={NO_FILES}
                    value={START_SYNC_CONTIQ}
                  />
                </ImageBox>
              </CenterImageBox>
            ) : (
              <>
                <TypographyComponent
                  variant="h3"
                  children="Recent"
                  color={theme.palette.text.lowEmphasis}
                />
                <PresentationBox>
                  {files.map((file: any) => {
                    return (
                      <PresentationCard key={file.id} cardImage={CardImage} pdfName={file.name} />
                    );
                  })}
                </PresentationBox>
              </>
            )}
          </ContentBox>
        }
      />
    </Box>
  );
};

export default Home;
