import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import SignUpPage from './index';
import LoginImage from '@assets/images/image.png';
import theme from '@src/themes';
import { addUser } from '@src/service';
import { ThemeProvider } from '@emotion/react';
import { BrowserRouter as Router } from 'react-router-dom';

jest.mock('@src/service', () => ({
  addUser: jest.fn()
}));

test('renders the SignUpPage component', () => {
  render(
    <ThemeProvider theme={theme}>
      <Router>
        <SignUpPage />
      </Router>
    </ThemeProvider>
  );

  const signup_screen = screen.getByTestId('signupPage');
  expect(signup_screen).toBeInTheDocument();
  expect(LoginImage).toBeInTheDocument;
});

test('handles successful sign-up', async () => {
  (addUser as jest.Mock).mockResolvedValue(true);

  render(
    <ThemeProvider theme={theme}>
      <Router>
        <SignUpPage />
      </Router>
    </ThemeProvider>
  );

  const nameInput = screen.getByPlaceholderText('John Cena');
  const emailInput = screen.getByPlaceholderText('john@example.com');
  const passwordInput = screen.getByPlaceholderText('Create a password');
  const signInButton = screen.getByTestId('signUp-btn');
  fireEvent.change(nameInput, { target: { value: 'Benhur' } });
  fireEvent.change(emailInput, { target: { value: 'benhur@gmail.com' } });
  fireEvent.change(passwordInput, { target: { value: 'Test@1234' } });
  fireEvent.click(signInButton);
});

test('handles failed sign-up', async () => {
  (addUser as jest.Mock).mockResolvedValue(false);

  render(
    <ThemeProvider theme={theme}>
      <Router>
        <SignUpPage />
      </Router>
    </ThemeProvider>
  );

  const nameInput = screen.getByPlaceholderText('John Cena');
  const emailInput = screen.getByPlaceholderText('john@example.com');
  const passwordInput = screen.getByPlaceholderText('Create a password');
  const signInButton = screen.getByTestId('signUp-btn');
  fireEvent.change(nameInput, { target: { value: 'Majahar' } });
  fireEvent.change(emailInput, { target: { value: 'majahar@gmail.com' } });
  fireEvent.change(passwordInput, { target: { value: 'Test@1234' } });
  fireEvent.click(signInButton);
});
