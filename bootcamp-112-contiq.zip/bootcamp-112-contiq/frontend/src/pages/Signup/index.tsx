import React from 'react';
import LoginTemplate from '@components/templates/LoginTemplate';
import SignUpOrganism from '@components/organisms/SignUp';
import LoginImage from '@assets/images/image.png';
import { Box } from '@mui/material';
import { addUser } from '@src/service';
import { useNavigate } from 'react-router-dom';
import { NAVIGATE_SIGNIN, USER_ALREADY_EXIST } from '@src/utils/constants';

const SignUpPage = () => {
  const navigate = useNavigate();

  const handleSignUp = async (name: string, email: string, password: string) => {
    const user = await addUser(name, email, password);

    if (user) {
      navigate(NAVIGATE_SIGNIN);
    } else {
      window.alert(USER_ALREADY_EXIST);
    }
  };

  return (
    <Box data-testid="signupPage">
      <LoginTemplate src={LoginImage} RightComponent={<SignUpOrganism onSignUp={handleSignUp} />} />
    </Box>
  );
};

export default SignUpPage;
