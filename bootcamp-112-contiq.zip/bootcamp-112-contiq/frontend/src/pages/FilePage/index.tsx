import React, { useEffect, useState } from 'react';
import HomeTemplate from '@components/templates/HomeTemplate';
import Header from '@components/organisms/Header';
import { Stack, Grid, styled } from '@mui/material';
import theme from '@src/themes';
import {
  START_DATE,
  END_DATE,
  FILE_TYPE,
  PUBLISH_LABEL,
  PUBLISH_PLACEHOLDER,
  FileItems,
  PublishItems,
  NOT_FOUND
} from '@src/utils/constants';
import SideBar from '@components/organisms/SideBar';
import DatePicker from '@components/organisms/DatePicker';
import DropDown from '@components/molecules/DropDown';
import MuiTabs from '@components/molecules/MuiTabs';
import ImageComponent from '@components/atoms/image';
import RightFilter from '@assets/images/Filter.svg';
import TypographyComponent from '@components/atoms/Typography';
import MuiButton from '@components/atoms/button';
import AddIcon from '@assets/icons/addIcon.svg';
import { FileType } from '@src/utils/types';
import PresentationCard from '@components/molecules/PresentationCard';
import CardImage from '@assets/images/DigitalTransformation.svg';
import { fetchFiles } from '@src/service';
import { filterFilesByDate, getUserId } from '@src/utils/functions';
import Modal from '@components/organisms/Modal';

const MainGrid = styled(Grid)({
  height: '5.75rem',
  padding: '28px, 24px, 28px, 24px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between'
});

const AddFilesButton = styled(Grid)({
  marginLeft: 'auto',
  marginRight: '20px'
});

const ContentGrid = styled(Grid)`
  height: '80vh';
`;

const ContentBox = styled(Grid)({
  height: '80vh'
});

const FilePage = () => {
  const [startDate, setstartDate] = useState<string>('');
  const [endDate, setendDate] = useState<string>('');
  const [show, setShow] = useState(false);
  const [FileNames, setFileNames] = useState<FileType[]>([]);

  const userId: number | null = getUserId();

  useEffect(() => {
    userId &&
      fetchFiles(userId).then((data) => {
        setFileNames(data);
      });
  }, []);

  const parsedStartDate = startDate ? new Date(startDate) : null;
  const parsedEndDate = endDate ? new Date(endDate) : null;
  const filteredFiles = filterFilesByDate(FileNames, parsedStartDate, parsedEndDate);

  const openUploadModal = () => {
    setShow(true);
  };
  const closeModal = () => {
    setShow(false);
  };

  return (
    <>
      <HomeTemplate
        navComponent={<SideBar selectedItem={'file'} />}
        middleComponent={
          <Grid marginLeft={5}>
            <MainGrid container>
              <Grid item>{<TypographyComponent children="Files" variant="h2" />}</Grid>
              <AddFilesButton>
                <MuiButton
                  text="Add Files"
                  variant="contained"
                  startIcon={<img src={AddIcon} />}
                  onClick={openUploadModal}
                  data-testid="Modal-Button"
                />
              </AddFilesButton>
            </MainGrid>
            <ContentGrid item>
              <ContentBox>
                <Stack height="3.7rem" justifyContent="space-between" direction="row">
                  <Stack direction="row" height="36px" gap="10px">
                    <DropDown placeholder={FILE_TYPE} label={FILE_TYPE} menuItems={FileItems} />
                    <DatePicker label={START_DATE} date={startDate} setDate={setstartDate} />
                    <DatePicker label={END_DATE} date={endDate} setDate={setendDate} />
                    <DropDown
                      menuItems={PublishItems}
                      placeholder={PUBLISH_PLACEHOLDER}
                      label={PUBLISH_LABEL}
                    />
                  </Stack>
                  <Stack>
                    <ImageComponent
                      imgSrc={RightFilter}
                      imgAlt={NOT_FOUND}
                      sx={{ paddingRight: '20px' }}
                    />
                  </Stack>
                </Stack>
                <MuiTabs
                  variant={'standard'}
                  tabNames={['All files', 'Slides', 'Docs']}
                  selectedColor={theme.palette.primary.main}
                  backgroundColor={theme.palette.text.white}
                  notSelectedColor={theme.palette.text.mediumEmphasis}
                  borderBottom={`1px solid ${theme.palette.grays.gray600}`}
                  isTabDisabled={true}
                  onSelectTab={function (tabName: string): void {
                    throw new Error('Function not implemented.');
                  }}
                  selectedTab={'All files'}
                />
                <Grid display="flex" flexWrap="wrap" gap={theme.spacing(6)} paddingTop="25px">
                  {filteredFiles.map((item) => (
                    <PresentationCard pdfName={item.name} cardImage={CardImage} />
                  ))}
                </Grid>
              </ContentBox>
            </ContentGrid>
          </Grid>
        }
        headerComponent={<Header />}
      />
      {show && <Modal handleClose={closeModal} />}
    </>
  );
};

export default FilePage;
