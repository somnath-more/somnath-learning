import React, { useEffect, useState } from 'react';
import { Box } from '@mui/material';
import Header from '@components/organisms/Header';
import SideBar from '@components/organisms/SideBar';
import HomeTemplate from '@components/templates/HomeTemplate';
import PdfViewer from '@components/organisms/PDFViewer';
import { useLocation } from 'react-router-dom';
import { fetchFileById } from '@src/service';
import { FileType } from '@src/utils/types';
import { INITIAL_FILE } from '@src/utils/constants';
import { FILE_URL } from '@src/utils/urls';

const PDFPage = () => {
  const location = useLocation();
  const [file, setFile] = useState<FileType>(INITIAL_FILE);
  const [fileRender, setFileRender] = useState<string>('');
  const dataObject = location.state?.dataObject;

  useEffect(() => {
    if (dataObject?.id) {
      fetchFileById(dataObject.id).then((res) => {
        if (res) {
          setFile(res);
          const updatedFileRender = `${FILE_URL}resource?filepath=${res.userId}/${res.name}`;
          setFileRender(updatedFileRender);
        }
      });
    }
  }, [dataObject?.id]);

  return (
    <Box data-testid="pdf-page">
      <HomeTemplate
        navComponent={<SideBar selectedItem="file" />}
        headerComponent={<Header />}
        middleComponent={
          fileRender && (
            <PdfViewer
              fileName={file.name}
              searchKey={dataObject.searchKey}
              fileRender={fileRender}
            />
          )
        }
      />
    </Box>
  );
};

export default PDFPage;
