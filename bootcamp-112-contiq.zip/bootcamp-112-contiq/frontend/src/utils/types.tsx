export type RadioButtons = {
  label: string;
  isChecked: boolean;
};

export interface FilesType {
  id:number;
  user_id: number;
  name: string;
  type: string;
  path: string;
  created_at: string;
  updated_at: string;
}

export interface ModifiedNotificationsType {
  id:number;
  userId: number;
  filename: string;
  createdTime: string;
  action: string;
}

export type FileType = {
  id: string;
  userId: number;
  name: string;
  type: string;
  path: string;
  content: string;
  createdAt: number;
};
