import { SetStateAction } from 'react';
import { FileType, ModifiedNotificationsType } from './types';
import {
  fetchFileByName,
  AddNotificationData,
  deleteFileById,
  fetchNotificationData,
  fetchUserNotificationCount,
  updateNotificationCount,
  uploadLocalFile,
  fetchUsers
} from '@src/service';
import { IMockNotifactions } from '@components/organisms/NotificationCard';

export const convertToFiveDigits = (num: number): string => {
  const str = num.toString();
  const leadingZeros = '00000';
  return leadingZeros.slice(0, 5 - str.length) + str;
};

export const inputValidator = (input: string, regex: RegExp) => {
  return regex.test(input);
};

export const passwordValidator = (newPassword: string, confirmPassword: string) => {
  return newPassword === confirmPassword;
};

export const filterFilesByDate = (
  FileNames: FileType[],
  startDate: Date | null,
  endDate: Date | null
) => {
  const startDateTimestamp = startDate ? startDate.setHours(0, 0, 0, 0) : null;
  const endDateTimestamp = endDate ? endDate.setHours(23, 59, 59, 999) : null;

  return FileNames.filter((file) => {
    const fileTimestamp = new Date(file.createdAt).setHours(0, 0, 0, 0);

    if (startDateTimestamp && endDateTimestamp) {
      return fileTimestamp >= startDateTimestamp && fileTimestamp <= endDateTimestamp;
    } else if (startDateTimestamp) {
      return fileTimestamp >= startDateTimestamp;
    } else if (endDateTimestamp) {
      return fileTimestamp <= endDateTimestamp;
    }

    return true;
  });
};

export const formatDateTime = (dateTimeString: string) => {
  const months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];

  const date = new Date(dateTimeString);
  const day = date.getDate();
  const month = months[date.getMonth()];
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const ampm = hours >= 12 ? 'PM' : 'AM';

  const formattedDate = `${day} ${month} ${
    hours === 0 ? 12 : hours > 12 ? hours - 12 : hours
  }:${minutes.toString().padStart(2, '0')} ${ampm}`;

  return formattedDate;
};

export const formatDate = (date: Date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');

  return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
};

export const handleUpload = async (
  text: any,
  chosenFile: File | null,
  setModal: (arg0: any) => void,
  setUploadTriggered: (arg0: boolean) => void
) => {
  setUploadTriggered(true);

  try {
    const trigger = await fetchFileByName(text);
    setModal(trigger);

    if (!trigger) {
      if (chosenFile) {
        await Promise.all([uploadLocalFile(chosenFile), AddNotificationData(text, 'UPLOADED')]);
      } else {
        console.error('No file chosen for upload.');
      }
    } else {
      if (chosenFile) {
        await Promise.all([
          deleteFileById(text),
          uploadLocalFile(chosenFile),
          AddNotificationData(text, 'UPDATED')
        ]);
      } else {
        console.error('No file chosen for update.');
      }
    }
    setTimeout(() => {
      window.location.reload();
    }, 2000);
  } catch (error) {
    console.error('An error occurred:', error);
  }
};

export const handleUploadButton = async (text: string, chosenFile: File | null) => {
  try {
    if (chosenFile) {
      const check = await fetchFileByName(text);
      if (!check) {
        await uploadLocalFile(chosenFile);
        await AddNotificationData(text, 'UPLOADED');
      } else {
        await deleteFileById(text);
        await uploadLocalFile(chosenFile);
        await AddNotificationData(text, 'UPDATED');
      }

      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } else {
      console.error('No file chosen for upload or update.');
    }
  } catch (error) {
    console.error('An error occurred:', error);
  }
};

export const getUserID = (): number => {
  const userObject = JSON.parse(localStorage.getItem('user')!);
  return userObject.id;
};

export const fetchAndProcessNotifications = async (
  setNotificationCount: {
    (value: SetStateAction<number>): void;
    (value: SetStateAction<number>): void;
    (arg0: number): void;
  },
  setNotificationsData: {
    (value: SetStateAction<IMockNotifactions[] | undefined>): void;
    (value: SetStateAction<IMockNotifactions[] | undefined>): void;
    (arg0: { id: number; name: any; user_action: string; file_name: string; date: string }[]): void;
  },
  setTotalCount: {
    (value: SetStateAction<number>): void;
    (value: SetStateAction<number>): void;
    (arg0: number): void;
  }
) => {
  try {
    const UserData = await fetchUsers();
    const data = await fetchNotificationData();
    const transformedData = await Promise.all(
      data.map(async (notification: ModifiedNotificationsType) => {
        const name = UserData.find((user: { id: number }) => user.id === notification.userId).name;
        const formattedDate = formatDateTime(notification.createdTime);

        return {
          id: notification.id,
          name,
          user_action: notification.action,
          file_name: notification.filename,
          date: formattedDate
        };
      })
    );

    setNotificationsData(transformedData);

    const unreadCount = transformedData.length;
    const userNotificationCount = await fetchUserNotificationCount();
    const newNotificationCount = unreadCount - userNotificationCount;

    setNotificationCount(newNotificationCount);
    setTotalCount(unreadCount);
  } catch (error) {
    console.error('Error fetching notifications:', error);
  }
};

export const sortNotificationsByCreatedTimeDesc = (notifications: ModifiedNotificationsType) => {
  if (Array.isArray(notifications) && notifications.length > 0) {
    return notifications.slice().sort((a, b) => {
      const dateA = new Date(a.createdTime).getTime();
      const dateB = new Date(b.createdTime).getTime();
      return dateB - dateA;
    });
  } else {
    return [];
  }
};

export const getUserId = (): number | null => {
  const userJSON = localStorage.getItem('user');

  if (userJSON) {
    const userObject = JSON.parse(userJSON);
    return userObject.id;
  }

  return null;
};
