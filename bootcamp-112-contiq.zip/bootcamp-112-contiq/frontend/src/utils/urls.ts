const BASE_URL = 'https://be-bc-112.fe-assignment.tk/api/v1';

export const NOTIFICATION_URL = `${BASE_URL}/notifications/`;
export const USER_URL = `${BASE_URL}/users/`;
export const FILE_URL = `${BASE_URL}/files/`;
