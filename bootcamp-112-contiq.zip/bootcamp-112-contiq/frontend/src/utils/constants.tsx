import user from '../../public/assets/icons/user.svg';
import settings from '../../public/assets/icons/settings2.svg';
import logout from '../../public/assets/icons/logout.svg';
import theme from '../themes';

export const NOT_FOUND = 'not found image';
export const CLOSE_NOT_FOUND = 'not found close image';
export const TEMP_FILE = `My React and TypeScript App!! ${new Date().toLocaleDateString()}`;
export const SYNCDRIVE = 'Sync entire drive';
export const SYNCFOLDER = 'Sync folders';
export const EMAIL = 'Email ID';
export const PASSWORD = 'Password';
export const EMAIL_PLACEHOLDER = 'john@example.com';
export const PASSWORD_PLACEHOLDER = 'Create a password';
export const AVATAR_ALT_TEXT = 'Avatar';
export const NO_FILES = 'No files availabe';
export const START_SYNC_CONTIQ = 'Start by syncing your cloud storage to contiq';
export const RADIO_BUTTON_GROUP = [
  {
    label: 'Sync entire drive',
    isChecked: false
  },
  {
    label: 'Sync folders',
    isChecked: true
  }
];
export const SIDE_BAR_LABELS = ['Home', 'Office', 'People', 'Calender', 'Files', 'Metrics'];
export const FILE_TYPE = 'File type';
export const PUBLISH_LABEL = 'Published by';
export const FILE_ITEM1 = 'PDF';
export const FILE_ITEM2 = 'PPT';
export const FILE_ITEM3 = 'Image';
export const PUBLISH_ITEM1 = 'Published by me';
export const PUBLISH_ITEM2 = 'Published by Sales team';
export const PUBLISH_ITEM3 = 'Published by others';
export const PUBLISH_PLACEHOLDER = 'Publish setting';

export const USER_ID = 'IDJR';
export const USER_PROFILE_OPTIONS = [
  { id: 1, name: 'Profile', icon: user },
  { id: 2, name: 'Settings', icon: settings },
  { id: 3, name: 'Logout', icon: logout }
];

export const Avatarprops = {
  file_name: 'New.pdf',
  user_action: 'UPLOAD',
  dateTime: '2023-08-10',
  avatarSrc: 'path/to/avatar.jpg',
  avatarAlt: 'Avatar Alt Text',
  name: 'John Doe'
};
export const SYNC_PROGRESS_MODEL = [
  'Sync in progress',
  'Closing this window will not',
  'interrupt your sync',
  'Estimated time - 10 mins',
  'Completed 1/2'
];
export const COPY_TEXT = 'Text copied';

export const DAYS_OF_WEEK = new Map([
  ['Su', 'SUN'],
  ['Mo', 'MON'],
  ['Tu', 'TUE'],
  ['We', 'WED'],
  ['Th', 'THU'],
  ['Fr', 'FRI'],
  ['Sa', 'SAT']
]);
export const DAY = 'day';
export const START_DATE = 'Start date';
export const END_DATE = 'End date';

export const mockNotifications = [
  {
    id: 1,
    name: 'Amit',
    user_action: 'UPLOADED',
    file_name: 'company agreement.pdf ',
    date: '20 June 10:30 AM'
  },
  {
    id: 2,
    name: 'John',
    user_action: 'UPLOADED',
    file_name: 'company agreement.pdf ',
    date: '22 July 11:30 AM'
  },
  {
    id: 4,
    name: 'Grace',
    user_action: 'DELETED',
    file_name: 'company profile.pdf ',
    date: '11 April 10:25 PM'
  },
  {
    id: 5,
    name: 'Sai',
    user_action: 'DELETED',
    file_name: 'company agreement.pdf ',
    date: '11 August 7:25 PM'
  },
  {
    id: 6,
    name: 'Ram',
    user_action: 'DELETED',
    file_name: 'company agreement.pdf ',
    date: '11 August 7:25 PM'
  },
  {
    id: 7,
    name: 'Vimal',
    user_action: 'UPDATED',
    file_name: 'company agreement.pdf ',
    date: '16 April 4:25 AM'
  },
  {
    id: 8,
    name: 'Arun',
    user_action: 'UPDATED',
    file_name: 'company Presentation.pdf ',
    date: '10 october 4:25 AM'
  },
  {
    id: 9,
    name: 'Amit',
    user_action: 'UPLOADED',
    file_name: 'company agreement.pdf ',
    date: '20 June 8:30 AM'
  },
  {
    id: 10,
    name: 'Amit',
    user_action: 'DELETED',
    file_name: 'company agreement.pdf ',
    date: '1 July 7:30 PM'
  }
];

export const SIGN_IN = 'Sign In';
export const REMEMBER_ME = 'Remember me';
export const FORGOT_PASSWORD = 'Forgot password?';
export const WITH_GOOGLE = 'Continue with google';
export const DOESNT_HAVE_ACCOUNT = 'Doesn’t have an account?';
export const SIGN_UP = 'Sign Up';
export const EMAIL_ERROR = 'Please enter a valid email address';
export const PASSWORD_ERROR =
  'Password should be at least 8 characters with 1 uppercase, 1 lowercase, and 1 special character';

export const SEARCH_RESULT = 'Search results';
export const OTHER_DOCUMENTS_TXT = 'Other documents';
export const DOCUMENT_IMG1_ALT = 'power user img not found';
export const DOCUMENT_IMG2_ALT = 'learn basics img not found';

export const ALREADY_ACCOUNT = 'Already have an account?';
export const CREATE_ACCOUNT = 'Create account';
export const NAME_ERROR = 'User name should be minimum 4 characters and maximum 50 characters';
export const NAME = 'Name';
export const NAME_PLACEHOLDER = 'John Cena';

export const BACK_BUTTON = 'Back';
export const SYNC_BUTTON = 'Sync';
export const FOLDER_NAMES = ['Zemoso decks', 'Sample data', 'Zemoso data'];
export const FORM_CONTENT = 'Choose the folders to sync with contiq';
export const FOLDER_TITLE = 'Add files';
export const FILES = {
  'Company overview': true,
  'Software agreement': true,
  'Sample data': false,
  'Zemoso data': false
};

export const PASSWORD_RESET = 'Password reset';
export const PASSWORD_RESET_MESSAGE1 = 'Your password has been successfully reset.';
export const PASSWORD_RESET_MESSAGE2 = 'Click below to login magically.';
export const PASSWORD_RESET_BUTTON = 'Continue';
export const RESET_PASSWORD = 'Reset your password';
export const RESET_PASSWORD_MESSAGE1 = 'The verification mail will be sent to the mailbox';
export const RESET_PASSWORD_MESSAGE2 = 'please check it.';
export const RESET_PASSWORD_BUTTON = 'Send';
export const UPLOAD_MODEL_HEADING = 'Upload options';
export const UPLOAD_MODEL_BODY =
  ' already exists in this location. Do you want to replace the existing file with a new version or keep both files?';
export const UPLOAD_MODEL_BUTTON1 = 'Cancel';
export const UPLOAD_MODEL_BUTTON2 = 'Upload';
export const UPLOAD_MODEL_PDF_NAME = 'Contract agreement.pdf';
export const HOME = 'Home';
export const RECENT = 'Recent';

export const DROP_FILES_TEXT = 'Drop your files here ';
export const CHOOSE_FILE_BUTTON = 'Choose files';
export const UPLOAD_FILE_BUTTON = 'Upload file';
export const CREATE_NEW_PASSWORD = 'Create new password';
export const CREATE_NEW_PASSWORD_MESSAGE = 'Enter new password below to change your password';
export const CREATE_NEW_PASSWORD_BUTTON = 'Reset Password';
export const NEW_PASSWORD = 'New password';
export const NEW_PASSWORD_PLACEHOLDER = 'Enter new password';
export const CONFIRM_NEW_PASSWORD = 'Confirm new password';
export const CONFIRM_NEW_PASSWORD_PLACEHOLDER = 'Confirm new password';
export const CONFIRM_PASSWORD_ERROR = 'Confirm password does not match';
export const SLIDE = 'SLIDE';

export const DRAG_MEDIA_CONTENT = ['Drag media here to upload of', 'connect an account'];

export const DISCOVERY_DOCS = ['https://www.googleapis.com/discovery/v1/apis/drive/v3/rest'];
export const SCOPE = 'https://www.googleapis.com/auth/drive.metadata.readonly';
export const PRESENTATION_CARD = [
  {
    img: 'profile-img',
    imgAlt: 'profile image not found',
    name: 'profile.pdf',
    icon: 'pdf-icon',
    iconAlt: 'icon not found',
    Date: '2023-07-22'
  },
  {
    img: 'contract-img',
    imgAlt: 'contract agreement image not found',
    name: 'Contract agreement.ppt',
    icon: 'pdf-icon',
    iconAlt: 'icon not found',
    Date: '2023-04-19'
  }
];
export const PDF_LICENSE = 'eIIdD68GXNVYsFcQbuJ9';

export const PDF_STYLE = `.document-content-container,
.LeftPanel,
.content {
  background-color: ${theme.palette.text.white};
}
#Thumbnail-container {
  height: ${theme.spacing(62)} !important;
  width:  ${theme.spacing(49)} !important;
  border-radius:  ${theme.spacing(0.5)};
  padding:  ${theme.spacing(1)},  ${theme.spacing(2)}
}
.Thumbnail .page-label {
  display: none;
}
.left-panel-container {
  width: 100%;
  padding: 0 !important
}
.Thumbnail.active .container .page-image {
  border:  ${theme.spacing(0.5)} solid ${theme.palette.primary.main};
}
::-webkit-scrollbar-track{
  background-color: ${theme.palette.grays.gray600};
  width: ${theme.spacing(3.5)};
  border-radius: ${theme.spacing(3)};
}
::-webkit-scrollbar-thumb {
  background-color: ${theme.palette.grays.gray100};
  border-radius: ${theme.spacing(4)};
  height: ${theme.spacing(49)};
  width: ${theme.spacing(1.5)};
}
  `;
export const DEFAULT_ZOOM = 0.85;
export const MIN_ZOOM = 0.1;
export const MAX_ZOOM = 1.5;

export const FileItems = { item1: 'PDF', item2: 'PPT', item3: 'Image' };
export const PublishItems = {
  item1: 'Published by me',
  item2: 'Published by sales team',
  item3: 'Published by others'
};
export const RECENT_FILE_DATA = [
  {
    id: 1,
    name: 'Company transformation.pdf'
  },
  {
    id: 2,
    name: 'Company Profile.pdf'
  },
  {
    id: 3,
    name: 'Company transformation.ppt'
  }
];

export const FILE_DATA = [
  {
    id: 1,
    key: 1,
    label: 'Company agreement.pdf',
    details:
      'Since being established in 1908 as a sewing machine repair business, the brother group has pursued the diversification and globalization of business in its history of more...'
  },
  {
    id: 2,
    key: 2,
    label: 'Software agreement2.pdf',
    details:
      'Since being established in 1908 as a sewing machine repair business, the brother group has pursued the diversification and globalization of business in its history of more...'
  },
  {
    id: 3,
    key: 3,
    label: 'Software agreement3.pdf',
    details:
      'Since being established in 1908 as a sewing machine repair business, the brother group has pursued the diversification and globalization of business in its history of more...'
  },
  {
    id: 4,
    key: 4,
    label: 'Software agreement.pdf',
    details:
      'Since being established in 1908 as a sewing machine repair business, the brother group has pursued the diversification and globalization of business in its history of more...'
  },
  {
    id: 5,
    key: 5,
    label: 'Company agreement2.pdf',
    details:
      'Since being established in 1908 as a sewing machine repair business, the brother group has pursued the diversification and globalization of business in its history of more...'
  },
  {
    id: 6,
    key: 6,
    label: 'Company agreement3.pdf',
    details:
      'Since being established in 1908 as a sewing machine repair business, the brother group has pursued the diversification and globalization of business in its history of more...'
  }
];

export const UPLOADING_TEXT = 'Uploading 1/1';
export const INITIAL_FILE = {
  id: '',
  userId: 0,
  name: '',
  type: '',
  path: '',
  content: '',
  createdAt: 0
};

export const NAVIGATE_SIGNIN = '/';
export const NAVIGATE_SIGNUP = '/signup';
export const NAVIGATE_RESET_PASSWORD = '/reset-password';
export const NAVIGATE_CREATE_NEW_PASSWORD = '/create-new-password';
export const NAVIGATE_CONFIRM_NEW_PASSWORD = '/confirm-new-password';
export const NAVIGATE_HOME = '/home';
export const NAVIGATE_FILE = '/file';
export const NAVIGATE_PDF = '/pdf';

export const WINDOW_ALERT_NEW_PASSWORD_ALREADY_EXIST =
  'New password already exists try again with a different password';
export const EMAIL_NOT_EXIST = 'Email Does Not Exist';
export const LOGIN_FILED = 'Login failed: The provided email and password do not match.';
export const USER_ALREADY_EXIST = 'User already exists';

// export const REDIRECT_URL = 'https://bc112-fe.fe-assignment.tk/home';
export const REDIRECT_URL = 'http://localhost:3000/home';
