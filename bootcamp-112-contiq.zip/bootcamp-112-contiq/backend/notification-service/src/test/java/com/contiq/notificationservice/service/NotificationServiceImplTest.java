package com.contiq.notificationservice.service;

import com.contiq.notificationservice.dto.NotificationDTO;
import com.contiq.notificationservice.entity.Action;
import com.contiq.notificationservice.entity.Notification;
import com.contiq.notificationservice.exception.EntityPersistenceException;
import com.contiq.notificationservice.mapper.NotificationMapper;
import com.contiq.notificationservice.repository.NotificationRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.when;

class NotificationServiceImplTest {
    @Mock
    private NotificationRepository notificationRepository;

    @InjectMocks
    private NotificationServiceImpl notificationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    void getAllNotifications_NotificationsExist_ReturnsListOfNotificationDTOs() {
        Notification notification1 = new Notification();
        notification1.setId(1);
        notification1.setUserId(1);
        notification1.setCreatedTime(LocalDateTime.now());
        notification1.setAction(Action.UPLOADED);
        notification1.setFilename("file12.pdf");
        Notification notification2 = new Notification();
        notification2.setId(2);
        notification2.setUserId(2);
        notification2.setCreatedTime(LocalDateTime.now());
        notification2.setAction(Action.DELETED);
        notification2.setFilename("file23.pdf");
        List<Notification> notifications = new ArrayList<>();
        notifications.add(notification1);
        notifications.add(notification2);
        when(notificationRepository.findAll()).thenReturn(notifications);

        List<NotificationDTO> result = notificationService.getAllNotifications();

        Assertions.assertNotNull(result);
        Assertions.assertEquals(notifications.size(), result.size());
        NotificationDTO notificationDTO1 = result.get(0);
        Assertions.assertEquals(notification1.getId(), notificationDTO1.getId());
        Assertions.assertEquals(notification1.getCreatedTime(), notificationDTO1.getCreatedTime());
        Assertions.assertEquals(notification1.getFilename(), notificationDTO1.getFilename());
        Assertions.assertEquals(notification1.getAction(), notificationDTO1.getAction());
        NotificationDTO notificationDTO2 = result.get(1);
        Assertions.assertEquals(notification2.getId(), notificationDTO2.getId());
        Assertions.assertEquals(notification2.getCreatedTime(), notificationDTO2.getCreatedTime());
        Assertions.assertEquals(notification2.getFilename(), notificationDTO2.getFilename());
        Assertions.assertEquals(notification2.getAction(), notificationDTO2.getAction());
    }

    @Test
    void getAllNotifications_NoNotifications_ReturnsEmptyList() {
        when(notificationRepository.findAll()).thenReturn(new ArrayList<>());

        List<NotificationDTO> result = notificationService.getAllNotifications();

        Assertions.assertNotNull(result);
        Assertions.assertTrue(result.isEmpty());
    }

    @Test
    void saveNotification_ValidNotification_ReturnsNotificationDTO() {
        Notification notification1 = new Notification();
        notification1.setId(1);
        notification1.setUserId(1);
        notification1.setCreatedTime(LocalDateTime.now());
        notification1.setAction(Action.UPLOADED);
        notification1.setFilename("file12.pdf");
        when(notificationRepository.save(notification1)).thenReturn(notification1);

        NotificationDTO notificationDTO1 = NotificationMapper.convertEntityToDto(notificationRepository.save(notification1));

        Assertions.assertNotNull(notificationDTO1);
        Assertions.assertEquals(notification1.getId(), notificationDTO1.getId());
        Assertions.assertEquals(notification1.getCreatedTime(), notificationDTO1.getCreatedTime());
        Assertions.assertEquals(notification1.getFilename(), notificationDTO1.getFilename());
        Assertions.assertEquals(notification1.getAction(), notificationDTO1.getAction());
    }

    @Test
    void saveNotification_FailedSave_ThrowsException() {
        Notification notification = new Notification();
        NotificationDTO notificationDTO = new NotificationDTO();

        when(notificationRepository.save(notification)).thenThrow(new RuntimeException("DB Error"));

        assertThrows(EntityPersistenceException.class, () -> notificationService.saveNotification(notificationDTO));
    }


}
