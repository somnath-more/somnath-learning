package com.contiq.notificationservice.controller;

import com.contiq.notificationservice.dto.NotificationDTO;
import com.contiq.notificationservice.service.NotificationService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;


class NotificationControllerTest {

    @Mock
    private NotificationService notificationService;

    @InjectMocks
    private NotificationController notificationController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveNotification_ReturnNotificationDTO() {
        NotificationDTO notificationDTO = new NotificationDTO();
        when(notificationService.saveNotification(notificationDTO)).thenReturn(notificationDTO);

        NotificationDTO response = notificationController.saveNotification(notificationDTO).getBody();

        Assertions.assertEquals(notificationDTO, response);
        verify(notificationService, times(1)).saveNotification(notificationDTO);
    }


    @Test
    void testGetAllNotifications_ReturnsListOfNotificationDTOs() {
        List<NotificationDTO> expectedNotificationDTOs = new ArrayList<>();
        when(notificationService.getAllNotifications()).thenReturn(expectedNotificationDTOs);

        List<NotificationDTO> result = notificationController.findAllNotifications().getBody();

        Assertions.assertEquals(expectedNotificationDTOs, result);
        verify(notificationService, times(1)).getAllNotifications();
    }
}
