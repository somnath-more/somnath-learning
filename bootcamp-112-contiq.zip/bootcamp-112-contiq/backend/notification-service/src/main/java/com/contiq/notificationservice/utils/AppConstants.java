package com.contiq.notificationservice.utils;

public class AppConstants {
    public static final String NOTIFICATION_FILTER_URL = "/api/v1/notifications/*";

}
