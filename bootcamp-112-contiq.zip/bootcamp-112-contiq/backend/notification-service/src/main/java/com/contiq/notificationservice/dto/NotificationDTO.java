package com.contiq.notificationservice.dto;

import com.contiq.notificationservice.entity.Action;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationDTO {

    private long id;
    private LocalDateTime createdTime;
    private long userId;
    private Action action;
    private String filename;

}
