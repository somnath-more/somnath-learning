package com.contiq.notificationservice.entity;

public enum Action {
    UPLOADED,
    UPDATED,
    DELETED
}