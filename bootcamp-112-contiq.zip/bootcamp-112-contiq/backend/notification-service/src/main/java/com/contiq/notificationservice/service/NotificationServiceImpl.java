package com.contiq.notificationservice.service;

import com.contiq.notificationservice.dto.NotificationDTO;
import com.contiq.notificationservice.entity.Notification;
import com.contiq.notificationservice.exception.EntityPersistenceException;
import com.contiq.notificationservice.mapper.NotificationMapper;
import com.contiq.notificationservice.repository.NotificationRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Override
    public List<NotificationDTO> getAllNotifications() {
        List<Notification> notifications = notificationRepository.findAll();
        List<NotificationDTO> notificationDTOs = new ArrayList<>();
        for (Notification notification : notifications) {
            notificationDTOs.add(NotificationMapper.convertEntityToDto(notification));
        }
        return notificationDTOs;
    }

    @Override
    public NotificationDTO saveNotification(NotificationDTO notificationDTO) {
        try {
            return NotificationMapper.convertEntityToDto(notificationRepository.save(NotificationMapper.convertDtoToEntity(notificationDTO)));
        }
        catch (Exception e){
            throw new EntityPersistenceException("Unable to save Notification");
        }
    }
}
