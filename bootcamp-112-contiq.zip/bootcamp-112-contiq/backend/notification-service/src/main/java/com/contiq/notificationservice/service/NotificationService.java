package com.contiq.notificationservice.service;

import com.contiq.notificationservice.dto.NotificationDTO;

import java.util.List;

public interface NotificationService {
    List<NotificationDTO> getAllNotifications();
    NotificationDTO saveNotification(NotificationDTO notificationDTO);
}
