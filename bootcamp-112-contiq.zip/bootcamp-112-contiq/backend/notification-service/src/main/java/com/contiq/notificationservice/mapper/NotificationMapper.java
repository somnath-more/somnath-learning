package com.contiq.notificationservice.mapper;

import com.contiq.notificationservice.dto.NotificationDTO;
import com.contiq.notificationservice.entity.Notification;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;

public class NotificationMapper {
    @Autowired
    private static ModelMapper modelMapper;
    static {
        modelMapper = new ModelMapper();
    }

    public static Notification convertDtoToEntity(NotificationDTO notificationDTO){
        modelMapper.getConfiguration()
                .setMatchingStrategy(MatchingStrategies.LOOSE);
        return modelMapper.map(notificationDTO, Notification.class);
    }
    public static NotificationDTO convertEntityToDto(Notification notification){
        modelMapper.getConfiguration()
                .setMatchingStrategy(MatchingStrategies.LOOSE);
        return modelMapper.map(notification, NotificationDTO.class);
    }
}
