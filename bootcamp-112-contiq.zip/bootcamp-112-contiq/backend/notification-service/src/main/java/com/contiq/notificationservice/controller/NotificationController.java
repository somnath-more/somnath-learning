package com.contiq.notificationservice.controller;

import com.contiq.notificationservice.dto.NotificationDTO;
import com.contiq.notificationservice.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import java.util.List;

@RestController
@RequestMapping("/api/v1/notifications")
@Slf4j
public class NotificationController {
    @Autowired
    private NotificationService notificationService;

    @GetMapping
    @Scheduled(fixedRate = 6000)
    public ResponseEntity<List<NotificationDTO>> findAllNotifications(){
        return new ResponseEntity<>(notificationService.getAllNotifications(), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<NotificationDTO> saveNotification(@RequestBody NotificationDTO notificationDTO){
        return new ResponseEntity<>(notificationService.saveNotification(notificationDTO), HttpStatus.CREATED);
    }

}
