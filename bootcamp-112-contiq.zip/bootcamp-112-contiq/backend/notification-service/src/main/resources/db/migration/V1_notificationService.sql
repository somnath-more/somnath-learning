create table IF NOT EXISTS `contiq`. `notification` (
	`id` bigint not null auto_increment,
    `user_id` bigint not null,
    `action` enum('UPLOADED', 'DELETED', 'UPDATED') not null,
     `file_name` varchar(254) not null,
     `created_at`  datetime default now()  not null,
    primary key(`id`),
    key `USER_ID` (`user_id`),
    constraint `USER_ID` foreign key(`user_id`) references `user` (`id`)
    on delete no action on update no action
)engine=InnoDB auto_increment=1 DEFAULT CHARSET=latin1;