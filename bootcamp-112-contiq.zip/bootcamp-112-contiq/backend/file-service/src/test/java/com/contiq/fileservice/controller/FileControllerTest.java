package com.contiq.fileservice.controller;

import com.contiq.fileservice.entity.File;
import com.contiq.fileservice.exception.FileException;
import com.contiq.fileservice.service.FileDownloadService;
import com.contiq.fileservice.service.FileService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.util.Collections;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class FileControllerTest {

    private MockMvc mockMvc;

    @Mock
    private FileDownloadService downloadService;

    @Mock
    private FileService fileService;

    @BeforeEach
    void setup() {
        FileController fileController = new FileController();
        fileController.fileService = fileService;
        fileController.downloadService = downloadService;
        mockMvc = MockMvcBuilders.standaloneSetup(fileController).build();
    }

    @Test
    void testUploadFile() throws Exception {
        File dummyFile = new File();
        when(downloadService.saveFile(any(MultipartFile.class), anyLong())).thenReturn(dummyFile);

        MockMultipartFile multipartFile = new MockMultipartFile("file", "test.txt", "text/plain", "This is a test".getBytes());

        mockMvc.perform(MockMvcRequestBuilders.multipart("/api/v1/files").file(multipartFile).param("userId", "1")).andExpect(status().isCreated()).andExpect(content().string("File uploaded successfully from local"));
    }

    @Test
    void testUploadFile_SaveException() throws Exception {
        MockMultipartFile file = new MockMultipartFile("file", "test.txt", "text/plain", "sample content".getBytes());
        Long userId = 1L;

        doThrow(new FileException("Failed to save file locally")).when(downloadService).saveFile(any(MultipartFile.class), eq(userId));

        mockMvc.perform(multipart("/api/v1/files").file(file).param("userId", "1")).andExpect(status().isBadRequest()).andExpect(content().string("Failed to save file locally"));
    }

    @Test
    void testUploadGoogleDriveFile() throws Exception {
        String fileId = "sampleFileId";
        String fileName = "sampleFileName";
        String mimeType = "application/octet-stream";
        ByteArrayOutputStream os = new ByteArrayOutputStream();

        when(downloadService.downloadFile(fileId)).thenReturn(os);
        when(downloadService.getFileName(fileId)).thenReturn(fileName);
        File dummyFile = new File();
        when(downloadService.saveFile(any(ByteArrayOutputStream.class), eq(fileName), eq(mimeType), anyLong())).thenReturn(dummyFile);

        mockMvc.perform(post("/api/v1/files/drive").param("fileId", fileId).param("userId", "1")).andExpect(status().isCreated()).andExpect(content().string("File uploaded successfully from drive"));
    }

    @Test
    void testUploadGoogleDriveFile_FileException() throws Exception {
        String fileId = "sampleFileId";
        String errorMessage = "Error downloading file";

        when(downloadService.downloadFile(fileId)).thenThrow(new FileException(errorMessage));

        mockMvc.perform(post("/api/v1/files/drive").param("fileId", fileId).param("userId", "1"))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(errorMessage));
    }

    @Test
    void testSearchFiles() throws Exception {
        when(fileService.searchFiles(anyString(), anyLong())).thenReturn(Collections.singletonList(new File()));

        mockMvc.perform(get("/api/v1/files/search").param("keyword", "test").param("userId", "1")).andExpect(status().isOk());

        verify(fileService, times(1)).searchFiles(anyString(), anyLong());
    }


    @Test
    void testGetFilesByUserId() throws Exception {
        when(fileService.findByUserId(anyLong())).thenReturn(Collections.singletonList(new File()));

        mockMvc.perform(get("/api/v1/files/user/1")).andExpect(status().isOk());

        verify(fileService, times(1)).findByUserId(anyLong());
    }

    @Test
    void testGetFileById() throws Exception {
        when(fileService.findById(anyString())).thenReturn(new File());

        mockMvc.perform(get("/api/v1/files/1")).andExpect(status().isOk());

        verify(fileService, times(1)).findById(anyString());
    }

    @Test
    void testGetFileById_NotFound() throws Exception {
        when(fileService.findById(anyString())).thenReturn(null);

        mockMvc.perform(get("/api/v1/files/unknown-id")).andExpect(status().isNotFound());

        verify(fileService, times(1)).findById(anyString());
    }

    @Test
    void testDeleteFile() throws Exception {
        when(fileService.findById(anyString())).thenReturn(new File());

        mockMvc.perform(delete("/api/v1/files/1")).andExpect(status().isOk());

        verify(fileService, times(1)).deleteFile(anyString());
    }

    @Test
    void testDeleteFile_NotFound() throws Exception {
        when(fileService.findById(anyString())).thenReturn(null);

        mockMvc.perform(delete("/api/v1/files/unknown-id")).andExpect(status().isNotFound());
        verify(fileService, times(0)).deleteFile(anyString());
    }

}
