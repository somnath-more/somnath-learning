package com.contiq.fileservice.service;

import com.contiq.fileservice.entity.File;
import com.contiq.fileservice.exception.FileException;
import com.contiq.fileservice.repository.FileRepository;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FileServiceImplTest {

    @InjectMocks
    private FileServiceImpl fileService;

    @Mock
    private FileRepository fileRepository;

    @Mock
    private PDDocument mockDocument;

    @Test
    void testSaveFile_Success() {
        File file = new File();
        when(fileRepository.save(any())).thenReturn(file);

        File result = fileService.saveFile(file);
        assertNotNull(result);
    }

    @Test
    void testSaveFile_Failure() {
        when(fileRepository.save(any())).thenThrow(new RuntimeException());
        File file = new File();

        assertThrows(FileException.class, () -> fileService.saveFile(file));
    }


    @Test
    void testFindByUserId_HasFiles() {
        Long userId = 1L;
        when(fileRepository.findByUserId(userId)).thenReturn(Arrays.asList(new File(), new File()));

        List<File> result = fileService.findByUserId(userId);
        assertEquals(2, result.size());
    }

    @Test
    void testFindByUserId_Failure() {
        Long userId = 1L;
        when(fileRepository.findByUserId(userId)).thenThrow(new RuntimeException());

        assertThrows(FileException.class, () -> fileService.findByUserId(userId));
    }

    @Test
    void testSearchFiles_MatchingFiles() {
        Long userId = 1L;
        String keyword = "test";
        when(fileRepository.findByUserIdAndKeyword(userId, keyword)).thenReturn(List.of(new File()));

        List<File> result = fileService.searchFiles(keyword, userId);
        assertEquals(1, result.size());
    }

    @Test
    void testSearchFiles_Failure() {
        Long userId = 1L;
        String keyword = "test";
        when(fileRepository.findByUserIdAndKeyword(userId, keyword)).thenThrow(new RuntimeException());

        assertThrows(FileException.class, () -> fileService.searchFiles(keyword, userId));
    }

    @Test
    void testFindById_FileExists() {
        String fileId = "123";
        when(fileRepository.findById(fileId)).thenReturn(Optional.of(new File()));

        File result = fileService.findById(fileId);
        assertNotNull(result);
    }

    @Test
    void testFindById_Failure() {
        String fileId = "123";
        when(fileRepository.findById(fileId)).thenThrow(new RuntimeException());

        assertThrows(FileException.class, () -> fileService.findById(fileId));
    }

    @Test
    void testGetFileResource_FileNotExists() {
        String filePath = "test.txt";
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);

        ResponseEntity<Resource> response = fileService.getFileResource(mockRequest, filePath);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
        assertNull(response.getHeaders().getContentType());
    }

    @Test
    void testDeleteFile_Success() {
        String fileId = "123";
        File file = new File();
        file.setPath("/tmp/test.txt");
        when(fileRepository.findById(fileId)).thenReturn(Optional.of(file));
        doNothing().when(fileRepository).deleteById(fileId);

        assertDoesNotThrow(() -> fileService.deleteFile(fileId));
    }

    @Test
    void testDeleteFile_FileNotExists() {
        String fileId = "123";
        when(fileRepository.findById(fileId)).thenReturn(Optional.empty());

        assertThrows(FileException.class, () -> fileService.deleteFile(fileId));
    }

    @Test
    void testDeleteFile_Failure() {
        String fileId = "123";
        when(fileRepository.findById(fileId)).thenReturn(Optional.of(new File()));
        doThrow(new RuntimeException()).when(fileRepository).deleteById(fileId);

        assertThrows(FileException.class, () -> fileService.deleteFile(fileId));
    }

    @Test
    void testExtractContentFromPdf_Failure() {
        try (MockedStatic<PDDocument> mocked = Mockito.mockStatic(PDDocument.class)) {
            InputStream mockInputStream = new ByteArrayInputStream("test".getBytes());
            mocked.when(() -> PDDocument.load(mockInputStream)).thenReturn(mockDocument);

            assertThrows(NullPointerException.class, () -> fileService.extractContentFromPdf(mockInputStream));
        }
    }
}
