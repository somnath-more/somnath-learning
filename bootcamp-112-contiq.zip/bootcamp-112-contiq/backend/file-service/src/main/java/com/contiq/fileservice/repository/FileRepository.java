package com.contiq.fileservice.repository;


import com.contiq.fileservice.entity.File;
import org.springframework.data.elasticsearch.annotations.Query;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FileRepository extends ElasticsearchRepository<File, String> {

    /**
     * Retrieves a list of files associated with the given user ID.
     *
     * @param userId The ID of the user whose files are to be retrieved.
     * @return A list of files belonging to the specified user.
     */
    List<File> findByUserId(Long userId);

    /**
     * Retrieves a list of files associated with the given user ID and matching the provided name.
     *
     * @param userId The ID of the user whose files are to be retrieved.
     * @param name   The name to match for file retrieval.
     * @return A list of files matching the user ID and name.
     */
    List<File> findByUserIdAndName(Long userId, String name);

    /**
     * Custom query to search for files associated with the given user ID and containing the provided keyword.
     *
     * @param userId  The ID of the user whose files are to be searched.
     * @param keyword The keyword to search for in file names or content.
     * @return A list of files matching the user ID and keyword search criteria.
     */
    @Query("{\"bool\": {\"must\": [{\"match\": {\"userId\": \"?0\"}}, {\"bool\": {\"should\": [{\"match\": {\"name\": \"?1\"}}, {\"match\": {\"content\": \"?1\"}}]}}]}}")
    List<File> findByUserIdAndKeyword(Long userId, String keyword);
}
