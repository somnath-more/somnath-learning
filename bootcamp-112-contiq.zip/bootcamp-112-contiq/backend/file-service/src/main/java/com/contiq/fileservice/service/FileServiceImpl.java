package com.contiq.fileservice.service;

import com.contiq.fileservice.entity.File;
import com.contiq.fileservice.exception.FileException;
import com.contiq.fileservice.repository.FileRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

@Service("default")
@Slf4j
public class FileServiceImpl implements FileService {

    @Autowired
    private FileRepository fileRepository;

    @Value("${file.storage.location}")
    private String baseDir;

    @Override
    public File saveFile(File file) {
        try {
            log.info("Request received at saveFile service");
            return fileRepository.save(file);
        } catch (Exception e) {
            log.error("Error saving file: {}", e.getMessage());
            throw new FileException("Failed to save file.");
        }
    }

    @Override
    public List<File> findByUserId(Long userId) {
        try {
            log.info("Request received at findByUserId service for userId {}", userId);
            return fileRepository.findByUserId(userId);
        } catch (Exception e) {
            log.error("Error finding files by user ID: {}", e.getMessage());
            throw new FileException("Failed to find files by user ID.");
        }
    }

    @Override
    public List<File> searchFiles(String keyword, Long userId) {
        try {
            log.info("Request received at searchFiles service for userId {}", userId);
            return fileRepository.findByUserIdAndKeyword(userId, keyword);
        } catch (Exception e) {
            log.error("Error searching files: {}", e.getMessage());
            throw new FileException("Failed to search files.");
        }
    }

    @Override
    public File findById(String id) {
        try {
            log.info("Request received at findById service for file id {}", id);
            Optional<File> fileOptional = fileRepository.findById(id);
            return fileOptional.orElse(null);
        } catch (Exception e) {
            log.error("Error finding file by ID: {}", e.getMessage());
            throw new FileException("Failed to find file by ID.");
        }
    }

    @Override
    public ResponseEntity<Resource> getFileResource(HttpServletRequest httpRequest, String filepath) {
        try {
            log.info("Request received at getFileResource");
            Path storageLocation = Paths.get(baseDir);
            Path filePath = storageLocation.resolve(filepath);
            Resource resource = new UrlResource(filePath.toUri());

            if (resource.exists() && resource.isReadable()) {
                String contentType = httpRequest.getServletContext().getMimeType(filePath.toString());
                return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType)).body(resource);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }


    /**
     * Deletes the file with the specified ID from elastic search DB and from local also.
     */
    @Override
    public void deleteFile(String id) {
        try {
            log.info("Request received at deleteFile service for file id {}", id);
            Optional<File> fileOptional = fileRepository.findById(id);
            if (fileOptional.isEmpty()) {
                log.error("File with ID: {} not found", id);
                throw new FileException("File not found.");
            }

            fileRepository.deleteById(id);

            Path path = Paths.get(fileOptional.get().getPath());
            Files.deleteIfExists(path);

        } catch (Exception e) {
            log.error("Error deleting file: {}", e.getMessage());
            throw new FileException("Failed to delete file.");
        }
    }

    @Override
    public String extractContentFromPdf(InputStream inputStream) {
        try {
            log.info("Extracting file content...");
            PDDocument document = PDDocument.load(inputStream);
            PDFTextStripper pdfTextStripper = new PDFTextStripper();
            String content = pdfTextStripper.getText(document);
            document.close();
            return content;
        } catch (IOException e) {
            log.error("Error extracting content from PDF: {}", e.getMessage());
            throw new FileException("Failed to extract content from PDF.");
        }
    }
}
