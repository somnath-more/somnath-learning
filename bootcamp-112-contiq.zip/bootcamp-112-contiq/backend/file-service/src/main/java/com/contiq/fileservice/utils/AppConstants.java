package com.contiq.fileservice.utils;

public class AppConstants {
    public static final String FILES_FILTER_URL = "/api/v1/file/*";

}
