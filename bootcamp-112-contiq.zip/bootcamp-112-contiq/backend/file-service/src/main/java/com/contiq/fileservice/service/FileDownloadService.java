package com.contiq.fileservice.service;

import com.contiq.fileservice.entity.File;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.google.auth.http.HttpCredentialsAdapter;
import com.google.auth.oauth2.GoogleCredentials;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.List;

@Service
@Slf4j
public class FileDownloadService {

    @Autowired
    FileService fileService;

    @Value("${file.storage.location}")
    private String baseDir;

    public Drive getDriveService() throws IOException {
        GoogleCredentials credentials = GoogleCredentials.getApplicationDefault().createScoped(List.of(DriveScopes.DRIVE));
        HttpRequestInitializer requestInitializer = new HttpCredentialsAdapter(credentials);
        return new Drive.Builder(new NetHttpTransport(), GsonFactory.getDefaultInstance(), requestInitializer).setApplicationName("Drive samples").build();
    }

    public ByteArrayOutputStream downloadFile(String realFileId) throws IOException {
        Drive service = getDriveService();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        service.files().get(realFileId).executeMediaAndDownloadTo(outputStream);
        return outputStream;
    }


    public String getFileName(String realFileId) throws IOException {
        Drive service = getDriveService();
        com.google.api.services.drive.model.File file = service.files().get(realFileId).execute();
        return file.getName();
    }

    public File saveFile(MultipartFile multipartFile, Long userId) throws IOException {
        String originalFileName = multipartFile.getOriginalFilename();
        String contentType = multipartFile.getContentType();
        byte[] bytes = multipartFile.getBytes();

        return saveFile(bytes, originalFileName, contentType, userId);
    }

    public File saveFile(ByteArrayOutputStream outputStream, String originalFileName, String contentType, Long userId) throws IOException {
        byte[] bytes = outputStream.toByteArray();

        return saveFile(bytes, originalFileName, contentType, userId);
    }

    private File saveFile(byte[] content, String originalFileName, String contentType, Long userId) throws IOException {

        String sanitizedUserId = sanitizeUserId(userId.toString());
        String sanitizedFileName = sanitizeFileName(originalFileName);

        Path path = Paths.get(baseDir, sanitizedUserId, sanitizedFileName);

        Files.createDirectories(path.getParent());
        Files.write(path, content);

        File uploadedFile = new File();
        uploadedFile.setUserId(userId);
        uploadedFile.setName(originalFileName);
        uploadedFile.setType(contentType);
        uploadedFile.setPath(path.toString());
        uploadedFile.setCreatedAt(Instant.now().toEpochMilli());
        uploadedFile.setContent(fileService.extractContentFromPdf(new ByteArrayInputStream(content)));

        return fileService.saveFile(uploadedFile);
    }

    private String sanitizeUserId(String userId) {
        return userId.replaceAll("[^a-zA-Z0-9]", "");
    }

    private String sanitizeFileName(String fileName) {
        return fileName.replaceAll("[^a-zA-Z0-9.]", "");
    }

}