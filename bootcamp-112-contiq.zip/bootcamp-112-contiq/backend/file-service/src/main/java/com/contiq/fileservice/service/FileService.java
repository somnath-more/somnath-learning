package com.contiq.fileservice.service;

import com.contiq.fileservice.entity.File;
import org.elasticsearch.ResourceNotFoundException;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public interface FileService {

    /**
     * Saves the provided file.
     *
     * @param file The file to be saved.
     * @return The saved file object.
     */
    File saveFile(File file);

    /**
     * Retrieves a list of files associated with the given user ID.
     *
     * @param userId The ID of the user whose files are to be retrieved.
     * @return A list of files belonging to the specified user.
     */
    List<File> findByUserId(Long userId);

    /**
     * Searches for files containing the provided keyword and associated with the given user ID.
     *
     * @param keyword The keyword to search for in file names or content.
     * @param userId  The ID of the user whose files are to be searched.
     * @return A list of files matching the search criteria.
     */
    List<File> searchFiles(String keyword, Long userId);

    /**
     * Retrieves the file with the specified ID.
     *
     * @param id The ID of the file to retrieve.
     * @return The file object corresponding to the provided ID.
     */
    File findById(String id);

    /**
     * Deletes the file with the specified ID.
     *
     * @param id The ID of the file to be deleted.
     */
    void deleteFile(String id);

    /**
     * Extracts content from a PDF file provided as an input stream.
     *
     * @param inputStream The input stream of the PDF file.
     * @return The extracted content from the PDF.
     * @throws IOException If an I/O error occurs during PDF processing.
     */
    String extractContentFromPdf(InputStream inputStream) throws IOException;

    /**
     * Retrieves a ResponseEntity containing a Resource representing a file located at the specified filepath.
     * This method takes an HttpServletRequest and a filepath as input and constructs a ResponseEntity
     * that wraps a Resource. The Resource can represent various types of file resources, such as
     * files on the local filesystem, resources from a classpath, or other sources.
     *
     * @param httpRequest The HttpServletRequest object containing information about the current request.
     * @param filepath    The path to the file to be retrieved as a Resource.
     * @return A ResponseEntity containing a Resource representing the requested file.
     * @throws IllegalArgumentException if the provided filepath is null or empty.
     * @throws ResourceNotFoundException if the requested file does not exist or cannot be accessed.
     */
    ResponseEntity<Resource> getFileResource(HttpServletRequest httpRequest, String filepath);

}

