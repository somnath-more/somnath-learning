package com.contiq.fileservice.controller;

import com.contiq.fileservice.entity.File;
import com.contiq.fileservice.exception.FileException;
import com.contiq.fileservice.service.FileDownloadService;
import com.contiq.fileservice.service.FileService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@RestController
@Slf4j
@RequestMapping("/api/v1/files")
public class FileController {

    @Autowired
    @Qualifier("default")
    FileService fileService;

    @Autowired
    FileDownloadService downloadService;


    @PostMapping
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile multipartFile, @RequestParam Long userId) throws IOException {
        log.info("Request received at uploadFile controller for userId {}", userId);
        try {
            downloadService.saveFile(multipartFile, userId);
            return ResponseEntity.status(HttpStatus.CREATED).body("File uploaded successfully from local");
        } catch (FileException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PostMapping("/drive")
    public ResponseEntity<String> uploadGoogleDriveFile(@RequestParam String fileId, @RequestParam Long userId) throws IOException {
        log.info("Request received at uploadGoogleDriveFile controller for userId {}", userId);
        try {
            ByteArrayOutputStream outputStream = downloadService.downloadFile(fileId);
            String originalFileName = downloadService.getFileName(fileId);
            downloadService.saveFile(outputStream, originalFileName, "application/octet-stream", userId);
            return ResponseEntity.status(HttpStatus.CREATED).body("File uploaded successfully from drive");
        } catch (FileException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @GetMapping("/search")
    public ResponseEntity<List<File>> searchFiles(@RequestParam String keyword, @RequestParam Long userId) {
        log.info("Request received at searchFiles controller for userId {}", userId);
        List<File> files = fileService.searchFiles(keyword, userId);
        return ResponseEntity.ok(files);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<File>> getFilesByUserId(@PathVariable Long userId) {
        log.info("Request received at getFilesByUserId controller for userId {}", userId);
        List<File> files = fileService.findByUserId(userId);
        return ResponseEntity.ok(files);
    }

    @GetMapping("/{id}")
    public ResponseEntity<File> getFileById(@PathVariable String id) {
        log.info("Request received at getFileById controller for file id {}", id);
        File file = fileService.findById(id);
        if (file != null) {
            return ResponseEntity.ok(file);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/resource")
    public ResponseEntity<Resource> getFileResource(HttpServletRequest httpRequest, @RequestParam String filepath) {
        return fileService.getFileResource(httpRequest, filepath);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFile(@PathVariable String id) {
        log.info("Request received at deleteFile controller for file id {}", id);
        File file = fileService.findById(id);
        if (file == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("File not found");
        }

        fileService.deleteFile(id);
        return ResponseEntity.status(HttpStatus.OK).body("Deleted a file");
    }
}
