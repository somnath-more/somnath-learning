create table IF NOT EXISTS `contiq`.`user` (
	`id` bigint not null auto_increment,
    `name` varchar(254) not null,
    `email` varchar(254) not null,
    `password` varchar(254) not null,
    `notification_count` bigint default 0 not null ,
    primary key(`id`),
    unique key `email` (`email`)
)engine=InnoDB auto_increment=1 DEFAULT CHARSET=latin1;