package com.contiq.userservice.config;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.contiq.userservice.utils.AppConstants.USER_FILTER_URL;

@Configuration
public class FilterConfig {

    @Bean
    public FilterRegistrationBean jwtFilter() {
        FilterRegistrationBean filter= new FilterRegistrationBean();
        filter.setFilter(new JwtFilter());
        filter.addUrlPatterns(USER_FILTER_URL);
        filter.addInitParameter("exclusions", "/api/v1/users/*");
        return filter;
    }
}