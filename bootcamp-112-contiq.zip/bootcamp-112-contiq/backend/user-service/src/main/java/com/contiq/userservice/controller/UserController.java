package com.contiq.userservice.controller;

import com.contiq.userservice.config.JwtGeneratorInterface;
import com.contiq.userservice.dto.LoginUserDTO;
import com.contiq.userservice.dto.UserDTO;
import com.contiq.userservice.entity.UserEntity;
import com.contiq.userservice.exception.UserNotFound;
import com.contiq.userservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Map;

import static com.contiq.userservice.utils.AppConstants.BASE_URL;
import static com.contiq.userservice.utils.AppConstants.EMAIL;
import static com.contiq.userservice.utils.AppConstants.UPDATE_NOTIFICATION;
import static com.contiq.userservice.utils.AppConstants.RESET_PASSWORD;

@RestController
@Slf4j
@RequestMapping(BASE_URL)
public class UserController {

	private final UserService userService;

	@Autowired
	public UserController(UserService userService) {
		this.userService = userService;
	}

	@Autowired
	private JwtGeneratorInterface jwtGenerator;

	@GetMapping
	public ResponseEntity<List<UserDTO>> getAll() {
		log.info("Request received at getAllUsers.");
		return ResponseEntity.ok(userService.findAll());
	}

	@GetMapping(EMAIL)
	public ResponseEntity<UserDTO> getByEmail(@PathVariable String email) {
		log.info("Request received at getByEmail.");
		return ResponseEntity.ok(userService.findByEmail(email));
	}

	@PostMapping
	public ResponseEntity<UserDTO> create(@RequestBody UserDTO userDTO) {
		log.info("Request received at createUser.");
		return ResponseEntity.status(HttpStatus.CREATED).body(userService.save(userDTO));
	}

	@PatchMapping(UPDATE_NOTIFICATION)
	public ResponseEntity<UserDTO> updateNotificationCount(
			@PathVariable int id,
			@RequestBody Map<String, Object> updates) {
		log.info("Request received at updateNotificationCount.");
		return ResponseEntity.ok(userService.updateNotificationCount(id, updates));
	}

	@PatchMapping(RESET_PASSWORD)
	public ResponseEntity<UserDTO> updatePassword(
			@PathVariable int id,
			@RequestBody Map<String, Object> updates) {
		log.info("Request received at updatePassword.");
		return ResponseEntity.ok(userService.updatePassword(id, updates));
	}

	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody LoginUserDTO loginUserDTO) {
		try {
			if(loginUserDTO.getEmail() == null || loginUserDTO.getPassword() == null) {
				throw new UserNotFound("UserName or Password is Empty");
			}
			UserEntity userData = userService.getUserByEmailAndPassword(loginUserDTO.getEmail(), loginUserDTO.getPassword());
			if(userData == null){
				throw new UserNotFound("UserName or Password is Invalid");
			}
			return new ResponseEntity<>(jwtGenerator.generateToken(loginUserDTO), HttpStatus.OK);
		} catch (UserNotFound e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}
}
