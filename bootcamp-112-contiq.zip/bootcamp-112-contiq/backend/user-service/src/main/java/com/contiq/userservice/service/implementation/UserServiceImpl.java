package com.contiq.userservice.service.implementation;

import com.contiq.userservice.dto.UserDTO;
import com.contiq.userservice.entity.UserEntity;
import com.contiq.userservice.exception.UserNotFound;
import com.contiq.userservice.mapper.UserMapper;
import com.contiq.userservice.repository.UserRepository;

import java.util.List;

import com.contiq.userservice.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;

@Slf4j
@Service
public class 	UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserMapper userMapper;
	
	
	@Override
	public List<UserDTO> findAll() {
		log.info("Inside Service findAllUser():");
		List<UserEntity> userEntityList = userRepository.findAll();
		return userEntityList.stream()
				.map(userMapper::entityToDTO)
				.toList();
	}
	
	@Override
	public UserDTO findByEmail(String email) {
		log.info("Inside Service findByEmail():");
		Optional<UserEntity> result = userRepository.findByEmail(email);
		if (result.isPresent()) {
			UserEntity userEntity = result.get();
			return userMapper.entityToDTO(userEntity);
		} else {
			throw new UserNotFound("User with email not found: " + email);
		}
	}
	
	
	@Override
	public UserDTO save(UserDTO userDTO) {
		log.info("Inside Service saveUser():");
		return userMapper.entityToDTO(userRepository.save(userMapper.dtoToEntity(userDTO)));
	}
	
	@Override
	public UserDTO updateNotificationCount(int id, Map<String, Object> userUpdates) {
		log.info("Inside Service updateNotificationCount():");
		Optional<UserEntity> result = userRepository.findById(id);
		if (result.isPresent()) {
			UserEntity userEntity = result.get();
			if (userUpdates.containsKey("notificationCount")) {
				int newNotificationCount = (int) userUpdates.get("notificationCount");
				userEntity.setNotificationCount(newNotificationCount);
			}
			return userMapper.entityToDTO(userRepository.save(userEntity));
		} else {
			throw new UserNotFound("Did not find User id: " + id);
		}
	}
	
	
	@Override
	public UserDTO updatePassword(int id, Map<String, Object> userUpdates) {
		log.info("Inside Service updatePassword():");
		Optional<UserEntity> result = userRepository.findById(id);
		if (result.isPresent()) {
			UserEntity userEntity = result.get();
			if (userUpdates.containsKey("password")) {
				String newPassword = (String) userUpdates.get("password");
				userEntity.setPassword(newPassword);
			}
			return userMapper.entityToDTO(userRepository.save(userEntity));
		} else {
			throw new UserNotFound("Did not find User id: " + id);
		}
	}

	@Override
	public UserEntity getUserByEmailAndPassword(String email, String password) throws UserNotFound {
		Optional<UserEntity> user = userRepository.findByEmailAndPassword(email,password);
		if(user.isEmpty()){
			throw new UserNotFound("Invalid email and password");
		}
		return user.get();
	}
}
