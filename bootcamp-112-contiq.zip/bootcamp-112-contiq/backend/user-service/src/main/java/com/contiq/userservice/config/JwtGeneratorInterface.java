package com.contiq.userservice.config;
import com.contiq.userservice.dto.LoginUserDTO;

import java.util.Map;

public interface JwtGeneratorInterface {
    Map<String, String> generateToken(LoginUserDTO loginUserDTO);

}

