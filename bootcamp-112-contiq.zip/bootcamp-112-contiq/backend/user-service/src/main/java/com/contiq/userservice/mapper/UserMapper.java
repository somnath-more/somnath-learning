package com.contiq.userservice.mapper;

import com.contiq.userservice.dto.UserDTO;
import com.contiq.userservice.entity.UserEntity;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

public class UserMapper {
	
	@Autowired
	ModelMapper modelMapper;
	
	public UserEntity dtoToEntity(UserDTO userDTO){
		return modelMapper.map(userDTO, UserEntity.class);
	}
	
	public UserDTO entityToDTO(UserEntity userEntity){
		return modelMapper.map(userEntity, UserDTO.class);
	}
}
