package com.contiq.userservice.service;

import com.contiq.userservice.dto.UserDTO;
import com.contiq.userservice.entity.UserEntity;

import java.util.List;
import java.util.Map;

public interface UserService {
	List<UserDTO> findAll();
	UserDTO findByEmail(String email);
	UserDTO save(UserDTO User);
	UserDTO updateNotificationCount(int id, Map<String, Object> User);
	UserDTO updatePassword(int id, Map<String, Object> User);

	UserEntity getUserByEmailAndPassword(String email, String password);
}
