package com.contiq.userservice.service;

import com.contiq.userservice.dto.UserDTO;
import com.contiq.userservice.entity.UserEntity;
import com.contiq.userservice.exception.UserNotFound;
import com.contiq.userservice.mapper.UserMapper;
import com.contiq.userservice.repository.UserRepository;
import com.contiq.userservice.service.implementation.UserServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;


import java.util.Arrays;
import java.util.List;
import java.util.HashMap;
import java.util.Optional;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceImpTest {

	@Mock
	private UserRepository userRepository;

	@Mock
	private UserMapper userMapper;

	@InjectMocks
	private UserServiceImpl userService;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testFindAll_ReturnsListOfUserDTOs() {
		List<UserEntity> userEntityList = Arrays.asList(
				new UserEntity(1, "Majahar","majahar@gmail.com","Test@123",0),
				new UserEntity(2, "Majahar","majahar@gmail.com","Test@123",0)
		);

		List<UserDTO> userDTOList = Arrays.asList(
				new UserDTO(1,"Majahar","majahar@gmail.com","Test@123",0),
				new UserDTO(2,"Majahar","majahar@gmail.com","Test@123",0)
		);

		when(userRepository.findAll()).thenReturn(userEntityList);
		when(userMapper.entityToDTO(any(UserEntity.class)))
				.thenReturn(userDTOList.get(0), userDTOList.get(1));

		List<UserDTO> result = userService.findAll();

		assertEquals(userDTOList.size(), result.size());

		for (int i = 0; i < userDTOList.size(); i++) {
			UserDTO expectedDTO = userDTOList.get(i);
			UserDTO actualDTO = result.get(i);
			
			assertEquals(expectedDTO.getName(), actualDTO.getName());
		}
	}
	
	@Test
	void testFindByEmailExistingUser() {
		
		String email = "test@example.com";
		UserEntity userEntity = new UserEntity();
		when(userRepository.findByEmail(email)).thenReturn(Optional.of(userEntity));
		when(userMapper.entityToDTO(userEntity)).thenReturn(new UserDTO());
		
		UserDTO userDTO = userService.findByEmail(email);
		
		assertNotNull(userDTO);
		verify(userRepository, times(1)).findByEmail(email);
		verify(userMapper, times(1)).entityToDTO(userEntity);
	}
	
	
	@Test
	void testFindByEmailNonExistingUser() {
		
		String email = "nonexistent@example.com";
		when(userRepository.findByEmail(email)).thenReturn(Optional.empty());
		
		assertThrows(UserNotFound.class, () -> userService.findByEmail(email));
		verify(userRepository, times(1)).findByEmail(email);
	}
	@Test
	void testSave_CreatesUser() {
		UserDTO newUserDTO = new UserDTO(3, "New User","newuser@example.com","NewPass@123",0);
		UserEntity newUserEntity = new UserEntity(3, "New User","newuser@example.com","NewPass@123",0);

		when(userMapper.dtoToEntity(newUserDTO)).thenReturn(newUserEntity);
		when(userMapper.entityToDTO(newUserEntity)).thenReturn(newUserDTO);
		when(userRepository.save(newUserEntity)).thenReturn(newUserEntity);

		UserDTO savedUserDTO = userService.save(newUserDTO);

		assertEquals(newUserDTO, savedUserDTO);
	}
	
	@Test
	void testUpdateNotificationCount_Success() {
		int userId = 1;
		int newNotificationCount = 10;

		UserEntity userEntity = new UserEntity();
		userEntity.setId(userId);
		userEntity.setNotificationCount(5);

		Map<String, Object> userUpdates = new HashMap<>();
		userUpdates.put("notificationCount", newNotificationCount);


		when(userRepository.findById(userId)).thenReturn(Optional.of(userEntity));
		when(userRepository.save(any(UserEntity.class))).thenReturn(userEntity);
		UserDTO userDTO = new UserDTO();
		userDTO.setNotificationCount(newNotificationCount);
		when(userMapper.entityToDTO(userEntity)).thenReturn(userDTO);
		
		UserDTO updatedUser = userService.updateNotificationCount(userId, userUpdates);

		assertEquals(newNotificationCount, updatedUser.getNotificationCount());
	}
	
	@Test
	void testUpdatePassword_Success() {
		int userId = 1;
		String newPassword = "newPassword123";

		UserEntity userEntity = new UserEntity();
		userEntity.setId(userId);
		userEntity.setPassword("oldPassword");

		Map<String, Object> userUpdates = new HashMap<>();
		userUpdates.put("password", newPassword);

		when(userRepository.findById(userId)).thenReturn(Optional.of(userEntity));
		when(userRepository.save(any(UserEntity.class))).thenReturn(userEntity);
		UserDTO userDTO = new UserDTO();
		userDTO.setPassword(newPassword);
		when(userMapper.entityToDTO(userEntity)).thenReturn(userDTO);
		
		UserDTO updatedUser = userService.updatePassword(userId, userUpdates);

		assertEquals(newPassword, updatedUser.getPassword());
	}

	@Test
	void testUpdateNotificationCount_UserNotFound() {
		int userId = 1;
		Map<String, Object> userUpdates = new HashMap<>();
		userUpdates.put("notificationCount", 10);
		
		when(userRepository.findById(userId)).thenReturn(Optional.empty());
		
		assertThrows(UserNotFound.class, () -> userService.updateNotificationCount(userId, userUpdates));
		verify(userRepository).findById(userId);
		verify(userRepository, never()).save(any(UserEntity.class));
	}
	
	@Test
	void testUpdatePassword_UserNotFound() {
		int userId = 1;
		Map<String, Object> userUpdates = new HashMap<>();
		userUpdates.put("password", "newPassword123");
		
		when(userRepository.findById(userId)).thenReturn(Optional.empty());
		
		assertThrows(UserNotFound.class, () -> userService.updatePassword(userId, userUpdates));
		verify(userRepository).findById(userId);
		verify(userRepository, never()).save(any(UserEntity.class));
	}

	@Test
	void testGetUserByEmailAndPasswordValid() throws UserNotFound {
		UserEntity userEntity = new UserEntity();
		userEntity.setEmail("test@example.com");
		userEntity.setPassword("password123");
		when(userRepository.findByEmailAndPassword("test@example.com", "password123"))
				.thenReturn(Optional.of(userEntity));
		UserEntity result = userService.getUserByEmailAndPassword("test@example.com", "password123");
		assertNotNull(result);
		assertEquals("test@example.com", result.getEmail());
		assertEquals("password123", result.getPassword());
	}

	@Test
	void testGetUserByEmailAndPasswordInvalid() {
		when(userRepository.findByEmailAndPassword("invalid@example.com", "invalidpassword"))
				.thenReturn(Optional.empty());
		assertThrows(UserNotFound.class, () -> userService.getUserByEmailAndPassword("invalid@example.com", "invalidpassword"));
	}
}
