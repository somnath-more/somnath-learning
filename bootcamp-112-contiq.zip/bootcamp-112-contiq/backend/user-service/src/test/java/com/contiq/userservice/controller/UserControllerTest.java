package com.contiq.userservice.controller;

import com.contiq.userservice.dto.LoginUserDTO;
import com.contiq.userservice.dto.UserDTO;
import com.contiq.userservice.service.UserService;
import com.contiq.userservice.config.JwtGeneratorInterface;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
class UserControllerTest {
	
	@Mock
	private UserService userService;
	
	@InjectMocks
	private UserController userController;

	@Mock
	private JwtGeneratorInterface jwtGenerator;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void testGetAll_ReturnsListOfUserDTOs() {
		List<UserDTO> userDTOList = Arrays.asList(
				new UserDTO(1, "Majahar", "majahar@gmail.com", "Test@123", 0),
				new UserDTO(2,"Shridhar", "shridhar@gmail.com", "Test@123", 0)
		);
		
		when(userService.findAll()).thenReturn(userDTOList);
		
		ResponseEntity<List<UserDTO>> response = userController.getAll();
		
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(userDTOList, response.getBody());
	}
	
	@Test
	void testGetByEmail_WithValidEmail_ReturnsUserDTO() {
		String userEmail = "majahar@gmail.com";
		UserDTO userDTO = new UserDTO(1, "Majahar", userEmail, "Test@123", 0);
		
		when(userService.findByEmail(userEmail)).thenReturn(userDTO);
		
		ResponseEntity<UserDTO> response = userController.getByEmail(userEmail);
		
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(userDTO, response.getBody());
	}
	
	@Test
	void testCreate_ReturnsCreatedUserDTO() {
		UserDTO userDTO = new UserDTO(1,"Majahar", "majahar@gmail.com", "Test@123", 0);
		
		when(userService.save(userDTO)).thenReturn(userDTO);
		
		ResponseEntity<UserDTO> response = userController.create(userDTO);
		
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertEquals(userDTO, response.getBody());
	}
	
	@Test
	void testUpdateNotificationCount_ReturnsUpdatedUserDTO() {
		int userId = 1;
		Map<String, Object> updates = new HashMap<>();
		updates.put("notificationCount", 1);
		
		UserDTO updatedUserDTO = new UserDTO(userId, "Majahar", "majahar@gmail.com", "Test@123", 1);
		
		when(userService.updateNotificationCount(userId, updates)).thenReturn(updatedUserDTO);
		
		ResponseEntity<UserDTO> response = userController.updateNotificationCount(userId, updates);
		
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(updatedUserDTO, response.getBody());
	}
	
	@Test
	void testUpdatePassword_ReturnsUpdatedUserDTO() {
		int userId = 1;
		Map<String, Object> updates = new HashMap<>();
		updates.put("password", "NewPassword123");
		
		UserDTO updatedUserDTO = new UserDTO(userId, "Majahar", "majahar@gmail.com", "NewPassword123", 0);
		
		when(userService.updatePassword(userId, updates)).thenReturn(updatedUserDTO);
		
		ResponseEntity<UserDTO> response = userController.updatePassword(userId, updates);
		
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals(updatedUserDTO, response.getBody());
	}

	@Test
	void testLoginUser_EmptyUsernameOrPassword() {
		LoginUserDTO loginUserDTO = new LoginUserDTO();
		loginUserDTO.setEmail(null);
		loginUserDTO.setPassword(null);

		ResponseEntity<?> response = userController.loginUser(loginUserDTO);

		assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
		assertEquals("UserName or Password is Empty", response.getBody());
		verify(userService, never()).getUserByEmailAndPassword(anyString(), anyString());
		verify(jwtGenerator, never()).generateToken(any(LoginUserDTO.class));
	}

	@Test
	void testLoginUser_InvalidUsernameOrPassword() {
		LoginUserDTO loginUserDTO = new LoginUserDTO();
		loginUserDTO.setEmail("test@example.com");
		loginUserDTO.setPassword("password");

		when(userService.getUserByEmailAndPassword(loginUserDTO.getEmail(), loginUserDTO.getPassword())).thenReturn(null);

		ResponseEntity<?> response = userController.loginUser(loginUserDTO);

		assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
		assertEquals("UserName or Password is Invalid", response.getBody());
		verify(userService, times(1)).getUserByEmailAndPassword(loginUserDTO.getEmail(), loginUserDTO.getPassword());
		verify(jwtGenerator, never()).generateToken(any(LoginUserDTO.class));
	}
}
